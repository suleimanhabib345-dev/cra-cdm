
import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Users from "./pages/Users";
import Agents from "./pages/Agents";
import AIAgents from "./pages/AIAgents";
import Incidents from "./pages/Incidents";
import Reports from "./pages/Reports";
import ScannerTools from "./pages/tools/Scanner";
import ForensicsTools from "./pages/tools/Forensics";
import ADScanTools from "./pages/tools/ADScan";
import CloudScanTools from "./pages/tools/CloudScan";
import WebScanTools from "./pages/tools/WebScan";
import CICDScanTools from "./pages/tools/CICDScan";
import AllDevices from "./pages/devices/AllDevices";
import DeviceGroups from "./pages/devices/DeviceGroups";
import InactiveDevices from "./pages/devices/InactiveDevices";
import Transactions from "./pages/devices/Transactions";
import PortEvents from "./pages/events/PortEvents";
import ManageUsers from "./pages/manage/Users";
import ManageGroups from "./pages/manage/Groups";
import Filetree from "./pages/Filetree";
import DownloadAgents from "./pages/DownloadAgents";
import License from "./pages/License";
import Company from "./pages/Company";
import Settings from "./pages/Settings";
import Logout from "./pages/Logout";
import SoftwareHistory from "./pages/SoftwareHistory";
import Vulnerabilities from "./pages/Vulnerabilities";
import AcceptInvite from "./pages/AcceptInvite";
import AuthGuard from "./components/AuthGuard";
import ErrorBoundary from "./components/ErrorBoundary";

const queryClient = new QueryClient();

const App = () => {
  return (
    <React.StrictMode>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AuthGuard>
              <ErrorBoundary>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/vulnerabilities" element={<Vulnerabilities />} />
                <Route path="/users" element={<Users />} />
                <Route path="/agents" element={<Agents />} />
                <Route path="/ai-agents" element={<AIAgents />} />
                <Route path="/incidents" element={<Incidents />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/software-history" element={<SoftwareHistory />} />
                <Route path="/tools/scanner" element={<ScannerTools />} />
                <Route path="/tools/forensics" element={<ForensicsTools />} />
                <Route path="/tools/adscan" element={<ADScanTools />} />
                <Route path="/tools/cloudscan" element={<CloudScanTools />} />
                <Route path="/tools/webscan" element={<WebScanTools />} />
                <Route path="/tools/cicd" element={<CICDScanTools />} />
                <Route path="/devices/all" element={<AllDevices />} />
                <Route path="/devices/inactive" element={<InactiveDevices />} />
                <Route path="/devices/groups" element={<DeviceGroups />} />
                <Route path="/devices/transactions" element={<Transactions />} />
                <Route path="/events/ports" element={<PortEvents />} />
                <Route path="/manage/users" element={<ManageUsers />} />
                <Route path="/manage/groups" element={<ManageGroups />} />
                <Route path="/filetree" element={<Filetree />} />
                <Route path="/download-agents" element={<DownloadAgents />} />
                <Route path="/license" element={<License />} />
                <Route path="/company" element={<Company />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/logout" element={<Logout />} />
                <Route path="/auth/accept-invite" element={<AcceptInvite />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
              </ErrorBoundary>
            </AuthGuard>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </React.StrictMode>
  );
};

export default App;
