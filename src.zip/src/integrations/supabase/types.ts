export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      agent_tokens: {
        Row: {
          agent_id: string
          created_at: string
          expires_at: string | null
          revoked: boolean
          token: string
        }
        Insert: {
          agent_id: string
          created_at?: string
          expires_at?: string | null
          revoked?: boolean
          token: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          expires_at?: string | null
          revoked?: boolean
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_tokens_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      agents: {
        Row: {
          created_at: string
          hostname: string
          id: string
          ip_address: string | null
          last_seen: string | null
          platform: string | null
          status: string | null
          updated_at: string
          version: string | null
        }
        Insert: {
          created_at?: string
          hostname: string
          id?: string
          ip_address?: string | null
          last_seen?: string | null
          platform?: string | null
          status?: string | null
          updated_at?: string
          version?: string | null
        }
        Update: {
          created_at?: string
          hostname?: string
          id?: string
          ip_address?: string | null
          last_seen?: string | null
          platform?: string | null
          status?: string | null
          updated_at?: string
          version?: string | null
        }
        Relationships: []
      }
      certificates: {
        Row: {
          agent_id: string
          certificate_name: string | null
          created_at: string
          detected_at: string
          file_path: string | null
          id: string
          is_expired: boolean | null
          is_self_signed: boolean | null
          issuer: string | null
          key_algorithm: string | null
          key_size: number | null
          serial_number: string | null
          signature_algorithm: string | null
          store_location: string | null
          store_name: string | null
          subject: string | null
          thumbprint: string | null
          updated_at: string
          usage: string[] | null
          valid_from: string | null
          valid_to: string | null
        }
        Insert: {
          agent_id: string
          certificate_name?: string | null
          created_at?: string
          detected_at?: string
          file_path?: string | null
          id?: string
          is_expired?: boolean | null
          is_self_signed?: boolean | null
          issuer?: string | null
          key_algorithm?: string | null
          key_size?: number | null
          serial_number?: string | null
          signature_algorithm?: string | null
          store_location?: string | null
          store_name?: string | null
          subject?: string | null
          thumbprint?: string | null
          updated_at?: string
          usage?: string[] | null
          valid_from?: string | null
          valid_to?: string | null
        }
        Update: {
          agent_id?: string
          certificate_name?: string | null
          created_at?: string
          detected_at?: string
          file_path?: string | null
          id?: string
          is_expired?: boolean | null
          is_self_signed?: boolean | null
          issuer?: string | null
          key_algorithm?: string | null
          key_size?: number | null
          serial_number?: string | null
          signature_algorithm?: string | null
          store_location?: string | null
          store_name?: string | null
          subject?: string | null
          thumbprint?: string | null
          updated_at?: string
          usage?: string[] | null
          valid_from?: string | null
          valid_to?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "certificates_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          account_type: string
          address: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          id: string
          license_expires: string | null
          license_key: string | null
          name: string
          updated_at: string
        }
        Insert: {
          account_type?: string
          address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          license_expires?: string | null
          license_key?: string | null
          name: string
          updated_at?: string
        }
        Update: {
          account_type?: string
          address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          license_expires?: string | null
          license_key?: string | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      device_vulnerabilities: {
        Row: {
          agent_id: string
          created_at: string
          detected_at: string
          device_id: string
          id: string
          patched_at: string | null
          status: string | null
          updated_at: string
          vulnerability_id: string
        }
        Insert: {
          agent_id: string
          created_at?: string
          detected_at?: string
          device_id: string
          id?: string
          patched_at?: string | null
          status?: string | null
          updated_at?: string
          vulnerability_id: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          detected_at?: string
          device_id?: string
          id?: string
          patched_at?: string | null
          status?: string | null
          updated_at?: string
          vulnerability_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "device_vulnerabilities_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "device_vulnerabilities_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "device_vulnerabilities_vulnerability_id_fkey"
            columns: ["vulnerability_id"]
            isOneToOne: false
            referencedRelation: "vulnerabilities"
            referencedColumns: ["id"]
          },
        ]
      }
      devices: {
        Row: {
          agent_version: string | null
          company_id: string | null
          created_at: string
          group_id: string | null
          hostname: string
          id: string
          ip_address: string | null
          last_seen: string | null
          mac_address: string | null
          os_version: string | null
          platform: string | null
          status: Database["public"]["Enums"]["device_status"] | null
          updated_at: string
        }
        Insert: {
          agent_version?: string | null
          company_id?: string | null
          created_at?: string
          group_id?: string | null
          hostname: string
          id?: string
          ip_address?: string | null
          last_seen?: string | null
          mac_address?: string | null
          os_version?: string | null
          platform?: string | null
          status?: Database["public"]["Enums"]["device_status"] | null
          updated_at?: string
        }
        Update: {
          agent_version?: string | null
          company_id?: string | null
          created_at?: string
          group_id?: string | null
          hostname?: string
          id?: string
          ip_address?: string | null
          last_seen?: string | null
          mac_address?: string | null
          os_version?: string | null
          platform?: string | null
          status?: Database["public"]["Enums"]["device_status"] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "devices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "devices_hostname_fkey"
            columns: ["hostname"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["hostname"]
          },
          {
            foreignKeyName: "devices_hostname_fkey"
            columns: ["hostname"]
            isOneToOne: false
            referencedRelation: "vulnerability_details"
            referencedColumns: ["hostname"]
          },
        ]
      }
      environment_variables: {
        Row: {
          agent_id: string
          created_at: string
          detected_at: string
          id: string
          is_sensitive: boolean | null
          updated_at: string
          value_length: number | null
          variable_name: string
          variable_scope: string | null
          variable_value_hash: string | null
        }
        Insert: {
          agent_id: string
          created_at?: string
          detected_at?: string
          id?: string
          is_sensitive?: boolean | null
          updated_at?: string
          value_length?: number | null
          variable_name: string
          variable_scope?: string | null
          variable_value_hash?: string | null
        }
        Update: {
          agent_id?: string
          created_at?: string
          detected_at?: string
          id?: string
          is_sensitive?: boolean | null
          updated_at?: string
          value_length?: number | null
          variable_name?: string
          variable_scope?: string | null
          variable_value_hash?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "environment_variables_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      file_permissions: {
        Row: {
          acl: Json | null
          agent_id: string
          created_at: string
          detected_at: string
          file_path: string
          file_size: number | null
          file_type: string | null
          group_owner: string | null
          id: string
          is_sensitive: boolean | null
          modified_at: string | null
          owner: string | null
          permissions: string | null
          permissions_octal: string | null
          updated_at: string
        }
        Insert: {
          acl?: Json | null
          agent_id: string
          created_at?: string
          detected_at?: string
          file_path: string
          file_size?: number | null
          file_type?: string | null
          group_owner?: string | null
          id?: string
          is_sensitive?: boolean | null
          modified_at?: string | null
          owner?: string | null
          permissions?: string | null
          permissions_octal?: string | null
          updated_at?: string
        }
        Update: {
          acl?: Json | null
          agent_id?: string
          created_at?: string
          detected_at?: string
          file_path?: string
          file_size?: number | null
          file_type?: string | null
          group_owner?: string | null
          id?: string
          is_sensitive?: boolean | null
          modified_at?: string | null
          owner?: string | null
          permissions?: string | null
          permissions_octal?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "file_permissions_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      firewall_rules: {
        Row: {
          action: string | null
          agent_id: string
          created_at: string
          destination_address: string | null
          destination_port: string | null
          detected_at: string
          direction: string | null
          id: string
          interface: string | null
          is_enabled: boolean | null
          profile: string | null
          protocol: string | null
          rule_name: string
          rule_number: number | null
          source_address: string | null
          source_port: string | null
          updated_at: string
        }
        Insert: {
          action?: string | null
          agent_id: string
          created_at?: string
          destination_address?: string | null
          destination_port?: string | null
          detected_at?: string
          direction?: string | null
          id?: string
          interface?: string | null
          is_enabled?: boolean | null
          profile?: string | null
          protocol?: string | null
          rule_name: string
          rule_number?: number | null
          source_address?: string | null
          source_port?: string | null
          updated_at?: string
        }
        Update: {
          action?: string | null
          agent_id?: string
          created_at?: string
          destination_address?: string | null
          destination_port?: string | null
          detected_at?: string
          direction?: string | null
          id?: string
          interface?: string | null
          is_enabled?: boolean | null
          profile?: string | null
          protocol?: string | null
          rule_name?: string
          rule_number?: number | null
          source_address?: string | null
          source_port?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "firewall_rules_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      license_assignments: {
        Row: {
          agent_id: string
          assigned_at: string
          id: string
          license_id: string
        }
        Insert: {
          agent_id: string
          assigned_at?: string
          id?: string
          license_id: string
        }
        Update: {
          agent_id?: string
          assigned_at?: string
          id?: string
          license_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "license_assignments_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "license_assignments_license_id_fkey"
            columns: ["license_id"]
            isOneToOne: false
            referencedRelation: "licenses"
            referencedColumns: ["id"]
          },
        ]
      }
      licenses: {
        Row: {
          company_id: string
          created_at: string
          date_created: string
          device_id: string | null
          expiration_date: string
          hostname: string | null
          id: string
          is_active: boolean | null
          license_key: string
          updated_at: string
          volume: number
        }
        Insert: {
          company_id: string
          created_at?: string
          date_created?: string
          device_id?: string | null
          expiration_date: string
          hostname?: string | null
          id?: string
          is_active?: boolean | null
          license_key: string
          updated_at?: string
          volume: number
        }
        Update: {
          company_id?: string
          created_at?: string
          date_created?: string
          device_id?: string | null
          expiration_date?: string
          hostname?: string | null
          id?: string
          is_active?: boolean | null
          license_key?: string
          updated_at?: string
          volume?: number
        }
        Relationships: [
          {
            foreignKeyName: "licenses_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "licenses_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "devices"
            referencedColumns: ["id"]
          },
        ]
      }
      network_connections: {
        Row: {
          agent_id: string
          created_at: string
          detected_at: string
          id: string
          local_address: string | null
          local_port: number | null
          process_id: number | null
          process_name: string | null
          protocol: string | null
          remote_address: string | null
          remote_port: number | null
          state: string | null
          user: string | null
        }
        Insert: {
          agent_id: string
          created_at?: string
          detected_at?: string
          id?: string
          local_address?: string | null
          local_port?: number | null
          process_id?: number | null
          process_name?: string | null
          protocol?: string | null
          remote_address?: string | null
          remote_port?: number | null
          state?: string | null
          user?: string | null
        }
        Update: {
          agent_id?: string
          created_at?: string
          detected_at?: string
          id?: string
          local_address?: string | null
          local_port?: number | null
          process_id?: number | null
          process_name?: string | null
          protocol?: string | null
          remote_address?: string | null
          remote_port?: number | null
          state?: string | null
          user?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "network_connections_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      nvd_scan_history: {
        Row: {
          company_id: string | null
          completed_at: string | null
          created_at: string
          error_message: string | null
          id: string
          initiated_by: string | null
          scanned_software: number
          started_at: string
          status: string
          total_software: number
          vulnerabilities_found: number
        }
        Insert: {
          company_id?: string | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          initiated_by?: string | null
          scanned_software?: number
          started_at?: string
          status?: string
          total_software?: number
          vulnerabilities_found?: number
        }
        Update: {
          company_id?: string | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          initiated_by?: string | null
          scanned_software?: number
          started_at?: string
          status?: string
          total_software?: number
          vulnerabilities_found?: number
        }
        Relationships: [
          {
            foreignKeyName: "nvd_scan_history_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "nvd_scan_history_initiated_by_fkey"
            columns: ["initiated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      port_events: {
        Row: {
          address: string | null
          agent_id: string
          family: string | null
          id: string
          pid: number | null
          port_number: number
          process_name: string | null
          protocol: string
          service: string | null
          socket: string | null
          status: string
          timestamp: string
        }
        Insert: {
          address?: string | null
          agent_id: string
          family?: string | null
          id?: string
          pid?: number | null
          port_number: number
          process_name?: string | null
          protocol: string
          service?: string | null
          socket?: string | null
          status: string
          timestamp?: string
        }
        Update: {
          address?: string | null
          agent_id?: string
          family?: string | null
          id?: string
          pid?: number | null
          port_number?: number
          process_name?: string | null
          protocol?: string
          service?: string | null
          socket?: string | null
          status?: string
          timestamp?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_port_events_agent_id"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "port_events_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          company_id: string | null
          created_at: string
          email: string
          first_name: string | null
          id: string
          last_name: string | null
          role: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          company_id?: string | null
          created_at?: string
          email: string
          first_name?: string | null
          id: string
          last_name?: string | null
          role?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          company_id?: string | null
          created_at?: string
          email?: string
          first_name?: string | null
          id?: string
          last_name?: string | null
          role?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduled_tasks: {
        Row: {
          agent_id: string
          command: string | null
          created_at: string
          detected_at: string
          id: string
          is_enabled: boolean | null
          last_result: string | null
          last_run: string | null
          next_run: string | null
          schedule: string | null
          script_path: string | null
          task_name: string
          task_type: string | null
          updated_at: string
          user: string | null
        }
        Insert: {
          agent_id: string
          command?: string | null
          created_at?: string
          detected_at?: string
          id?: string
          is_enabled?: boolean | null
          last_result?: string | null
          last_run?: string | null
          next_run?: string | null
          schedule?: string | null
          script_path?: string | null
          task_name: string
          task_type?: string | null
          updated_at?: string
          user?: string | null
        }
        Update: {
          agent_id?: string
          command?: string | null
          created_at?: string
          detected_at?: string
          id?: string
          is_enabled?: boolean | null
          last_result?: string | null
          last_run?: string | null
          next_run?: string | null
          schedule?: string | null
          script_path?: string | null
          task_name?: string
          task_type?: string | null
          updated_at?: string
          user?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "scheduled_tasks_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      security_policies: {
        Row: {
          agent_id: string
          created_at: string
          description: string | null
          detected_at: string
          expected_value: string | null
          id: string
          is_compliant: boolean | null
          policy_category: string | null
          policy_name: string
          policy_setting: string | null
          severity: string | null
          updated_at: string
        }
        Insert: {
          agent_id: string
          created_at?: string
          description?: string | null
          detected_at?: string
          expected_value?: string | null
          id?: string
          is_compliant?: boolean | null
          policy_category?: string | null
          policy_name: string
          policy_setting?: string | null
          severity?: string | null
          updated_at?: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          description?: string | null
          detected_at?: string
          expected_value?: string | null
          id?: string
          is_compliant?: boolean | null
          policy_category?: string | null
          policy_name?: string
          policy_setting?: string | null
          severity?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "security_policies_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      software_history: {
        Row: {
          created_at: string
          current_version: string | null
          device_id: string
          id: string
          installed_date: string | null
          previous_version: string | null
          software_name: string
          updated_at: string
          updated_date: string | null
        }
        Insert: {
          created_at?: string
          current_version?: string | null
          device_id: string
          id?: string
          installed_date?: string | null
          previous_version?: string | null
          software_name: string
          updated_at?: string
          updated_date?: string | null
        }
        Update: {
          created_at?: string
          current_version?: string | null
          device_id?: string
          id?: string
          installed_date?: string | null
          previous_version?: string | null
          software_name?: string
          updated_at?: string
          updated_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "software_history_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      system_groups: {
        Row: {
          agent_id: string
          created_at: string
          description: string | null
          detected_at: string
          group_id: string | null
          group_name: string
          group_type: string | null
          id: string
          is_builtin: boolean | null
          members: string[] | null
          updated_at: string
        }
        Insert: {
          agent_id: string
          created_at?: string
          description?: string | null
          detected_at?: string
          group_id?: string | null
          group_name: string
          group_type?: string | null
          id?: string
          is_builtin?: boolean | null
          members?: string[] | null
          updated_at?: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          description?: string | null
          detected_at?: string
          group_id?: string | null
          group_name?: string
          group_type?: string | null
          id?: string
          is_builtin?: boolean | null
          members?: string[] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "system_groups_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      system_processes: {
        Row: {
          agent_id: string
          command_line: string | null
          cpu_percent: number | null
          created_at: string
          detected_at: string
          executable_path: string | null
          id: string
          memory_mb: number | null
          parent_process_id: number | null
          process_id: number
          process_name: string
          start_time: string | null
          status: string | null
          user: string | null
        }
        Insert: {
          agent_id: string
          command_line?: string | null
          cpu_percent?: number | null
          created_at?: string
          detected_at?: string
          executable_path?: string | null
          id?: string
          memory_mb?: number | null
          parent_process_id?: number | null
          process_id: number
          process_name: string
          start_time?: string | null
          status?: string | null
          user?: string | null
        }
        Update: {
          agent_id?: string
          command_line?: string | null
          cpu_percent?: number | null
          created_at?: string
          detected_at?: string
          executable_path?: string | null
          id?: string
          memory_mb?: number | null
          parent_process_id?: number | null
          process_id?: number
          process_name?: string
          start_time?: string | null
          status?: string | null
          user?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "system_processes_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      system_services: {
        Row: {
          agent_id: string
          binary_path: string | null
          created_at: string
          dependencies: string[] | null
          description: string | null
          detected_at: string
          display_name: string | null
          id: string
          service_name: string
          startup_type: string | null
          status: string | null
          updated_at: string
          user_account: string | null
        }
        Insert: {
          agent_id: string
          binary_path?: string | null
          created_at?: string
          dependencies?: string[] | null
          description?: string | null
          detected_at?: string
          display_name?: string | null
          id?: string
          service_name: string
          startup_type?: string | null
          status?: string | null
          updated_at?: string
          user_account?: string | null
        }
        Update: {
          agent_id?: string
          binary_path?: string | null
          created_at?: string
          dependencies?: string[] | null
          description?: string | null
          detected_at?: string
          display_name?: string | null
          id?: string
          service_name?: string
          startup_type?: string | null
          status?: string | null
          updated_at?: string
          user_account?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "system_services_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      system_users: {
        Row: {
          agent_id: string
          created_at: string
          description: string | null
          detected_at: string
          full_name: string | null
          groups: string[] | null
          home_directory: string | null
          id: string
          is_admin: boolean | null
          is_enabled: boolean | null
          is_locked: boolean | null
          last_login: string | null
          password_expires: string | null
          password_last_set: string | null
          shell: string | null
          updated_at: string
          user_id: string | null
          username: string
        }
        Insert: {
          agent_id: string
          created_at?: string
          description?: string | null
          detected_at?: string
          full_name?: string | null
          groups?: string[] | null
          home_directory?: string | null
          id?: string
          is_admin?: boolean | null
          is_enabled?: boolean | null
          is_locked?: boolean | null
          last_login?: string | null
          password_expires?: string | null
          password_last_set?: string | null
          shell?: string | null
          updated_at?: string
          user_id?: string | null
          username: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          description?: string | null
          detected_at?: string
          full_name?: string | null
          groups?: string[] | null
          home_directory?: string | null
          id?: string
          is_admin?: boolean | null
          is_enabled?: boolean | null
          is_locked?: boolean | null
          last_login?: string | null
          password_expires?: string | null
          password_last_set?: string | null
          shell?: string | null
          updated_at?: string
          user_id?: string | null
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "system_users_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      vulnerabilities: {
        Row: {
          affected_software: string[] | null
          cpe_match: string | null
          created_at: string
          cve_id: string | null
          cvss_score: number | null
          cvss_vector: string | null
          description: string | null
          fix_available: boolean | null
          id: string
          published_date: string | null
          reference_urls: string[] | null
          severity: Database["public"]["Enums"]["vulnerability_severity"]
          title: string
          updated_at: string
        }
        Insert: {
          affected_software?: string[] | null
          cpe_match?: string | null
          created_at?: string
          cve_id?: string | null
          cvss_score?: number | null
          cvss_vector?: string | null
          description?: string | null
          fix_available?: boolean | null
          id?: string
          published_date?: string | null
          reference_urls?: string[] | null
          severity: Database["public"]["Enums"]["vulnerability_severity"]
          title: string
          updated_at?: string
        }
        Update: {
          affected_software?: string[] | null
          cpe_match?: string | null
          created_at?: string
          cve_id?: string | null
          cvss_score?: number | null
          cvss_vector?: string | null
          description?: string | null
          fix_available?: boolean | null
          id?: string
          published_date?: string | null
          reference_urls?: string[] | null
          severity?: Database["public"]["Enums"]["vulnerability_severity"]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      windows_kb_updates: {
        Row: {
          agent_id: string
          classification: string | null
          created_at: string
          description: string | null
          detected_at: string
          id: string
          install_date: string | null
          is_mandatory: boolean | null
          kb_number: string
          requires_reboot: boolean | null
          status: string | null
          superseded_by: string[] | null
          title: string | null
          updated_at: string
        }
        Insert: {
          agent_id: string
          classification?: string | null
          created_at?: string
          description?: string | null
          detected_at?: string
          id?: string
          install_date?: string | null
          is_mandatory?: boolean | null
          kb_number: string
          requires_reboot?: boolean | null
          status?: string | null
          superseded_by?: string[] | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          agent_id?: string
          classification?: string | null
          created_at?: string
          description?: string | null
          detected_at?: string
          id?: string
          install_date?: string | null
          is_mandatory?: boolean | null
          kb_number?: string
          requires_reboot?: boolean | null
          status?: string | null
          superseded_by?: string[] | null
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "windows_kb_updates_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      vulnerability_details: {
        Row: {
          detected_at: string | null
          hostname: string | null
          ip_address: string | null
          patched_at: string | null
          platform: string | null
          severity: string | null
          status: string | null
          vulnerability_description: string | null
          vulnerability_id: string | null
          vulnerability_title: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      archive_old_network_connections: {
        Args: { retention_days?: number }
        Returns: number
      }
      archive_old_port_events: {
        Args: { retention_days?: number }
        Returns: number
      }
      archive_old_processes: {
        Args: { retention_days?: number }
        Returns: number
      }
      get_unique_platforms: { Args: never; Returns: Json[] }
      get_vulnerability_counts: { Args: never; Returns: Json[] }
      verify_agent_token: { Args: { token_value: string }; Returns: string }
    }
    Enums: {
      device_status: "active" | "inactive" | "maintenance"
      vulnerability_severity: "critical" | "high" | "medium" | "low"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      device_status: ["active", "inactive", "maintenance"],
      vulnerability_severity: ["critical", "high", "medium", "low"],
    },
  },
} as const
