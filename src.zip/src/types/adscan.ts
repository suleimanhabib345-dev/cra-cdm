export type ScanSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export type ScanStatus = 'idle' | 'connecting' | 'running' | 'completed' | 'error';

export type ScanCategory =
  | 'Password Policy'
  | 'Privileged Accounts'
  | 'Kerberos'
  | 'Delegation'
  | 'ADCS / PKI'
  | 'Domain Trusts'
  | 'Account Hygiene'
  | 'Protocol Security'
  | 'Group Policy'
  | 'LAPS'
  | 'DNS & Infrastructure'
  | 'Domain Controllers'
  | 'ACL / Permissions'
  | 'Optional Features'
  | 'Replication'
  | 'Service Accounts'
  | 'Hardening'
  | 'Deprecated OS'
  | 'Legacy Protocols'
  | 'Exchange'
  | 'Protected Admins'
  | 'Credential Exposure'
  | 'Shadow Credentials'
  | 'SID History'
  | 'RBCD';

export interface Finding {
  id: string;
  category: ScanCategory;
  title: string;
  severity: ScanSeverity;
  description: string;
  details: string[];
  recommendation: string;
  riskScore: number;
  references: string[];
}

export interface ScanStats {
  totalChecks: number;
  completedChecks: number;
  findingsCount: Record<ScanSeverity, number>;
  riskScore: number;
  riskLevel: string;
  lapsConverage: number;
  deprecatedOsCount: number;
  unconstrainedDelegation: number;
  adminCountAccounts: number;
  kerberoastableAccounts: number;
  staleAccounts: number;
}

export interface ScanConfig {
  domain: string;
  username: string;
  password: string;
  hash: string;
  authMethod: 'password' | 'hash';
  dcIp: string;
  useLdaps: boolean;
  selectedChecks: string[];
}

export interface ScanResult {
  id: string;
  domain: string;
  dcIp: string;
  scanTime: string;
  status: ScanStatus;
  findings: Finding[];
  stats: ScanStats;
}

export interface TerminalLine {
  id: number;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'system' | 'check';
  message: string;
}

export interface GraphNode {
  id: string;
  label: string;
  type: 'user' | 'group' | 'computer' | 'domain' | 'gpo' | 'ou' | 'dc';
  x: number;
  y: number;
  vx: number;
  vy: number;
  severity?: ScanSeverity;
  details?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  label: string;
  type: 'memberOf' | 'adminTo' | 'hasSession' | 'canRDP' | 'delegation' | 'trust' | 'gpLink' | 'attackPath';
}

export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export const SCAN_MODULES = [
  {
    id: 'identity',
    title: 'Identity & Access',
    description: 'User accounts, privileges, and access control analysis',
    checks: [
      { id: 'password_policy', name: 'Password Policy', description: 'Minimum length, complexity, lockout settings' },
      { id: 'privileged_accounts', name: 'Privileged Accounts', description: 'Domain/Enterprise/Schema Admins audit' },
      { id: 'account_hygiene', name: 'Account Hygiene', description: 'Stale users, PASSWD_NOTREQD, old passwords' },
      { id: 'service_accounts', name: 'Service Accounts', description: 'gMSA adoption, adminCount, SPNs' },
      { id: 'protected_admins', name: 'Protected Admin Users', description: 'adminCount=1 inventory and orphan detection' },
      { id: 'passwords_in_desc', name: 'Credential Exposure', description: 'Passwords in descriptions and GPP cpasswords' },
    ],
  },
  {
    id: 'kerberos',
    title: 'Kerberos & Authentication',
    description: 'Kerberos protocol security and authentication weaknesses',
    checks: [
      { id: 'kerberoasting', name: 'Kerberoasting', description: 'Accounts with SPNs vulnerable to offline cracking' },
      { id: 'asrep_roasting', name: 'AS-REP Roasting', description: 'Pre-auth disabled accounts' },
      { id: 'rc4_encryption', name: 'Legacy Encryption', description: 'RC4-HMAC and DES-only encryption types' },
      { id: 'sid_history', name: 'SID History', description: 'SID history entries enabling privilege escalation' },
      { id: 'shadow_creds', name: 'Shadow Credentials', description: 'msDS-KeyCredentialLink certificate-based auth' },
    ],
  },
  {
    id: 'delegation',
    title: 'Delegation & Trusts',
    description: 'Kerberos delegation and domain trust analysis',
    checks: [
      { id: 'unconstrained_deleg', name: 'Unconstrained Delegation', description: 'Non-DC computers with unconstrained delegation' },
      { id: 'constrained_deleg', name: 'Constrained Delegation', description: 'Protocol transition and target analysis' },
      { id: 'rbcd', name: 'RBCD', description: 'Resource-based constrained delegation on DCs' },
      { id: 'dangerous_deleg', name: 'Dangerous Targets', description: 'Delegation to high-value service classes' },
      { id: 'domain_trusts', name: 'Domain Trusts', description: 'Bidirectional trusts without SID filtering' },
    ],
  },
  {
    id: 'certificates',
    title: 'Certificates & PKI',
    description: 'Active Directory Certificate Services security',
    checks: [
      { id: 'adcs_templates', name: 'ADCS Templates', description: 'ESC1-15 template vulnerability detection' },
      { id: 'ca_config', name: 'CA Configuration', description: 'Certificate Authority settings audit' },
      { id: 'weak_keys', name: 'Weak Key Sizes', description: 'Templates with weak cryptographic key sizes' },
      { id: 'enrollee_acl', name: 'Enrollment ACLs', description: 'Enrollee permissions on certificate templates' },
    ],
  },
  {
    id: 'infrastructure',
    title: 'Infrastructure & Protocol',
    description: 'Network protocols, GPOs, and infrastructure security',
    checks: [
      { id: 'ldap_signing', name: 'LDAP Signing', description: 'LDAP signing and channel binding enforcement' },
      { id: 'smb_security', name: 'SMB Security', description: 'SMBv1 detection, signing, null sessions' },
      { id: 'gpo_health', name: 'GPO Health', description: 'Disabled, orphaned, unlinked GPOs' },
      { id: 'laps', name: 'LAPS Coverage', description: 'Local Admin Password Solution deployment' },
      { id: 'dns_infra', name: 'DNS Infrastructure', description: 'Wildcard records, LLMNR/NetBIOS guidance' },
      { id: 'dc_health', name: 'Domain Controllers', description: 'Single-DC, legacy OS, FSMO, RODC policy' },
    ],
  },
  {
    id: 'hardening',
    title: 'Hardening & Compliance',
    description: 'Miscellaneous hardening and compliance checks',
    checks: [
      { id: 'deprecated_os', name: 'Deprecated OS', description: 'End-of-life operating systems in use' },
      { id: 'optional_features', name: 'Optional Features', description: 'AD Recycle Bin, PAM status' },
      { id: 'replication', name: 'Replication Health', description: 'Sites, site links, replication intervals' },
      { id: 'exchange', name: 'Exchange Security', description: 'PrivExchange and CVE-2019-0686 exposure' },
      { id: 'pre_win2k', name: 'Pre-Win2K Access', description: 'Anonymous/Everyone in compatible access group' },
      { id: 'admin_sdholder', name: 'AdminSDHolder ACL', description: 'Non-privileged write ACEs on AdminSDHolder' },
    ],
  },
  {
    id: 'cve_detection',
    title: 'CVE Detection & Coercion',
    description: 'Critical CVE detection, NTLM coercion, relay mitigations, and GPO abuse',
    checks: [
      { id: 'zerologon', name: 'ZeroLogon (CVE-2020-1472)', description: 'Unpatched DCs vulnerable to Netlogon RPC attack' },
      { id: 'nopac', name: 'NoPac (CVE-2021-42278/42287)', description: 'sAMAccountName spoofing + KDC confusion' },
      { id: 'printnightmare', name: 'PrintNightmare (CVE-2021-1675)', description: 'Print Spooler RCE on domain controllers' },
      { id: 'coercion', name: 'NTLM Coercion', description: 'PetitPotam, SpoolSample, DFSCoerce attack surface' },
      { id: 'ntlm_relay', name: 'NTLM Relay Config', description: 'LDAP signing, SMB signing, channel binding' },
      { id: 'gpo_abuse', name: 'GPO Permission Abuse', description: 'Non-privileged write access to domain-linked GPOs' },
      { id: 'transitive_priv', name: 'Transitive Privilege', description: 'Indirect admin access via nested group chains' },
    ],
  },
] as const;

export const QUICK_ACCESS_CHECKS = [
  { id: 'password_policy', name: 'Password Policy', icon: 'KeyRound' },
  { id: 'kerberoasting', name: 'Kerberos', icon: 'Ticket' },
  { id: 'unconstrained_deleg', name: 'Delegation', icon: 'GitBranch' },
  { id: 'adcs_templates', name: 'ADCS/PKI', icon: 'ShieldCheck' },
  { id: 'domain_trusts', name: 'Trusts', icon: 'Link' },
  { id: 'account_hygiene', name: 'Hygiene', icon: 'UserCheck' },
] as const;
