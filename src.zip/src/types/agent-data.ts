// TypeScript type definitions for agent data collection

// System Groups
export interface SystemGroup {
  id: string;
  agent_id: string;
  group_name: string;
  group_id: string | null;
  group_type: string | null;
  members: string[] | null;
  description: string | null;
  is_builtin: boolean;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// System Users
export interface SystemUser {
  id: string;
  agent_id: string;
  username: string;
  user_id: string | null;
  full_name: string | null;
  description: string | null;
  home_directory: string | null;
  shell: string | null;
  is_admin: boolean;
  is_enabled: boolean;
  is_locked: boolean;
  password_last_set: string | null;
  password_expires: string | null;
  last_login: string | null;
  groups: string[] | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// File Permissions
export interface FilePermission {
  id: string;
  agent_id: string;
  file_path: string;
  file_type: string | null;
  owner: string | null;
  group_owner: string | null;
  permissions: string | null;
  permissions_octal: string | null;
  acl: any | null;
  is_sensitive: boolean;
  file_size: number | null;
  modified_at: string | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// Windows KB Updates
export interface WindowsKBUpdate {
  id: string;
  agent_id: string;
  kb_number: string;
  title: string | null;
  description: string | null;
  classification: string | null;
  install_date: string | null;
  status: string | null;
  is_mandatory: boolean;
  requires_reboot: boolean;
  superseded_by: string[] | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// System Processes
export interface SystemProcess {
  id: string;
  agent_id: string;
  process_id: number;
  process_name: string;
  executable_path: string | null;
  command_line: string | null;
  parent_process_id: number | null;
  user: string | null;
  cpu_percent: number | null;
  memory_mb: number | null;
  start_time: string | null;
  status: string | null;
  detected_at: string;
  created_at: string;
}

// Network Connections
export interface NetworkConnection {
  id: string;
  agent_id: string;
  local_address: string | null;
  local_port: number | null;
  remote_address: string | null;
  remote_port: number | null;
  protocol: string | null;
  state: string | null;
  process_id: number | null;
  process_name: string | null;
  user: string | null;
  detected_at: string;
  created_at: string;
}

// Scheduled Tasks
export interface ScheduledTask {
  id: string;
  agent_id: string;
  task_name: string;
  task_type: string | null;
  schedule: string | null;
  command: string | null;
  script_path: string | null;
  user: string | null;
  is_enabled: boolean;
  last_run: string | null;
  next_run: string | null;
  last_result: string | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// Security Policies
export interface SecurityPolicy {
  id: string;
  agent_id: string;
  policy_category: string | null;
  policy_name: string;
  policy_setting: string | null;
  expected_value: string | null;
  is_compliant: boolean | null;
  severity: string | null;
  description: string | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// Firewall Rules
export interface FirewallRule {
  id: string;
  agent_id: string;
  rule_name: string;
  rule_number: number | null;
  direction: string | null;
  action: string | null;
  protocol: string | null;
  source_address: string | null;
  source_port: string | null;
  destination_address: string | null;
  destination_port: string | null;
  interface: string | null;
  is_enabled: boolean;
  profile: string | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// System Services
export interface SystemService {
  id: string;
  agent_id: string;
  service_name: string;
  display_name: string | null;
  description: string | null;
  status: string | null;
  startup_type: string | null;
  user_account: string | null;
  binary_path: string | null;
  dependencies: string[] | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// Certificates
export interface Certificate {
  id: string;
  agent_id: string;
  certificate_name: string | null;
  subject: string | null;
  issuer: string | null;
  serial_number: string | null;
  thumbprint: string | null;
  valid_from: string | null;
  valid_to: string | null;
  is_expired: boolean;
  is_self_signed: boolean;
  key_algorithm: string | null;
  key_size: number | null;
  signature_algorithm: string | null;
  store_location: string | null;
  store_name: string | null;
  file_path: string | null;
  usage: string[] | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}

// Environment Variables
export interface EnvironmentVariable {
  id: string;
  agent_id: string;
  variable_name: string;
  variable_value_hash: string | null;
  variable_scope: string | null;
  is_sensitive: boolean;
  value_length: number | null;
  detected_at: string;
  created_at: string;
  updated_at: string;
}
