export type CloudProvider = 'aws' | 'azure' | 'gcp';

export type CloudScanStatus = 'idle' | 'connecting' | 'enumerating' | 'analyzing' | 'completed' | 'error';

export type CloudSeverity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export type AttackPathCategory =
  | 'privilege_escalation'
  | 'trust_misconfiguration'
  | 'data_exposure'
  | 'credential_risk'
  | 'network_exposure'
  | 'persistence'
  | 'lateral_movement'
  | 'permission_misconfiguration';

export type CloudNodeType = 'user' | 'role' | 'group' | 'escalation' | 'data' | 'external' | 'service' | 'network';

export type CloudEdgeType = 'priv_esc' | 'trust' | 'data_access' | 'network' | 'service' | 'public_access' | 'cross_account' | 'membership';

export interface CloudScanConfig {
  provider: CloudProvider;
  awsProfile: string;
  accessKeyId: string;
  secretAccessKey: string;
  sessionToken: string;
  authMethod: 'profile' | 'keys' | 'sso';
  regions: string[];
  selectedModules: string[];
  accountId: string;
  // AI provider — optional, enables SCOPE Phase 4 analysis
  aiEnabled?: boolean;
  aiProvider?: string;
  aiApiKey?: string;
  aiModel?: string;
  aiBaseUrl?: string;
  // Which SCOPE agents to run (undefined = all four)
  selectedAgents?: string[];
}

export interface AttackPath {
  id: string;
  name: string;
  severity: CloudSeverity;
  category: AttackPathCategory;
  description: string;
  exploitability: 'trivial' | 'easy' | 'moderate' | 'difficult';
  steps: string[];
  mitreTechniques: string[];
  detectionOpportunities: string[];
  remediation: string[];
  affectedResources: string[];
}

export interface CloudFinding {
  id: string;
  resourceType: string;
  resourceId: string;
  arn: string;
  region: string;
  service: string;
  severity: CloudSeverity;
  title: string;
  description: string;
  remediation: string;
}

export interface TrustRelationship {
  roleId: string;
  roleArn: string;
  principal: string;
  trustType: 'cross-account' | 'same-account' | 'service' | 'federated';
  isWildcard: boolean;
  hasExternalId: boolean;
  hasMfaCondition: boolean;
  risk: CloudSeverity;
  isInternal: boolean;
}

export interface CloudScanSummary {
  totalUsers: number;
  totalRoles: number;
  totalPolicies: number;
  totalTrustRelationships: number;
  criticalPrivEscRisks: number;
  wildcardTrustPolicies: number;
  crossAccountTrusts: number;
  usersWithoutMfa: number;
  riskScore: CloudSeverity;
  servicesAnalyzed: number;
  pathsByCategory: Record<string, number>;
  reachability: {
    principalsWithAdminReach: number;
    principalsWithDataReach: number;
    maxBlastRadiusPrincipal: string;
    maxBlastRadiusNodes: number;
    avgHopCount: number;
  };
}

export interface CloudGraphNode {
  id: string;
  label: string;
  type: CloudNodeType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  severity?: CloudSeverity;
  details?: string;
  service?: string;
}

export interface CloudGraphEdge {
  source: string;
  target: string;
  edgeType: CloudEdgeType;
  severity?: CloudSeverity;
  label: string;
}

export interface CloudGraphData {
  nodes: CloudGraphNode[];
  edges: CloudGraphEdge[];
}

export interface CloudScanResult {
  id: string;
  accountId: string;
  provider: CloudProvider;
  scanTime: string;
  status: CloudScanStatus;
  summary: CloudScanSummary;
  graph: CloudGraphData;
  attackPaths: AttackPath[];
  findings: CloudFinding[];
  trustRelationships: TrustRelationship[];
}

export interface EnumModuleStatus {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'complete' | 'partial' | 'error';
  findingsCount: number;
}

export const CLOUD_PROVIDERS: { id: CloudProvider; name: string; icon: string; enabled: boolean }[] = [
  { id: 'aws', name: 'Amazon Web Services', icon: 'aws', enabled: true },
  { id: 'azure', name: 'Microsoft Azure', icon: 'azure', enabled: false },
  { id: 'gcp', name: 'Google Cloud Platform', icon: 'gcp', enabled: false },
];

export const AWS_SCAN_MODULES = [
  {
    id: 'identity',
    title: 'Identity & Access Management',
    description: 'Users, roles, groups, policies, trust relationships, and credential state',
    services: [
      { id: 'iam', name: 'IAM', description: 'Users, roles, policies, MFA, access keys, trust relationships' },
      { id: 'sts', name: 'STS', description: 'Identity federation, assumed roles, session tokens' },
    ],
  },
  {
    id: 'storage',
    title: 'Storage & Data Protection',
    description: 'Bucket policies, encryption, access controls, and secret management',
    services: [
      { id: 's3', name: 'S3', description: 'Bucket policies, ACLs, public access, encryption, logging' },
      { id: 'kms', name: 'KMS', description: 'Key policies, rotation, grants, cross-account access' },
      { id: 'secrets', name: 'Secrets Manager', description: 'Secret policies, rotation, access control' },
    ],
  },
  {
    id: 'compute',
    title: 'Compute & Serverless',
    description: 'Instance security, function permissions, and execution roles',
    services: [
      { id: 'ec2', name: 'EC2', description: 'Instances, security groups, EBS, VPC, SSM' },
      { id: 'lambda', name: 'Lambda', description: 'Functions, layers, permissions, execution roles, env vars' },
      { id: 'codebuild', name: 'CodeBuild', description: 'Build projects, IAM roles, VPC config, artifacts' },
    ],
  },
  {
    id: 'database',
    title: 'Database & Messaging',
    description: 'Database security, queue policies, and topic access control',
    services: [
      { id: 'rds', name: 'RDS', description: 'Database instances, authentication, network isolation' },
      { id: 'sns', name: 'SNS', description: 'Topic policies, subscriptions, access control' },
      { id: 'sqs', name: 'SQS', description: 'Queue policies, attributes, dead-letter queues' },
    ],
  },
  {
    id: 'network',
    title: 'Network & API',
    description: 'API security, resource policies, and authentication methods',
    services: [
      { id: 'apigateway', name: 'API Gateway', description: 'APIs, stages, resource policies, auth methods' },
    ],
  },
] as const;

export const AWS_REGIONS = [
  'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
  'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1', 'eu-north-1',
  'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1', 'ap-northeast-2', 'ap-south-1',
  'sa-east-1', 'ca-central-1', 'me-south-1', 'af-south-1',
] as const;

export const CATEGORY_LABELS: Record<AttackPathCategory, string> = {
  privilege_escalation: 'Privilege Escalation',
  trust_misconfiguration: 'Trust Misconfiguration',
  data_exposure: 'Data Exposure',
  credential_risk: 'Credential Risk',
  network_exposure: 'Network Exposure',
  persistence: 'Persistence',
  lateral_movement: 'Lateral Movement',
  permission_misconfiguration: 'Permission Misconfiguration',
};
