import type { TerminalLine } from './adscan';

// ── Scan Configuration ──────────────────────────────────────────────────────

export type WebScanStatus =
  | 'idle'
  | 'connecting'
  | 'crawling'
  | 'auditing'
  | 'completed'
  | 'error'
  | 'cancelled';

export type WebScanType = 'full' | 'quick' | 'api' | 'passive' | 'authenticated';

export interface WebScanConfig {
  targetUrl: string;
  scanType: WebScanType;
  maxDepth: number;
  maxPages: number;
  agentId: string | null;
  providerId: string | null;
  headless: boolean;
  followRedirects: boolean;
  includeSubdomains: boolean;
  customHeaders?: Record<string, string>;
  authConfig?: AuthConfig;
  excludePatterns?: string[];
}

export interface AuthConfig {
  type: 'basic' | 'bearer' | 'cookie' | 'form' | 'oauth2';
  credentials: Record<string, string>;
}

// ── AI Provider / Model ─────────────────────────────────────────────────────

export type AIProviderType = 'openai' | 'anthropic' | 'openrouter' | 'groq' | 'gemini' | 'custom';

export interface AIProviderConfig {
  id: string;
  name: string;
  type: AIProviderType;
  apiKey: string;
  model: string;
  baseUrl?: string;
  maxTokens?: number;
  temperature?: number;
}

export const DEFAULT_MODELS: Record<AIProviderType, string[]> = {
  openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'o3-mini'],
  anthropic: ['claude-sonnet-4-6', 'claude-opus-4-6', 'claude-haiku-4-5-20251001'],
  openrouter: [
    'anthropic/claude-sonnet-4-6',
    'openai/gpt-4o',
    'meta-llama/llama-3.3-70b-instruct',
    'google/gemini-2.0-flash-001',
    'deepseek/deepseek-chat',
  ],
  groq: [
    'llama-3.3-70b-versatile',
    'llama-3.1-8b-instant',
    'mixtral-8x7b-32768',
    'gemma2-9b-it',
  ],
  gemini: ['gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-1.5-pro'],
  custom: [],
};

// ── Agent Types (pulled from the AI Agents module) ──────────────────────────

export interface WebScanAgent {
  id: string;
  name: string;
  description: string;
  type: string;
  status: 'idle' | 'executing' | 'inactive' | 'error';
  capabilities: string[];
}

// ── Browser & Crawl State ───────────────────────────────────────────────────

export interface BrowserState {
  currentUrl: string;
  pageTitle: string;
  screenshotUrl: string | null;
  viewportWidth: number;
  viewportHeight: number;
  isNavigating: boolean;
  interactiveElements: InteractiveElement[];
}

export interface InteractiveElement {
  id: string;
  tag: string;
  type?: string;
  text: string;
  selector: string;
  attributes: Record<string, string>;
  bbox?: { x: number; y: number; width: number; height: number };
}

export interface CrawlNode {
  url: string;
  title: string;
  depth: number;
  status: 'pending' | 'visiting' | 'visited' | 'error';
  statusCode?: number;
  contentType?: string;
  responseTime?: number;
  parentUrl?: string;
  links: string[];
}

export interface CrawlGraph {
  nodes: CrawlNode[];
  totalUrls: number;
  visitedUrls: number;
  errorUrls: number;
}

// ── MCP Tool Call Tracking ──────────────────────────────────────────────────

export interface MCPToolCall {
  id: string;
  timestamp: string;
  tool: string;
  params: Record<string, unknown>;
  result?: unknown;
  duration?: number;
  status: 'pending' | 'running' | 'success' | 'error';
}

// ── Findings ────────────────────────────────────────────────────────────────

export type WebVulnSeverity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export interface WebVulnerability {
  id: string;
  title: string;
  severity: WebVulnSeverity;
  cvss: number;
  cwe?: string;
  endpoint: string;
  method: string;
  parameter?: string;
  description: string;
  evidence?: string;
  remediation: string;
  references?: string[];
  screenshot?: string;
  request?: string;
  response?: string;
  affectedEndpoints?: string[];
}

// ── Scan Results ────────────────────────────────────────────────────────────

export interface WebScanSummary {
  totalUrls: number;
  scannedUrls: number;
  totalFindings: number;
  severityCounts: Record<WebVulnSeverity, number>;
  riskScore: number;
  scanDuration: number;
  technologiesDetected: string[];
}

export interface WebScanResult {
  id: string;
  config: WebScanConfig;
  status: WebScanStatus;
  startTime: string;
  endTime?: string;
  summary: WebScanSummary;
  vulnerabilities: WebVulnerability[];
  crawlGraph: CrawlGraph;
  toolCalls: MCPToolCall[];
}

// ── Scan History ────────────────────────────────────────────────────────────

export interface WebScanHistoryEntry {
  id: string;
  url: string;
  date: string;
  findings: number;
  severities: Record<WebVulnSeverity, number>;
  status: WebScanStatus;
  scanType: WebScanType;
  agent: string;
  duration: string;
  vulnerabilities?: WebVulnerability[];
  terminalLines?: TerminalLine[];
  toolCalls?: MCPToolCall[];
}

// ── WebSocket Events ────────────────────────────────────────────────────────

export type WSEventType =
  | 'terminal'
  | 'browser_state'
  | 'screenshot'
  | 'crawl_progress'
  | 'finding'
  | 'tool_call'
  | 'status'
  | 'error';

export interface WSEvent {
  type: WSEventType;
  data: unknown;
  timestamp: string;
}

export { TerminalLine };
