
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';

export type Device = {
  id: string;
  hostname: string;
  ip_address?: string;
  mac_address?: string;
  platform?: string;
  os_version?: string;
  group_id?: string;
  status?: string;
  last_seen?: string;
  created_at: string;
  updated_at: string;
};

export type DeviceGroup = {
  id: string;
  name: string;
  description?: string;
  created_at: string;
  updated_at: string;
  device_count?: number;
};

type DeviceGroupWithCounts = {
  id: string;
  name: string;
  description: string;
  created_at: string;
  updated_at: string;
  company_id: string;
  device_count: number;
};

export const useDevicesData = () => {
  const { user } = useAuth();

  // Fetch all agents (treating them as devices), filtered by company
  const {
    data: agentsData,
    isLoading: isAgentsLoading,
    error: agentsError,
    refetch: refetchAgents
  } = useQuery({
    queryKey: ['agents', user?.id],
    queryFn: async () => {
      // Get user's company_id and role
      let companyId: string | null = null;
      let isSuperAdmin = false;
      if (user?.id) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('company_id, role')
          .eq('id', user.id)
          .single();
        companyId = profile?.company_id || null;
        isSuperAdmin = profile?.role === 'super_admin';
      }

      let query = supabase
        .from('agents')
        .select('*')
        .order('hostname');

      if (!isSuperAdmin) {
        if (!companyId) return [] as Device[];
        query = query.eq('company_id', companyId);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Map agents to device format for compatibility
      return data.map(agent => ({
        id: agent.id,
        hostname: agent.hostname,
        ip_address: agent.ip_address,
        platform: agent.platform,
        status: agent.status,
        last_seen: agent.last_seen,
        created_at: agent.created_at,
        updated_at: agent.updated_at,
        mac_address: undefined,
        os_version: undefined,
        group_id: undefined
      })) as Device[];
    },
    enabled: !!user
  });

  // Fetch device groups with counts (keep for compatibility)
  const {
    data: groupsData,
    isLoading: isGroupsLoading,
    error: groupsError,
    refetch: refetchGroups
  } = useQuery({
    queryKey: ['device_groups'],
    queryFn: async () => {
      const { data, error } = await supabase
        .rpc('get_device_groups_with_counts');
      
      if (error) throw error;
      return data as DeviceGroupWithCounts[];
    }
  });

  // Setup realtime subscription for agents
  useEffect(() => {
    const agentsChannel = supabase
      .channel('agents-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'agents' },
        () => {
          refetchAgents();
        }
      )
      .subscribe();

    const groupsChannel = supabase
      .channel('device-groups-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'device_groups' },
        () => {
          refetchGroups();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(agentsChannel);
      supabase.removeChannel(groupsChannel);
    };
  }, [refetchAgents, refetchGroups]);

  // Create device categories from platform data (agents)
  const deviceCategories = agentsData && agentsData.length > 0 ? 
    Object.entries(
      agentsData.reduce((acc, agent) => {
        const platformType = agent.platform?.toLowerCase() || 'unknown';
        acc[platformType] = (acc[platformType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    ).map(([name, count]) => ({
      id: name,
      name: name.charAt(0).toUpperCase() + name.slice(1),
      count
    })) : [];

  // Get inactive devices - devices with "inactive" status AND not seen in last 24 hours
  const inactiveDevices = agentsData ? 
    agentsData.filter(agent => {
      const hasInactiveStatus = agent.status?.toLowerCase() === 'inactive';
      const lastSeenDate = agent.last_seen ? new Date(agent.last_seen) : null;
      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const notSeenRecently = !lastSeenDate || lastSeenDate < twentyFourHoursAgo;
      
      return hasInactiveStatus && notSeenRecently;
    }) : [];

  console.log('All agents:', agentsData?.length);
  console.log('Inactive devices (status = inactive AND not seen in 24h):', inactiveDevices.length);

  return {
    devices: agentsData || [],
    deviceGroups: groupsData || [],
    deviceCategories,
    inactiveDevices,
    isLoading: isAgentsLoading || isGroupsLoading,
    error: agentsError || groupsError,
    refetchDevices: refetchAgents,
    refetchGroups
  };
};
