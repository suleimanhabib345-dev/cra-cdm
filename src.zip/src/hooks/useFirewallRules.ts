import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { FirewallRule } from '@/types/agent-data';

export const useFirewallRules = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['firewall_rules', agentId] : ['firewall_rules'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('firewall_rules')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as FirewallRule[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('firewall-rules-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'firewall_rules' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
