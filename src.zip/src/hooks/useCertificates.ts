import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { Certificate } from '@/types/agent-data';

export const useCertificates = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['certificates', agentId] : ['certificates'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('certificates')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as Certificate[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('certificates-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'certificates' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
