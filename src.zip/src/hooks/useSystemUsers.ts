import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { SystemUser } from '@/types/agent-data';

export const useSystemUsers = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['system_users', agentId] : ['system_users'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('system_users')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as SystemUser[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('system-users-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'system_users' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
