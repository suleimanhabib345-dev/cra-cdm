import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { SystemGroup } from '@/types/agent-data';

export const useSystemGroups = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['system_groups', agentId] : ['system_groups'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('system_groups')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as SystemGroup[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('system-groups-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'system_groups' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
