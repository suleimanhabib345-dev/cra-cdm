
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { usePortEvents } from './usePortEvents';
import { usePortStatusDevices } from './usePortStatusDevices';

export type { PortEvent } from './usePortEvents';
export type { PortStatusDevice } from './usePortStatusDevices';

export const usePortEventsData = () => {
  const { 
    data: portEvents, 
    isLoading: isPortEventsLoading,
    error: portEventsError,
    refetch: refetchPortEvents
  } = usePortEvents();

  const { 
    data: portStatusDevices, 
    isLoading: isPortStatusLoading,
    error: portStatusError,
    refetch: refetchPortStatus
  } = usePortStatusDevices();

  // Log data for debugging
  useEffect(() => {
    if (portEvents) {
      console.log('Port events loaded:', portEvents.length);
    }
    if (portStatusDevices) {
      console.log('Port status devices loaded:', portStatusDevices.length);
      const totalPorts = portStatusDevices.reduce((sum, device) => sum + device.ports.length, 0);
      console.log('Total ports across all devices:', totalPorts);
    }
  }, [portEvents, portStatusDevices]);

  // Setup realtime subscription for port events
  useEffect(() => {
    const portEventsChannel = supabase
      .channel('port-events-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'port_events' },
        (payload) => {
          console.log('Port events real-time update:', payload);
          refetchPortEvents();
          refetchPortStatus();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(portEventsChannel);
    };
  }, [refetchPortEvents, refetchPortStatus]);

  return {
    portEvents: portEvents || [],
    portStatusDevices: portStatusDevices || [],
    isLoading: isPortEventsLoading || isPortStatusLoading,
    error: portEventsError || portStatusError,
    refetchPortEvents,
    refetchPortStatus
  };
};
