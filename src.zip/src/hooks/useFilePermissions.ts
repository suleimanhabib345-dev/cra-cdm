import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { FilePermission } from '@/types/agent-data';

export const useFilePermissions = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['file_permissions', agentId] : ['file_permissions'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('file_permissions')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as FilePermission[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('file-permissions-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'file_permissions' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
