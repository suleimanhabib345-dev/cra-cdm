import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { SystemProcess } from '@/types/agent-data';

export const useSystemProcesses = (agentId?: string, limit: number = 1000) => {
  const query = useQuery({
    queryKey: agentId ? ['system_processes', agentId, limit] : ['system_processes', limit],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('system_processes')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false })
        .limit(limit);

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as SystemProcess[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('system-processes-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'system_processes' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
