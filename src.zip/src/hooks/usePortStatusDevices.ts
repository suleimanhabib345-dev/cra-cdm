
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { PortEvent } from './usePortEvents';

export type PortStatusDevice = {
  id: string;
  hostname: string;
  platform: string;
  version: string;
  lastPortTransaction: string;
  ports: PortEvent[];
};

export const usePortStatusDevices = () => {
  return useQuery({
    queryKey: ['port_status_devices'],
    queryFn: async () => {
      console.log('Fetching port status devices...');
      
      // Get all port events with agent data - this ensures we only get agents with port events
      const { data: portEventsData, error: portEventsError } = await supabase
        .from('port_events')
        .select(`
          id,
          port_number,
          service,
          protocol,
          address,
          socket,
          family,
          process_name,
          pid,
          status,
          timestamp,
          agent_id,
          agents!agent_id (
            id,
            hostname,
            platform,
            version
          )
        `)
        .order('timestamp', { ascending: false });
      
      if (portEventsError) {
        console.error('Error fetching port events:', portEventsError);
        throw portEventsError;
      }

      console.log('Raw port events data:', portEventsData?.length, 'events');
      
      // Filter out events without valid agents
      const validEvents = portEventsData?.filter(event => event.agents) || [];
      console.log('Valid events with agents:', validEvents.length);

      // Group port events by agent_id and create device objects
      const deviceMap = new Map<string, PortStatusDevice>();
      
      validEvents.forEach(event => {
        const agent = event.agents;
        if (!agent) {
          console.warn('Event without agent found:', event.id);
          return;
        }
        
        const agentId = event.agent_id;
        
        if (!deviceMap.has(agentId)) {
          deviceMap.set(agentId, {
            id: agentId,
            hostname: agent.hostname,
            platform: agent.platform || 'Unknown',
            version: agent.version || 'Unknown',
            lastPortTransaction: event.timestamp || 'Never',
            ports: []
          });
        }
        
        const device = deviceMap.get(agentId)!;
        
        // Update last transaction if this event is more recent
        if (event.timestamp && event.timestamp > device.lastPortTransaction) {
          device.lastPortTransaction = event.timestamp;
        }
        
        // Add port event to the device
        device.ports.push({
          id: event.id,
          hostname: agent.hostname,
          port_number: event.port_number,
          service: event.service || '',
          protocol: event.protocol,
          address: event.address || '',
          socket: event.socket || '',
          family: event.family || '',
          process_name: event.process_name || '',
          pid: event.pid || 0,
          status: event.status,
          timestamp: event.timestamp || '',
          agent: {
            hostname: agent.hostname,
            platform: agent.platform || 'Unknown',
            version: agent.version || 'Unknown'
          }
        });
      });
      
      const devices = Array.from(deviceMap.values()).sort((a, b) => 
        a.hostname.localeCompare(b.hostname)
      );
      
      console.log('Final devices with ports:', devices.length);
      devices.forEach(device => {
        console.log(`Device ${device.hostname}: ${device.ports.length} ports`);
      });
      
      return devices;
    }
  });
};
