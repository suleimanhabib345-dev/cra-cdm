
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export type Incident = {
  id: string;
  title: string;
  description: string | null;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Progress' | 'Closed';
  device_id: string | null;
  detected_at: string;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
  company_id: string | null;
};

export type IncidentStatusOverview = {
  status: string;
  count: number;
};

export type IncidentSeverityCount = {
  severity: string;
  count: number;
};

export type IncidentTrend = {
  date: string;
  critical: number;
  high: number;
  medium: number;
  low: number;
};

export const useIncidentsData = () => {
  // Fetch all incidents
  const { 
    data: incidents, 
    isLoading: isIncidentsLoading,
    error: incidentsError,
    refetch: refetchIncidents
  } = useQuery({
    queryKey: ['incidents'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('incidents')
        .select('*')
        .order('detected_at', { ascending: false });
      
      if (error) throw error;
      return data as Incident[];
    }
  });

  // Fetch incident status counts
  const {
    data: statusCounts,
    isLoading: isStatusLoading,
    error: statusError
  } = useQuery({
    queryKey: ['incident_status_counts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .rpc('get_incident_status_counts');
      
      if (error) throw error;
      return data as IncidentStatusOverview[];
    }
  });

  // Fetch incident severity counts
  const {
    data: severityCounts,
    isLoading: isSeverityLoading,
    error: severityError
  } = useQuery({
    queryKey: ['incident_severity_counts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .rpc('get_incident_severity_counts');
      
      if (error) throw error;
      return data as IncidentSeverityCount[];
    }
  });

  // Fetch trend data
  const {
    data: trendData,
    isLoading: isTrendLoading,
    error: trendError
  } = useQuery({
    queryKey: ['incidents_trend'],
    queryFn: async () => {
      const { data, error } = await supabase
        .rpc('get_incidents_trend_last_7_days');
      
      if (error) throw error;
      return data as IncidentTrend[];
    }
  });

  return {
    incidents: incidents || [],
    statusCounts: statusCounts || [],
    severityCounts: severityCounts || [],
    trendData: trendData || [],
    isLoading: isIncidentsLoading || isStatusLoading || isSeverityLoading || isTrendLoading,
    error: incidentsError || statusError || severityError || trendError,
    refetchIncidents
  };
};
