import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { ScheduledTask } from '@/types/agent-data';

export const useScheduledTasks = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['scheduled_tasks', agentId] : ['scheduled_tasks'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('scheduled_tasks')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as ScheduledTask[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('scheduled-tasks-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'scheduled_tasks' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
