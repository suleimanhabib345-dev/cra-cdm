import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { SecurityPolicy } from '@/types/agent-data';

export const useSecurityPolicies = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['security_policies', agentId] : ['security_policies'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('security_policies')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as SecurityPolicy[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('security-policies-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'security_policies' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
