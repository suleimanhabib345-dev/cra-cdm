import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { WindowsKBUpdate } from '@/types/agent-data';

export const useWindowsKB = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['windows_kb_updates', agentId] : ['windows_kb_updates'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('windows_kb_updates')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as WindowsKBUpdate[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('windows-kb-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'windows_kb_updates' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
