import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { SystemService } from '@/types/agent-data';

export const useSystemServices = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['system_services', agentId] : ['system_services'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('system_services')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as SystemService[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('system-services-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'system_services' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
