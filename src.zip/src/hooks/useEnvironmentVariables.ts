import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { EnvironmentVariable } from '@/types/agent-data';

export const useEnvironmentVariables = (agentId?: string) => {
  const query = useQuery({
    queryKey: agentId ? ['environment_variables', agentId] : ['environment_variables'],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('environment_variables')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as EnvironmentVariable[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('environment-variables-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'environment_variables' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
