
import { useState, useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export type Agent = {
  id: string;
  hostname: string;
  ip_address: string;
  platform: string;
  last_seen: string;
  status: 'Active' | 'Inactive' | 'Needs Update';
  version: string;
};

export type AgentInstallation = {
  id: string;
  hostname: string;
  ip_address: string;
  platform: string;
  installed_at: string;
  status: string;
};

export type Platform = {
  id: string;
  name: string;
  display_name: string;
};

export type AgentStatusOverview = {
  status: string;
  count: number;
  percentage: number;
};

export const useAgentsData = () => {
  const { user } = useAuth();

  // Fetch all agents (filtered by company)
  const {
    data: agents,
    isLoading: isAgentsLoading,
    error: agentsError,
    refetch: refetchAgents
  } = useQuery({
    queryKey: ['agents', user?.id],
    queryFn: async () => {
      // Get user's company_id and role
      let companyId: string | null = null;
      let isSuperAdmin = false;
      if (user?.id) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('company_id, role')
          .eq('id', user.id)
          .single();
        companyId = profile?.company_id || null;
        isSuperAdmin = profile?.role === 'super_admin';
      }

      let query = supabase
        .from('agents')
        .select('*')
        .order('hostname');

      // Super admins see all agents; others see only their company's
      if (!isSuperAdmin) {
        if (!companyId) return []; // No company = no agents
        query = query.eq('company_id', companyId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    enabled: !!user
  });

  // Fetch recent installations
  const {
    data: recentInstallations,
    isLoading: isInstallationsLoading,
    error: installationsError
  } = useQuery({
    queryKey: ['agent_installations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('agent_installations')
        .select('*')
        .order('installed_at', { ascending: false })
        .limit(5);
      
      if (error) throw error;
      return data;
    }
  });

  // Fetch platforms
  const {
    data: platforms,
    isLoading: isPlatformsLoading,
    error: platformsError
  } = useQuery({
    queryKey: ['platforms'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('platforms')
        .select('*')
        .order('display_name');
      
      if (error) throw error;
      return data;
    }
  });

  // Fetch agent status overview
  const {
    data: statusOverview,
    isLoading: isStatusLoading,
    error: statusError
  } = useQuery({
    queryKey: ['agent_status_overview'],
    queryFn: async () => {
      const { data, error } = await supabase
        .rpc('get_agent_status_overview');
      
      if (error) throw error;
      return data;
    }
  });

  // Setup realtime subscription
  useEffect(() => {
    const agentsChannel = supabase
      .channel('agents-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'agents' },
        () => {
          refetchAgents();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(agentsChannel);
    };
  }, [refetchAgents]);

  return {
    agents: agents || [],
    recentInstallations: recentInstallations || [],
    platforms: platforms || [],
    statusOverview: statusOverview || [],
    isLoading: isAgentsLoading || isInstallationsLoading || isPlatformsLoading || isStatusLoading,
    error: agentsError || installationsError || platformsError || statusError
  };
};
