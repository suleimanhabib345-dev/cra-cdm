import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import type { NetworkConnection } from '@/types/agent-data';

export const useNetworkConnections = (agentId?: string, limit: number = 1000) => {
  const query = useQuery({
    queryKey: agentId ? ['network_connections', agentId, limit] : ['network_connections', limit],
    queryFn: async () => {
      let queryBuilder = supabase
        .from('network_connections')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false })
        .limit(limit);

      if (agentId) {
        queryBuilder = queryBuilder.eq('agent_id', agentId);
      }

      const { data, error } = await queryBuilder;

      if (error) throw error;
      return data as NetworkConnection[];
    }
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('network-connections-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'network_connections' },
        () => {
          query.refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [query.refetch]);

  return query;
};
