
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export type PortEvent = {
  id: string;
  hostname: string;
  port_number: number;
  service: string;
  protocol: string;
  address: string;
  socket: string;
  family: string;
  process_name: string;
  pid: number;
  status: string;
  timestamp: string;
  agent: {
    hostname: string;
    platform: string;
    version: string;
  };
};

export const usePortEvents = () => {
  return useQuery({
    queryKey: ['port_events'],
    queryFn: async () => {
      const { data: portData, error: portError } = await supabase
        .from('port_events')
        .select(`
          id,
          port_number,
          service,
          protocol,
          address,
          socket,
          family,
          process_name,
          pid,
          status,
          timestamp,
          agents!agent_id (
            hostname,
            platform,
            version
          )
        `)
        .order('timestamp', { ascending: false });
      
      if (portError) throw portError;
      
      // Transform the data to match our PortEvent type
      return portData?.map(item => ({
        id: item.id,
        hostname: item.agents?.hostname || 'Unknown',
        port_number: item.port_number,
        service: item.service || '',
        protocol: item.protocol,
        address: item.address || '',
        socket: item.socket || '',
        family: item.family || '',
        process_name: item.process_name || '',
        pid: item.pid || 0,
        status: item.status,
        timestamp: item.timestamp || '',
        agent: {
          hostname: item.agents?.hostname || 'Unknown',
          platform: item.agents?.platform || 'Unknown',
          version: item.agents?.version || 'Unknown'
        }
      })) as PortEvent[] || [];
    }
  });
};
