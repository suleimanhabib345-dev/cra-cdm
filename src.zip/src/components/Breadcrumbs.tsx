import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

const ROUTE_LABELS: Record<string, string> = {
  'vulnerabilities': 'Vulnerabilities',
  'incidents': 'Incidents',
  'agents': 'Agents Management',
  'ai-agents': 'AI Agents / Skills',
  'download-agents': 'Download Agents',
  'tools': 'Tools',
  'adscan': 'ADScan',
  'cloudscan': 'CloudScan',
  'webscan': 'Web/API Scan',
  'scanner': 'Scanner',
  'forensics': 'Forensics',
  'software-history': 'Software History',
  'devices': 'Devices',
  'all': 'All Devices',
  'groups': 'Groups',
  'inactive': 'Inactive Devices',
  'transactions': 'Transactions',
  'events': 'Events',
  'ports': 'Port Events',
  'manage': 'Users / Groups',
  'users': 'Manage Users',
  'filetree': 'Filetree / Permissions',
  'reports': 'Reports',
  'license': 'License Key',
  'company': 'Company Staff',
  'settings': 'Settings',
  'logout': 'Logout',
};

const Breadcrumbs: React.FC = () => {
  const location = useLocation();
  const segments = location.pathname.split('/').filter(Boolean);

  return (
    <nav className="flex items-center gap-1.5 text-xs">
      <Link
        to="/"
        className="flex items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors"
      >
        <Home size={13} />
        <span>Home</span>
      </Link>
      {segments.map((segment, i) => {
        const path = '/' + segments.slice(0, i + 1).join('/');
        const isLast = i === segments.length - 1;
        const label = ROUTE_LABELS[segment] || segment.charAt(0).toUpperCase() + segment.slice(1);

        return (
          <React.Fragment key={path}>
            <ChevronRight size={11} className="text-gray-600" />
            {isLast ? (
              <span className="text-gray-300 font-medium">{label}</span>
            ) : (
              <Link to={path} className="text-gray-500 hover:text-gray-300 transition-colors">
                {label}
              </Link>
            )}
          </React.Fragment>
        );
      })}
      {segments.length === 0 && (
        <>
          <ChevronRight size={11} className="text-gray-600" />
          <span className="text-gray-300 font-medium">Dashboard</span>
        </>
      )}
    </nav>
  );
};

export default Breadcrumbs;
