import React, { useState, useEffect } from 'react';
import {
  Brain, Cpu, Zap, SlidersHorizontal, RotateCcw, Save,
  AlertTriangle, CheckCircle2, Info, ChevronDown, ChevronUp,
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  loadAIModelSettings, saveAIModelSettings, resetAIModelSettings,
  DEFAULT_AI_MODEL_SETTINGS,
  type AIModelSettings,
} from '@/services/aiModelSettingsService';
import { loadProviderConfig } from '@/services/aiProviderService';

// ── Helpers ──────────────────────────────────────────────────────────────────

const MODEL_CONTEXT_WINDOWS: Record<string, number> = {
  'gpt-4o': 128_000, 'gpt-4o-mini': 128_000, 'gpt-4-turbo': 128_000, 'gpt-3.5-turbo': 16_385,
  'claude-3-5-sonnet-20241022': 200_000, 'claude-3-5-haiku-20241022': 200_000,
  'claude-3-haiku-20240307': 200_000, 'claude-3-opus-20240229': 200_000,
  'meta/llama-3.1-70b-instruct': 131_072, 'meta/llama-3.1-8b-instruct': 131_072,
  'meta/llama-3.3-70b-instruct': 131_072, 'nvidia/llama-3.1-nemotron-70b-instruct': 131_072,
  'llama-3.1-70b-versatile': 32_768, 'llama-3.3-70b-versatile': 32_768,
  'llama-3.1-8b-instant': 32_768, 'mixtral-8x7b-32768': 32_768,
  'qwen/qwen3-32b': 32_768, 'deepseek/deepseek-chat-v3-0324:free': 32_768,
  'meta-llama/llama-3.1-8b-instruct:free': 32_768, 'meta-llama/llama-3.3-70b-instruct:free': 8_192,
  'google/gemma-3-27b-it:free': 8_192,
};

function getModelContextWindow(model: string): number | null {
  if (!model) return null;
  if (MODEL_CONTEXT_WINDOWS[model]) return MODEL_CONTEXT_WINDOWS[model];
  const base = model.split(':')[0];
  for (const [k, v] of Object.entries(MODEL_CONTEXT_WINDOWS)) {
    if (base === k || base.startsWith(k) || k.startsWith(base)) return v;
  }
  return null;
}

function fmt(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(0)}K` : `${n}`;
}

function TokenBar({ used, total, label }: { used: number; total: number; label: string }) {
  const pct = Math.min(100, Math.round((used / total) * 100));
  const color = pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-yellow-500' : 'bg-emerald-500';
  const textColor = pct >= 90 ? 'text-red-400' : pct >= 70 ? 'text-yellow-400' : 'text-emerald-400';
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-gray-400">{label}</span>
        <span className={textColor}>{fmt(used)} / {fmt(total)} tokens ({pct}%)</span>
      </div>
      <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function SectionHeader({ icon: Icon, title, color = 'text-blue-400' }: {
  icon: React.ElementType; title: string; color?: string;
}) {
  return (
    <div className="flex items-center gap-2 mb-3">
      <Icon size={14} className={color} />
      <span className="text-xs font-semibold text-gray-300 uppercase tracking-wider">{title}</span>
    </div>
  );
}

function SettingRow({ label, description, children }: {
  label: string; description?: string; children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5 border-b border-gray-800 last:border-0">
      <div className="min-w-0 flex-1">
        <p className="text-sm text-gray-200">{label}</p>
        {description && <p className="text-xs text-gray-500 mt-0.5">{description}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

function NullableNumber({
  value, onChange, min, max, step = 1, placeholder, width = 'w-24',
}: {
  value: number | null; onChange: (v: number | null) => void;
  min: number; max: number; step?: number; placeholder: string; width?: string;
}) {
  const [raw, setRaw] = useState(value === null ? '' : String(value));
  useEffect(() => { setRaw(value === null ? '' : String(value)); }, [value]);

  return (
    <Input
      type="number"
      value={raw}
      min={min} max={max} step={step}
      placeholder={placeholder}
      className={`${width} bg-cdm-dark border-gray-700 text-gray-300 text-xs h-8`}
      onChange={e => {
        setRaw(e.target.value);
        const n = parseFloat(e.target.value);
        if (e.target.value === '' || e.target.value === '0') onChange(null);
        else if (!isNaN(n) && n >= min && n <= max) onChange(n);
      }}
      onBlur={() => {
        if (raw === '') { onChange(null); }
      }}
    />
  );
}

// ── Main component ────────────────────────────────────────────────────────────

const AIModelSettingsPanel: React.FC = () => {
  const [settings, setSettings] = useState<AIModelSettings>(loadAIModelSettings);
  const [saved, setSaved] = useState(false);
  const [activeModel, setActiveModel] = useState<string | null>(null);

  useEffect(() => {
    const cfg = loadProviderConfig();
    if (cfg) setActiveModel(cfg.model);
  }, []);

  const ctxWindow = activeModel ? getModelContextWindow(activeModel) : null;
  const effectiveInput = settings.maxInputTokens ?? ctxWindow ?? 8_192;
  const effectiveOutput = settings.maxOutputTokens ?? Math.min(4_096, Math.round(effectiveInput * 0.3));
  const inputBudget = Math.round(effectiveInput * (1 - settings.safeTokenThreshold));

  const update = <K extends keyof AIModelSettings>(key: K, value: AIModelSettings[K]) =>
    setSettings(prev => ({ ...prev, [key]: value }));

  const handleSave = () => {
    saveAIModelSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleReset = () => setSettings(resetAIModelSettings());

  const stepsWarning = settings.maxSteps > 80;
  const stepsColor = settings.maxSteps > 80 ? 'text-yellow-400' : settings.maxSteps > 50 ? 'text-emerald-400' : 'text-gray-400';

  return (
    <div className="space-y-1">
      {/* Active model banner */}
      <div className="flex items-center justify-between px-4 py-3 bg-gray-800/60 rounded-lg border border-gray-700 mb-4">
        <div className="flex items-center gap-2">
          <Brain size={14} className="text-purple-400" />
          <span className="text-xs text-gray-400">Active model:</span>
          <span className="text-xs font-mono text-white">
            {activeModel ?? <span className="text-gray-500 italic">No provider configured</span>}
          </span>
        </div>
        {ctxWindow && (
          <span className="text-xs text-gray-500">{fmt(ctxWindow)} token context</span>
        )}
      </div>

      {/* Token budget preview */}
      {ctxWindow && (
        <div className="px-4 py-3 bg-gray-800/40 rounded-lg border border-gray-700 space-y-2 mb-4">
          <p className="text-xs text-gray-400 mb-2">Effective token budget (based on current settings)</p>
          <TokenBar used={inputBudget} total={effectiveInput} label="Input budget (available for conversation)" />
          <TokenBar used={effectiveOutput} total={effectiveInput} label="Output reserved" />
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">

        {/* ── Token Management ─────────────────────────────────── */}
        <div className="bg-gray-800/40 rounded-lg border border-gray-700 p-4">
          <SectionHeader icon={Cpu} title="Token Management" color="text-blue-400" />

          <SettingRow label="Max Input Tokens" description="Override context window limit (leave blank = model default)">
            <NullableNumber
              value={settings.maxInputTokens}
              onChange={v => update('maxInputTokens', v)}
              min={1024} max={200_000} step={1024}
              placeholder={ctxWindow ? fmt(ctxWindow) : 'auto'}
            />
          </SettingRow>

          <SettingRow label="Max Output Tokens" description="Max tokens per LLM response (leave blank = model default)">
            <NullableNumber
              value={settings.maxOutputTokens}
              onChange={v => update('maxOutputTokens', v)}
              min={256} max={32_000} step={256}
              placeholder="auto"
            />
          </SettingRow>

          <SettingRow
            label={`Output Reserve — ${Math.round(settings.safeTokenThreshold * 100)}%`}
            description="Fraction of context window reserved for output + overhead"
          >
            <div className="w-36">
              <Slider
                value={[Math.round(settings.safeTokenThreshold * 100)]}
                min={20} max={60} step={1}
                onValueChange={([v]) => update('safeTokenThreshold', v / 100)}
                className="[&_.bg-primary]:bg-blue-500"
              />
              <div className="flex justify-between text-[10px] text-gray-600 mt-1">
                <span>20%</span><span>60%</span>
              </div>
            </div>
          </SettingRow>

          <SettingRow label="Auto Token Shrinking" description="Compress conversation history when nearing context limit">
            <Switch
              checked={settings.autoTokenShrinking}
              onCheckedChange={v => update('autoTokenShrinking', v)}
            />
          </SettingRow>

          <SettingRow label="Skill Chunking" description="Split large skill files into per-step context windows">
            <Switch
              checked={settings.chunkingEnabled}
              onCheckedChange={v => update('chunkingEnabled', v)}
            />
          </SettingRow>
        </div>

        {/* ── Execution Controls ───────────────────────────────── */}
        <div className="bg-gray-800/40 rounded-lg border border-gray-700 p-4">
          <SectionHeader icon={Zap} title="Execution" color="text-yellow-400" />

          <SettingRow
            label={`Max Steps — ${settings.maxSteps}`}
            description="Total agent loop iterations before the scan ends"
          >
            <div className="w-36">
              <Slider
                value={[settings.maxSteps]}
                min={10} max={120} step={5}
                onValueChange={([v]) => update('maxSteps', v)}
                className={`[&_.bg-primary]:${stepsWarning ? 'bg-yellow-500' : 'bg-emerald-500'}`}
              />
              <div className="flex justify-between text-[10px] text-gray-600 mt-1">
                <span>10</span><span className={stepsColor}>{settings.maxSteps}</span><span>120</span>
              </div>
            </div>
          </SettingRow>

          {stepsWarning && (
            <div className="flex items-center gap-1.5 text-xs text-yellow-500 bg-yellow-500/10 border border-yellow-500/20 rounded px-2.5 py-1.5 mb-2">
              <AlertTriangle size={12} />
              High step count may increase API costs and scan duration
            </div>
          )}

          <SettingRow
            label={`Tool Call Retries — ${settings.maxToolCallRetries}`}
            description="Retry attempts per LLM call on context/rate errors"
          >
            <div className="w-36">
              <Slider
                value={[settings.maxToolCallRetries]}
                min={1} max={5} step={1}
                onValueChange={([v]) => update('maxToolCallRetries', v)}
                className="[&_.bg-primary]:bg-emerald-500"
              />
              <div className="flex justify-between text-[10px] text-gray-600 mt-1">
                <span>1</span><span>5</span>
              </div>
            </div>
          </SettingRow>
        </div>

        {/* ── Model Behavior ───────────────────────────────────── */}
        <div className="bg-gray-800/40 rounded-lg border border-gray-700 p-4">
          <SectionHeader icon={SlidersHorizontal} title="Model Behavior" color="text-purple-400" />

          <SettingRow
            label="Temperature"
            description="Randomness of model outputs. Leave blank to use model default (recommended)"
          >
            <div className="flex items-center gap-2">
              {settings.temperature !== null && (
                <span className="text-xs text-gray-400 w-8 text-right">{settings.temperature.toFixed(1)}</span>
              )}
              <NullableNumber
                value={settings.temperature}
                onChange={v => update('temperature', v)}
                min={0} max={2} step={0.1}
                placeholder="default"
                width="w-24"
              />
            </div>
          </SettingRow>

          <SettingRow
            label="Top-p"
            description="Nucleus sampling probability. Leave blank to use model default"
          >
            <NullableNumber
              value={settings.topP}
              onChange={v => update('topP', v)}
              min={0} max={1} step={0.05}
              placeholder="default"
              width="w-24"
            />
          </SettingRow>

          <div className="flex items-start gap-1.5 text-xs text-gray-500 bg-gray-800 rounded px-2.5 py-2 mt-2">
            <Info size={11} className="mt-0.5 flex-shrink-0 text-gray-600" />
            <span>For security scanning, keep temperature at 0.0–0.3 to get deterministic, structured tool calls. Higher values may cause unpredictable behavior.</span>
          </div>
        </div>

        {/* ── Free Model Limits ────────────────────────────────── */}
        <div className="bg-gray-800/40 rounded-lg border border-gray-700 p-4">
          <SectionHeader icon={Info} title="Free Model Constraints" color="text-orange-400" />

          <div className="space-y-1 text-xs text-gray-400 mb-3 leading-relaxed">
            <p>Settings automatically applied when using free-tier providers (OpenRouter, NVIDIA NIM, Groq):</p>
          </div>

          <div className="space-y-2">
            {[
              { label: 'Auto token shrinking', active: settings.autoTokenShrinking, key: 'autoTokenShrinking' as const },
              { label: 'Skill chunking (large inputs)', active: settings.chunkingEnabled, key: 'chunkingEnabled' as const },
            ].map(({ label, active, key }) => (
              <div key={key} className="flex items-center justify-between py-1.5 border-b border-gray-800 last:border-0">
                <span className="text-xs text-gray-300">{label}</span>
                <div className="flex items-center gap-1.5">
                  <span className={`text-[10px] font-medium ${active ? 'text-emerald-400' : 'text-gray-600'}`}>
                    {active ? 'ON' : 'OFF'}
                  </span>
                  <Switch
                    checked={active}
                    onCheckedChange={v => update(key, v)}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-3 flex items-start gap-1.5 text-xs text-orange-400/80 bg-orange-500/5 border border-orange-500/15 rounded px-2.5 py-2">
            <AlertTriangle size={11} className="mt-0.5 flex-shrink-0" />
            <span>Disabling these on free/small models may cause context overflow errors. Enable both for models with &lt;32K context.</span>
          </div>
        </div>
      </div>

      {/* Save / Reset */}
      <div className="flex items-center justify-between pt-4 border-t border-gray-700 mt-4">
        <Button
          variant="outline"
          size="sm"
          onClick={handleReset}
          className="border-gray-700 text-gray-400 hover:text-white gap-1.5 text-xs"
        >
          <RotateCcw size={13} />
          Reset to Defaults
        </Button>
        <Button
          size="sm"
          onClick={handleSave}
          className={`gap-1.5 text-xs transition-colors ${
            saved ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'
          } text-white`}
        >
          {saved ? <CheckCircle2 size={13} /> : <Save size={13} />}
          {saved ? 'Saved' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
};

export default AIModelSettingsPanel;
