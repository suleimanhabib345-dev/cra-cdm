
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { day: 'Mon', incidents: 3 },
  { day: 'Tue', incidents: 5 },
  { day: 'Wed', incidents: 2 },
  { day: 'Thu', incidents: 8 },
  { day: 'Fri', incidents: 4 },
  { day: 'Sat', incidents: 6 },
  { day: 'Sun', incidents: 3 },
];

const IncidentTrendChart = () => {
  return (
    <div className="stat-card h-[350px]">
      <h3 className="text-lg font-semibold mb-4">Incident Trends</h3>
      <ResponsiveContainer width="100%" height="85%">
        <LineChart data={data} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#333" />
          <XAxis 
            dataKey="day" 
            stroke="#aaa"
            tick={{ fill: '#aaa' }}
          />
          <YAxis 
            stroke="#aaa"
            tick={{ fill: '#aaa' }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#1a2035', 
              borderColor: '#333', 
              borderRadius: '0.375rem' 
            }}
            itemStyle={{ color: 'white' }}
            formatter={(value, name) => [value, 'Incidents']}
            labelFormatter={(label) => label}
          />
          <Line 
            type="monotone" 
            dataKey="incidents" 
            stroke="#3498db" 
            strokeWidth={2}
            activeDot={{ r: 6 }} 
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default IncidentTrendChart;
