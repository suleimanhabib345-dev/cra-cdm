
import React, { useState, useEffect } from 'react';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, AlertCircle, Info, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

// Define the Alert interface directly in this file since it's not exported from api.ts
interface Alert {
  id: string;
  title: string;
  description: string | null;
  severity: string;
  status: string | null;
  created_at: string;
  device_id: string | null;
}

interface AlertWithDevice extends Alert {
  device?: {
    hostname: string;
    id: string;
  };
}

const severityIcons = {
  critical: <AlertTriangle className="h-4 w-4 text-red-500" />,
  high: <AlertCircle className="h-4 w-4 text-orange-500" />,
  medium: <Info className="h-4 w-4 text-yellow-500" />,
  low: <CheckCircle2 className="h-4 w-4 text-green-500" />
};

const severityColors = {
  critical: "bg-red-900 text-red-300 border-red-700",
  high: "bg-orange-900 text-orange-300 border-orange-700",
  medium: "bg-yellow-900 text-yellow-300 border-yellow-700",
  low: "bg-green-900 text-green-300 border-green-700"
};

const statusColors = {
  new: "bg-blue-900 text-blue-300 border-blue-700",
  investigating: "bg-purple-900 text-purple-300 border-purple-700",
  resolved: "bg-green-900 text-green-300 border-green-700",
  dismissed: "bg-gray-700 text-gray-300 border-gray-600"
};

const AlertsTable = () => {
  const [page, setPage] = useState(1);
  const [alerts, setAlerts] = useState<AlertWithDevice[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  
  useEffect(() => {
    const fetchAlerts = async () => {
      setLoading(true);
      try {
        // Create query for data
        const query = supabase
          .from('alerts')
          .select(`
            id, 
            title, 
            description, 
            severity, 
            status, 
            created_at,
            device_id,
            device:devices(hostname, id)
          `)
          .order('created_at', { ascending: false });
        
        // Separate count query to avoid TypeScript error
        const countQuery = supabase
          .from('alerts')
          .select('*', { count: 'exact', head: true });
        
        // Get count
        const { count: totalCount, error: countError } = await countQuery;
        
        if (countError) throw countError;
        
        // Now get the paginated data
        const from = (page - 1) * 5;
        const to = from + 5 - 1;
        const { data, error } = await query.range(from, to);
        
        if (error) throw error;
        
        if (data) {
          setAlerts(data as AlertWithDevice[]);
          setTotalCount(totalCount || 0);
        }
      } catch (error) {
        console.error("Error fetching alerts:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchAlerts();
  }, [page]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalPages = Math.ceil(totalCount / 5);

  const handlePrevPage = () => {
    if (page > 1) setPage(page - 1);
  };

  const handleNextPage = () => {
    if (page < totalPages) setPage(page + 1);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Recent Alerts</h2>
      </div>
      
      {loading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-850">
                <TableRow>
                  <TableHead className="text-gray-300">Severity</TableHead>
                  <TableHead className="text-gray-300">Alert</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300 hidden md:table-cell">Device</TableHead>
                  <TableHead className="text-gray-300 hidden md:table-cell">Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {alerts && alerts.length > 0 ? (
                  alerts.map((alert) => (
                    <TableRow key={alert.id} className="hover:bg-gray-750 border-gray-700">
                      <TableCell>
                        <Badge variant="outline" className={severityColors[alert.severity.toLowerCase() as keyof typeof severityColors] || severityColors.medium}>
                          <span className="flex items-center">
                            {severityIcons[alert.severity.toLowerCase() as keyof typeof severityIcons] || severityIcons.medium}
                            <span className="ml-1 capitalize">{alert.severity}</span>
                          </span>
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium text-gray-300">
                        {alert.title}
                        <p className="text-sm text-gray-400 mt-1 line-clamp-1">{alert.description || 'No description'}</p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={statusColors[alert.status as keyof typeof statusColors] || statusColors.new}>
                          <span className="capitalize">{alert.status?.replace('_', ' ') || 'New'}</span>
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-gray-300">
                        {alert.device?.hostname || 'Unknown device'}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-gray-300">
                        {formatDate(alert.created_at)}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4 text-gray-400">
                      No alerts found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {totalPages > 1 && (
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm text-gray-400">
                Showing {((page - 1) * 5) + 1}-{Math.min(page * 5, totalCount)} of {totalCount} alerts
              </div>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handlePrevPage}
                  disabled={page === 1}
                  className="h-8 px-3"
                >
                  Previous
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleNextPage}
                  disabled={page >= totalPages}
                  className="h-8 px-3"
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AlertsTable;
