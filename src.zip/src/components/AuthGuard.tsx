
import React, { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import Auth from '@/pages/Auth';
import { supabase } from '@/integrations/supabase/client';
import { Shield, Clock, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PendingApproval = ({ email, onSignOut }: { email: string; onSignOut: () => void }) => (
  <div className="flex min-h-screen bg-cdm-dark text-white items-center justify-center">
    <div className="max-w-md w-full bg-cdm-darker rounded-lg p-8 text-center space-y-6">
      <div className="flex justify-center">
        <div className="bg-yellow-900/30 p-4 rounded-full">
          <Clock className="h-12 w-12 text-yellow-400" />
        </div>
      </div>
      <h2 className="text-2xl font-bold text-white">Account Pending Approval</h2>
      <p className="text-gray-400">
        Your account <span className="text-white font-medium">{email}</span> has been
        verified but is waiting for administrator approval.
      </p>
      <div className="bg-gray-800 rounded-lg p-4 text-left space-y-2">
        <div className="flex items-center gap-2 text-green-400">
          <Shield className="h-4 w-4" />
          <span className="text-sm">Email verified</span>
        </div>
        <div className="flex items-center gap-2 text-yellow-400">
          <Clock className="h-4 w-4" />
          <span className="text-sm">Awaiting admin approval</span>
        </div>
      </div>
      <p className="text-sm text-gray-500">
        You will be able to access the platform once an administrator approves your account.
        Please contact your organization's CRA administrator if this takes too long.
      </p>
      <Button
        variant="outline"
        className="w-full bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700"
        onClick={onSignOut}
      >
        <LogOut className="mr-2 h-4 w-4" />
        Sign Out
      </Button>
    </div>
  </div>
);

const AuthGuard = ({ children }: { children: React.ReactNode }) => {
  const { session, user, loading, signOut } = useAuth();
  const [approvalStatus, setApprovalStatus] = useState<'loading' | 'approved' | 'pending'>('loading');

  useEffect(() => {
    const checkApproval = async () => {
      if (!user?.id) {
        setApprovalStatus('loading');
        return;
      }

      const { data: profile, error } = await supabase
        .from('profiles')
        .select('is_approved, role')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('Error checking approval status:', error);
        // If profile doesn't exist yet (trigger hasn't fired), show pending
        setApprovalStatus('pending');
        return;
      }

      // Super admins are always approved
      if (profile?.role === 'super_admin') {
        setApprovalStatus('approved');
        return;
      }

      setApprovalStatus(profile?.is_approved ? 'approved' : 'pending');
    };

    if (session && user) {
      checkApproval();
    }
  }, [session, user]);

  if (loading) {
    return (
      <div className="flex min-h-screen bg-cdm-dark text-white items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!session) {
    return <Auth />;
  }

  if (approvalStatus === 'loading') {
    return (
      <div className="flex min-h-screen bg-cdm-dark text-white items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (approvalStatus === 'pending') {
    return <PendingApproval email={user?.email || ''} onSignOut={signOut} />;
  }

  return <>{children}</>;
};

export default AuthGuard;
