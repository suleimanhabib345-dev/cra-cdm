import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Minimize2 } from 'lucide-react';

export interface CICDPipelineFinding {
  id?: string;
  title: string;
  severity: string;
  endpoint?: string;
  description?: string;
}

export interface CICDRepoFinding {
  path: string;
  label: string;
  severity: string;
}

export interface CICDResult {
  id?: string;
  pipelineId?: string;
  repo: string;
  branch: string;
  status: string;
  technologies?: string[];
  findings: CICDPipelineFinding[];
  repoFindings: CICDRepoFinding[];
  createdAt: string;
}

type NodeType = 'repo' | 'branch' | 'file' | 'endpoint' | 'finding';

interface GNode {
  id: string;
  type: NodeType;
  label: string;
  severity?: string;
  detail?: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
}

interface GEdge {
  source: string;
  target: string;
}

const NODE_SIZES: Record<NodeType, number> = { repo: 24, branch: 14, file: 13, endpoint: 13, finding: 10 };
const NODE_ICONS: Record<NodeType, string> = { repo: '📦', branch: '🌿', file: '📄', endpoint: '🌐', finding: '⚠️' };

const SEV_COLOR: Record<string, string> = {
  CRITICAL: '#ef4444', critical: '#ef4444',
  HIGH: '#f97316', high: '#f97316',
  MEDIUM: '#eab308', medium: '#eab308',
  LOW: '#3b82f6', low: '#3b82f6',
  INFO: '#6b7280', info: '#6b7280',
};

const NODE_COLOR: Record<NodeType, string> = {
  repo: '#6366f1',
  branch: '#8b5cf6',
  file: '#3b82f6',
  endpoint: '#06b6d4',
  finding: '#ef4444',
};

function buildGraph(result: CICDResult): { nodes: GNode[]; edges: GEdge[] } {
  const nodes: GNode[] = [];
  const edges: GEdge[] = [];
  const zero = { x: 0, y: 0, vx: 0, vy: 0 };

  const repoId = 'repo';
  nodes.push({ id: repoId, type: 'repo', label: result.repo.split('/').pop() || result.repo, detail: result.repo, ...zero });

  const branchId = 'branch';
  nodes.push({ id: branchId, type: 'branch', label: result.branch, ...zero });
  edges.push({ source: repoId, target: branchId });

  // Repo findings grouped by file
  const fileMap = new Map<string, CICDRepoFinding[]>();
  for (const f of result.repoFindings) {
    if (!fileMap.has(f.path)) fileMap.set(f.path, []);
    fileMap.get(f.path)!.push(f);
  }

  let fi = 0;
  for (const [path, findings] of fileMap) {
    const fileId = `file-${fi++}`;
    nodes.push({ id: fileId, type: 'file', label: path.split('/').pop() || path, detail: path, ...zero });
    edges.push({ source: branchId, target: fileId });
    findings.forEach((f, i) => {
      const id = `${fileId}-f${i}`;
      const sev = f.severity?.toUpperCase() || 'INFO';
      nodes.push({ id, type: 'finding', label: f.label.length > 32 ? f.label.slice(0, 32) + '…' : f.label, severity: sev, detail: `${path}: ${f.label}`, ...zero });
      edges.push({ source: fileId, target: id });
    });
  }

  // Web findings grouped by endpoint
  const epMap = new Map<string, CICDPipelineFinding[]>();
  for (const f of result.findings) {
    const key = f.endpoint || '(app)';
    if (!epMap.has(key)) epMap.set(key, []);
    epMap.get(key)!.push(f);
  }

  let ei = 0;
  for (const [ep, findings] of epMap) {
    const epId = `ep-${ei++}`;
    const short = ep.length > 32 ? '…' + ep.slice(-30) : ep;
    nodes.push({ id: epId, type: 'endpoint', label: short, detail: ep, ...zero });
    edges.push({ source: repoId, target: epId });
    findings.forEach((f, i) => {
      const id = `${epId}-f${i}`;
      const sev = f.severity?.toUpperCase() || 'INFO';
      nodes.push({ id, type: 'finding', label: f.title.length > 32 ? f.title.slice(0, 32) + '…' : f.title, severity: sev, detail: f.description || f.title, ...zero });
      edges.push({ source: epId, target: id });
    });
  }

  if (nodes.length <= 2) {
    nodes.push({ id: 'clean', type: 'finding', label: 'No findings ✓', severity: 'INFO', ...zero });
    edges.push({ source: repoId, target: 'clean' });
  }

  return { nodes, edges };
}

interface Props {
  result: CICDResult;
  persistKey?: string;
  className?: string;
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill(); ctx.stroke();
}

const GRAPH_STORE = 'cra_cicd_graph_';

const CICDAttackGraph: React.FC<Props> = ({ result, persistKey, className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const nodesRef = useRef<GNode[]>([]);
  const animFrame = useRef<number>(0);
  const draggedRef = useRef<GNode | null>(null);
  const dragStart = useRef({ x: 0, y: 0 });
  const persistKeyRef = useRef(persistKey);
  persistKeyRef.current = persistKey;

  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [isDragging, setIsDragging] = useState(false);
  const [hovered, setHovered] = useState<GNode | null>(null);
  const [selected, setSelected] = useState<GNode | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [graphData] = useState(() => buildGraph(result));

  // Esc to exit fullscreen
  useEffect(() => {
    if (!isExpanded) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setIsExpanded(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [isExpanded]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { x: tx, y: ty, scale } = transform;
    const nodes = nodesRef.current;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(tx, ty);
    ctx.scale(scale, scale);

    // Edges
    for (const edge of graphData.edges) {
      const src = nodes.find(n => n.id === edge.source);
      const tgt = nodes.find(n => n.id === edge.target);
      if (!src || !tgt) continue;
      ctx.beginPath();
      ctx.moveTo(src.x, src.y);
      ctx.lineTo(tgt.x, tgt.y);
      ctx.strokeStyle = '#374151';
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.5;
      ctx.stroke();
      ctx.globalAlpha = 1;
      // Arrow
      const angle = Math.atan2(tgt.y - src.y, tgt.x - src.x);
      const tgtSize = NODE_SIZES[tgt.type] || 10;
      const ax = tgt.x - Math.cos(angle) * (tgtSize + 4);
      const ay = tgt.y - Math.sin(angle) * (tgtSize + 4);
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(ax - 5 * Math.cos(angle - Math.PI / 6), ay - 5 * Math.sin(angle - Math.PI / 6));
      ctx.lineTo(ax - 5 * Math.cos(angle + Math.PI / 6), ay - 5 * Math.sin(angle + Math.PI / 6));
      ctx.closePath();
      ctx.fillStyle = '#4b5563';
      ctx.globalAlpha = 0.6;
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    // Nodes
    for (const node of nodes) {
      const size = NODE_SIZES[node.type] || 10;
      const color = node.type === 'finding' ? (SEV_COLOR[node.severity || 'INFO'] || '#6b7280') : NODE_COLOR[node.type];
      const isHov = hovered?.id === node.id;
      const isSel = selected?.id === node.id;

      // Severity glow for findings
      if (node.type === 'finding' && node.severity) {
        const sev = (node.severity || '').toUpperCase();
        if (sev === 'CRITICAL' || sev === 'HIGH') {
          ctx.beginPath();
          ctx.arc(node.x, node.y, size + 7, 0, Math.PI * 2);
          ctx.fillStyle = color.replace(')', ', 0.2)').replace('rgb', 'rgba') || 'rgba(239,68,68,0.15)';
          ctx.fill();
        }
      }

      ctx.beginPath();
      ctx.arc(node.x, node.y, size, 0, Math.PI * 2);
      ctx.fillStyle = isSel ? '#fff' : color;
      ctx.fill();
      ctx.strokeStyle = isHov ? '#fff' : isSel ? color : 'rgba(255,255,255,0.2)';
      ctx.lineWidth = isHov || isSel ? 2 : 1;
      ctx.stroke();

      ctx.font = `${size * 0.85}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(NODE_ICONS[node.type] || '', node.x, node.y);

      ctx.font = `${isHov ? 'bold ' : ''}10px Inter, system-ui, sans-serif`;
      ctx.fillStyle = isHov ? '#fff' : '#9ca3af';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText(node.label, node.x, node.y + size + 3);
    }

    ctx.restore();

    // Tooltip
    if (hovered && hovered.detail) {
      const sx = hovered.x * scale + tx;
      const sy = hovered.y * scale + ty;
      const tw = 220; const th = hovered.severity ? 52 : 36;
      const ttx = Math.min(sx + 16, canvas.width - tw - 8);
      const tty = Math.max(sy - 16, 8);
      ctx.fillStyle = 'rgba(15,23,42,0.95)';
      ctx.strokeStyle = 'rgba(71,85,105,0.5)';
      ctx.lineWidth = 1;
      rr(ctx, ttx, tty, tw, th, 5);
      ctx.font = 'bold 10px Inter, system-ui, sans-serif';
      ctx.fillStyle = '#f1f5f9';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      const lbl = `${NODE_ICONS[hovered.type]} ${hovered.label}`;
      ctx.fillText(lbl, ttx + 7, tty + 7);
      if (hovered.severity) {
        ctx.font = '9px Inter, system-ui, sans-serif';
        ctx.fillStyle = SEV_COLOR[hovered.severity] || '#94a3b8';
        ctx.fillText(`Severity: ${hovered.severity}`, ttx + 7, tty + 22);
        ctx.fillStyle = '#64748b';
        const det = hovered.detail!.length > 34 ? hovered.detail!.slice(0, 34) + '…' : hovered.detail!;
        ctx.fillText(det, ttx + 7, tty + 36);
      } else {
        ctx.font = '9px Inter, system-ui, sans-serif';
        ctx.fillStyle = '#64748b';
        const det = hovered.detail!.length > 36 ? hovered.detail!.slice(0, 36) + '…' : hovered.detail!;
        ctx.fillText(det, ttx + 7, tty + 22);
      }
    }
  }, [graphData.edges, hovered, selected, transform]);

  // Initialize simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !graphData.nodes.length) return;

    const w = canvas.width || 600;
    const h = canvas.height || 400;
    const cx = w / 2, cy = h / 2;
    const radius = Math.min(w, h) * 0.35;

    // Try saved positions
    const pk = persistKeyRef.current;
    if (pk) {
      try {
        const saved = JSON.parse(localStorage.getItem(GRAPH_STORE + pk) || 'null') as Record<string, { x: number; y: number }> | null;
        if (saved && graphData.nodes.every(n => n.id in saved)) {
          nodesRef.current = graphData.nodes.map(n => ({ ...n, x: saved[n.id].x, y: saved[n.id].y, vx: 0, vy: 0 }));
          draw();
          return;
        }
      } catch {}
    }

    nodesRef.current = graphData.nodes.map((n, i) => {
      const angle = (2 * Math.PI * i) / graphData.nodes.length;
      return { ...n, x: cx + radius * Math.cos(angle) + (Math.random() - 0.5) * 40, y: cy + radius * Math.sin(angle) + (Math.random() - 0.5) * 40, vx: 0, vy: 0 };
    });

    let iter = 0;
    const max = 200;
    const simulate = () => {
      if (iter >= max) {
        draw();
        const pk2 = persistKeyRef.current;
        if (pk2) {
          const pos: Record<string, { x: number; y: number }> = {};
          for (const n of nodesRef.current) pos[n.id] = { x: n.x, y: n.y };
          try { localStorage.setItem(GRAPH_STORE + pk2, JSON.stringify(pos)); } catch {}
        }
        return;
      }
      const alpha = 1 - iter / max;
      const nodes = nodesRef.current;

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[j].x - nodes[i].x, dy = nodes[j].y - nodes[i].y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const f = (700 * alpha) / (dist * dist);
          const fx = (dx / dist) * f, fy = (dy / dist) * f;
          nodes[i].vx -= fx; nodes[i].vy -= fy;
          nodes[j].vx += fx; nodes[j].vy += fy;
        }
      }

      for (const edge of graphData.edges) {
        const src = nodes.find(n => n.id === edge.source);
        const tgt = nodes.find(n => n.id === edge.target);
        if (!src || !tgt) continue;
        const dx = tgt.x - src.x, dy = tgt.y - src.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (dist - 110) * 0.012 * alpha;
        const fx = (dx / dist) * f, fy = (dy / dist) * f;
        src.vx += fx; src.vy += fy;
        tgt.vx -= fx; tgt.vy -= fy;
      }

      for (const n of nodes) {
        n.vx += (cx - n.x) * 0.001 * alpha;
        n.vy += (cy - n.y) * 0.001 * alpha;
        n.vx *= 0.6; n.vy *= 0.6;
        n.x = Math.max(40, Math.min(w - 40, n.x + n.vx));
        n.y = Math.max(40, Math.min(h - 40, n.y + n.vy));
      }

      iter++;
      draw();
      animFrame.current = requestAnimationFrame(simulate);
    };
    simulate();
    return () => cancelAnimationFrame(animFrame.current);
  }, [graphData]);

  useEffect(() => { draw(); }, [draw]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const obs = new ResizeObserver(() => {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
      draw();
    });
    obs.observe(container);
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    draw();
    return () => obs.disconnect();
  }, [draw, isExpanded]);

  const getNodeAt = useCallback((mx: number, my: number): GNode | null => {
    const { x: tx, y: ty, scale } = transform;
    const wx = (mx - tx) / scale, wy = (my - ty) / scale;
    for (let i = nodesRef.current.length - 1; i >= 0; i--) {
      const n = nodesRef.current[i];
      const s = NODE_SIZES[n.type] || 10;
      const dx = wx - n.x, dy = wy - n.y;
      if (dx * dx + dy * dy <= (s + 4) * (s + 4)) return n;
    }
    return null;
  }, [transform]);

  const onMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = canvasRef.current?.getBoundingClientRect();
    if (!r) return;
    const mx = e.clientX - r.left, my = e.clientY - r.top;

    if (draggedRef.current) {
      const { x: tx, y: ty, scale } = transform;
      const pinnedId = draggedRef.current.id;
      draggedRef.current.x = (mx - tx) / scale;
      draggedRef.current.y = (my - ty) / scale;
      draggedRef.current.vx = 0; draggedRef.current.vy = 0;
      const nodes = nodesRef.current;
      const canvas = canvasRef.current;
      if (canvas) {
        const w = canvas.width, h = canvas.height;
        for (let s = 0; s < 3; s++) {
          for (const edge of graphData.edges) {
            const src = nodes.find(n => n.id === edge.source);
            const tgt = nodes.find(n => n.id === edge.target);
            if (!src || !tgt) continue;
            const dx = tgt.x - src.x, dy = tgt.y - src.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const f = (dist - 110) * 0.025;
            const fx = (dx / dist) * f, fy = (dy / dist) * f;
            if (src.id !== pinnedId) { src.vx += fx; src.vy += fy; }
            if (tgt.id !== pinnedId) { tgt.vx -= fx; tgt.vy -= fy; }
          }
          for (const n of nodes) {
            if (n.id === pinnedId) continue;
            n.vx *= 0.65; n.vy *= 0.65;
            n.x = Math.max(40, Math.min(w - 40, n.x + n.vx));
            n.y = Math.max(40, Math.min(h - 40, n.y + n.vy));
          }
        }
      }
      draw(); return;
    }

    if (isDragging) {
      setTransform(p => ({ ...p, x: p.x + (e.clientX - dragStart.current.x), y: p.y + (e.clientY - dragStart.current.y) }));
      dragStart.current = { x: e.clientX, y: e.clientY };
      return;
    }

    const n = getNodeAt(mx, my);
    setHovered(n);
    if (canvasRef.current) canvasRef.current.style.cursor = n ? 'grab' : 'default';
  }, [isDragging, getNodeAt, transform, draw, graphData.edges]);

  const onMouseDown = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = canvasRef.current?.getBoundingClientRect();
    if (!r) return;
    const n = getNodeAt(e.clientX - r.left, e.clientY - r.top);
    if (n) {
      draggedRef.current = n;
      setSelected(n);
      if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
    } else {
      setIsDragging(true);
      dragStart.current = { x: e.clientX, y: e.clientY };
      if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
    }
  }, [getNodeAt]);

  const onMouseUp = useCallback(() => {
    if (draggedRef.current) {
      const pk = persistKeyRef.current;
      if (pk) {
        const pos: Record<string, { x: number; y: number }> = {};
        for (const n of nodesRef.current) pos[n.id] = { x: n.x, y: n.y };
        try { localStorage.setItem(GRAPH_STORE + pk, JSON.stringify(pos)); } catch {}
      }
    }
    draggedRef.current = null;
    setIsDragging(false);
    if (canvasRef.current) canvasRef.current.style.cursor = hovered ? 'grab' : 'default';
  }, [hovered]);

  const onWheel = useCallback((e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const r = canvasRef.current?.getBoundingClientRect();
    if (!r) return;
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const d = e.deltaY > 0 ? 0.9 : 1.1;
    setTransform(p => {
      const ns = Math.max(0.3, Math.min(3, p.scale * d));
      const ratio = ns / p.scale;
      return { scale: ns, x: mx - (mx - p.x) * ratio, y: my - (my - p.y) * ratio };
    });
  }, []);

  const resetView = () => setTransform({ x: 0, y: 0, scale: 1 });

  const stats = { total: graphData.nodes.filter(n => n.type === 'finding').length };
  const criticalCount = graphData.nodes.filter(n => n.type === 'finding' && (n.severity === 'CRITICAL' || n.severity === 'critical')).length;
  const highCount = graphData.nodes.filter(n => n.type === 'finding' && (n.severity === 'HIGH' || n.severity === 'high')).length;

  return (
    <>
      <div className={`relative flex flex-col bg-[#0a0e17] rounded-lg border border-gray-800 overflow-hidden ${isExpanded ? 'fixed inset-4 z-50' : ''} ${className}`}>
        <div className="flex items-center justify-between px-4 py-2 bg-[#0f1520] border-b border-gray-800">
          <div className="flex items-center gap-3">
            <span className="text-xs font-medium text-gray-400">CI/CD Attack Graph</span>
            <span className="text-[10px] text-gray-600 font-mono">{result.repo} / {result.branch}</span>
            {criticalCount > 0 && <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-900/30 text-red-400">{criticalCount} critical</span>}
            {highCount > 0 && <span className="text-[10px] px-1.5 py-0.5 rounded bg-orange-900/30 text-orange-400">{highCount} high</span>}
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setTransform(p => ({ ...p, scale: Math.max(0.3, p.scale / 1.2) }))} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300"><ZoomOut size={12} /></button>
            <button onClick={() => setTransform(p => ({ ...p, scale: Math.min(3, p.scale * 1.2) }))} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300"><ZoomIn size={12} /></button>
            <button onClick={resetView} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300"><RotateCcw size={12} /></button>
            <button onClick={() => setIsExpanded(!isExpanded)} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300">
              {isExpanded ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
            </button>
          </div>
        </div>
        <div ref={containerRef} className={`${isExpanded ? 'flex-1' : 'h-[480px]'}`}>
          <canvas ref={canvasRef} onMouseMove={onMouseMove} onMouseDown={onMouseDown} onMouseUp={onMouseUp} onMouseLeave={onMouseUp} onWheel={onWheel} className="w-full h-full" />
        </div>
        <div className="flex flex-wrap items-center gap-3 px-4 py-2 bg-[#0f1520] border-t border-gray-800">
          {[['repo','#6366f1','Repository'],['branch','#8b5cf6','Branch'],['file','#3b82f6','File'],['endpoint','#06b6d4','Endpoint']].map(([,c,l]) => (
            <div key={l} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c }} />
              <span className="text-[10px] text-gray-500">{l}</span>
            </div>
          ))}
          {[['CRITICAL','#ef4444'],['HIGH','#f97316'],['MEDIUM','#eab308'],['LOW','#3b82f6']].map(([s, c]) => (
            <div key={s} className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: c }} />
              <span className="text-[9px] text-gray-600">{s}</span>
            </div>
          ))}
          <span className="ml-auto text-[10px] text-gray-600">{stats.total} finding{stats.total !== 1 ? 's' : ''}</span>
        </div>
        {selected && (
          <div className="absolute bottom-12 left-4 bg-[#0f172a]/95 border border-gray-700 rounded-lg p-3 max-w-[240px] backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <span>{NODE_ICONS[selected.type]}</span>
              <span className="text-xs font-medium text-white truncate">{selected.label}</span>
            </div>
            <div className="text-[10px] text-gray-500">Type: {selected.type}</div>
            {selected.severity && (
              <div className="text-[10px] mt-0.5" style={{ color: SEV_COLOR[selected.severity] || '#94a3b8' }}>Severity: {selected.severity}</div>
            )}
            {selected.detail && selected.detail !== selected.label && (
              <div className="text-[10px] text-gray-400 mt-1 break-all">{selected.detail}</div>
            )}
          </div>
        )}
      </div>
      {isExpanded && <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setIsExpanded(false)} />}
    </>
  );
};

export default CICDAttackGraph;
