import React, { useState } from 'react';
import { ArrowLeft, FileText, List, Users, Network, Lock, CalendarIcon, Filter, Search, ExternalLink, ChevronLeft, ChevronRight } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useSystemUsers } from '@/hooks/useSystemUsers';
import { useSystemGroups } from '@/hooks/useSystemGroups';
import { usePortEvents } from '@/hooks/usePortEvents';
import { useFilePermissions } from '@/hooks/useFilePermissions';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';

// Types for our device
interface Vulnerability {
  critical: number;
  high: number;
  medium: number;
  low: number;
  informational: number;
}

interface Device {
  id: number;
  hostname: string;
  ips: string[];
  os: string;
  version: string;
  vulnerabilities: Vulnerability;
  lastTransaction: string;
}

// Enhanced vulnerability interface
interface VulnerabilityDetail {
  id: number;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'informational';
  cvss: number;
  date: string;
  status: string;
  affects: string;
  exploitability: string;
  reference: {
    name: string;
    url: string;
  };
}

// Enhanced software interface
interface Software {
  id: number;
  name: string;
  version: string;
  vendor: string;
  installDate: string;
  architecture: string;
}

// Vulnerability and software data are now fetched dynamically inside the component
const _unusedVulnSamples: VulnerabilityDetail[] = [
  {
    id: 1,
    title: 'CVE-2025-1234',
    description: 'Critical vulnerability in network stack that allows remote code execution without authentication.',
    severity: 'critical',
    cvss: 9.8,
    date: '2025-04-01T10:30:00',
    status: 'open',
    affects: 'libc6 5.1.4',
    exploitability: 'High',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-1234' }
  },
  { 
    id: 2,
    title: 'CVE-2025-5678',
    description: 'High severity buffer overflow in kernel module that allows local privilege escalation.',
    severity: 'high',
    cvss: 8.4,
    date: '2025-04-05T14:20:00',
    status: 'open',
    affects: 'kernel-5.15.0',
    exploitability: 'Medium',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-5678' }
  },
  { 
    id: 3,
    title: 'CVE-2025-9012',
    description: 'Medium severity information disclosure in system service that allows authenticated users to read sensitive information.',
    severity: 'medium',
    cvss: 5.6,
    date: '2025-04-10T09:15:00',
    status: 'open',
    affects: 'systemd 249-5',
    exploitability: 'Low',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-9012' }
  },
  { 
    id: 4,
    title: 'CVE-2025-3456',
    description: 'Low severity XSS vulnerability in web interface that allows attackers to execute arbitrary web scripts.',
    severity: 'low',
    cvss: 3.2,
    date: '2025-04-12T16:45:00',
    status: 'open',
    affects: 'nginx 1.18.0',
    exploitability: 'Low',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-3456' }
  },
  { 
    id: 5,
    title: 'CVE-2025-7890',
    description: 'Critical vulnerability in OpenSSL that allows remote code execution.',
    severity: 'critical',
    cvss: 9.5,
    date: '2025-04-08T11:22:00',
    status: 'open',
    affects: 'openssl 1.1.1k',
    exploitability: 'High',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-7890' }
  },
  { 
    id: 6,
    title: 'CVE-2025-8912',
    description: 'High severity vulnerability in Apache that allows unauthorized access.',
    severity: 'high',
    cvss: 7.8,
    date: '2025-04-07T08:45:00',
    status: 'open',
    affects: 'apache2 2.4.52',
    exploitability: 'Medium',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-8912' }
  },
  { 
    id: 7,
    title: 'CVE-2025-4321',
    description: 'Medium severity vulnerability in Python that allows denial of service.',
    severity: 'medium',
    cvss: 5.2,
    date: '2025-04-09T14:30:00',
    status: 'open',
    affects: 'python3 3.9.7',
    exploitability: 'Low',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-4321' }
  },
  { 
    id: 8,
    title: 'CVE-2025-6543',
    description: 'Low severity vulnerability in Node.js that exposes sensitive information.',
    severity: 'low',
    cvss: 3.8,
    date: '2025-04-10T10:15:00',
    status: 'open',
    affects: 'nodejs 16.13.0',
    exploitability: 'Low',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-6543' }
  },
  { 
    id: 9,
    title: 'CVE-2025-9876',
    description: 'High severity vulnerability in Java that allows arbitrary code execution.',
    severity: 'high',
    cvss: 8.1,
    date: '2025-04-11T09:40:00',
    status: 'open',
    affects: 'openjdk 11.0.14',
    exploitability: 'Medium',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-9876' }
  },
  { 
    id: 10,
    title: 'CVE-2025-2468',
    description: 'Medium severity vulnerability in MySQL that allows unauthorized data access.',
    severity: 'medium',
    cvss: 6.4,
    date: '2025-04-12T13:25:00',
    status: 'open',
    affects: 'mysql-server 8.0.28',
    exploitability: 'Medium',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-2468' }
  },
  { 
    id: 11,
    title: 'CVE-2025-1357',
    description: 'Critical vulnerability in Redis that allows remote code execution.',
    severity: 'critical',
    cvss: 9.3,
    date: '2025-04-13T08:10:00',
    status: 'open',
    affects: 'redis 6.2.6',
    exploitability: 'High',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-1357' }
  },
  { 
    id: 12,
    title: 'CVE-2025-5792',
    description: 'Low severity vulnerability in Nginx that allows information disclosure.',
    severity: 'low',
    cvss: 3.5,
    date: '2025-04-14T11:30:00',
    status: 'open',
    affects: 'nginx 1.20.1',
    exploitability: 'Low',
    reference: { name: 'NVD', url: 'https://nvd.nist.gov/vuln/detail/CVE-2025-5792' }
  },
];

const _unusedSoftwareSamples: Software[] = [
  { id: 1, name: 'Chrome', version: '120.0.6099.217', vendor: 'Google', installDate: '2025-01-15', architecture: 'x64' },
];

// Real data is now fetched via hooks inside the component

interface DeviceDetailsProps {
  device: Device;
  onBack: () => void;
}

const DeviceDetails: React.FC<DeviceDetailsProps> = ({ device, onBack }) => {
  const [selectedTab, setSelectedTab] = useState('vulnerabilities');
  const [vulnViewType, setVulnViewType] = useState<'latest' | 'byDate'>('latest');
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVulnTab, setSelectedVulnTab] = useState<'packages' | 'kernel'>('packages');
  const [softwareSearchQuery, setSearchSoftwareQuery] = useState('');

  // Fetch real data from database using agent ID
  const agentId = typeof device.id === 'string' ? device.id : undefined;
  const { data: systemUsers } = useSystemUsers(agentId);
  const { data: systemGroups } = useSystemGroups(agentId);

  // Fetch port events for this agent
  const { data: portEventsData } = useQuery({
    queryKey: ['port_events', agentId],
    queryFn: async () => {
      if (!agentId) return [];
      const { data, error } = await supabase
        .from('port_events')
        .select('*')
        .eq('agent_id', agentId)
        .order('timestamp', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!agentId
  });

  // Fetch software for this agent
  const { data: softwareData } = useQuery({
    queryKey: ['software_history', agentId],
    queryFn: async () => {
      if (!agentId) return [];
      const { data, error } = await supabase
        .from('software_history')
        .select('*')
        .eq('device_id', agentId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!agentId
  });

  // Fetch vulnerabilities for this agent
  const { data: deviceVulnsData } = useQuery({
    queryKey: ['device_vulnerabilities', agentId],
    queryFn: async () => {
      if (!agentId) return [];
      const { data, error } = await supabase
        .from('device_vulnerabilities')
        .select('*, vulnerability:vulnerabilities!inner(*)')
        .eq('device_id', agentId)
        .is('patched_at', null);
      if (error) throw error;
      return data || [];
    },
    enabled: !!agentId
  });

  // Fetch file permissions for this agent
  const { data: filePermsData } = useQuery({
    queryKey: ['file_permissions', agentId],
    queryFn: async () => {
      if (!agentId) return [];
      const { data, error } = await supabase
        .from('file_permissions')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!agentId
  });

  // Map real vulnerability data to display format
  const realVulnerabilities: VulnerabilityDetail[] = (deviceVulnsData || []).map((dv: any, idx: number) => ({
    id: idx + 1,
    title: dv.vulnerability?.title || dv.vulnerability?.cve_id || 'Unknown',
    description: dv.vulnerability?.description || '',
    severity: dv.vulnerability?.severity || 'medium',
    cvss: dv.vulnerability?.severity === 'critical' ? 9.0 : dv.vulnerability?.severity === 'high' ? 7.5 : dv.vulnerability?.severity === 'medium' ? 5.0 : 3.0,
    date: dv.detected_at || '',
    status: dv.status || 'open',
    affects: (dv.vulnerability?.affected_software || []).join(', ') || 'N/A',
    exploitability: dv.vulnerability?.severity === 'critical' ? 'High' : 'Low',
    reference: {
      name: dv.vulnerability?.cve_id ? 'NVD' : '',
      url: dv.vulnerability?.cve_id ? `https://nvd.nist.gov/vuln/detail/${dv.vulnerability.cve_id}` : ''
    }
  }));

  // Map real software data to display format
  const realSoftware: Software[] = (softwareData || []).map((sw: any, idx: number) => ({
    id: idx + 1,
    name: sw.software_name || '',
    version: sw.current_version || '',
    vendor: '',
    installDate: sw.installed_date || sw.created_at || '',
    architecture: ''
  }));

  const itemsPerPage = 10;
  
  // Filtering vulnerabilities based on search query
  const filteredVulnerabilities = realVulnerabilities.filter(vuln => {
    if (!searchQuery) return true;
    
    return (
      vuln.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vuln.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vuln.affects.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vuln.severity.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });
  
  // Filtering software based on search query
  const filteredSoftware = realSoftware.filter(sw => {
    if (!softwareSearchQuery) return true;
    
    return (
      sw.name.toLowerCase().includes(softwareSearchQuery.toLowerCase()) ||
      sw.version.toLowerCase().includes(softwareSearchQuery.toLowerCase()) ||
      sw.vendor.toLowerCase().includes(softwareSearchQuery.toLowerCase()) ||
      sw.architecture.toLowerCase().includes(softwareSearchQuery.toLowerCase())
    );
  });
  
  // Calculate pagination
  const totalPages = Math.ceil(filteredVulnerabilities.length / itemsPerPage);
  const paginatedVulnerabilities = filteredVulnerabilities.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div>
      {/* Header with device info and back button */}
      <div className="mb-6">
        <button 
          className="text-blue-400 hover:text-blue-300 flex items-center gap-1 text-sm mb-4"
          onClick={onBack}
        >
          <ArrowLeft size={16} />
          Back to devices list
        </button>
        
        <div className="bg-cdm-dark p-4 rounded-lg mb-4">
          <h2 className="text-xl font-bold mb-2">{device.hostname}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-gray-400 text-sm">Operating System</p>
              <p>{device.os} {device.version}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">IP Addresses</p>
              <p>{device.ips.join(', ')}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Last Seen</p>
              <p>{new Date(device.lastTransaction).toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs navigation */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid grid-cols-5 mb-6 bg-cdm-dark">
          <TabsTrigger value="vulnerabilities" className="flex items-center gap-2">
            <FileText size={16} /> Vulnerabilities
          </TabsTrigger>
          <TabsTrigger value="software" className="flex items-center gap-2">
            <List size={16} /> Software List
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users size={16} /> Users/Groups
          </TabsTrigger>
          <TabsTrigger value="ports" className="flex items-center gap-2">
            <Network size={16} /> Ports
          </TabsTrigger>
          <TabsTrigger value="permissions" className="flex items-center gap-2">
            <Lock size={16} /> Permissions
          </TabsTrigger>
        </TabsList>

        {/* Vulnerabilities Tab Content */}
        <TabsContent value="vulnerabilities" className="space-y-4">
          {/* Subtabs for Latest vs By Date */}
          <div className="flex space-x-4 mb-6">
            <button 
              onClick={() => setVulnViewType('latest')}
              className={cn(
                "px-4 py-2 rounded-lg",
                vulnViewType === 'latest' 
                  ? "bg-white text-black" 
                  : "bg-cdm-dark text-white hover:bg-gray-700"
              )}
            >
              Latest Vulnerabilities
            </button>
            <button 
              onClick={() => setVulnViewType('byDate')}
              className={cn(
                "px-4 py-2 rounded-lg",
                vulnViewType === 'byDate' 
                  ? "bg-white text-black" 
                  : "bg-cdm-dark text-white hover:bg-gray-700"
              )}
            >
              Vulnerabilities by date
            </button>
            
            {vulnViewType === 'byDate' && (
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <CalendarIcon className="h-4 w-4" />
                    {date ? format(date, 'PPP') : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            )}
          </div>

          {/* Vulnerability summary boxes */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div className="bg-cdm-dark border-2 border-red-600 rounded-lg p-4 text-center">
              <div className="text-4xl font-bold text-red-500">{device.vulnerabilities.critical}</div>
              <div className="text-red-500">Critical</div>
              <div className="text-xs text-gray-400 mt-2">CVSS 3.2: 9.0-10.0</div>
            </div>
            <div className="bg-cdm-dark border-2 border-orange-500 rounded-lg p-4 text-center">
              <div className="text-4xl font-bold text-orange-500">{device.vulnerabilities.high}</div>
              <div className="text-orange-500">High</div>
              <div className="text-xs text-gray-400 mt-2">CVSS 3.2: 7.0-8.9</div>
            </div>
            <div className="bg-cdm-dark border-2 border-yellow-500 rounded-lg p-4 text-center">
              <div className="text-4xl font-bold text-yellow-500">{device.vulnerabilities.medium}</div>
              <div className="text-yellow-500">Medium</div>
              <div className="text-xs text-gray-400 mt-2">CVSS 3.2: 4.0-6.9</div>
            </div>
            <div className="bg-cdm-dark border-2 border-green-500 rounded-lg p-4 text-center">
              <div className="text-4xl font-bold text-green-500">{device.vulnerabilities.low}</div>
              <div className="text-green-500">Low</div>
              <div className="text-xs text-gray-400 mt-2">CVSS 3.2: 0.1-3.9</div>
            </div>
            <div className="bg-cdm-dark border-2 border-gray-500 rounded-lg p-4 text-center">
              <div className="text-4xl font-bold text-gray-400">{device.vulnerabilities.informational}</div>
              <div className="text-gray-400">Info</div>
              <div className="text-xs text-gray-400 mt-2">CVSS 3.2: 0.0</div>
            </div>
          </div>

          {/* Categories tabs for Packages and Kernel */}
          <div className="bg-cdm-dark p-4 rounded-lg">
            <div className="flex border-b border-gray-700 mb-4">
              <button
                onClick={() => setSelectedVulnTab('packages')}
                className={cn(
                  "py-2 px-4 font-medium relative",
                  selectedVulnTab === 'packages' 
                    ? "text-white border-b-2 border-blue-500" 
                    : "text-gray-400 hover:text-white"
                )}
              >
                Packages
                <span className="inline-flex items-center ml-2 gap-1">
                  <span className="px-1.5 rounded-full bg-red-500 text-white text-xs">14</span>
                  <span className="px-1.5 rounded-full bg-orange-500 text-white text-xs">57</span>
                  <span className="px-1.5 rounded-full bg-yellow-500 text-white text-xs">52</span>
                </span>
              </button>
              
              <button
                onClick={() => setSelectedVulnTab('kernel')}
                className={cn(
                  "py-2 px-4 font-medium relative",
                  selectedVulnTab === 'kernel' 
                    ? "text-white border-b-2 border-blue-500" 
                    : "text-gray-400 hover:text-white"
                )}
              >
                Kernel
                <span className="inline-flex items-center ml-2 gap-1">
                  <span className="px-1.5 rounded-full bg-orange-500 text-white text-xs">47</span>
                  <span className="px-1.5 rounded-full bg-yellow-500 text-white text-xs">26</span>
                </span>
              </button>
            </div>
            
            {/* Search and filter bar */}
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  placeholder="Search vulnerabilities..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-cdm-darker border-gray-700"
                />
              </div>
            </div>
            
            {/* Vulnerabilities table with headers that have filter options */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm table-fixed">
                <thead className="text-gray-400 border-b border-gray-700">
                  <tr>
                    <th className="py-2 text-left font-medium w-1/12">
                      <div className="flex items-center gap-1">
                        <span>CVE</span>
                        <DropdownMenu>
                          <DropdownMenuTrigger>
                            <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => setSearchQuery("CVE-2025")}>
                              Filter by CVE-2025
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("")}>
                              Clear filter
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium w-1/12">
                      <div className="flex items-center gap-1">
                        <span>Severity</span>
                        <DropdownMenu>
                          <DropdownMenuTrigger>
                            <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => setSearchQuery("critical")}>
                              Critical
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("high")}>
                              High
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("medium")}>
                              Medium
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("low")}>
                              Low
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("")}>
                              Clear filter
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium w-1/12">
                      <div className="flex items-center gap-1">
                        <span>CVSS</span>
                        <DropdownMenu>
                          <DropdownMenuTrigger>
                            <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => setSearchQuery("9")}>
                              CVSS 9.0+
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("8")}>
                              CVSS 8.0+
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("")}>
                              Clear filter
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium w-2/12">
                      <div className="flex items-center gap-1">
                        <span>Affects</span>
                        <DropdownMenu>
                          <DropdownMenuTrigger>
                            <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => setSearchQuery("kernel")}>
                              Kernel
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("libc")}>
                              libc
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("")}>
                              Clear filter
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium w-3/12">Description</th>
                    <th className="py-2 text-left font-medium w-1/12">
                      <div className="flex items-center gap-1">
                        <span>Exploitability</span>
                        <DropdownMenu>
                          <DropdownMenuTrigger>
                            <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => setSearchQuery("High")}>
                              High
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("Medium")}>
                              Medium
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("Low")}>
                              Low
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSearchQuery("")}>
                              Clear filter
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium w-1/12">Reference</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedVulnerabilities.length > 0 ? (
                    paginatedVulnerabilities.map(vuln => (
                      <tr key={vuln.id} className="border-b border-gray-700">
                        <td className="py-2 truncate">{vuln.title}</td>
                        <td className="py-2">
                          <span className={cn(
                            "px-2 py-1 rounded text-xs",
                            {
                              "bg-red-900 text-red-300": vuln.severity === 'critical',
                              "bg-orange-900 text-orange-300": vuln.severity === 'high',
                              "bg-yellow-900 text-yellow-300": vuln.severity === 'medium',
                              "bg-blue-900 text-blue-300": vuln.severity === 'low',
                            }
                          )}>
                            {vuln.severity.charAt(0).toUpperCase() + vuln.severity.slice(1)}
                          </span>
                        </td>
                        <td className="py-2">{vuln.cvss}</td>
                        <td className="py-2 truncate">{vuln.affects}</td>
                        <td className="py-2 truncate" title={vuln.description}>
                          {vuln.description}
                        </td>
                        <td className="py-2">{vuln.exploitability}</td>
                        <td className="py-2">
                          <a 
                            href={vuln.reference.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center text-blue-400 hover:text-blue-300"
                            title={vuln.reference.name}
                          >
                            <span>{vuln.reference.name}</span>
                            <ExternalLink size={12} className="ml-1" />
                          </a>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="py-4 text-center text-gray-400">
                        No vulnerabilities found matching your criteria
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {/* Pagination controls */}
            {filteredVulnerabilities.length > 0 && (
              <div className="flex justify-between items-center mt-4">
                <div className="text-sm text-gray-400">
                  Showing {Math.min((currentPage - 1) * itemsPerPage + 1, filteredVulnerabilities.length)} to {Math.min(currentPage * itemsPerPage, filteredVulnerabilities.length)} of {filteredVulnerabilities.length} entries
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="bg-cdm-dark border-gray-700"
                  >
                    <ChevronLeft size={16} />
                  </Button>
                  
                  {Array.from({ length: Math.min(totalPages, 5) }).map((_, idx) => {
                    // Show pages around current page
                    let pageNum = currentPage;
                    if (totalPages <= 5) {
                      pageNum = idx + 1;
                    } else if (currentPage <= 3) {
                      pageNum = idx + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + idx;
                    } else {
                      pageNum = currentPage - 2 + idx;
                    }
                    
                    return (
                      <Button 
                        key={idx}
                        variant={currentPage === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(pageNum)}
                        className={currentPage !== pageNum ? "bg-cdm-dark border-gray-700" : ""}
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages || totalPages === 0}
                    className="bg-cdm-dark border-gray-700"
                  >
                    <ChevronRight size={16} />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Software List Tab Content */}
        <TabsContent value="software" className="space-y-4">
          <div className="bg-cdm-dark p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Installed Software</h3>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  placeholder="Search software..."
                  value={softwareSearchQuery}
                  onChange={(e) => setSearchSoftwareQuery(e.target.value)}
                  className="pl-10 bg-cdm-darker border-gray-700"
                />
              </div>
            </div>
            <table className="w-full text-sm">
              <thead className="text-gray-400 border-b border-gray-700">
                <tr>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Name</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger>
                          <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("Microsoft")}>
                            Microsoft
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("Google")}>
                            Google
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("")}>
                            Clear filter
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Architecture</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger>
                          <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("x64")}>
                            x64
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("x86")}>
                            x86
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("")}>
                            Clear filter
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Version</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger>
                          <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("1.")}>
                            Version 1.x
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("")}>
                            Clear filter
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Vendor</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger>
                          <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("Microsoft")}>
                            Microsoft
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("")}>
                            Clear filter
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Install Date</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger>
                          <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("2025")}>
                            2025
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("2024")}>
                            2024
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setSearchSoftwareQuery("")}>
                            Clear filter
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredSoftware.length > 0 ? (
                  filteredSoftware.map(software => (
                    <tr key={software.id} className="border-b border-gray-700">
                      <td className="py-2">{software.name}</td>
                      <td className="py-2">{software.architecture}</td>
                      <td className="py-2">{software.version}</td>
                      <td className="py-2">{software.vendor}</td>
                      <td className="py-2">{software.installDate}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-4 text-center text-gray-400">
                      No software found matching your criteria
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Users/Groups Tab Content */}
        <TabsContent value="users" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-cdm-dark p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">Users</h3>
              <table className="w-full text-sm">
                <thead className="text-gray-400 border-b border-gray-700">
                  <tr>
                    <th className="py-2 text-left font-medium">
                      <div className="flex items-center gap-1">
                        <span>Username</span>
                        <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium">
                      <div className="flex items-center gap-1">
                        <span>Groups</span>
                        <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {(systemUsers || []).map(user => (
                    <tr key={user.id} className="border-b border-gray-700">
                      <td className="py-2">{user.username}</td>
                      <td className="py-2">{Array.isArray(user.groups) ? user.groups.join(', ') : (user.groups || '')}</td>
                    </tr>
                  ))}
                  {(!systemUsers || systemUsers.length === 0) && (
                    <tr><td colSpan={2} className="py-4 text-center text-gray-500">No user data available</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            
            <div className="bg-cdm-dark p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">Groups</h3>
              <table className="w-full text-sm">
                <thead className="text-gray-400 border-b border-gray-700">
                  <tr>
                    <th className="py-2 text-left font-medium">
                      <div className="flex items-center gap-1">
                        <span>Group Name</span>
                        <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                      </div>
                    </th>
                    <th className="py-2 text-left font-medium">
                      <div className="flex items-center gap-1">
                        <span>Members</span>
                        <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {(systemGroups || []).map(group => (
                    <tr key={group.id} className="border-b border-gray-700">
                      <td className="py-2">{group.group_name}</td>
                      <td className="py-2">{Array.isArray(group.members) ? group.members.join(', ') : (group.members || '')}</td>
                    </tr>
                  ))}
                  {(!systemGroups || systemGroups.length === 0) && (
                    <tr><td colSpan={2} className="py-4 text-center text-gray-500">No group data available</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Ports Tab Content */}
        <TabsContent value="ports" className="space-y-4">
          <div className="bg-cdm-dark p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-4">Open Ports</h3>
            <table className="w-full text-sm">
              <thead className="text-gray-400 border-b border-gray-700">
                <tr>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Port</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Protocol</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Service</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>State</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Process</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {(portEventsData || []).map((port: any) => (
                  <tr key={port.id} className="border-b border-gray-700">
                    <td className="py-2">{port.port_number}</td>
                    <td className="py-2">{port.protocol}</td>
                    <td className="py-2">{port.service || ''}</td>
                    <td className="py-2">{port.status}</td>
                    <td className="py-2">{port.process_name || ''}</td>
                  </tr>
                ))}
                {(!portEventsData || portEventsData.length === 0) && (
                  <tr><td colSpan={5} className="py-4 text-center text-gray-500">No port data available</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Permissions Tab Content */}
        <TabsContent value="permissions" className="space-y-4">
          <div className="bg-cdm-dark p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-4">File System Permissions</h3>
            <p className="text-gray-400 mb-6">Critical files and directories with unusual permissions</p>
            
            <div className="relative flex items-center mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input
                placeholder="Search file paths or permissions..."
                className="pl-10 bg-cdm-darker border-gray-700 w-64"
              />
            </div>
            
            <table className="w-full text-sm">
              <thead className="text-gray-400 border-b border-gray-700">
                <tr>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Path</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Owner</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Permissions</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                  <th className="py-2 text-left font-medium">
                    <div className="flex items-center gap-1">
                      <span>Risk</span>
                      <Filter size={14} className="cursor-pointer text-gray-500 hover:text-white" />
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {(filePermsData || []).map((fp: any) => {
                  const perms = fp.permissions_octal || fp.permissions || '';
                  const isWorldWritable = perms.endsWith('7') || (fp.permissions && fp.permissions.includes('rwxrwxrwx'));
                  const risk = isWorldWritable ? 'High' : fp.is_sensitive ? 'Medium' : 'Low';
                  const riskColor = risk === 'High' ? 'bg-orange-900 text-orange-300' : risk === 'Medium' ? 'bg-yellow-900 text-yellow-300' : 'bg-green-900 text-green-300';
                  return (
                    <tr key={fp.id} className="border-b border-gray-700">
                      <td className="py-2">{fp.file_path}</td>
                      <td className="py-2">{fp.owner || ''}</td>
                      <td className="py-2">{fp.permissions || fp.permissions_octal || ''}</td>
                      <td className="py-2">
                        <span className={`px-2 py-1 rounded text-xs ${riskColor}`}>{risk}</span>
                      </td>
                    </tr>
                  );
                })}
                {(!filePermsData || filePermsData.length === 0) && (
                  <tr><td colSpan={4} className="py-4 text-center text-gray-500">No file permission data available</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DeviceDetails;
