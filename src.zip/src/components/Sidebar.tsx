
import React, { useEffect, useState } from 'react';
import {
  Home,
  Shield,
  Monitor,
  AlertTriangle,
  Settings,
  LogOut,
  CircleDollarSign,
  Key,
  Users2,
  FolderTree,
  History,
  Activity,
  Sun,
  Moon,
  Server,
  FileText,
  Wrench,
  Radar,
  Cloud,
  Bot,
  Globe,
  GitBranch,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import SidebarSubmenu from './SidebarSubmenu';
import { Button } from '@/components/ui/button';

const Sidebar = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const [openSubmenus, setOpenSubmenus] = useState({
    'history': false,
    'vulnerabilities': false,
    'devices': false,
    'users': false,
    'software': false,
    'tools': false,
    'cicd': false,
  });

  const toggleSubmenu = (name: string) => {
    setOpenSubmenus(prev => ({
      ...prev,
      [name]: !prev[name]
    }));
  };

  const isInSubMenuGroup = (paths: string[]) => {
    return paths.some(path => currentPath.startsWith(path));
  };

  const isActivePath = (path: string) => {
    return currentPath === path;
  };

  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleTheme = () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    try { localStorage.setItem('theme', next ? 'dark' : 'light'); } catch {}
  };

  const toggleCollapse = () => {
    const next = !isCollapsed;
    setIsCollapsed(next);
    try { localStorage.setItem('sidebarCollapsed', String(next)); } catch {}
  };

  useEffect(() => {
    try {
      const saved = localStorage.getItem('theme');
      if (saved === 'light') setIsDarkMode(false);
      const savedCollapsed = localStorage.getItem('sidebarCollapsed');
      if (savedCollapsed === 'true') setIsCollapsed(true);
    } catch {}
  }, []);

  useEffect(() => {
    const body = document.body;
    if (!body) return;
    if (isDarkMode) {
      body.classList.remove('light-mode');
    } else {
      body.classList.add('light-mode');
    }
  }, [isDarkMode]);

  return (
    <div className={`sidebar ${isCollapsed ? 'w-16' : 'w-64'} transition-all duration-200 h-screen bg-cdm-darker text-white flex flex-col border-r border-gray-800 flex-shrink-0 overflow-hidden`}>
      <div className="p-4 border-b border-gray-800 flex items-center justify-between min-w-0">
        {!isCollapsed && <h1 className="text-xl font-bold text-white truncate">CRA CDM</h1>}
        <div className={`flex items-center gap-1 ${isCollapsed ? 'mx-auto' : ''}`}>
          {!isCollapsed && (
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="h-8 w-8 text-gray-300 hover:text-white hover:bg-gray-800"
            >
              {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleCollapse}
            className="h-8 w-8 text-gray-300 hover:text-white hover:bg-gray-800 flex-shrink-0"
            title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </Button>
        </div>
      </div>

      <div className="overflow-y-auto flex-grow">
        <nav className="mt-4 px-2 space-y-1">
          <Link to="/" className={`sidebar-item ${isActivePath('/') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Dashboard' : ''}>
            <Home className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Dashboard</span>}
          </Link>

          <Link to="/vulnerabilities" className={`sidebar-item ${isActivePath('/vulnerabilities') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Vulnerabilities' : ''}>
            <Shield className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Vulnerabilities</span>}
          </Link>

          <Link to="/incidents" className={`sidebar-item ${isActivePath('/incidents') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Incidents' : ''}>
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Incidents</span>}
          </Link>

          <Link to="/agents" className={`sidebar-item ${isActivePath('/agents') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Agents Management' : ''}>
            <Monitor className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Agents Management</span>}
          </Link>

          <Link to="/ai-agents" className={`sidebar-item ${isActivePath('/ai-agents') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'AI Agents / Skills' : ''}>
            <Bot className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">AI Agents / Skills</span>}
          </Link>

          {isCollapsed ? (
            <button onClick={toggleCollapse} className={`sidebar-item w-full justify-center px-2 ${isInSubMenuGroup(['/tools/adscan', '/tools/cloudscan', '/tools/webscan', '/tools/cicd']) ? 'active' : ''}`} title="Tools (click to expand)">
              <Wrench className="w-5 h-5 flex-shrink-0" />
            </button>
          ) : (
            <SidebarSubmenu
              title="Tools"
              icon={<Wrench className="w-5 h-5 mr-3" />}
              isOpen={openSubmenus.tools || isInSubMenuGroup(['/tools/adscan', '/tools/cloudscan', '/tools/webscan', '/tools/cicd'])}
              onClick={() => toggleSubmenu('tools')}
            >
              <Link to="/tools/adscan" className={`submenu-item ${isActivePath('/tools/adscan') ? 'active' : ''}`}>
                <Radar className="w-4 h-4 mr-2" />
                <span>ADScan</span>
              </Link>
              <Link to="/tools/cloudscan" className={`submenu-item ${isActivePath('/tools/cloudscan') ? 'active' : ''}`}>
                <Cloud className="w-4 h-4 mr-2" />
                <span>CloudScan</span>
              </Link>
              <Link to="/tools/webscan" className={`submenu-item ${isActivePath('/tools/webscan') ? 'active' : ''}`}>
                <Globe className="w-4 h-4 mr-2" />
                <span>Web/API Scan</span>
              </Link>
              <Link to="/tools/cicd" className={`submenu-item ${isActivePath('/tools/cicd') ? 'active' : ''}`}>
                <GitBranch className="w-4 h-4 mr-2" />
                <span>CI/CD Pipeline</span>
              </Link>
            </SidebarSubmenu>
          )}

          {isCollapsed ? (
            <button onClick={toggleCollapse} className={`sidebar-item w-full justify-center px-2 ${isInSubMenuGroup(['/software-history', '/tools/forensics']) ? 'active' : ''}`} title="Software History & Forensics (click to expand)">
              <History className="w-5 h-5 flex-shrink-0" />
            </button>
          ) : (
            <SidebarSubmenu
              title="Software History & Forensics"
              icon={<History className="w-5 h-5 mr-3" />}
              isOpen={openSubmenus.software || isInSubMenuGroup(['/software-history', '/tools/forensics'])}
              onClick={() => toggleSubmenu('software')}
            >
              <Link to="/software-history" className={`submenu-item ${isActivePath('/software-history') ? 'active' : ''}`}>
                <span>Software History</span>
              </Link>
              <Link to="/tools/forensics" className={`submenu-item ${isActivePath('/tools/forensics') ? 'active' : ''}`}>
                <span>Forensics</span>
              </Link>
            </SidebarSubmenu>
          )}

          {isCollapsed ? (
            <button onClick={toggleCollapse} className={`sidebar-item w-full justify-center px-2 ${isInSubMenuGroup(['/devices']) ? 'active' : ''}`} title="Devices (click to expand)">
              <Server className="w-5 h-5 flex-shrink-0" />
            </button>
          ) : (
            <SidebarSubmenu
              title="Devices"
              icon={<Server className="w-5 h-5 mr-3" />}
              isOpen={openSubmenus.devices || isInSubMenuGroup(['/devices'])}
              onClick={() => toggleSubmenu('devices')}
            >
              <Link to="/devices/all" className={`submenu-item ${isActivePath('/devices/all') ? 'active' : ''}`}>
                <span>All Devices</span>
              </Link>
              <Link to="/devices/groups" className={`submenu-item ${isActivePath('/devices/groups') ? 'active' : ''}`}>
                <span>Device Groups</span>
              </Link>
              <Link to="/devices/inactive" className={`submenu-item ${isActivePath('/devices/inactive') ? 'active' : ''}`}>
                <span>Inactive Devices</span>
              </Link>
              <Link to="/devices/transactions" className={`submenu-item ${isActivePath('/devices/transactions') ? 'active' : ''}`}>
                <span>Transactions</span>
              </Link>
            </SidebarSubmenu>
          )}

          <Link to="/events/ports" className={`sidebar-item ${isActivePath('/events/ports') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Port Events' : ''}>
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Port Events</span>}
          </Link>

          {isCollapsed ? (
            <button onClick={toggleCollapse} className={`sidebar-item w-full justify-center px-2 ${isInSubMenuGroup(['/manage']) ? 'active' : ''}`} title="Users / Groups (click to expand)">
              <Users2 className="w-5 h-5 flex-shrink-0" />
            </button>
          ) : (
            <SidebarSubmenu
              title="Users / Groups"
              icon={<Users2 className="w-5 h-5 mr-3" />}
              isOpen={openSubmenus.users || isInSubMenuGroup(['/manage'])}
              onClick={() => toggleSubmenu('users')}
            >
              <Link to="/manage/users" className={`submenu-item ${isActivePath('/manage/users') ? 'active' : ''}`}>
                <span>Manage Users</span>
              </Link>
              <Link to="/manage/groups" className={`submenu-item ${isActivePath('/manage/groups') ? 'active' : ''}`}>
                <span>Manage Groups</span>
              </Link>
            </SidebarSubmenu>
          )}

          <Link to="/filetree" className={`sidebar-item ${isActivePath('/filetree') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Filetree/Permissions' : ''}>
            <FolderTree className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Filetree/Permissions</span>}
          </Link>

          <Link to="/reports" className={`sidebar-item ${isActivePath('/reports') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Reports' : ''}>
            <FileText className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Reports</span>}
          </Link>

          <Link to="/license" className={`sidebar-item ${isActivePath('/license') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'License Key' : ''}>
            <Key className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">License Key</span>}
          </Link>

          <Link to="/company" className={`sidebar-item ${isActivePath('/company') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Company Staff' : ''}>
            <CircleDollarSign className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Company Staff</span>}
          </Link>

          <Link to="/settings" className={`sidebar-item ${isActivePath('/settings') ? 'active' : ''} ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Settings' : ''}>
            <Settings className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="ml-3">Settings</span>}
          </Link>
        </nav>
      </div>

      <div className="p-4 border-t border-gray-800">
        <Link to="/logout" className={`sidebar-item ${isCollapsed ? 'justify-center px-2' : ''}`} title={isCollapsed ? 'Logout' : ''}>
          <LogOut className="w-5 h-5 flex-shrink-0" />
          {!isCollapsed && <span className="ml-3">Logout</span>}
        </Link>
        {isCollapsed && (
          <button onClick={toggleTheme} className="sidebar-item justify-center px-2 w-full mt-1" title={isDarkMode ? 'Light mode' : 'Dark mode'}>
            {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
