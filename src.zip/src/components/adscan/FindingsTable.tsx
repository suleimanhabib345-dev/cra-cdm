import React, { useState } from 'react';
import { ChevronDown, ChevronRight, ExternalLink, Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import type { Finding, ScanSeverity } from '@/types/adscan';

interface FindingsTableProps {
  findings: Finding[];
}

const severityConfig: Record<ScanSeverity, { bg: string; text: string; border: string; order: number }> = {
  CRITICAL: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-l-red-500', order: 0 },
  HIGH: { bg: 'bg-orange-900/20', text: 'text-orange-400', border: 'border-l-orange-500', order: 1 },
  MEDIUM: { bg: 'bg-blue-900/20', text: 'text-blue-400', border: 'border-l-blue-500', order: 2 },
  LOW: { bg: 'bg-emerald-900/20', text: 'text-emerald-400', border: 'border-l-emerald-500', order: 3 },
  INFO: { bg: 'bg-gray-800/30', text: 'text-gray-400', border: 'border-l-gray-500', order: 4 },
};

const FindingsTable: React.FC<FindingsTableProps> = ({ findings }) => {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<ScanSeverity | 'ALL'>('ALL');

  const toggle = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const expandAll = () => setExpandedIds(new Set(filtered.map(f => f.id)));
  const collapseAll = () => setExpandedIds(new Set());

  const filtered = findings
    .filter(f => {
      if (severityFilter !== 'ALL' && f.severity !== severityFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          f.title.toLowerCase().includes(q) ||
          f.category.toLowerCase().includes(q) ||
          f.description.toLowerCase().includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => severityConfig[a.severity].order - severityConfig[b.severity].order);

  return (
    <div className="bg-cdm-darker rounded-lg border border-gray-800">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
        <h3 className="text-sm font-semibold text-white">
          Findings ({filtered.length})
        </h3>
        <div className="flex items-center gap-2">
          <button onClick={expandAll} className="text-[10px] text-blue-400 hover:text-blue-300">Expand All</button>
          <span className="text-gray-700">|</span>
          <button onClick={collapseAll} className="text-[10px] text-blue-400 hover:text-blue-300">Collapse All</button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 px-4 py-2 border-b border-gray-800/50">
        <div className="relative flex-1 max-w-xs">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <Input
            placeholder="Search findings..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="h-7 pl-7 text-xs bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
          />
        </div>
        <div className="flex items-center gap-1">
          <Filter size={12} className="text-gray-500 mr-1" />
          {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'] as const).map(sev => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                severityFilter === sev
                  ? sev === 'ALL'
                    ? 'bg-gray-700 text-white'
                    : `${severityConfig[sev].bg} ${severityConfig[sev].text}`
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* Findings list */}
      <div className="divide-y divide-gray-800/50 max-h-[500px] overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="py-8 text-center text-sm text-gray-500">No findings match your filters.</div>
        ) : (
          filtered.map(finding => {
            const config = severityConfig[finding.severity];
            const isExpanded = expandedIds.has(finding.id);

            return (
              <div key={finding.id} className={`border-l-2 ${config.border}`}>
                {/* Finding header */}
                <button
                  onClick={() => toggle(finding.id)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
                >
                  {isExpanded ? (
                    <ChevronDown size={14} className="text-gray-500 shrink-0" />
                  ) : (
                    <ChevronRight size={14} className="text-gray-500 shrink-0" />
                  )}
                  <Badge className={`${config.bg} ${config.text} border-0 text-[10px] px-1.5 py-0 shrink-0`}>
                    {finding.severity}
                  </Badge>
                  <span className="text-sm text-white flex-1 truncate">{finding.title}</span>
                  <span className="text-[10px] text-gray-600 shrink-0">{finding.category}</span>
                  <span className="text-[10px] text-gray-600 shrink-0 font-mono">-{finding.riskScore}pts</span>
                </button>

                {/* Expanded details */}
                {isExpanded && (
                  <div className="px-4 pb-4 pl-10 space-y-3 animate-in fade-in duration-200">
                    <p className="text-xs text-gray-400 leading-relaxed">{finding.description}</p>

                    {finding.details.length > 0 && (
                      <div>
                        <h5 className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Affected Objects</h5>
                        <div className="bg-[#0d1117] rounded p-2 space-y-0.5">
                          {finding.details.map((detail, i) => (
                            <div key={i} className="text-xs font-mono text-gray-300 flex items-start gap-2">
                              <span className="text-red-400 shrink-0">•</span>
                              <span>{detail}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <h5 className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Recommendation</h5>
                      <p className="text-xs text-emerald-400/80 leading-relaxed">{finding.recommendation}</p>
                    </div>

                    {finding.references.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {finding.references.map((ref, i) => (
                          <a
                            key={i}
                            href={ref}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] text-blue-400 hover:text-blue-300 transition-colors"
                          >
                            <ExternalLink size={10} />
                            {ref.includes('mitre') ? 'MITRE ATT&CK' : 'Reference'}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default FindingsTable;
