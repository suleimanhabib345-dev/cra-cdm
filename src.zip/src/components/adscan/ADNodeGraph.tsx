import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ZoomIn, ZoomOut, Maximize2, Minimize2, RotateCcw } from 'lucide-react';
import type { GraphData, GraphNode, GraphEdge } from '@/types/adscan';

const GRAPH_STORE = 'cra_graph_';

interface ADNodeGraphProps {
  data: GraphData;
  className?: string;
  persistKey?: string;
}

const NODE_COLORS: Record<GraphNode['type'], string> = {
  user: '#3b82f6',
  group: '#f59e0b',
  computer: '#10b981',
  domain: '#8b5cf6',
  dc: '#ef4444',
  gpo: '#06b6d4',
  ou: '#6b7280',
};

const NODE_SIZES: Record<GraphNode['type'], number> = {
  domain: 24,
  dc: 18,
  group: 16,
  user: 12,
  computer: 14,
  gpo: 12,
  ou: 14,
};

const EDGE_COLORS: Record<GraphEdge['type'], string> = {
  memberOf: '#4b5563',
  adminTo: '#ef4444',
  hasSession: '#3b82f6',
  canRDP: '#10b981',
  delegation: '#f59e0b',
  trust: '#8b5cf6',
  gpLink: '#06b6d4',
  attackPath: '#ef4444',
};

const NODE_ICONS: Record<GraphNode['type'], string> = {
  user: '👤',
  group: '👥',
  computer: '💻',
  domain: '🏢',
  dc: '🖥️',
  gpo: '📋',
  ou: '📁',
};

const ADNodeGraph: React.FC<ADNodeGraphProps> = ({ data, className = '', persistKey }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [isDragging, setIsDragging] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const draggedNodeRef = useRef<GraphNode | null>(null);
  const nodesRef = useRef<GraphNode[]>([]);
  const animFrame = useRef<number>(0);
  const persistKeyRef = useRef(persistKey);
  persistKeyRef.current = persistKey;

  // Esc to exit fullscreen
  useEffect(() => {
    if (!isExpanded) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setIsExpanded(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [isExpanded]);

  // Initialize nodes with force simulation positions
  useEffect(() => {
    if (!data.nodes.length) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.width;
    const height = canvas.height;

    // Initialize nodes in a circle layout, then simulate forces
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.35;

    // Restore saved positions if available
    const pk = persistKeyRef.current;
    if (pk) {
      try {
        const saved = JSON.parse(localStorage.getItem(GRAPH_STORE + pk) || 'null') as Record<string, { x: number; y: number }> | null;
        if (saved && data.nodes.every(n => n.id in saved)) {
          nodesRef.current = data.nodes.map(n => ({ ...n, x: saved[n.id].x, y: saved[n.id].y, vx: 0, vy: 0 }));
          draw();
          return;
        }
      } catch {}
    }

    nodesRef.current = data.nodes.map((node, i) => {
      const angle = (2 * Math.PI * i) / data.nodes.length;
      return {
        ...node,
        x: centerX + radius * Math.cos(angle) + (Math.random() - 0.5) * 40,
        y: centerY + radius * Math.sin(angle) + (Math.random() - 0.5) * 40,
        vx: 0,
        vy: 0,
      };
    });

    // Run force simulation
    let iterations = 0;
    const maxIterations = 200;

    const simulate = () => {
      if (iterations >= maxIterations) {
        draw();
        const pk2 = persistKeyRef.current;
        if (pk2) {
          const pos: Record<string, { x: number; y: number }> = {};
          for (const n of nodesRef.current) pos[n.id] = { x: n.x, y: n.y };
          try { localStorage.setItem(GRAPH_STORE + pk2, JSON.stringify(pos)); } catch {}
        }
        return;
      }

      const alpha = 1 - iterations / maxIterations;
      const nodes = nodesRef.current;

      // Repulsion between all nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[j].x - nodes[i].x;
          const dy = nodes[j].y - nodes[i].y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = (800 * alpha) / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          nodes[i].vx -= fx;
          nodes[i].vy -= fy;
          nodes[j].vx += fx;
          nodes[j].vy += fy;
        }
      }

      // Attraction along edges
      for (const edge of data.edges) {
        const source = nodes.find(n => n.id === edge.source);
        const target = nodes.find(n => n.id === edge.target);
        if (!source || !target) continue;

        const dx = target.x - source.x;
        const dy = target.y - source.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = (dist - 120) * 0.01 * alpha;
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        source.vx += fx;
        source.vy += fy;
        target.vx -= fx;
        target.vy -= fy;
      }

      // Center gravity
      for (const node of nodes) {
        node.vx += (centerX - node.x) * 0.001 * alpha;
        node.vy += (centerY - node.y) * 0.001 * alpha;
      }

      // Apply velocities with damping
      for (const node of nodes) {
        node.vx *= 0.6;
        node.vy *= 0.6;
        node.x += node.vx;
        node.y += node.vy;
        // Bounds
        node.x = Math.max(40, Math.min(width - 40, node.x));
        node.y = Math.max(40, Math.min(height - 40, node.y));
      }

      iterations++;
      draw();
      animFrame.current = requestAnimationFrame(simulate);
    };

    simulate();

    return () => cancelAnimationFrame(animFrame.current);
  }, [data]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x: tx, y: ty, scale } = transform;
    const nodes = nodesRef.current;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(tx, ty);
    ctx.scale(scale, scale);

    // Draw edges
    for (const edge of data.edges) {
      const source = nodes.find(n => n.id === edge.source);
      const target = nodes.find(n => n.id === edge.target);
      if (!source || !target) continue;

      const isAttackPath = edge.type === 'attackPath';
      ctx.beginPath();
      ctx.moveTo(source.x, source.y);
      ctx.lineTo(target.x, target.y);
      ctx.strokeStyle = EDGE_COLORS[edge.type] || '#4b5563';
      ctx.lineWidth = isAttackPath ? 2.5 : 1;
      ctx.globalAlpha = isAttackPath ? 0.9 : 0.4;
      if (isAttackPath) {
        ctx.setLineDash([6, 4]);
      } else {
        ctx.setLineDash([]);
      }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;

      // Arrow head
      const angle = Math.atan2(target.y - source.y, target.x - source.x);
      const targetSize = NODE_SIZES[target.type] || 12;
      const arrowX = target.x - Math.cos(angle) * (targetSize + 4);
      const arrowY = target.y - Math.sin(angle) * (targetSize + 4);
      const arrowSize = isAttackPath ? 8 : 5;

      ctx.beginPath();
      ctx.moveTo(arrowX, arrowY);
      ctx.lineTo(
        arrowX - arrowSize * Math.cos(angle - Math.PI / 6),
        arrowY - arrowSize * Math.sin(angle - Math.PI / 6)
      );
      ctx.lineTo(
        arrowX - arrowSize * Math.cos(angle + Math.PI / 6),
        arrowY - arrowSize * Math.sin(angle + Math.PI / 6)
      );
      ctx.closePath();
      ctx.fillStyle = EDGE_COLORS[edge.type] || '#4b5563';
      ctx.globalAlpha = isAttackPath ? 0.9 : 0.5;
      ctx.fill();
      ctx.globalAlpha = 1;

      // Edge label
      if (isAttackPath) {
        const midX = (source.x + target.x) / 2;
        const midY = (source.y + target.y) / 2;
        ctx.font = '9px monospace';
        ctx.fillStyle = '#ef4444';
        ctx.textAlign = 'center';
        ctx.fillText(edge.label, midX, midY - 6);
      }
    }

    // Draw nodes
    for (const node of nodes) {
      const size = NODE_SIZES[node.type] || 12;
      const color = NODE_COLORS[node.type] || '#6b7280';
      const isHovered = hoveredNode?.id === node.id;
      const isSelected = selectedNode?.id === node.id;

      // Glow for severity
      if (node.severity) {
        const glowColors: Record<string, string> = {
          CRITICAL: 'rgba(239, 68, 68, 0.3)',
          HIGH: 'rgba(245, 158, 11, 0.25)',
          MEDIUM: 'rgba(59, 130, 246, 0.2)',
          LOW: 'rgba(16, 185, 129, 0.15)',
        };
        ctx.beginPath();
        ctx.arc(node.x, node.y, size + 8, 0, Math.PI * 2);
        ctx.fillStyle = glowColors[node.severity] || 'transparent';
        ctx.fill();
      }

      // Node circle
      ctx.beginPath();
      ctx.arc(node.x, node.y, size, 0, Math.PI * 2);
      ctx.fillStyle = isSelected ? '#ffffff' : color;
      ctx.fill();

      // Border
      ctx.strokeStyle = isHovered ? '#ffffff' : isSelected ? color : 'rgba(255,255,255,0.2)';
      ctx.lineWidth = isHovered || isSelected ? 2.5 : 1;
      ctx.stroke();

      // Icon
      ctx.font = `${size * 0.9}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(NODE_ICONS[node.type] || '', node.x, node.y);

      // Label
      ctx.font = `${isHovered ? 'bold ' : ''}10px Inter, system-ui, sans-serif`;
      ctx.fillStyle = isHovered ? '#ffffff' : '#9ca3af';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText(node.label, node.x, node.y + size + 4);
    }

    ctx.restore();

    // Draw tooltip for hovered node
    if (hoveredNode) {
      const sx = hoveredNode.x * scale + tx;
      const sy = hoveredNode.y * scale + ty;
      const tooltipW = 180;
      const tooltipH = hoveredNode.details ? 52 : 36;
      const tooltipX = Math.min(sx + 20, canvas.width - tooltipW - 10);
      const tooltipY = Math.max(sy - 20, 10);

      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.strokeStyle = 'rgba(71, 85, 105, 0.5)';
      ctx.lineWidth = 1;
      roundedRect(ctx, tooltipX, tooltipY, tooltipW, tooltipH, 6);

      ctx.font = 'bold 11px Inter, system-ui, sans-serif';
      ctx.fillStyle = '#f1f5f9';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(`${NODE_ICONS[hoveredNode.type]} ${hoveredNode.label}`, tooltipX + 8, tooltipY + 8);

      ctx.font = '10px Inter, system-ui, sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(`Type: ${hoveredNode.type}`, tooltipX + 8, tooltipY + 24);

      if (hoveredNode.details) {
        ctx.fillStyle = hoveredNode.severity === 'CRITICAL' ? '#ef4444' : hoveredNode.severity === 'HIGH' ? '#f59e0b' : '#94a3b8';
        ctx.fillText(hoveredNode.details, tooltipX + 8, tooltipY + 38);
      }
    }
  }, [data.edges, hoveredNode, selectedNode, transform]);

  useEffect(() => {
    draw();
  }, [draw]);

  // Canvas resize — re-run when isExpanded changes so portal canvas gets measured
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const observer = new ResizeObserver(() => {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
      draw();
    });

    observer.observe(container);
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    draw();

    return () => observer.disconnect();
  }, [draw, isExpanded]);

  // Mouse interactions
  const getNodeAtPos = useCallback(
    (mx: number, my: number): GraphNode | null => {
      const { x: tx, y: ty, scale } = transform;
      const worldX = (mx - tx) / scale;
      const worldY = (my - ty) / scale;

      for (let i = nodesRef.current.length - 1; i >= 0; i--) {
        const node = nodesRef.current[i];
        const size = NODE_SIZES[node.type] || 12;
        const dx = worldX - node.x;
        const dy = worldY - node.y;
        if (dx * dx + dy * dy <= (size + 4) * (size + 4)) {
          return node;
        }
      }
      return null;
    },
    [transform]
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;

      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;

      // Node dragging — pin dragged node, spring-pull connected nodes
      if (draggedNodeRef.current) {
        const { x: tx, y: ty, scale } = transform;
        const pinnedId = draggedNodeRef.current.id;
        draggedNodeRef.current.x = (mx - tx) / scale;
        draggedNodeRef.current.y = (my - ty) / scale;
        draggedNodeRef.current.vx = 0;
        draggedNodeRef.current.vy = 0;

        const nodes = nodesRef.current;
        const canvas = canvasRef.current;
        if (canvas) {
          const w = canvas.width, h = canvas.height;
          for (let s = 0; s < 3; s++) {
            for (const edge of data.edges) {
              const src = nodes.find(n => n.id === edge.source);
              const tgt = nodes.find(n => n.id === edge.target);
              if (!src || !tgt) continue;
              const dx = tgt.x - src.x;
              const dy = tgt.y - src.y;
              const dist = Math.sqrt(dx * dx + dy * dy) || 1;
              const f = (dist - 120) * 0.025;
              const fx = (dx / dist) * f;
              const fy = (dy / dist) * f;
              if (src.id !== pinnedId) { src.vx += fx; src.vy += fy; }
              if (tgt.id !== pinnedId) { tgt.vx -= fx; tgt.vy -= fy; }
            }
            for (const node of nodes) {
              if (node.id === pinnedId) continue;
              node.vx *= 0.65;
              node.vy *= 0.65;
              node.x = Math.max(40, Math.min(w - 40, node.x + node.vx));
              node.y = Math.max(40, Math.min(h - 40, node.y + node.vy));
            }
          }
        }

        draw();
        return;
      }

      if (isDragging) {
        setTransform(prev => ({
          ...prev,
          x: prev.x + (e.clientX - dragStart.current.x),
          y: prev.y + (e.clientY - dragStart.current.y),
        }));
        dragStart.current = { x: e.clientX, y: e.clientY };
        return;
      }

      const node = getNodeAtPos(mx, my);
      setHoveredNode(node);
      if (canvasRef.current) {
        canvasRef.current.style.cursor = node ? 'grab' : 'default';
      }
    },
    [isDragging, getNodeAtPos, transform, draw]
  );

  const handleMouseDown = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;

      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const node = getNodeAtPos(mx, my);

      if (node) {
        draggedNodeRef.current = node;
        setSelectedNode(node);
        if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
      } else {
        setIsDragging(true);
        dragStart.current = { x: e.clientX, y: e.clientY };
        if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
      }
    },
    [getNodeAtPos]
  );

  const handleMouseUp = useCallback(() => {
    if (draggedNodeRef.current) {
      const pk = persistKeyRef.current;
      if (pk) {
        const pos: Record<string, { x: number; y: number }> = {};
        for (const n of nodesRef.current) pos[n.id] = { x: n.x, y: n.y };
        try { localStorage.setItem(GRAPH_STORE + pk, JSON.stringify(pos)); } catch {}
      }
    }
    draggedNodeRef.current = null;
    setIsDragging(false);
    if (canvasRef.current) canvasRef.current.style.cursor = hoveredNode ? 'grab' : 'default';
  }, [hoveredNode]);

  const handleWheel = useCallback((e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const delta = e.deltaY > 0 ? 0.9 : 1.1;

    setTransform(prev => {
      const newScale = Math.max(0.3, Math.min(3, prev.scale * delta));
      const ratio = newScale / prev.scale;
      return {
        scale: newScale,
        x: mx - (mx - prev.x) * ratio,
        y: my - (my - prev.y) * ratio,
      };
    });
  }, []);

  const resetView = () => setTransform({ x: 0, y: 0, scale: 1 });
  const zoomIn = () => setTransform(prev => ({ ...prev, scale: Math.min(3, prev.scale * 1.2) }));
  const zoomOut = () => setTransform(prev => ({ ...prev, scale: Math.max(0.3, prev.scale / 1.2) }));

  return (
    <>
      <div className={`relative flex flex-col bg-[#0d1117] rounded-lg border border-gray-800 overflow-hidden ${isExpanded ? 'fixed inset-4 z-50' : ''} ${className}`}>
        <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-gray-800">
          <span className="text-xs font-medium text-gray-400">AD Relationship Graph</span>
          <div className="flex items-center gap-1">
            <button onClick={zoomOut} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors" title="Zoom out"><ZoomOut size={12} /></button>
            <button onClick={zoomIn} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors" title="Zoom in"><ZoomIn size={12} /></button>
            <button onClick={resetView} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors" title="Reset view"><RotateCcw size={12} /></button>
            <button onClick={() => setIsExpanded(!isExpanded)} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors" title={isExpanded ? 'Minimize' : 'Maximize'}>
              {isExpanded ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
            </button>
          </div>
        </div>
        <div ref={containerRef} className={`${isExpanded ? 'flex-1' : 'h-[480px]'}`}>
          <canvas ref={canvasRef} onMouseMove={handleMouseMove} onMouseDown={handleMouseDown} onMouseUp={handleMouseUp} onMouseLeave={handleMouseUp} onWheel={handleWheel} className="w-full h-full" />
        </div>
        <div className="flex flex-wrap items-center gap-3 px-4 py-2 bg-[#161b22] border-t border-gray-800">
          {Object.entries(NODE_COLORS).map(([type, color]) => (
            <div key={type} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
              <span className="text-[10px] text-gray-500 capitalize">{type}</span>
            </div>
          ))}
          <div className="ml-2 flex items-center gap-1.5">
            <span className="w-4 h-0.5 bg-red-500" style={{ borderTop: '2px dashed #ef4444' }} />
            <span className="text-[10px] text-gray-500">Attack Path</span>
          </div>
        </div>
        {selectedNode && (
          <div className="absolute bottom-12 left-4 bg-[#0f172a]/95 border border-gray-700 rounded-lg p-3 max-w-[220px] backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <span>{NODE_ICONS[selectedNode.type]}</span>
              <span className="text-sm font-medium text-white">{selectedNode.label}</span>
            </div>
            <div className="text-xs text-gray-400">Type: {selectedNode.type}</div>
            {selectedNode.severity && (
              <div className={`text-xs mt-1 ${selectedNode.severity === 'CRITICAL' ? 'text-red-400' : selectedNode.severity === 'HIGH' ? 'text-amber-400' : 'text-blue-400'}`}>
                Severity: {selectedNode.severity}
              </div>
            )}
            {selectedNode.details && <div className="text-xs text-gray-300 mt-1">{selectedNode.details}</div>}
          </div>
        )}
      </div>
      {isExpanded && <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setIsExpanded(false)} />}
    </>
  );
};

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
}

export default ADNodeGraph;
