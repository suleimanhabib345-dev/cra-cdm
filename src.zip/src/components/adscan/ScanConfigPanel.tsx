import React, { useState } from 'react';
import { Play, Loader2, Server, KeyRound, Hash, Shield, Square } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import type { ScanConfig } from '@/types/adscan';

interface ScanConfigPanelProps {
  onStartScan: (config: ScanConfig) => void;
  onStopScan?: () => void;
  isRunning: boolean;
}

const ScanConfigPanel: React.FC<ScanConfigPanelProps> = ({ onStartScan, onStopScan, isRunning }) => {
  const [config, setConfig] = useState<ScanConfig>({
    domain: '',
    username: '',
    password: '',
    hash: '',
    authMethod: 'password',
    dcIp: '',
    useLdaps: true,
    selectedChecks: [],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStartScan(config);
  };

  const updateConfig = (field: keyof ScanConfig, value: string | boolean | string[]) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="bg-cdm-darker rounded-lg border border-gray-800 p-5">
      <div className="flex items-center gap-2 mb-4">
        <Shield size={16} className="text-red-400" />
        <h3 className="text-sm font-semibold text-white">Scan Configuration</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Domain */}
        <div className="space-y-1.5">
          <Label htmlFor="domain" className="text-xs text-gray-400">
            <Server size={12} className="inline mr-1" />
            Domain
          </Label>
          <Input
            id="domain"
            placeholder="corp.local"
            value={config.domain}
            onChange={e => updateConfig('domain', e.target.value)}
            className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
            required
          />
        </div>

        {/* DC IP */}
        <div className="space-y-1.5">
          <Label htmlFor="dcIp" className="text-xs text-gray-400">
            DC IP (optional)
          </Label>
          <Input
            id="dcIp"
            placeholder="Auto-resolve via DNS"
            value={config.dcIp}
            onChange={e => updateConfig('dcIp', e.target.value)}
            className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
          />
        </div>

        {/* Username */}
        <div className="space-y-1.5">
          <Label htmlFor="username" className="text-xs text-gray-400">
            Username
          </Label>
          <Input
            id="username"
            placeholder="admin"
            value={config.username}
            onChange={e => updateConfig('username', e.target.value)}
            className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
            required
          />
        </div>

        {/* Auth Method Toggle + Credential */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label className="text-xs text-gray-400">
              {config.authMethod === 'password' ? (
                <><KeyRound size={12} className="inline mr-1" />Password</>
              ) : (
                <><Hash size={12} className="inline mr-1" />NT Hash</>
              )}
            </Label>
            <button
              type="button"
              onClick={() => updateConfig('authMethod', config.authMethod === 'password' ? 'hash' : 'password')}
              className="text-[10px] text-blue-400 hover:text-blue-300 transition-colors"
            >
              Switch to {config.authMethod === 'password' ? 'hash' : 'password'}
            </button>
          </div>
          {config.authMethod === 'password' ? (
            <Input
              type="password"
              placeholder="••••••••"
              value={config.password}
              onChange={e => updateConfig('password', e.target.value)}
              className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
              required={config.authMethod === 'password'}
            />
          ) : (
            <Input
              placeholder="aad3b435b51404ee:31d6cfe0..."
              value={config.hash}
              onChange={e => updateConfig('hash', e.target.value)}
              className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white font-mono placeholder:text-gray-600"
              required={config.authMethod === 'hash'}
            />
          )}
        </div>
      </div>

      {/* Options row */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-800">
        <div className="flex items-center gap-2">
          <Switch
            checked={config.useLdaps}
            onCheckedChange={(checked) => updateConfig('useLdaps', checked)}
            className="data-[state=checked]:bg-emerald-600"
          />
          <span className="text-xs text-gray-400">Use LDAPS (port 636)</span>
        </div>

        <div className="flex items-center gap-2">
          {isRunning && onStopScan && (
            <Button
              type="button"
              onClick={onStopScan}
              className="bg-gray-700 hover:bg-gray-600 text-white text-sm h-8 px-4 gap-1.5"
            >
              <Square size={13} />
              STOP
            </Button>
          )}
          <Button
            type="submit"
            disabled={isRunning || !config.domain || !config.username}
            className="bg-red-600 hover:bg-red-700 text-white text-sm h-8 px-4 disabled:opacity-50"
          >
            {isRunning ? (
              <>
                <Loader2 size={14} className="mr-2 animate-spin" />
                Scanning...
              </>
            ) : (
              <>
                <Play size={14} className="mr-2" />
                Start Scan
              </>
            )}
          </Button>
        </div>
      </div>
    </form>
  );
};

export default ScanConfigPanel;
