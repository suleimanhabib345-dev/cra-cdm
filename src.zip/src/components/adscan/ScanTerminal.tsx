import React, { useEffect, useRef, useState } from 'react';
import { Terminal, Maximize2, Minimize2, Trash2, Pause, Play } from 'lucide-react';
import type { TerminalLine } from '@/types/adscan';

interface ScanTerminalProps {
  lines: TerminalLine[];
  isRunning: boolean;
  className?: string;
}

const lineColorMap: Record<TerminalLine['type'], string> = {
  info: 'text-blue-400',
  success: 'text-emerald-400',
  warning: 'text-amber-400',
  error: 'text-red-400',
  system: 'text-purple-400',
  check: 'text-cyan-400',
};

const ScanTerminal: React.FC<ScanTerminalProps> = ({ lines, isRunning, className = '' }) => {
  const terminalRef = useRef<HTMLDivElement>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [displayedLines, setDisplayedLines] = useState<TerminalLine[]>([]);
  const lineIndexRef = useRef(0);

  useEffect(() => {
    if (!isExpanded) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setIsExpanded(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [isExpanded]);

  useEffect(() => {
    if (isPaused) return;
    if (lines.length === 0) {
      setDisplayedLines([]);
      lineIndexRef.current = 0;
      return;
    }
    if (lines.length > lineIndexRef.current) {
      setDisplayedLines(lines.slice());
      lineIndexRef.current = lines.length;
    }
  }, [lines, isPaused]);

  useEffect(() => {
    if (terminalRef.current && !isPaused) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [displayedLines, isPaused]);

  const clearTerminal = () => {
    setDisplayedLines([]);
    lineIndexRef.current = 0;
  };

  return (
    <>
      <div className={`scan-terminal flex flex-col bg-[#0d1117] rounded-lg border border-gray-800 overflow-hidden ${isExpanded ? 'fixed inset-4 z-50' : ''} ${className}`}>
        {/* Terminal Header */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-gray-800">
          <div className="flex items-center gap-2">
            <Terminal size={14} className="text-emerald-400" />
            <span className="text-xs font-mono text-gray-400">Vulnerability Scan</span>
            {isRunning && (
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <span className="text-xs text-emerald-400 font-mono">LIVE</span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
              title={isPaused ? 'Resume' : 'Pause'}
            >
              {isPaused ? <Play size={12} /> : <Pause size={12} />}
            </button>
            <button
              onClick={clearTerminal}
              className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
              title="Clear"
            >
              <Trash2 size={12} />
            </button>
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
              title={isExpanded ? 'Minimize' : 'Maximize'}
            >
              {isExpanded ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        <div
          ref={terminalRef}
          className={`overflow-y-auto p-3 font-mono text-xs leading-5 ${isExpanded ? 'flex-1' : 'h-[280px]'}`}
          style={{ backgroundColor: '#0d1117' }}
        >
          {displayedLines.length === 0 ? (
            <div className="text-gray-600 flex items-center gap-2">
              <span className="text-emerald-500">$</span>
              <span>Waiting for scan to start...</span>
              <span className="animate-pulse">▊</span>
            </div>
          ) : (
            displayedLines.map((line, idx) =>
              line ? (
                <div key={line.id ?? idx} className="flex gap-2 hover:bg-white/[0.02] px-1 -mx-1 rounded">
                  <span className="text-gray-600 select-none shrink-0">{line.timestamp}</span>
                  <span className={lineColorMap[line.type] || 'text-gray-400'}>{line.message}</span>
                </div>
              ) : null
            )
          )}
          {isRunning && displayedLines.length > 0 && (
            <div className="flex gap-2 px-1 -mx-1">
              <span className="text-gray-600 select-none shrink-0">
                {displayedLines[displayedLines.length - 1]?.timestamp}
              </span>
              <span className="text-emerald-500 animate-pulse">▊</span>
            </div>
          )}
        </div>

        {/* Terminal Footer */}
        <div className="flex items-center justify-between px-4 py-1.5 bg-[#161b22] border-t border-gray-800 text-[10px] text-gray-600 font-mono">
          <span>{displayedLines.length} lines</span>
          <span>{isRunning ? (isPaused ? 'PAUSED' : 'SCANNING...') : displayedLines.length > 0 ? 'COMPLETE' : 'READY'}</span>
        </div>
      </div>

      {isExpanded && (
        <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setIsExpanded(false)} />
      )}
    </>
  );
};

export default ScanTerminal;
