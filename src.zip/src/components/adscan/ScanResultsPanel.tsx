import React from 'react';
import {
  Shield, AlertTriangle, Info, TrendingDown, Users, Key, Monitor,
  Lock, Network, FileWarning
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import type { ScanStats, ScanSeverity } from '@/types/adscan';

interface ScanResultsPanelProps {
  stats: ScanStats;
  domain: string;
}

const riskColors: Record<string, { bg: string; text: string; bar: string }> = {
  CRITICAL: { bg: 'bg-red-900/20', text: 'text-red-400', bar: 'bg-red-500' },
  HIGH: { bg: 'bg-orange-900/20', text: 'text-orange-400', bar: 'bg-orange-500' },
  MEDIUM: { bg: 'bg-blue-900/20', text: 'text-blue-400', bar: 'bg-blue-500' },
  LOW: { bg: 'bg-emerald-900/20', text: 'text-emerald-400', bar: 'bg-emerald-500' },
};

const ScanResultsPanel: React.FC<ScanResultsPanelProps> = ({ stats, domain }) => {
  const riskConfig = riskColors[stats.riskLevel] || riskColors.MEDIUM;

  return (
    <div className="space-y-4">
      {/* Risk Score Header */}
      <div className={`${riskConfig.bg} rounded-lg border border-gray-800 p-5`}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-lg font-bold text-white">{domain}</h3>
            <p className="text-xs text-gray-400 mt-0.5">
              {stats.completedChecks}/{stats.totalChecks} checks completed
            </p>
          </div>
          <div className="text-right">
            <div className={`text-3xl font-bold ${riskConfig.text}`}>
              {stats.riskScore}<span className="text-lg text-gray-500">/100</span>
            </div>
            <span className={`text-xs font-semibold ${riskConfig.text}`}>
              {stats.riskLevel} RISK
            </span>
          </div>
        </div>
        <Progress value={stats.riskScore} className="h-2 bg-gray-800" />
        <div className="flex justify-between mt-1">
          <span className="text-[10px] text-gray-600">Critical (0)</span>
          <span className="text-[10px] text-gray-600">Low (100)</span>
        </div>
      </div>

      {/* Severity Breakdown */}
      <div className="grid grid-cols-5 gap-2">
        {(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'] as ScanSeverity[]).map(sev => {
          const count = stats.findingsCount[sev] || 0;
          const colors: Record<ScanSeverity, string> = {
            CRITICAL: 'border-red-500/30 text-red-400',
            HIGH: 'border-orange-500/30 text-orange-400',
            MEDIUM: 'border-blue-500/30 text-blue-400',
            LOW: 'border-emerald-500/30 text-emerald-400',
            INFO: 'border-gray-500/30 text-gray-400',
          };
          return (
            <div key={sev} className={`bg-cdm-darker rounded-lg border ${colors[sev].split(' ')[0]} p-3 text-center`}>
              <div className={`text-xl font-bold ${colors[sev].split(' ')[1]}`}>{count}</div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">{sev}</div>
            </div>
          );
        })}
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <MetricTile
          icon={<Key size={14} />}
          label="Kerberoastable"
          value={stats.kerberoastableAccounts}
          color={stats.kerberoastableAccounts > 0 ? 'text-red-400' : 'text-emerald-400'}
        />
        <MetricTile
          icon={<Network size={14} />}
          label="Unconstrained Deleg."
          value={stats.unconstrainedDelegation}
          color={stats.unconstrainedDelegation > 0 ? 'text-red-400' : 'text-emerald-400'}
        />
        <MetricTile
          icon={<Users size={14} />}
          label="adminCount=1"
          value={stats.adminCountAccounts}
          color="text-amber-400"
        />
        <MetricTile
          icon={<Lock size={14} />}
          label="LAPS Coverage"
          value={`${stats.lapsConverage}%`}
          color={stats.lapsConverage < 80 ? 'text-amber-400' : 'text-emerald-400'}
        />
        <MetricTile
          icon={<Monitor size={14} />}
          label="Deprecated OS"
          value={stats.deprecatedOsCount}
          color={stats.deprecatedOsCount > 0 ? 'text-amber-400' : 'text-emerald-400'}
        />
        <MetricTile
          icon={<FileWarning size={14} />}
          label="Stale Accounts"
          value={stats.staleAccounts}
          color={stats.staleAccounts > 2 ? 'text-amber-400' : 'text-emerald-400'}
        />
      </div>
    </div>
  );
};

function MetricTile({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <div className="bg-cdm-darker rounded-lg border border-gray-800 p-3 flex items-center gap-3">
      <div className="p-2 rounded-md bg-gray-800/50 text-gray-400">{icon}</div>
      <div>
        <div className={`text-lg font-bold ${color}`}>{value}</div>
        <div className="text-[10px] text-gray-500">{label}</div>
      </div>
    </div>
  );
}

export default ScanResultsPanel;
