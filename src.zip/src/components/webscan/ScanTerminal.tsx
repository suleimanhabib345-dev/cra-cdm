import React, { useEffect, useRef, useState } from 'react';
import { Terminal, Maximize2, Minimize2, Pause, Play, Trash2 } from 'lucide-react';
import type { TerminalLine } from '@/types/adscan';

interface ScanTerminalProps {
  lines: TerminalLine[];
  isRunning: boolean;
  className?: string;
}

const lineColorMap: Record<TerminalLine['type'], string> = {
  info: 'text-blue-400',
  success: 'text-emerald-400',
  warning: 'text-amber-400',
  error: 'text-red-400',
  system: 'text-purple-400',
  check: 'text-cyan-400',
};

const ScanTerminal: React.FC<ScanTerminalProps> = ({ lines, isRunning, className = '' }) => {
  const terminalRef = useRef<HTMLDivElement>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [displayedLines, setDisplayedLines] = useState<TerminalLine[]>([]);
  const lineIndexRef = useRef(0);

  // Immediate display — no animation delay, no replay on remount
  useEffect(() => {
    if (isPaused) return;
    if (lines.length === 0) {
      setDisplayedLines([]);
      lineIndexRef.current = 0;
      return;
    }
    if (lines.length > lineIndexRef.current) {
      setDisplayedLines(lines.slice());
      lineIndexRef.current = lines.length;
    }
  }, [lines, isPaused]);

  // Auto-scroll
  useEffect(() => {
    if (!isPaused && terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [displayedLines, isPaused]);

  return (
    <>
    <div className={`scan-terminal flex flex-col bg-[#0d1117] rounded-lg border border-gray-800 overflow-hidden ${isExpanded ? 'fixed inset-4 z-50' : ''} ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#161b22] border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Terminal size={14} className="text-emerald-400" />
          <span className="text-xs font-medium text-gray-300">System Log</span>
          {isRunning && (
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] text-emerald-400">LIVE</span>
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
            title={isPaused ? 'Resume' : 'Pause'}
          >
            {isPaused ? <Play size={12} /> : <Pause size={12} />}
          </button>
          <button
            onClick={() => { setDisplayedLines([]); lineIndexRef.current = 0; }}
            className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
            title="Clear"
          >
            <Trash2 size={12} />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
            title={isExpanded ? 'Minimize' : 'Maximize'}
          >
            {isExpanded ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
          </button>
        </div>
      </div>

      {/* Terminal body */}
      <div
        ref={terminalRef}
        className={`overflow-y-auto font-mono text-xs p-3 space-y-0.5 ${isExpanded ? 'flex-1' : 'h-[280px]'}`}
        style={{ backgroundColor: '#0d1117' }}
      >
        {displayedLines.length === 0 ? (
          <div className="text-gray-600 flex items-center gap-2 py-4 justify-center">
            <Terminal size={14} />
            <span>Waiting for scan output...</span>
          </div>
        ) : (
          displayedLines.map((line) => (
            <div key={line.id} className="flex gap-2 leading-5">
              <span className="text-gray-600 select-none w-16 flex-shrink-0 text-right">
                {line.timestamp}
              </span>
              <span className={lineColorMap[line.type] || 'text-gray-400'}>
                {line.message}
              </span>
            </div>
          ))
        )}
        {isRunning && (
          <div className="flex items-center gap-1 text-gray-600 mt-1">
            <span className="animate-pulse">_</span>
          </div>
        )}
      </div>
    </div>

      {isExpanded && (
        <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setIsExpanded(false)} />
      )}
    </>
  );
};

export default ScanTerminal;
