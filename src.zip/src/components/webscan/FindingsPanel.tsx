import React, { useState } from 'react';
import { Shield, ChevronDown, ExternalLink, Copy, CheckCircle2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { WebVulnerability, WebVulnSeverity } from '@/types/webscan';

interface FindingsPanelProps {
  findings: WebVulnerability[];
  className?: string;
}

const SEV_COLORS: Record<WebVulnSeverity, { bg: string; text: string; border: string }> = {
  critical: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-red-500/30' },
  high: { bg: 'bg-orange-900/30', text: 'text-orange-400', border: 'border-orange-500/30' },
  medium: { bg: 'bg-amber-900/30', text: 'text-amber-400', border: 'border-amber-500/30' },
  low: { bg: 'bg-blue-900/30', text: 'text-blue-400', border: 'border-blue-500/30' },
  info: { bg: 'bg-gray-800', text: 'text-gray-400', border: 'border-gray-700' },
};

const FindingsPanel: React.FC<FindingsPanelProps> = ({ findings, className = '' }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filter, setFilter] = useState<WebVulnSeverity | 'all'>('all');

  const filtered = filter === 'all' ? findings : findings.filter(f => f.severity === filter);

  const counts: Record<WebVulnSeverity, number> = {
    critical: findings.filter(f => f.severity === 'critical').length,
    high: findings.filter(f => f.severity === 'high').length,
    medium: findings.filter(f => f.severity === 'medium').length,
    low: findings.filter(f => f.severity === 'low').length,
    info: findings.filter(f => f.severity === 'info').length,
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (findings.length === 0) {
    return (
      <div className={`bg-cdm-darker rounded-lg border border-gray-800 p-8 flex flex-col items-center justify-center ${className}`}>
        <Shield size={32} className="text-gray-700 mb-3" />
        <h3 className="text-sm font-semibold text-white mb-1">No findings yet</h3>
        <p className="text-xs text-gray-600">Vulnerabilities will appear here during the scan</p>
      </div>
    );
  }

  return (
    <div className={`space-y-3 ${className}`}>
      {/* Severity summary */}
      <div className="grid grid-cols-5 gap-2">
        {(['critical', 'high', 'medium', 'low', 'info'] as const).map(sev => (
          <button
            key={sev}
            onClick={() => setFilter(filter === sev ? 'all' : sev)}
            className={`rounded-lg border p-3 transition-colors ${SEV_COLORS[sev].bg} ${SEV_COLORS[sev].border} ${
              filter === sev ? 'ring-1 ring-white/20' : ''
            }`}
          >
            <div className={`text-2xl font-bold ${SEV_COLORS[sev].text}`}>{counts[sev]}</div>
            <div className={`text-[10px] capitalize ${SEV_COLORS[sev].text} opacity-80`}>{sev}</div>
          </button>
        ))}
      </div>

      {/* Findings list */}
      <div className="space-y-2">
        {filtered.map(vuln => {
          const colors = SEV_COLORS[vuln.severity];
          const isExpanded = expandedId === vuln.id;

          return (
            <div key={vuln.id} className={`bg-cdm-darker rounded-lg border ${colors.border} overflow-hidden`}>
              <button
                onClick={() => setExpandedId(isExpanded ? null : vuln.id)}
                className="w-full flex items-center justify-between p-4 text-left hover:bg-white/[0.01] transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge className={`${colors.bg} ${colors.text} border-0 text-[10px] px-2 uppercase font-bold`}>
                      {vuln.severity}
                    </Badge>
                    <span className="text-[11px] text-gray-500">CVSS {vuln.cvss}</span>
                    {vuln.cwe && <span className="text-[10px] text-gray-600">{vuln.cwe}</span>}
                  </div>
                  <h4 className="text-sm font-medium text-white">{vuln.title}</h4>
                  <div className="flex items-center gap-2 mt-1.5">
                    <Badge variant="outline" className="text-[10px] border-gray-700 text-gray-500 font-mono">
                      {vuln.method} {vuln.endpoint}
                    </Badge>
                    {vuln.parameter && (
                      <Badge variant="outline" className="text-[10px] border-gray-700 text-amber-500 font-mono">
                        {vuln.parameter}
                      </Badge>
                    )}
                  </div>
                </div>
                <ChevronDown
                  size={16}
                  className={`text-gray-500 transition-transform flex-shrink-0 ml-3 ${isExpanded ? 'rotate-180' : ''}`}
                />
              </button>

              {isExpanded && (
                <div className="px-4 pb-4 border-t border-gray-800/50 pt-3 space-y-3">
                  <div>
                    <h5 className="text-xs font-semibold text-gray-400 mb-1">Description</h5>
                    <p className="text-xs text-gray-300">{vuln.description}</p>
                  </div>

                  {vuln.affectedEndpoints && vuln.affectedEndpoints.length > 1 && (
                    <div>
                      <h5 className="text-xs font-semibold text-gray-400 mb-1">
                        Affected Endpoints ({vuln.affectedEndpoints.length})
                      </h5>
                      <div className="space-y-0.5 max-h-32 overflow-y-auto">
                        {vuln.affectedEndpoints.map((ep, i) => (
                          <code key={i} className="text-[10px] text-cyan-400 bg-gray-900 px-2 py-0.5 rounded block font-mono break-all">
                            {ep}
                          </code>
                        ))}
                      </div>
                    </div>
                  )}

                  {vuln.evidence && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h5 className="text-xs font-semibold text-gray-400">Evidence</h5>
                        <button
                          onClick={() => handleCopy(vuln.evidence!, vuln.id)}
                          className="text-gray-600 hover:text-gray-400 p-0.5"
                        >
                          {copiedId === vuln.id ? <CheckCircle2 size={11} className="text-emerald-400" /> : <Copy size={11} />}
                        </button>
                      </div>
                      <code className="text-xs text-red-400 bg-gray-900 px-2 py-1.5 rounded block font-mono break-all">
                        {vuln.evidence}
                      </code>
                    </div>
                  )}

                  {vuln.request && (
                    <div>
                      <h5 className="text-xs font-semibold text-gray-400 mb-1">Request</h5>
                      <pre className="text-[10px] text-gray-400 bg-gray-900 px-2 py-1.5 rounded font-mono overflow-x-auto max-h-32">
                        {vuln.request}
                      </pre>
                    </div>
                  )}

                  <div>
                    <h5 className="text-xs font-semibold text-gray-400 mb-1">Remediation</h5>
                    <p className="text-xs text-gray-300">{vuln.remediation}</p>
                  </div>

                  {vuln.references && vuln.references.length > 0 && (
                    <div>
                      <h5 className="text-xs font-semibold text-gray-400 mb-1">References</h5>
                      <div className="space-y-0.5">
                        {vuln.references.map((ref, i) => (
                          <a
                            key={i}
                            href={ref}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                          >
                            <ExternalLink size={9} />
                            {ref}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default FindingsPanel;
