import React, { useState } from 'react';
import {
  Globe, Maximize2, Minimize2, RefreshCw, ExternalLink,
  ChevronLeft, ChevronRight, MousePointer2,
} from 'lucide-react';

interface BrowserOverlayProps {
  screenshotBase64: string | null;
  currentUrl: string;
  pageTitle: string;
  isNavigating: boolean;
  isRunning: boolean;
  className?: string;
}

const BrowserOverlay: React.FC<BrowserOverlayProps> = ({
  screenshotBase64,
  currentUrl,
  pageTitle,
  isNavigating,
  isRunning,
  className = '',
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <>
    <div className={`flex flex-col bg-[#0d1117] rounded-lg border border-gray-800 overflow-hidden ${isExpanded ? 'fixed inset-4 z-50' : ''} ${className}`}>
      {/* Chrome-style browser toolbar */}
      <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-900/80 border-b border-gray-800 min-w-0">
        {/* Traffic lights */}
        <div className="flex items-center gap-1.5 mr-1 flex-shrink-0">
          <div className="w-3 h-3 rounded-full bg-red-500/80" />
          <div className="w-3 h-3 rounded-full bg-amber-500/80" />
          <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
        </div>

        {/* Navigation buttons */}
        <button className="p-1 rounded hover:bg-gray-700 text-gray-500 flex-shrink-0">
          <ChevronLeft size={14} />
        </button>
        <button className="p-1 rounded hover:bg-gray-700 text-gray-500 flex-shrink-0">
          <ChevronRight size={14} />
        </button>
        <button className={`p-1 rounded hover:bg-gray-700 text-gray-500 flex-shrink-0 ${isNavigating ? 'animate-spin' : ''}`}>
          <RefreshCw size={14} />
        </button>

        {/* URL bar — truncates in normal view, full in fullscreen */}
        <div className="flex-1 min-w-0 flex items-center gap-1.5 bg-gray-800 rounded-md px-2 py-1 mx-1">
          {isRunning && (
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse flex-shrink-0" />
          )}
          <Globe size={11} className="text-gray-500 flex-shrink-0" />
          <span
            className="text-xs text-gray-300 font-mono min-w-0 flex-1"
            style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
            title={currentUrl || 'about:blank'}
          >
            {currentUrl || 'about:blank'}
          </span>
          {currentUrl && (
            <a
              href={currentUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-gray-400 flex-shrink-0"
              onClick={e => e.stopPropagation()}
            >
              <ExternalLink size={10} />
            </a>
          )}
        </div>

        {/* Expand button — always visible */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-white flex-shrink-0"
          title={isExpanded ? 'Minimize' : 'Maximize'}
        >
          {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
        </button>
      </div>

      {/* Page title */}
      {pageTitle && (
        <div className="px-3 py-1 bg-gray-900/50 border-b border-gray-800/50">
          <span className="text-[10px] text-gray-500 truncate block">{pageTitle}</span>
        </div>
      )}

      {/* Browser viewport */}
      <div className={`relative bg-gray-950 ${isExpanded ? 'flex-1' : 'h-[280px]'}`}>
        {screenshotBase64 ? (
          <img
            src={`data:image/jpeg;base64,${screenshotBase64}`}
            alt="Browser view"
            className="w-full h-full object-contain"
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-700">
            {isRunning ? (
              <>
                <div className="w-8 h-8 border-2 border-gray-700 border-t-red-500 rounded-full animate-spin mb-3" />
                <span className="text-xs">Loading page...</span>
              </>
            ) : (
              <>
                <MousePointer2 size={32} className="mb-3" />
                <span className="text-xs">Browser viewport</span>
                <span className="text-[10px] text-gray-800 mt-1">Start a scan to see live browser interactions</span>
              </>
            )}
          </div>
        )}

        {/* Navigating overlay */}
        {isNavigating && screenshotBase64 && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          </div>
        )}
      </div>
    </div>

      {isExpanded && (
        <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setIsExpanded(false)} />
      )}
    </>
  );
};

export default BrowserOverlay;
