import React, { useState } from 'react';
import { Wrench, ChevronDown, Clock, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { MCPToolCall } from '@/types/webscan';

interface ToolCallsPanelProps {
  toolCalls: MCPToolCall[];
  className?: string;
}

const statusIcon: Record<string, React.ReactNode> = {
  pending: <Loader2 size={12} className="animate-spin text-gray-500" />,
  running: <Loader2 size={12} className="animate-spin text-cyan-400" />,
  success: <CheckCircle2 size={12} className="text-emerald-400" />,
  error: <AlertCircle size={12} className="text-red-400" />,
};

const ToolCallsPanel: React.FC<ToolCallsPanelProps> = ({ toolCalls, className = '' }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (toolCalls.length === 0) {
    return (
      <div className={`bg-cdm-darker rounded-lg border border-gray-800 p-6 flex flex-col items-center justify-center ${className}`}>
        <Wrench size={24} className="text-gray-700 mb-2" />
        <span className="text-xs text-gray-600">No MCP tool calls yet</span>
      </div>
    );
  }

  return (
    <div className={`bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden ${className}`}>
      <div className="flex items-center justify-between px-3 py-2 bg-gray-900/80 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Wrench size={14} className="text-cyan-400" />
          <span className="text-xs font-medium text-gray-300">MCP Tool Calls</span>
          <Badge className="bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{toolCalls.length}</Badge>
        </div>
      </div>

      <div className="max-h-[300px] overflow-y-auto divide-y divide-gray-800/50">
        {toolCalls.map(tc => {
          const isExpanded = expandedId === tc.id;

          return (
            <div key={tc.id}>
              <button
                onClick={() => setExpandedId(isExpanded ? null : tc.id)}
                className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-white/[0.01] transition-colors"
              >
                {statusIcon[tc.status] || statusIcon.success}
                <span className="text-xs font-mono text-cyan-300 flex-shrink-0">{tc.tool}</span>
                <span className="text-[10px] text-gray-600 truncate flex-1">
                  {JSON.stringify(tc.params).slice(0, 60)}
                </span>
                {tc.duration !== undefined && (
                  <span className="text-[10px] text-gray-600 flex-shrink-0 flex items-center gap-0.5">
                    <Clock size={9} />
                    {tc.duration}ms
                  </span>
                )}
                <ChevronDown
                  size={12}
                  className={`text-gray-600 transition-transform flex-shrink-0 ${isExpanded ? 'rotate-180' : ''}`}
                />
              </button>

              {isExpanded && (
                <div className="px-3 pb-2 space-y-1.5 ml-6">
                  <div>
                    <span className="text-[10px] text-gray-500 block mb-0.5">Parameters</span>
                    <pre className="text-[10px] text-gray-400 bg-gray-900 rounded px-2 py-1 overflow-x-auto font-mono">
                      {JSON.stringify(tc.params, null, 2)}
                    </pre>
                  </div>
                  {tc.result !== undefined && (
                    <div>
                      <span className="text-[10px] text-gray-500 block mb-0.5">Result</span>
                      <pre className="text-[10px] text-gray-400 bg-gray-900 rounded px-2 py-1 overflow-x-auto font-mono">
                        {typeof tc.result === 'string' ? tc.result : JSON.stringify(tc.result, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ToolCallsPanel;
