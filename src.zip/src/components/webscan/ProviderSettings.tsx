import React, { useState, useEffect } from 'react';
import {
  Settings2, Eye, EyeOff, CheckCircle2, AlertCircle, Loader2, X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { AIProviderConfig, AIProviderType } from '@/types/webscan';
import { DEFAULT_MODELS } from '@/types/webscan';
import { loadProviderConfig, saveProviderConfig, testAIProvider } from '@/services/webscanService';

interface ProviderSettingsProps {
  open: boolean;
  onClose: () => void;
  onSave: (config: AIProviderConfig) => void;
}

const PROVIDERS: { id: AIProviderType; label: string; note?: string }[] = [
  { id: 'openai', label: 'OpenAI' },
  { id: 'anthropic', label: 'Anthropic' },
  { id: 'openrouter', label: 'OpenRouter', note: 'Multi-model gateway' },
  { id: 'groq', label: 'Groq', note: 'Ultra-fast inference' },
  { id: 'gemini', label: 'Google Gemini', note: 'Flash & Pro models' },
  { id: 'custom', label: 'Custom / Local' },
];

const PROVIDER_BASE_URLS: Partial<Record<AIProviderType, string>> = {
  openrouter: 'https://openrouter.ai/api/v1',
  groq: 'https://api.groq.com/openai/v1',
  gemini: 'https://generativelanguage.googleapis.com/v1beta/openai',
};

const ProviderSettings: React.FC<ProviderSettingsProps> = ({ open, onClose, onSave }) => {
  const [providerType, setProviderType] = useState<AIProviderType>('openai');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('gpt-4o');
  const [baseUrl, setBaseUrl] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'ok' | 'error'>('idle');
  const [testError, setTestError] = useState('');

  // Load saved config
  useEffect(() => {
    const saved = loadProviderConfig();
    if (saved) {
      setProviderType(saved.type);
      setApiKey(saved.apiKey);
      setModel(saved.model);
      setBaseUrl(saved.baseUrl || '');
    }
  }, [open]);

  // Update base URL when provider changes (model is free-text, leave it)
  useEffect(() => {
    const knownUrl = PROVIDER_BASE_URLS[providerType];
    if (knownUrl) setBaseUrl(knownUrl);
    else if (providerType !== 'custom') setBaseUrl('');
  }, [providerType]);

  const friendlyError = (raw: string): string => {
    if (/429|quota|rate.?limit|RESOURCE_EXHAUSTED|free.?tier/i.test(raw))
      return 'API quota exhausted — check your plan or wait for the daily reset.';
    if (/401|unauthorized|invalid.?api.?key|authentication/i.test(raw))
      return 'Invalid API key — double-check and try again.';
    if (/404|not.?found/i.test(raw))
      return 'Model not found — verify the model name is correct for this provider.';
    if (/403|forbidden/i.test(raw))
      return 'Access denied — your key may lack permission for this model.';
    if (/network|fetch|ECONNREFUSED|connect/i.test(raw))
      return 'Cannot reach the provider — check the Base URL or your network.';
    if (raw.length > 120) return raw.slice(0, 120) + '…';
    return raw;
  };

  const handleTest = async () => {
    setTestStatus('testing');
    setTestError('');
    const result = await testAIProvider({
      provider: providerType,
      apiKey,
      model,
      baseUrl: baseUrl || undefined,
    });
    if (result.status === 'ok') {
      setTestStatus('ok');
    } else {
      setTestStatus('error');
      setTestError(friendlyError(result.error || 'Connection failed'));
    }
  };

  const handleSave = () => {
    const config: AIProviderConfig = {
      id: `provider-${Date.now()}`,
      name: PROVIDERS.find(p => p.id === providerType)?.label || providerType,
      type: providerType,
      apiKey,
      model,
      baseUrl: baseUrl || undefined,
    };
    saveProviderConfig(config);
    onSave(config);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black/70" onClick={onClose} />
      <div className="theme-dark relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-lg overflow-hidden m-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <Settings2 size={18} className="text-red-400" />
            AI Provider Settings
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Provider selection */}
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Provider</label>
            <div className="grid grid-cols-3 gap-2">
              {PROVIDERS.map(p => (
                <button
                  key={p.id}
                  onClick={() => setProviderType(p.id)}
                  className={`px-3 py-2 rounded-md border text-xs font-medium transition-colors text-left ${
                    providerType === p.id
                      ? 'border-red-500 bg-red-900/10 text-white'
                      : 'border-gray-700 text-gray-400 hover:border-gray-600'
                  }`}
                >
                  <div>{p.label}</div>
                  {p.note && <div className="text-[9px] text-gray-600 font-normal mt-0.5">{p.note}</div>}
                </button>
              ))}
            </div>
          </div>

          {/* API Key */}
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">API Key</label>
            <div className="relative">
              <Input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={e => { setApiKey(e.target.value); setTestStatus('idle'); }}
                placeholder={
                  providerType === 'openai' ? 'sk-...' :
                  providerType === 'anthropic' ? 'sk-ant-...' :
                  providerType === 'openrouter' ? 'sk-or-...' :
                  providerType === 'groq' ? 'gsk_...' :
                  providerType === 'gemini' ? 'AIzaSy...' :
                  'Enter API key'
                }
                className="bg-cdm-dark border-gray-700 text-white pr-10"
              />
              <button
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showKey ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          {/* Model */}
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Model</label>
            <Input
              value={model}
              onChange={e => { setModel(e.target.value); setTestStatus('idle'); }}
              placeholder={DEFAULT_MODELS[providerType][0] || 'e.g., gpt-4o'}
              className="bg-cdm-dark border-gray-700 text-white font-mono text-sm"
            />
            {DEFAULT_MODELS[providerType].length > 0 && (
              <div className="flex flex-wrap gap-1 mt-1.5">
                {DEFAULT_MODELS[providerType].map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setModel(m)}
                    className={`text-[10px] px-1.5 py-0.5 rounded border transition-colors ${
                      model === m
                        ? 'border-red-500/50 bg-red-900/10 text-red-400'
                        : 'border-gray-700 text-gray-600 hover:text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Base URL (for custom/openrouter/groq/gemini) */}
          {(providerType === 'custom' || providerType === 'openrouter' || providerType === 'groq' || providerType === 'gemini' || baseUrl) && (
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Base URL (optional)</label>
              <Input
                value={baseUrl}
                onChange={e => setBaseUrl(e.target.value)}
                placeholder="https://api.example.com/v1"
                className="bg-cdm-dark border-gray-700 text-white"
              />
            </div>
          )}

          {/* Test result */}
          {testStatus !== 'idle' && (
            <div className={`flex items-center gap-2 px-3 py-2 rounded-md text-xs ${
              testStatus === 'ok'
                ? 'bg-emerald-900/20 text-emerald-400 border border-emerald-500/20'
                : testStatus === 'error'
                  ? 'bg-red-900/20 text-red-400 border border-red-500/20'
                  : 'bg-gray-800 text-gray-400'
            }`}>
              {testStatus === 'testing' && <Loader2 size={14} className="animate-spin" />}
              {testStatus === 'ok' && <CheckCircle2 size={14} />}
              {testStatus === 'error' && <AlertCircle size={14} />}
              <span>
                {testStatus === 'testing' && 'Testing connection...'}
                {testStatus === 'ok' && 'Connection successful'}
                {testStatus === 'error' && (testError || 'Connection failed')}
              </span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-800">
          <Button
            variant="outline"
            onClick={handleTest}
            disabled={!apiKey || testStatus === 'testing'}
            className="border-gray-700 text-gray-400 gap-2"
          >
            {testStatus === 'testing' ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
            Test Connection
          </Button>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="border-gray-700 text-gray-400">
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={!apiKey || !model}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Save
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderSettings;
