
import React, { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import { useLocation } from 'react-router-dom';

type SidebarSubmenuProps = {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isOpen?: boolean;
  onClick?: () => void;
  count?: number;
  isRed?: boolean;
  noAutoClose?: boolean;
};

const SidebarSubmenu = ({ 
  title, 
  icon, 
  children, 
  isOpen: externalIsOpen, 
  onClick,
  count,
  isRed,
  noAutoClose
}: SidebarSubmenuProps) => {
  // Use internal state if no external state is provided
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  
  // Determine which isOpen value to use
  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;
  
  // Get current location to highlight active items
  const location = useLocation();
  
  // Function to toggle submenu visibility
  const toggleSubmenu = () => {
    if (onClick) {
      onClick();
    } else {
      setInternalIsOpen(!internalIsOpen);
    }
  };
  
  // Determine if any child route is active to highlight the submenu
  const isChildActive = React.Children.toArray(children).some((child: any) => {
    if (child.props && child.props.to) {
      return location.pathname.startsWith(child.props.to);
    }
    return false;
  });
  
  return (
    <div className="relative">
      <button 
        onClick={toggleSubmenu} 
        className={`w-full flex items-center justify-between px-4 py-2 text-sm rounded-md transition-colors ${
          isRed
            ? 'bg-red-900/20 hover:bg-red-900/30 text-red-200'
            : isChildActive
              ? 'hover:bg-gray-700 text-white'
              : 'hover:bg-gray-800 text-gray-300 hover:text-white'
        }`}
        style={!isRed && isChildActive ? { backgroundColor: 'rgba(6,182,212,0.15)' } : undefined}
      >
        <div className="flex items-center">
          {icon}
          <span className="ml-2">{title}</span>
        </div>
        <div className="flex items-center">
          {count !== undefined && (
            <span className={`px-2 py-0.5 rounded-full text-xs mr-2 ${
              isRed ? 'bg-red-800 text-red-200' : 'bg-gray-700 text-gray-300'
            }`}>
              {count}
            </span>
          )}
          <ChevronDown 
            size={16} 
            className={`transition-transform ${isOpen ? 'transform rotate-180' : ''}`} 
          />
        </div>
      </button>
      
      <div className={`mt-1 ml-8 pl-4 border-l border-gray-700 space-y-1 overflow-hidden transition-all duration-200 ${
        isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
      }`}>
        {children}
      </div>
    </div>
  );
};

export default SidebarSubmenu;
