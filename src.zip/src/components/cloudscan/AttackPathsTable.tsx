import React, { useState } from 'react';
import { ChevronDown, ChevronRight, ExternalLink, Search, Filter, Crosshair } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import type { AttackPath, CloudSeverity, AttackPathCategory } from '@/types/cloudscan';
import { CATEGORY_LABELS } from '@/types/cloudscan';

interface AttackPathsTableProps {
  paths: AttackPath[];
}

const sevConfig: Record<CloudSeverity, { bg: string; text: string; border: string; order: number; icon: string }> = {
  critical: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-l-red-500', order: 0, icon: '◆' },
  high: { bg: 'bg-orange-900/20', text: 'text-orange-400', border: 'border-l-orange-500', order: 1, icon: '▲' },
  medium: { bg: 'bg-blue-900/20', text: 'text-blue-400', border: 'border-l-blue-500', order: 2, icon: '●' },
  low: { bg: 'bg-emerald-900/20', text: 'text-emerald-400', border: 'border-l-emerald-500', order: 3, icon: '○' },
  info: { bg: 'bg-gray-800/30', text: 'text-gray-400', border: 'border-l-gray-500', order: 4, icon: '·' },
};

const exploitColors: Record<string, string> = {
  trivial: 'text-red-400',
  easy: 'text-orange-400',
  moderate: 'text-blue-400',
  difficult: 'text-emerald-400',
};

const AttackPathsTable: React.FC<AttackPathsTableProps> = ({ paths }) => {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<CloudSeverity | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<AttackPathCategory | 'all'>('all');

  const toggle = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const expandAll = () => setExpandedIds(new Set(filtered.map(p => p.id)));
  const collapseAll = () => setExpandedIds(new Set());

  const filtered = paths
    .filter(p => {
      if (severityFilter !== 'all' && p.severity !== severityFilter) return false;
      if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
      }
      return true;
    })
    .sort((a, b) => sevConfig[a.severity].order - sevConfig[b.severity].order);

  const categories = [...new Set(paths.map(p => p.category))];

  return (
    <div className="bg-cdm-darker rounded-lg border border-gray-800">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Crosshair size={14} className="text-cyan-400" />
          Attack Paths ({filtered.length})
        </h3>
        <div className="flex items-center gap-2">
          <button onClick={expandAll} className="text-[10px] text-cyan-400 hover:text-cyan-300">Expand All</button>
          <span className="text-gray-700">|</span>
          <button onClick={collapseAll} className="text-[10px] text-cyan-400 hover:text-cyan-300">Collapse All</button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 px-4 py-2 border-b border-gray-800/50">
        <div className="relative flex-1 max-w-xs">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <Input
            placeholder="Search attack paths..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="h-7 pl-7 text-xs bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
          />
        </div>
        <div className="flex items-center gap-1">
          <Filter size={12} className="text-gray-500 mr-1" />
          {(['all', 'critical', 'high', 'medium', 'low'] as const).map(sev => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                severityFilter === sev
                  ? sev === 'all' ? 'bg-gray-700 text-white' : `${sevConfig[sev].bg} ${sevConfig[sev].text}`
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {sev === 'all' ? 'ALL' : sev.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(categoryFilter === cat ? 'all' : cat)}
              className={`px-2 py-0.5 rounded text-[10px] transition-colors ${
                categoryFilter === cat ? 'bg-cyan-900/30 text-cyan-400' : 'text-gray-600 hover:text-gray-400'
              }`}
            >
              {CATEGORY_LABELS[cat] || cat}
            </button>
          ))}
        </div>
      </div>

      {/* Paths list */}
      <div className="divide-y divide-gray-800/50 max-h-[600px] overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="py-8 text-center text-sm text-gray-500">No attack paths match your filters.</div>
        ) : (
          filtered.map(path => {
            const sc = sevConfig[path.severity];
            const isExpanded = expandedIds.has(path.id);

            return (
              <div key={path.id} className={`border-l-2 ${sc.border}`}>
                <button
                  onClick={() => toggle(path.id)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
                >
                  {isExpanded ? <ChevronDown size={14} className="text-gray-500 shrink-0" /> : <ChevronRight size={14} className="text-gray-500 shrink-0" />}
                  <Badge className={`${sc.bg} ${sc.text} border-0 text-[10px] px-1.5 py-0 shrink-0`}>
                    {sc.icon} {path.severity.toUpperCase()}
                  </Badge>
                  <span className="text-sm text-white flex-1 truncate">{path.name}</span>
                  <Badge className={`bg-gray-800/50 border-0 text-[10px] px-1.5 py-0 ${exploitColors[path.exploitability]}`}>
                    {path.exploitability}
                  </Badge>
                  <span className="text-[10px] text-gray-600 shrink-0">{CATEGORY_LABELS[path.category]}</span>
                </button>

                {isExpanded && (
                  <div className="px-4 pb-4 pl-10 space-y-3 animate-in fade-in duration-200">
                    <p className="text-xs text-gray-400 leading-relaxed">{path.description}</p>

                    {/* Steps */}
                    <div>
                      <h5 className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Exploitation Steps</h5>
                      <div className="bg-[#0d1117] rounded p-2 space-y-1">
                        {path.steps.map((step, i) => (
                          <div key={i} className="text-xs text-gray-300 flex items-start gap-2">
                            <span className="text-cyan-500 font-mono shrink-0">{i + 1}.</span>
                            <span>{step}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* MITRE */}
                    {path.mitreTechniques.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {path.mitreTechniques.map(t => (
                          <Badge key={t} className="bg-purple-900/20 text-purple-400 border-0 text-[10px] px-1.5">
                            {t}
                          </Badge>
                        ))}
                      </div>
                    )}

                    {/* Detection */}
                    <div>
                      <h5 className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Detection Opportunities</h5>
                      <div className="space-y-0.5">
                        {path.detectionOpportunities.map((d, i) => (
                          <div key={i} className="text-xs text-amber-400/70 flex items-start gap-2">
                            <span className="text-amber-500 shrink-0">⚡</span>
                            <span>{d}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Remediation */}
                    <div>
                      <h5 className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Remediation</h5>
                      <div className="space-y-0.5">
                        {path.remediation.map((r, i) => (
                          <div key={i} className="text-xs text-emerald-400/80 flex items-start gap-2">
                            <span className="text-emerald-500 shrink-0">→</span>
                            <span>{r}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Affected Resources */}
                    <div className="flex flex-wrap gap-1.5">
                      {path.affectedResources.map((r, i) => (
                        <span key={i} className="text-[10px] font-mono text-gray-500 bg-gray-800/50 px-2 py-0.5 rounded">
                          {r}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default AttackPathsTable;
