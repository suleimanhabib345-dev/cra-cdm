import React, { useState, useEffect, useRef } from 'react';
import { Play, Square, Loader2, Cloud, KeyRound, User, Globe, Bot, CheckCircle2, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { CLOUD_PROVIDERS, AWS_REGIONS } from '@/types/cloudscan';
import type { CloudScanConfig as CloudScanConfigType, CloudProvider } from '@/types/cloudscan';
import { loadProviderConfig } from '@/services/aiProviderService';
import { fetchAgentList } from '@/services/cloudscanService';

const CONFIG_STORAGE_KEY = 'cra_cloudscan_config';
const CLOUD_AGENTS_KEY = 'cra_ai_agents_cloud';
const AI_ENABLED_KEY = 'cra_cloudscan_ai_enabled';

/** Map old scope-* IDs to cra-cl-* until containers are rebuilt. */
function normalizeAgentId(id: string): string {
  return id.startsWith('scope-') ? id.replace(/^scope-/, 'cra-cl-') : id;
}

/** Read cloud agents from AIAgents storage and build an override map (id → instructions). */
// Only these 4 top-level agents may be overridden; subagents are immutable.
const OVERRIDABLE_AGENT_IDS = new Set([
  'cra-cl-audit', 'cra-cl-defend', 'cra-cl-exploit', 'cra-cl-hunt',
]);

function loadCloudAgentOverrides(): Record<string, string> {
  try {
    const raw = localStorage.getItem(CLOUD_AGENTS_KEY);
    if (!raw) return {};
    const agents = JSON.parse(raw);
    if (!Array.isArray(agents)) return {};
    const overrides: Record<string, string> = {};
    for (const a of agents) {
      const id = normalizeAgentId(String(a.id ?? ''));
      if (
        id &&
        OVERRIDABLE_AGENT_IDS.has(id) &&
        a.instructions &&
        !String(a.instructions).startsWith('[Loading')
      ) {
        overrides[id] = String(a.instructions);
      }
    }
    return overrides;
  } catch { return {}; }
}

// Static descriptions for known DV-CLOUD agents; shown in the agent selector.
const AGENT_DESCRIPTIONS: Record<string, string> = {
  'cra-cl-audit':   'Orchestrator — full audit narrative & risk posture',
  'cra-cl-defend':  'SCPs, detective controls & quick-win remediations',
  'cra-cl-exploit': 'Exploitation scenarios & PoC steps per attack path',
  'cra-cl-hunt':    'CloudTrail & Athena threat-hunting queries',
};

// Fallback list used when the backend is unreachable.
const FALLBACK_SCOPE_AGENTS = Object.keys(AGENT_DESCRIPTIONS).map(id => ({
  id,
  label: id,
  desc: AGENT_DESCRIPTIONS[id],
}));

const DEFAULT_CONFIG: CloudScanConfigType = {
  provider: 'aws',
  awsProfile: '',
  accessKeyId: '',
  secretAccessKey: '',
  sessionToken: '',
  authMethod: 'keys',
  regions: ['us-east-1'],
  selectedModules: [],
  accountId: '',
};

function loadSavedConfig(): CloudScanConfigType {
  try {
    const raw = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_CONFIG, ...parsed };
    }
  } catch { /* ignore */ }
  return DEFAULT_CONFIG;
}

interface CloudScanConfigProps {
  onStartScan: (config: CloudScanConfigType & { aiEnabled?: boolean; aiProvider?: string; aiApiKey?: string; aiModel?: string; aiBaseUrl?: string; selectedAgents?: string[] }) => void;
  onStopScan?: () => void;
  isRunning: boolean;
}

const CloudScanConfig: React.FC<CloudScanConfigProps> = ({ onStartScan, onStopScan, isRunning }) => {
  const [config, setConfig] = useState<CloudScanConfigType>(loadSavedConfig);
  const [aiEnabled, setAiEnabled] = useState(() => {
    try { return localStorage.getItem(AI_ENABLED_KEY) === 'true'; } catch { return false; }
  });
  const [scopeAgents, setScopeAgents] = useState(FALLBACK_SCOPE_AGENTS);
  const [selectedAgents, setSelectedAgents] = useState<string[]>(FALLBACK_SCOPE_AGENTS.map(a => a.id));
  const [providerConfig, setProviderConfig] = useState(loadProviderConfig);
  const [credError, setCredError] = useState<string | null>(null);
  // Track whether agents were loaded from backend (to avoid redundant syncs)
  const agentsLoadedRef = useRef(false);

  // Load DV-CLOUD agents — merge backend list + overrides from AI Agents/Skills
  useEffect(() => {
    const overrideMap = loadCloudAgentOverrides();
    const overrideIds = Object.keys(overrideMap);

    fetchAgentList().then(data => {
      if (!data?.agents) return;
      // Normalize backend IDs (scope-* → cra-cl-*) and merge with user overrides
      const backendAgents = Object.entries(data.agents)
        .filter(([, v]) => v.available)
        .map(([rawId]) => {
          const id = normalizeAgentId(rawId);
          return { id, label: id, desc: AGENT_DESCRIPTIONS[id] ?? `DV-CLOUD agent: ${id}` };
        });
      const merged = new Map(backendAgents.map(a => [a.id, a]));
      for (const id of overrideIds) {
        if (!merged.has(id)) {
          merged.set(id, { id, label: id, desc: AGENT_DESCRIPTIONS[id] ?? `DV-CLOUD agent: ${id}` });
        }
      }
      const final = Array.from(merged.values());
      if (final.length > 0) {
        setScopeAgents(final);
        setSelectedAgents(final.map(a => a.id));
        agentsLoadedRef.current = true;
      }
    }).catch(() => {
      // Fallback + any agents added via AI Agents/Skills page
      if (overrideIds.length > 0) {
        const extra = overrideIds
          .filter(id => !FALLBACK_SCOPE_AGENTS.some(f => f.id === id))
          .map(id => ({ id, label: id, desc: AGENT_DESCRIPTIONS[id] ?? `DV-CLOUD agent: ${id}` }));
        if (extra.length > 0) setScopeAgents([...FALLBACK_SCOPE_AGENTS, ...extra]);
      }
    });
  }, []);

  // Persist aiEnabled so the toggle survives navigation (Item 8)
  useEffect(() => {
    try { localStorage.setItem(AI_ENABLED_KEY, String(aiEnabled)); } catch { /* ignore */ }
    if (aiEnabled) setProviderConfig(loadProviderConfig());
  }, [aiEnabled]);

  // Auto-sync selected agents to AI Agents/Skills Cloud tab (Item 7)
  // When AI is enabled and agents are loaded, add any missing agents to the cloud tab storage.
  useEffect(() => {
    if (!aiEnabled || !agentsLoadedRef.current) return;
    try {
      const stored: import('@/pages/AIAgents').AIAgent[] = JSON.parse(
        localStorage.getItem(CLOUD_AGENTS_KEY) || '[]'
      );
      const storedIds = new Set(stored.map((a) => a.id));
      let changed = false;
      for (const agent of scopeAgents) {
        if (selectedAgents.includes(agent.id) && !storedIds.has(agent.id)) {
          stored.push({
            id: agent.id,
            name: agent.id,
            description: agent.desc,
            status: 'idle' as const,
            type: 'audit',
            scope: 'cloud' as const,
            tasksCompleted: 0,
            successRate: 100,
            lastRun: 'Never',
            capabilities: [],
            instructions: '[Loading from DV-CLOUD engine — click Edit to fetch full agent content]',
            isTemplate: true,
          });
          changed = true;
        }
      }
      if (changed) localStorage.setItem(CLOUD_AGENTS_KEY, JSON.stringify(stored));
    } catch { /* ignore */ }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aiEnabled, selectedAgents]);

  // Persist AWS config whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
    } catch { /* ignore quota errors */ }
  }, [config]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCredError(null);

    // Validate credentials before attempting scan
    if (config.authMethod === 'keys') {
      if (!config.accessKeyId.trim()) {
        setCredError('Access Key ID is required. Enter your AWS credentials before starting a scan.');
        return;
      }
      if (!config.secretAccessKey.trim()) {
        setCredError('Secret Access Key is required. Enter your AWS credentials before starting a scan.');
        return;
      }
    } else if (config.authMethod === 'profile' || config.authMethod === 'sso') {
      if (!config.awsProfile.trim()) {
        setCredError(`AWS ${config.authMethod === 'sso' ? 'SSO' : 'profile'} name is required. Enter a valid profile name before starting a scan.`);
        return;
      }
    }

    const pc = loadProviderConfig();
    // Pass edited agent instructions from AI Agents/Skills as overrides
    const agentOverrides = aiEnabled ? loadCloudAgentOverrides() : undefined;
    onStartScan({
      ...config,
      aiEnabled,
      aiProvider: aiEnabled && pc ? pc.type : undefined,
      aiApiKey: aiEnabled && pc ? pc.apiKey : undefined,
      aiModel: aiEnabled && pc ? pc.model : undefined,
      aiBaseUrl: aiEnabled && pc?.baseUrl ? pc.baseUrl : undefined,
      selectedAgents: aiEnabled ? selectedAgents : undefined,
      agentOverrides: agentOverrides && Object.keys(agentOverrides).length > 0 ? agentOverrides : undefined,
    });
  };

  const update = (field: keyof CloudScanConfigType, value: string | boolean | string[] | CloudProvider) => {
    setConfig(prev => ({ ...prev, [field]: value }));
    // Clear credential error when user edits credential fields
    if (['accessKeyId', 'secretAccessKey', 'awsProfile'].includes(field as string)) {
      setCredError(null);
    }
  };

  const toggleRegion = (region: string) => {
    setConfig(prev => ({
      ...prev,
      regions: prev.regions.includes(region)
        ? prev.regions.filter(r => r !== region)
        : [...prev.regions, region],
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="bg-cdm-darker rounded-lg border border-gray-800 p-5 space-y-5">
      {/* Provider Selection */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Cloud size={16} className="text-cyan-400" />
          <h3 className="text-sm font-semibold text-white">Cloud Provider & Credentials</h3>
        </div>

        {/* Provider tabs */}
        <div className="flex gap-2 mb-4">
          {CLOUD_PROVIDERS.map(p => (
            <button
              key={p.id}
              type="button"
              onClick={() => p.enabled && update('provider', p.id)}
              disabled={!p.enabled}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm transition-all ${
                config.provider === p.id
                  ? 'border-cyan-500/50 bg-cyan-900/20 text-cyan-400'
                  : p.enabled
                    ? 'border-gray-700 text-gray-400 hover:border-gray-600 hover:text-gray-300'
                    : 'border-gray-800 text-gray-600 cursor-not-allowed opacity-50'
              }`}
            >
              <span className="font-medium">{p.id.toUpperCase()}</span>
              {!p.enabled && <Badge className="bg-gray-800 text-gray-500 border-0 text-[9px] px-1">Soon</Badge>}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Auth Method */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-gray-400">Authentication</Label>
              <div className="flex gap-1">
                {(['profile', 'keys', 'sso'] as const).map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => update('authMethod', m)}
                    className={`text-[10px] px-2 py-0.5 rounded transition-colors ${
                      config.authMethod === m
                        ? 'bg-cyan-900/30 text-cyan-400'
                        : 'text-gray-500 hover:text-gray-300'
                    }`}
                  >
                    {m === 'keys' ? 'Access Keys' : m === 'profile' ? 'Profile' : 'SSO'}
                  </button>
                ))}
              </div>
            </div>

            {config.authMethod === 'profile' ? (
              <Input
                placeholder="AWS_PROFILE name"
                value={config.awsProfile}
                onChange={e => update('awsProfile', e.target.value)}
                className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
              />
            ) : config.authMethod === 'keys' ? (
              <Input
                placeholder="AKIAXXXXXXXXXXXXXXXXX"
                value={config.accessKeyId}
                onChange={e => update('accessKeyId', e.target.value)}
                className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white font-mono placeholder:text-gray-600"
              />
            ) : (
              <Input
                placeholder="SSO profile name"
                value={config.awsProfile}
                onChange={e => update('awsProfile', e.target.value)}
                className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
              />
            )}
          </div>

          {/* Secret / Account ID */}
          <div className="space-y-1.5">
            <Label className="text-xs text-gray-400">
              {config.authMethod === 'keys' ? (
                <><KeyRound size={12} className="inline mr-1" />Secret Access Key</>
              ) : (
                <><User size={12} className="inline mr-1" />Account ID (optional)</>
              )}
            </Label>
            {config.authMethod === 'keys' ? (
              <Input
                type="password"
                placeholder="••••••••••••••••"
                value={config.secretAccessKey}
                onChange={e => update('secretAccessKey', e.target.value)}
                className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white placeholder:text-gray-600"
              />
            ) : (
              <Input
                placeholder="123456789012"
                value={config.accountId}
                onChange={e => update('accountId', e.target.value)}
                className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white font-mono placeholder:text-gray-600"
              />
            )}
          </div>
        </div>

        {/* Session token for keys auth */}
        {config.authMethod === 'keys' && (
          <div className="mt-3 space-y-1.5">
            <Label className="text-xs text-gray-400">Session Token (optional — for temporary credentials)</Label>
            <Input
              placeholder="FwoGZXIvYXdzE..."
              value={config.sessionToken}
              onChange={e => update('sessionToken', e.target.value)}
              className="h-8 text-sm bg-[#0d1117] border-gray-700 text-white font-mono placeholder:text-gray-600"
            />
          </div>
        )}
      </div>

      {/* Region Selection */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs text-gray-400">
            <Globe size={12} className="inline mr-1" />
            Regions ({config.regions.length} selected)
          </Label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => update('regions', [...AWS_REGIONS])}
              className="text-[10px] text-cyan-400 hover:text-cyan-300"
            >
              Select All
            </button>
            <button
              type="button"
              onClick={() => update('regions', ['us-east-1'])}
              className="text-[10px] text-cyan-400 hover:text-cyan-300"
            >
              us-east-1 only
            </button>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {AWS_REGIONS.map(region => (
            <button
              key={region}
              type="button"
              onClick={() => toggleRegion(region)}
              className={`text-[10px] px-2 py-1 rounded border transition-colors ${
                config.regions.includes(region)
                  ? 'border-cyan-500/40 bg-cyan-900/20 text-cyan-400'
                  : 'border-gray-800 text-gray-600 hover:border-gray-700 hover:text-gray-400'
              }`}
            >
              {region}
            </button>
          ))}
        </div>
      </div>

      {/* DV-CLOUD AI Analysis Toggle */}
      <div className="border border-gray-800 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Bot size={14} className="text-cyan-400" />
            <span className="text-sm font-medium text-white">DV-CLOUD AI Analysis</span>
            <Badge className="bg-cyan-900/20 text-cyan-400 border-cyan-500/30 text-[9px] px-1.5">Phase 4</Badge>
          </div>
          <Switch
            checked={aiEnabled}
            onCheckedChange={setAiEnabled}
            className="data-[state=checked]:bg-cyan-600"
          />
        </div>

        {aiEnabled && (
          <div className="mt-3 space-y-3">
            {providerConfig && providerConfig.apiKey ? (
              <div className="flex items-start gap-2 px-3 py-2.5 rounded-md bg-emerald-900/10 border border-emerald-500/20">
                <CheckCircle2 size={13} className="text-emerald-400 mt-0.5 shrink-0" />
                <div className="text-[11px] space-y-0.5">
                  <p className="text-emerald-400 font-medium">AI Provider configured</p>
                  <p className="text-gray-400">
                    {providerConfig.name || providerConfig.type} &mdash; <span className="font-mono text-gray-300">{providerConfig.model}</span>
                  </p>
                  <p className="text-gray-600">Configure provider via the settings button in the header above</p>
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-2 px-3 py-2.5 rounded-md bg-amber-900/10 border border-amber-500/20">
                <AlertCircle size={13} className="text-amber-400 mt-0.5 shrink-0" />
                <div className="text-[11px]">
                  <p className="text-amber-400 font-medium">No AI provider configured</p>
                  <p className="text-gray-400 mt-0.5">Click the <span className="text-white font-medium">AI Provider</span> button in the header to set up your provider before scanning</p>
                </div>
              </div>
            )}

            {/* DV-CLOUD agent selector */}
            <div className="rounded-md border border-gray-700/50 bg-gray-900/30 p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-[11px] font-medium text-gray-300">DV-CLOUD Agents</p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAgents(scopeAgents.map(a => a.id))}
                    className="text-[10px] text-cyan-400 hover:text-cyan-300"
                  >All</button>
                  <button
                    type="button"
                    onClick={() => setSelectedAgents([])}
                    className="text-[10px] text-gray-500 hover:text-gray-400"
                  >None</button>
                </div>
              </div>
              <div className="space-y-1.5">
                {scopeAgents.map(agent => {
                  const active = selectedAgents.includes(agent.id);
                  return (
                    <button
                      key={agent.id}
                      type="button"
                      onClick={() => setSelectedAgents(prev =>
                        prev.includes(agent.id)
                          ? prev.filter(id => id !== agent.id)
                          : [...prev, agent.id]
                      )}
                      className={`w-full flex items-start gap-2 px-2.5 py-1.5 rounded border text-left transition-all ${
                        active
                          ? 'border-cyan-500/40 bg-cyan-900/15 text-cyan-400'
                          : 'border-gray-700/40 text-gray-600 hover:border-gray-600 hover:text-gray-500'
                      }`}
                    >
                      <span className={`mt-0.5 h-3 w-3 shrink-0 rounded-sm border flex items-center justify-center ${
                        active ? 'border-cyan-400 bg-cyan-500/20' : 'border-gray-600'
                      }`}>
                        {active && <span className="block h-1.5 w-1.5 rounded-sm bg-cyan-400" />}
                      </span>
                      <span className="min-w-0">
                        <span className="block text-[10px] font-mono font-medium">{agent.label}</span>
                        <span className="block text-[10px] text-gray-500 leading-tight mt-0.5">{agent.desc}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Credential validation error */}
      {credError && (
        <div className="flex items-start gap-2 px-3 py-2.5 rounded-md bg-amber-900/10 border border-amber-500/30">
          <AlertCircle size={13} className="text-amber-400 mt-0.5 shrink-0" />
          <p className="text-[11px] text-amber-300">{credError}</p>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-end pt-2 border-t border-gray-800 gap-2">
        {isRunning && onStopScan && (
          <Button
            type="button"
            onClick={onStopScan}
            className="bg-red-700 hover:bg-red-800 text-white text-sm h-8 px-4"
          >
            <Square size={12} className="mr-2" />
            Stop Scan
          </Button>
        )}
        <Button
          type="submit"
          disabled={isRunning}
          className="bg-cyan-600 hover:bg-cyan-700 text-white text-sm h-8 px-4 disabled:opacity-50"
        >
          {isRunning ? (
            <>
              <Loader2 size={14} className="mr-2 animate-spin" />
              Scanning...
            </>
          ) : (
            <>
              <Play size={14} className="mr-2" />
              Start Cloud Scan
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default CloudScanConfig;
