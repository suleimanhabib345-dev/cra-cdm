import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Minimize2 } from 'lucide-react';
import type { CloudGraphData, CloudGraphNode, CloudGraphEdge, CloudNodeType, CloudEdgeType } from '@/types/cloudscan';

const GRAPH_STORE = 'cra_graph_';

interface CloudResourceGraphProps {
  data: CloudGraphData;
  className?: string;
  persistKey?: string;
}

const NODE_COLORS: Record<CloudNodeType, string> = {
  user: '#8b5cf6',
  role: '#06b6d4',
  group: '#f59e0b',
  escalation: '#ef4444',
  data: '#22c55e',
  external: '#f59e0b',
  service: '#a78bfa',
  network: '#f97316',
};

const NODE_SIZES: Record<CloudNodeType, number> = {
  escalation: 22,
  data: 16,
  user: 14,
  role: 14,
  group: 16,
  external: 14,
  service: 12,
  network: 14,
};

const EDGE_COLORS: Record<CloudEdgeType, string> = {
  priv_esc: '#ef4444',
  trust: '#64748b',
  data_access: '#22c55e',
  network: '#f97316',
  service: '#a78bfa',
  public_access: '#ef4444',
  cross_account: '#f59e0b',
  membership: '#475569',
};

const NODE_ICONS: Record<CloudNodeType, string> = {
  user: '👤',
  role: '🔑',
  group: '👥',
  escalation: '⚡',
  data: '💾',
  external: '🌐',
  service: '⚙️',
  network: '🔗',
};

const CloudResourceGraph: React.FC<CloudResourceGraphProps> = ({ data, className = '', persistKey }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredNode, setHoveredNode] = useState<CloudGraphNode | null>(null);
  const [selectedNode, setSelectedNode] = useState<CloudGraphNode | null>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [isDragging, setIsDragging] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const draggedNodeRef = useRef<CloudGraphNode | null>(null);
  const nodesRef = useRef<CloudGraphNode[]>([]);
  const animFrame = useRef<number>(0);
  const persistKeyRef = useRef(persistKey);
  persistKeyRef.current = persistKey;

  // Esc to exit fullscreen
  useEffect(() => {
    if (!isExpanded) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setIsExpanded(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [isExpanded]);

  useEffect(() => {
    if (!data.nodes.length) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const width = canvas.width;
    const height = canvas.height;
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.min(width, height) * 0.35;

    // Restore saved positions if available
    const pk = persistKeyRef.current;
    if (pk) {
      try {
        const saved = JSON.parse(localStorage.getItem(GRAPH_STORE + pk) || 'null') as Record<string, { x: number; y: number }> | null;
        if (saved && data.nodes.every(n => n.id in saved)) {
          nodesRef.current = data.nodes.map(n => ({ ...n, x: saved[n.id].x, y: saved[n.id].y, vx: 0, vy: 0 }));
          draw();
          return;
        }
      } catch {}
    }

    nodesRef.current = data.nodes.map((node, i) => {
      const angle = (2 * Math.PI * i) / data.nodes.length;
      return {
        ...node,
        x: cx + radius * Math.cos(angle) + (Math.random() - 0.5) * 50,
        y: cy + radius * Math.sin(angle) + (Math.random() - 0.5) * 50,
        vx: 0, vy: 0,
      };
    });

    let iter = 0;
    const maxIter = 200;

    const simulate = () => {
      if (iter >= maxIter) {
        draw();
        const pk2 = persistKeyRef.current;
        if (pk2) {
          const pos: Record<string, { x: number; y: number }> = {};
          for (const n of nodesRef.current) pos[n.id] = { x: n.x, y: n.y };
          try { localStorage.setItem(GRAPH_STORE + pk2, JSON.stringify(pos)); } catch {}
        }
        return;
      }
      const alpha = 1 - iter / maxIter;
      const nodes = nodesRef.current;

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[j].x - nodes[i].x;
          const dy = nodes[j].y - nodes[i].y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const f = (900 * alpha) / (dist * dist);
          const fx = (dx / dist) * f;
          const fy = (dy / dist) * f;
          nodes[i].vx -= fx; nodes[i].vy -= fy;
          nodes[j].vx += fx; nodes[j].vy += fy;
        }
      }

      for (const edge of data.edges) {
        const src = nodes.find(n => n.id === edge.source);
        const tgt = nodes.find(n => n.id === edge.target);
        if (!src || !tgt) continue;
        const dx = tgt.x - src.x;
        const dy = tgt.y - src.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (dist - 130) * 0.01 * alpha;
        const fx = (dx / dist) * f;
        const fy = (dy / dist) * f;
        src.vx += fx; src.vy += fy;
        tgt.vx -= fx; tgt.vy -= fy;
      }

      for (const n of nodes) {
        n.vx += (cx - n.x) * 0.001 * alpha;
        n.vy += (cy - n.y) * 0.001 * alpha;
        n.vx *= 0.6; n.vy *= 0.6;
        n.x += n.vx; n.y += n.vy;
        n.x = Math.max(50, Math.min(width - 50, n.x));
        n.y = Math.max(50, Math.min(height - 50, n.y));
      }

      iter++;
      draw();
      animFrame.current = requestAnimationFrame(simulate);
    };

    simulate();
    return () => cancelAnimationFrame(animFrame.current);
  }, [data]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { x: tx, y: ty, scale } = transform;
    const nodes = nodesRef.current;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(tx, ty);
    ctx.scale(scale, scale);

    // Edges
    for (const edge of data.edges) {
      const src = nodes.find(n => n.id === edge.source);
      const tgt = nodes.find(n => n.id === edge.target);
      if (!src || !tgt) continue;

      const isAttack = edge.edgeType === 'priv_esc' || edge.edgeType === 'public_access';
      ctx.beginPath();
      ctx.moveTo(src.x, src.y);
      ctx.lineTo(tgt.x, tgt.y);
      ctx.strokeStyle = EDGE_COLORS[edge.edgeType] || '#4b5563';
      ctx.lineWidth = isAttack ? 2.5 : 1;
      ctx.globalAlpha = isAttack ? 0.8 : 0.35;
      ctx.setLineDash(isAttack ? [6, 4] : []);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;

      // Arrow
      const angle = Math.atan2(tgt.y - src.y, tgt.x - src.x);
      const tgtSize = NODE_SIZES[tgt.type] || 14;
      const ax = tgt.x - Math.cos(angle) * (tgtSize + 5);
      const ay = tgt.y - Math.sin(angle) * (tgtSize + 5);
      const as = isAttack ? 8 : 5;
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(ax - as * Math.cos(angle - Math.PI / 6), ay - as * Math.sin(angle - Math.PI / 6));
      ctx.lineTo(ax - as * Math.cos(angle + Math.PI / 6), ay - as * Math.sin(angle + Math.PI / 6));
      ctx.closePath();
      ctx.fillStyle = EDGE_COLORS[edge.edgeType] || '#4b5563';
      ctx.globalAlpha = isAttack ? 0.8 : 0.4;
      ctx.fill();
      ctx.globalAlpha = 1;

      // Edge label on attack paths
      if (isAttack || edge.edgeType === 'cross_account') {
        const mx = (src.x + tgt.x) / 2;
        const my = (src.y + tgt.y) / 2;
        ctx.font = '9px monospace';
        ctx.fillStyle = EDGE_COLORS[edge.edgeType];
        ctx.textAlign = 'center';
        ctx.fillText(edge.label, mx, my - 6);
      }
    }

    // Nodes
    for (const node of nodes) {
      const size = NODE_SIZES[node.type] || 14;
      const color = NODE_COLORS[node.type] || '#6b7280';
      const isHovered = hoveredNode?.id === node.id;
      const isSelected = selectedNode?.id === node.id;

      if (node.severity) {
        const glow: Record<string, string> = {
          critical: 'rgba(239,68,68,0.25)',
          high: 'rgba(245,158,11,0.2)',
          medium: 'rgba(59,130,246,0.15)',
          low: 'rgba(16,185,129,0.1)',
        };
        ctx.beginPath();
        ctx.arc(node.x, node.y, size + 8, 0, Math.PI * 2);
        ctx.fillStyle = glow[node.severity] || 'transparent';
        ctx.fill();
      }

      ctx.beginPath();
      ctx.arc(node.x, node.y, size, 0, Math.PI * 2);
      ctx.fillStyle = isSelected ? '#ffffff' : color;
      ctx.fill();
      ctx.strokeStyle = isHovered ? '#fff' : isSelected ? color : 'rgba(255,255,255,0.15)';
      ctx.lineWidth = isHovered || isSelected ? 2.5 : 1;
      ctx.stroke();

      ctx.font = `${size * 0.8}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(NODE_ICONS[node.type] || '', node.x, node.y);

      ctx.font = `${isHovered ? 'bold ' : ''}10px Inter, system-ui, sans-serif`;
      ctx.fillStyle = isHovered ? '#fff' : '#9ca3af';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText(node.label, node.x, node.y + size + 4);
    }

    ctx.restore();

    // Tooltip
    if (hoveredNode) {
      const sx = hoveredNode.x * scale + tx;
      const sy = hoveredNode.y * scale + ty;
      const tw = 200;
      const th = hoveredNode.details ? 54 : 38;
      const ttx = Math.min(sx + 18, canvas.width - tw - 10);
      const tty = Math.max(sy - 18, 10);

      ctx.fillStyle = 'rgba(15,23,42,0.95)';
      ctx.strokeStyle = 'rgba(71,85,105,0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(ttx, tty, tw, th, 6);
      ctx.fill(); ctx.stroke();

      ctx.font = 'bold 11px Inter, system-ui, sans-serif';
      ctx.fillStyle = '#f1f5f9';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(`${NODE_ICONS[hoveredNode.type]} ${hoveredNode.label}`, ttx + 8, tty + 8);

      ctx.font = '10px Inter, system-ui, sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(`Type: ${hoveredNode.type}${hoveredNode.service ? ` (${hoveredNode.service})` : ''}`, ttx + 8, tty + 24);

      if (hoveredNode.details) {
        ctx.fillStyle = hoveredNode.severity === 'critical' ? '#ef4444' : hoveredNode.severity === 'high' ? '#f59e0b' : '#94a3b8';
        ctx.fillText(hoveredNode.details, ttx + 8, tty + 38);
      }
    }
  }, [data.edges, hoveredNode, selectedNode, transform]);

  useEffect(() => { draw(); }, [draw]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const obs = new ResizeObserver(() => {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
      draw();
    });
    obs.observe(container);
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    draw();
    return () => obs.disconnect();
  }, [draw, isExpanded]);

  const getNodeAt = useCallback((mx: number, my: number): CloudGraphNode | null => {
    const { x: tx, y: ty, scale } = transform;
    const wx = (mx - tx) / scale;
    const wy = (my - ty) / scale;
    for (let i = nodesRef.current.length - 1; i >= 0; i--) {
      const n = nodesRef.current[i];
      const s = NODE_SIZES[n.type] || 14;
      const dx = wx - n.x; const dy = wy - n.y;
      if (dx * dx + dy * dy <= (s + 4) * (s + 4)) return n;
    }
    return null;
  }, [transform]);

  const onMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = canvasRef.current?.getBoundingClientRect();
    if (!r) return;
    const mx = e.clientX - r.left;
    const my = e.clientY - r.top;

    if (draggedNodeRef.current) {
      const { x: tx, y: ty, scale } = transform;
      const pinnedId = draggedNodeRef.current.id;
      draggedNodeRef.current.x = (mx - tx) / scale;
      draggedNodeRef.current.y = (my - ty) / scale;
      draggedNodeRef.current.vx = 0;
      draggedNodeRef.current.vy = 0;

      const nodes = nodesRef.current;
      const canvas = canvasRef.current;
      if (canvas) {
        const w = canvas.width, h = canvas.height;
        for (let s = 0; s < 3; s++) {
          for (const edge of data.edges) {
            const src = nodes.find(n => n.id === edge.source);
            const tgt = nodes.find(n => n.id === edge.target);
            if (!src || !tgt) continue;
            const dx = tgt.x - src.x;
            const dy = tgt.y - src.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const f = (dist - 130) * 0.025;
            const fx = (dx / dist) * f;
            const fy = (dy / dist) * f;
            if (src.id !== pinnedId) { src.vx += fx; src.vy += fy; }
            if (tgt.id !== pinnedId) { tgt.vx -= fx; tgt.vy -= fy; }
          }
          for (const node of nodes) {
            if (node.id === pinnedId) continue;
            node.vx *= 0.65;
            node.vy *= 0.65;
            node.x = Math.max(50, Math.min(w - 50, node.x + node.vx));
            node.y = Math.max(50, Math.min(h - 50, node.y + node.vy));
          }
        }
      }

      draw();
      return;
    }
    if (isDragging) {
      setTransform(p => ({ ...p, x: p.x + (e.clientX - dragStart.current.x), y: p.y + (e.clientY - dragStart.current.y) }));
      dragStart.current = { x: e.clientX, y: e.clientY };
      return;
    }
    const n = getNodeAt(mx, my);
    setHoveredNode(n);
    if (canvasRef.current) canvasRef.current.style.cursor = n ? 'grab' : 'default';
  }, [isDragging, getNodeAt, transform, draw]);

  const onMouseDown = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = canvasRef.current?.getBoundingClientRect();
    if (!r) return;
    const n = getNodeAt(e.clientX - r.left, e.clientY - r.top);
    if (n) {
      draggedNodeRef.current = n;
      setSelectedNode(n);
      if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
    } else {
      setIsDragging(true);
      dragStart.current = { x: e.clientX, y: e.clientY };
      if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
    }
  }, [getNodeAt]);

  const onMouseUp = useCallback(() => {
    if (draggedNodeRef.current) {
      const pk = persistKeyRef.current;
      if (pk) {
        const pos: Record<string, { x: number; y: number }> = {};
        for (const n of nodesRef.current) pos[n.id] = { x: n.x, y: n.y };
        try { localStorage.setItem(GRAPH_STORE + pk, JSON.stringify(pos)); } catch {}
      }
    }
    draggedNodeRef.current = null;
    setIsDragging(false);
    if (canvasRef.current) canvasRef.current.style.cursor = 'default';
  }, []);

  const onWheel = useCallback((e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const r = canvasRef.current?.getBoundingClientRect();
    if (!r) return;
    const mx = e.clientX - r.left; const my = e.clientY - r.top;
    const d = e.deltaY > 0 ? 0.9 : 1.1;
    setTransform(p => {
      const ns = Math.max(0.3, Math.min(3, p.scale * d));
      const ratio = ns / p.scale;
      return { scale: ns, x: mx - (mx - p.x) * ratio, y: my - (my - p.y) * ratio };
    });
  }, []);

  return (
    <>
      <div className={`relative flex flex-col bg-[#0a0e17] rounded-lg border border-gray-800 overflow-hidden ${isExpanded ? 'fixed inset-4 z-50' : ''} ${className}`}>
        <div className="flex items-center justify-between px-4 py-2 bg-[#0f1520] border-b border-gray-800">
          <span className="text-xs font-medium text-gray-400">Cloud Resource & Attack Graph</span>
          <div className="flex items-center gap-1">
            <button onClick={() => setTransform(p => ({ ...p, scale: Math.max(0.3, p.scale / 1.2) }))} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"><ZoomOut size={12} /></button>
            <button onClick={() => setTransform(p => ({ ...p, scale: Math.min(3, p.scale * 1.2) }))} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"><ZoomIn size={12} /></button>
            <button onClick={() => setTransform({ x: 0, y: 0, scale: 1 })} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"><RotateCcw size={12} /></button>
            <button onClick={() => setIsExpanded(!isExpanded)} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors" title={isExpanded ? 'Minimize' : 'Maximize'}>
              {isExpanded ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
            </button>
          </div>
        </div>
        <div ref={containerRef} className={`${isExpanded ? 'flex-1' : 'h-[480px]'}`}>
          <canvas ref={canvasRef} onMouseMove={onMouseMove} onMouseDown={onMouseDown} onMouseUp={onMouseUp} onMouseLeave={onMouseUp} onWheel={onWheel} className="w-full h-full" />
        </div>
        <div className="flex flex-wrap items-center gap-3 px-4 py-2 bg-[#0f1520] border-t border-gray-800">
          {Object.entries(NODE_COLORS).map(([type, color]) => (
            <div key={type} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
              <span className="text-[10px] text-gray-500 capitalize">{type}</span>
            </div>
          ))}
          <div className="ml-2 flex items-center gap-1.5">
            <span className="w-4 border-t-2 border-dashed border-red-500" />
            <span className="text-[10px] text-gray-500">Priv Esc</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 border-t-2 border-dashed border-amber-500" />
            <span className="text-[10px] text-gray-500">Cross-Account</span>
          </div>
        </div>
        {selectedNode && (
          <div className="absolute bottom-12 left-4 bg-[#0f172a]/95 border border-gray-700 rounded-lg p-3 max-w-[240px] backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <span>{NODE_ICONS[selectedNode.type]}</span>
              <span className="text-sm font-medium text-white">{selectedNode.label}</span>
            </div>
            <div className="text-xs text-gray-400">Type: {selectedNode.type}{selectedNode.service ? ` (${selectedNode.service})` : ''}</div>
            {selectedNode.severity && (
              <div className={`text-xs mt-1 ${selectedNode.severity === 'critical' ? 'text-red-400' : selectedNode.severity === 'high' ? 'text-amber-400' : 'text-blue-400'}`}>
                Severity: {selectedNode.severity}
              </div>
            )}
            {selectedNode.details && <div className="text-xs text-gray-300 mt-1">{selectedNode.details}</div>}
          </div>
        )}
      </div>
      {isExpanded && <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setIsExpanded(false)} />}
    </>
  );
};

export default CloudResourceGraph;
