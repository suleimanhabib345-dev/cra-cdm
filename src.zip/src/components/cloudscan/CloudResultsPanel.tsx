import React from 'react';
import {
  Shield, Users, Key, Lock, Network, Globe, AlertTriangle, TrendingUp
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import type { CloudScanSummary, CloudSeverity, EnumModuleStatus } from '@/types/cloudscan';

interface CloudResultsPanelProps {
  summary: CloudScanSummary;
  accountId: string;
  modules: EnumModuleStatus[];
  findings?: { severity?: string }[];
}

const riskBadge: Record<CloudSeverity, { bg: string; text: string }> = {
  critical: { bg: 'bg-red-900/20', text: 'text-red-400' },
  high: { bg: 'bg-orange-900/20', text: 'text-orange-400' },
  medium: { bg: 'bg-blue-900/20', text: 'text-blue-400' },
  low: { bg: 'bg-emerald-900/20', text: 'text-emerald-400' },
  info: { bg: 'bg-gray-800/30', text: 'text-gray-400' },
};

const CloudResultsPanel: React.FC<CloudResultsPanelProps> = ({ summary, accountId, modules, findings }) => {
  const rc = riskBadge[summary?.riskScore ?? 'low'] ?? riskBadge['low'];
  const totalPaths = Object.values(summary?.pathsByCategory ?? {}).reduce((a, b) => a + b, 0);

  // Derive actual severity counts from findings (more accurate than the KPI fields)
  const sevCounts = React.useMemo(() => {
    if (findings && findings.length > 0) {
      return findings.reduce((acc, f) => {
        const s = (f.severity ?? '').toLowerCase() as 'critical' | 'high' | 'medium' | 'low';
        if (s in acc) acc[s]++;
        return acc;
      }, { critical: 0, high: 0, medium: 0, low: 0 });
    }
    // Fallback to whatever the scanner populated in the summary
    return {
      critical: summary?.criticalPrivEscRisks ?? 0,
      high: summary?.wildcardTrustPolicies ?? 0,
      medium: summary?.crossAccountTrusts ?? 0,
      low: summary?.usersWithoutMfa ?? 0,
    };
  }, [findings, summary]);

  return (
    <div className="space-y-4">
      {/* Risk Header */}
      <div className={`${rc.bg} rounded-lg border border-gray-800 p-5`}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-lg font-bold text-white">AWS Account {accountId}</h3>
            <p className="text-xs text-gray-400 mt-0.5">
              {summary.servicesAnalyzed} services analyzed — {totalPaths} attack paths discovered
            </p>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-bold uppercase ${rc.text}`}>
              {summary.riskScore}
            </div>
            <span className="text-xs text-gray-500">Overall Risk</span>
          </div>
        </div>

        {/* Finding severity breakdown */}
        <div className="grid grid-cols-4 gap-2 mt-3">
          {(['critical', 'high', 'medium', 'low'] as CloudSeverity[]).map(sev => {
            const sevCount = sevCounts[sev as keyof typeof sevCounts] ?? 0;
            const colors = riskBadge[sev];
            return (
              <div key={sev} className={`${colors.bg} rounded p-2 text-center border border-gray-800/50`}>
                <div className={`text-lg font-bold ${colors.text}`}>{sevCount}</div>
                <div className="text-[10px] text-gray-500 uppercase">{sev}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <KpiTile
          icon={<Shield size={14} />}
          label="Priv Esc Risks"
          value={summary?.criticalPrivEscRisks ?? 0}
          color={(summary?.criticalPrivEscRisks ?? 0) > 0 ? 'text-red-400' : 'text-emerald-400'}
        />
        <KpiTile
          icon={<AlertTriangle size={14} />}
          label="Wildcard Trusts"
          value={summary?.wildcardTrustPolicies ?? 0}
          color={(summary?.wildcardTrustPolicies ?? 0) > 0 ? 'text-red-400' : 'text-emerald-400'}
        />
        <KpiTile
          icon={<Globe size={14} />}
          label="Cross-Account"
          value={summary?.crossAccountTrusts ?? 0}
          color="text-amber-400"
        />
        <KpiTile
          icon={<Lock size={14} />}
          label="No MFA"
          value={summary?.usersWithoutMfa ?? 0}
          color={(summary?.usersWithoutMfa ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'}
        />
        <KpiTile
          icon={<TrendingUp size={14} />}
          label="Admin Reachable"
          value={summary?.reachability?.principalsWithAdminReach ?? 0}
          color={(summary?.reachability?.principalsWithAdminReach ?? 0) > 2 ? 'text-red-400' : 'text-amber-400'}
        />
        <KpiTile
          icon={<Network size={14} />}
          label="Max Blast Radius"
          value={`${summary?.reachability?.maxBlastRadiusNodes ?? 0} nodes`}
          color="text-amber-400"
        />
      </div>

      {/* Module Status */}
      <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
        <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Enumeration Modules</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {modules.map(mod => (
            <div key={mod.id} className="flex items-center justify-between px-3 py-2 rounded bg-[#0d1117] border border-gray-800/50">
              <div className="flex items-center gap-2">
                <span className={`w-1.5 h-1.5 rounded-full ${
                  mod.status === 'complete' ? 'bg-emerald-400' :
                  mod.status === 'running' ? 'bg-cyan-400 animate-pulse' :
                  mod.status === 'error' ? 'bg-red-400' :
                  mod.status === 'partial' ? 'bg-amber-400' : 'bg-gray-600'
                }`} />
                <span className="text-xs text-gray-300">{mod.name}</span>
              </div>
              {mod.findingsCount > 0 && (
                <span className="text-[10px] text-amber-400 font-mono">{mod.findingsCount}</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Reachability Stats */}
      <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
        <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Reachability Analysis</h4>
        <div className="space-y-3">
          <ReachStat label="Principals with admin reach" value={summary?.reachability?.principalsWithAdminReach ?? 0} max={(summary?.totalUsers ?? 0) + (summary?.totalRoles ?? 0)} color="bg-red-500" />
          <ReachStat label="Principals with data reach" value={summary?.reachability?.principalsWithDataReach ?? 0} max={(summary?.totalUsers ?? 0) + (summary?.totalRoles ?? 0)} color="bg-amber-500" />
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-500">Max blast radius principal</span>
            <span className="text-cyan-400 font-mono">{summary?.reachability?.maxBlastRadiusPrincipal ?? '—'}</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-500">Average hop count</span>
            <span className="text-gray-300 font-mono">{summary?.reachability?.avgHopCount ?? 0}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

function KpiTile({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string | number; color: string }) {
  return (
    <div className="bg-cdm-darker rounded-lg border border-gray-800 p-3 flex items-center gap-3">
      <div className="p-2 rounded-md bg-gray-800/50 text-gray-400">{icon}</div>
      <div>
        <div className={`text-lg font-bold ${color}`}>{value}</div>
        <div className="text-[10px] text-gray-500">{label}</div>
      </div>
    </div>
  );
}

function ReachStat({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="text-gray-500">{label}</span>
        <span className="text-gray-300 font-mono">{value}/{max} ({pct}%)</span>
      </div>
      <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export default CloudResultsPanel;
