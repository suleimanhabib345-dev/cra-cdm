import React, { useEffect, useState } from 'react';
import { ShieldAlert } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

// Reads from public.device_risk_scores (view created in
// 20260221_add_risk_scoring.sql). Score = criticality × Σ severity_weights
// over OPEN findings (critical=10, high=7, medium=4, low=1).

interface RiskRow {
  agent_id: string;
  hostname: string;
  platform: string | null;
  criticality: number;
  risk_score: number;
  risk_band: 'critical' | 'high' | 'medium' | 'low' | 'none';
  open_findings: number;
  critical_count: number;
  high_count: number;
  medium_count: number;
  low_count: number;
  company_id: string | null;
}

const BAND_STYLES: Record<RiskRow['risk_band'], string> = {
  critical: 'bg-red-900/40 text-red-300 border-red-700/50',
  high:     'bg-orange-900/40 text-orange-300 border-orange-700/50',
  medium:   'bg-yellow-900/40 text-yellow-300 border-yellow-700/50',
  low:      'bg-blue-900/40 text-blue-300 border-blue-700/50',
  none:     'bg-emerald-900/40 text-emerald-300 border-emerald-700/50',
};

const platformDot = (platform: string | null) => {
  const p = (platform || '').toLowerCase();
  if (p === 'linux')   return 'bg-orange-500';
  if (p === 'windows') return 'bg-blue-500';
  return 'bg-slate-500';
};

const CriticalityDots = ({ value }: { value: number }) => (
  <div className="flex gap-0.5" title={`Asset criticality: ${value}/5`}>
    {[1, 2, 3, 4, 5].map(n => (
      <span
        key={n}
        className={`h-1.5 w-1.5 rounded-full ${n <= value ? 'bg-cyan-400' : 'bg-gray-700'}`}
      />
    ))}
  </div>
);

const TopRiskHosts: React.FC = () => {
  const { user } = useAuth();
  const [rows, setRows] = useState<RiskRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const fetchRows = async () => {
      try {
        setLoading(true);

        let companyId: string | null = null;
        if (user?.id) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('company_id')
            .eq('id', user.id)
            .single();
          companyId = profile?.company_id || null;
        }

        // The view isn't in the generated supabase types, so cast through unknown.
        let query = (supabase.from as any)('device_risk_scores')
          .select('agent_id, hostname, platform, criticality, risk_score, risk_band, open_findings, critical_count, high_count, medium_count, low_count, company_id')
          .order('risk_score', { ascending: false })
          .limit(5);
        if (companyId) {
          query = query.eq('company_id', companyId);
        }
        const { data, error } = await query;
        if (error) throw error;
        if (!cancelled) setRows((data as RiskRow[]) || []);
      } catch (err) {
        console.error('TopRiskHosts: failed to load risk scores', err);
        if (!cancelled) setRows([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    if (user) fetchRows();
    return () => { cancelled = true; };
  }, [user]);

  return (
    <div className="bg-cdm-darker p-6 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <ShieldAlert size={18} className="text-cyan-400" />
          <h2 className="text-lg font-semibold text-white">Top Risk Hosts</h2>
        </div>
        <span className="text-xs text-gray-400 font-mono">
          score = criticality × Σ(C·10 + H·7 + M·4 + L·1)
        </span>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-32">
          <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-cyan-400" />
        </div>
      ) : rows.length === 0 ? (
        <div className="text-center py-8 text-gray-400 text-sm">No hosts with open findings.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase text-gray-400 border-b border-gray-800">
              <tr>
                <th className="py-2 pr-4">Host</th>
                <th className="py-2 pr-4">Criticality</th>
                <th className="py-2 pr-4">Score</th>
                <th className="py-2 pr-4">Band</th>
                <th className="py-2">Open findings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {rows.map(r => (
                <tr key={r.agent_id} className="hover:bg-gray-800/40 transition-colors">
                  <td className="py-2.5 pr-4">
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${platformDot(r.platform)}`} />
                      <span className="font-mono text-gray-100">{r.hostname}</span>
                    </div>
                  </td>
                  <td className="py-2.5 pr-4">
                    <CriticalityDots value={r.criticality} />
                  </td>
                  <td className="py-2.5 pr-4 font-mono font-semibold text-white tabular-nums">
                    {r.risk_score}
                  </td>
                  <td className="py-2.5 pr-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${BAND_STYLES[r.risk_band]}`}>
                      {r.risk_band.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-2.5">
                    <div className="flex gap-1.5 text-xs font-mono">
                      {r.critical_count > 0 && <span className="px-1.5 py-0.5 rounded bg-red-900/40 text-red-300">{r.critical_count}C</span>}
                      {r.high_count     > 0 && <span className="px-1.5 py-0.5 rounded bg-orange-900/40 text-orange-300">{r.high_count}H</span>}
                      {r.medium_count   > 0 && <span className="px-1.5 py-0.5 rounded bg-yellow-900/40 text-yellow-300">{r.medium_count}M</span>}
                      {r.low_count      > 0 && <span className="px-1.5 py-0.5 rounded bg-blue-900/40 text-blue-300">{r.low_count}L</span>}
                      {r.open_findings === 0 && <span className="px-1.5 py-0.5 rounded bg-emerald-900/40 text-emerald-300">none</span>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default TopRiskHosts;
