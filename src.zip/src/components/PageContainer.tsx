
import React from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';

interface PageContainerProps {
  title: string;
  children?: React.ReactNode;
}

const PageContainer = ({ title, children }: PageContainerProps) => {
  return (
    <div className="flex h-screen bg-cdm-dark overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6 grid-bg">
          {title && (
            <h1 className="text-2xl font-bold mb-6">{title}</h1>
          )}
          {children}
        </main>
      </div>
    </div>
  );
};

export default PageContainer;
