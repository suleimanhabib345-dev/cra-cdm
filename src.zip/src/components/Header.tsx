
import React, { useEffect, useState } from 'react';
import { User, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import Breadcrumbs from './Breadcrumbs';

interface UserProfile {
  email: string;
  firstName: string;
  lastName: string;
  role: string;
}

const Header = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const { data: userData } = await supabase.auth.getUser();
        const userId = userData.user?.id;
        const email = userData.user?.email || '';
        if (!userId) return;

        const { data: profileData } = await supabase
          .from('profiles')
          .select('first_name, last_name, role')
          .eq('id', userId)
          .single();

        setProfile({
          email,
          firstName: profileData?.first_name || '',
          lastName: profileData?.last_name || '',
          role: profileData?.role || 'user',
        });
      } catch (e) {
        console.error('Error loading profile:', e);
      }
    };
    loadProfile();
  }, []);

  const displayName = profile
    ? [profile.firstName, profile.lastName].filter(Boolean).join(' ') || profile.email
    : 'Loading...';

  const displayRole = profile?.role
    ? profile.role.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
    : '';

  return (
    <header className="h-14 bg-cdm-darker flex items-center justify-between px-6 border-b border-gray-800 flex-shrink-0 z-10">
      <Breadcrumbs />
      <div className="flex items-center space-x-4">
        <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse"></div>
        <Popover>
          <PopoverTrigger asChild>
            <button className="flex items-center bg-cdm-dark rounded-full pr-3 cursor-pointer hover:bg-gray-700 transition-colors">
              <div className="w-9 h-9 rounded-full bg-gray-700 flex items-center justify-center mr-2">
                <User className="text-gray-300" size={16} />
              </div>
              <div className="text-right">
                <div className="text-xs font-semibold text-white">{displayName}</div>
                <div className="text-[10px] text-gray-400">{displayRole}</div>
              </div>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-72 bg-gray-800 border-gray-700 text-white p-0" align="end">
            <div className="p-4 border-b border-gray-700">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gray-700 flex items-center justify-center flex-shrink-0">
                  <User className="text-gray-300" size={24} />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold truncate">{displayName}</div>
                  <div className="text-sm text-gray-400 truncate">{profile?.email}</div>
                  <div className="text-xs text-blue-400 mt-0.5">{displayRole}</div>
                </div>
              </div>
            </div>
            <div className="p-2">
              <button
                onClick={() => navigate('/logout')}
                className="flex items-center gap-2 w-full px-3 py-2 text-sm text-red-400 hover:bg-gray-700 rounded-md transition-colors"
              >
                <LogOut size={16} />
                Sign out
              </button>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </header>
  );
};

export default Header;
