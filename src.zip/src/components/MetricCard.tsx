
import React from 'react';
import { ArrowDown, ArrowUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MetricCardProps {
  title: string;
  value: number | string;
  trend?: number;
  trendText?: string;
  icon: React.ReactNode;
  iconColor?: string;
}

const MetricCard = ({ title, value, trend = 0, trendText = "vs last month", icon, iconColor }: MetricCardProps) => {
  return (
    <div className="stat-card">
      <div className="flex justify-between items-center">
        <h3 className="text-sm text-gray-400">{title}</h3>
        <div className={cn("p-2 rounded-full", iconColor || "bg-gray-800")}>
          {icon}
        </div>
      </div>
      <div className="stat-value">{value}</div>
      {trend !== 0 && (
        <div className={trend > 0 ? "trend-up" : "trend-down"}>
          {trend > 0 ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
          <span className="text-sm ml-1">
            {Math.abs(trend)}% {trendText}
          </span>
        </div>
      )}
    </div>
  );
};

export default MetricCard;
