import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, Loader2 } from 'lucide-react';

const AcceptInvite = () => {
  const navigate = useNavigate();
  const { user, session, loading } = useAuth();
  const { toast } = useToast();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!session) {
      // No invite session in URL hash and no existing session — bounce to login.
      navigate('/', { replace: true });
    }
  }, [loading, session, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast({ variant: 'destructive', title: 'Password too short', description: 'Use at least 8 characters.' });
      return;
    }
    if (password !== confirm) {
      toast({ variant: 'destructive', title: 'Passwords do not match' });
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      setDone(true);
      setTimeout(() => navigate('/', { replace: true }), 1500);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to set password';
      toast({ variant: 'destructive', title: 'Could not set password', description: msg });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !session) {
    return (
      <div className="flex min-h-screen bg-cdm-dark text-white items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-cdm-dark text-white items-center justify-center p-4">
      <div className="max-w-md w-full bg-cdm-darker rounded-lg p-8 space-y-6">
        {done ? (
          <div className="text-center space-y-4">
            <CheckCircle className="h-12 w-12 text-green-400 mx-auto" />
            <h2 className="text-2xl font-bold">Welcome aboard</h2>
            <p className="text-gray-400">Redirecting to your dashboard…</p>
          </div>
        ) : (
          <>
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold">Set your password</h2>
              <p className="text-gray-400 text-sm">
                Signed in as <span className="text-white">{user?.email}</span>. Choose a password to finish setting up your account.
              </p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">New password</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete="new-password"
                  className="bg-gray-700 border-gray-600 text-gray-100"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={8}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm">Confirm password</Label>
                <Input
                  id="confirm"
                  type="password"
                  autoComplete="new-password"
                  className="bg-gray-700 border-gray-600 text-gray-100"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  required
                  minLength={8}
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={submitting}>
                {submitting ? (
                  <span className="flex items-center justify-center">
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving…
                  </span>
                ) : (
                  'Set password and continue'
                )}
              </Button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default AcceptInvite;
