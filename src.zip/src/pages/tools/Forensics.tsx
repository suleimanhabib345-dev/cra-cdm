
import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { CalendarDays, ChevronDown, File, FileSearch, FileText, HardDrive, Terminal } from 'lucide-react';
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

// Mock data for devices
const devices = [
  { id: 1, name: 'Device 1' },
  { id: 2, name: 'Device 2' },
  { id: 3, name: 'Device 3' },
  { id: 4, name: 'Device 4' },
  { id: 5, name: 'Device 5' },
];

const Forensics = () => {
  const [selectedDevice, setSelectedDevice] = useState<string>('');
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  
  return (
    <PageContainer title="Forensics Tools">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Device Selection */}
          <div className="w-full md:w-1/2">
            <label className="block text-sm font-medium text-gray-300 mb-1">Choose a Device</label>
            <Select value={selectedDevice} onValueChange={setSelectedDevice}>
              <SelectTrigger className="w-full bg-cdm-dark border-gray-700">
                <SelectValue placeholder="Choose a device" />
              </SelectTrigger>
              <SelectContent className="bg-cdm-darker border-gray-700">
                {devices.map(device => (
                  <SelectItem key={device.id} value={device.name}>
                    {device.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date Selection */}
          <div className="w-full md:w-1/2">
            <label className="block text-sm font-medium text-gray-300 mb-1">Analysis Point-in-Time</label>
            <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
              <PopoverTrigger asChild>
                <Button 
                  variant="outline" 
                  className="w-full justify-between bg-cdm-dark border-gray-700 text-left font-normal"
                >
                  <div className="flex items-center gap-2">
                    <CalendarDays className="h-4 w-4" />
                    {date ? format(date, "MMM d, yyyy") : "Select date"}
                  </div>
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-cdm-darker border-gray-700" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(date) => {
                    setDate(date);
                    setIsCalendarOpen(false);
                  }}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <Tabs defaultValue="file-system" className="mt-6">
          <TabsList className="bg-cdm-dark border-gray-700">
            <TabsTrigger value="file-system" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <div className="flex items-center gap-2">
                <File className="h-4 w-4" />
                <span>File System</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="processes" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4" />
                <span>Running Processes</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="storage" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <div className="flex items-center gap-2">
                <HardDrive className="h-4 w-4" />
                <span>Storage Analysis</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>System Logs</span>
              </div>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="file-system" className="mt-4">
            <Card className="bg-cdm-dark border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileSearch className="h-5 w-5" />
                  File System Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDevice ? (
                  <div className="space-y-4">
                    <p className="text-gray-300">Showing file system analysis for {selectedDevice}</p>
                    <div className="p-4 border border-gray-700 rounded-lg">
                      <h4 className="text-sm font-medium mb-2">API Endpoint</h4>
                      <div className="font-mono text-sm bg-black p-2 rounded overflow-x-auto">
                        GET /api/forensics/file-system?device={'{deviceId}'}&date={'{analysisDate}'}
                      </div>
                    </div>
                    <p className="text-gray-400 text-sm">This endpoint will return a complete file system snapshot for the selected device at the specified point in time.</p>
                  </div>
                ) : (
                  <div className="p-8 text-center text-gray-400">
                    <FileSearch className="h-10 w-10 mx-auto mb-3 opacity-50" />
                    <p>Please select a device to begin file system analysis</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="processes" className="mt-4">
            <Card className="bg-cdm-dark border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="h-5 w-5" />
                  Running Processes Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDevice ? (
                  <div className="space-y-4">
                    <p className="text-gray-300">Showing process analysis for {selectedDevice}</p>
                    <div className="p-4 border border-gray-700 rounded-lg">
                      <h4 className="text-sm font-medium mb-2">API Endpoint</h4>
                      <div className="font-mono text-sm bg-black p-2 rounded overflow-x-auto">
                        GET /api/forensics/processes?device={'{deviceId}'}&date={'{analysisDate}'}
                      </div>
                    </div>
                    <p className="text-gray-400 text-sm">This endpoint returns a list of all running processes on the selected device at the specified point in time.</p>
                  </div>
                ) : (
                  <div className="p-8 text-center text-gray-400">
                    <Terminal className="h-10 w-10 mx-auto mb-3 opacity-50" />
                    <p>Please select a device to view process information</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="storage" className="mt-4">
            <Card className="bg-cdm-dark border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <HardDrive className="h-5 w-5" />
                  Storage Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDevice ? (
                  <div className="space-y-4">
                    <p className="text-gray-300">Showing storage analysis for {selectedDevice}</p>
                    <div className="p-4 border border-gray-700 rounded-lg">
                      <h4 className="text-sm font-medium mb-2">API Endpoint</h4>
                      <div className="font-mono text-sm bg-black p-2 rounded overflow-x-auto">
                        GET /api/forensics/storage?device={'{deviceId}'}&date={'{analysisDate}'}
                      </div>
                    </div>
                    <p className="text-gray-400 text-sm">This endpoint provides detailed information about storage usage, partitions, and potential issues.</p>
                  </div>
                ) : (
                  <div className="p-8 text-center text-gray-400">
                    <HardDrive className="h-10 w-10 mx-auto mb-3 opacity-50" />
                    <p>Please select a device to analyze storage</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="logs" className="mt-4">
            <Card className="bg-cdm-dark border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  System Logs
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDevice ? (
                  <div className="space-y-4">
                    <p className="text-gray-300">Showing system logs for {selectedDevice}</p>
                    <div className="p-4 border border-gray-700 rounded-lg">
                      <h4 className="text-sm font-medium mb-2">API Endpoint</h4>
                      <div className="font-mono text-sm bg-black p-2 rounded overflow-x-auto">
                        GET /api/forensics/logs?device={'{deviceId}'}&date={'{analysisDate}'}&type={'{logType}'}
                      </div>
                    </div>
                    <p className="text-gray-400 text-sm">This endpoint retrieves system logs of various types (system, security, application) for forensic analysis.</p>
                  </div>
                ) : (
                  <div className="p-8 text-center text-gray-400">
                    <FileText className="h-10 w-10 mx-auto mb-3 opacity-50" />
                    <p>Please select a device to view system logs</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* API Overview Section */}
        <div className="mt-8 p-4 border border-gray-700 rounded-lg bg-cdm-dark">
          <h3 className="text-lg font-semibold mb-2">Forensics API Integration Guide</h3>
          <p className="text-gray-400 mb-3">Integrate your Golang agent with these forensics endpoints to collect and analyze device data:</p>
          
          <div className="space-y-3">
            <div className="font-mono text-sm bg-black p-3 rounded overflow-x-auto">
              GET /api/forensics/{'{analysisType}'}?device={'{deviceId}'}&date={'{analysisDate}'}
            </div>
            
            <h4 className="font-medium mt-4 mb-2">Available Analysis Types:</h4>
            <ul className="list-disc list-inside text-sm text-gray-400 space-y-1">
              <li><span className="text-blue-400">file-system</span>: File system analysis and snapshots</li>
              <li><span className="text-blue-400">processes</span>: Running processes and services</li>
              <li><span className="text-blue-400">storage</span>: Storage usage and partition analysis</li>
              <li><span className="text-blue-400">logs</span>: System log collection and analysis</li>
              <li><span className="text-blue-400">registry</span>: Windows registry analysis (Windows only)</li>
              <li><span className="text-blue-400">network</span>: Network configuration and connections</li>
            </ul>
            
            <h4 className="font-medium mt-4 mb-2">Authentication:</h4>
            <p className="text-sm text-gray-400">All API requests require an Authorization header with a valid API token.</p>
            
            <div className="font-mono text-sm bg-black p-3 rounded overflow-x-auto mt-2">
              Authorization: Bearer {'{your_api_token}'}
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default Forensics;
