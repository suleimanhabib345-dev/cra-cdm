
import React from 'react';
import PageContainer from '@/components/PageContainer';

const Scanner = () => {
  return (
    <PageContainer title="Vulnerability Scanner">
      <div className="bg-cdm-darker rounded-lg p-6">
        <p className="text-gray-300">Vulnerability scanning tool interface will be displayed here.</p>
      </div>
    </PageContainer>
  );
};

export default Scanner;
