import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Github, Play, Square, ChevronDown, ChevronRight, Shield, AlertTriangle,
  GitBranch, Clock, CheckCircle2, XCircle, Loader2, RefreshCw, Globe,
  Link2, Unlink, FileCode, Info, Download, Webhook, RotateCw,
  Monitor, Zap, Bot, Trash2, X,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PageContainer from '@/components/PageContainer';
import ProviderSettings from '@/components/webscan/ProviderSettings';
import CICDAttackGraph from '@/components/cicd/CICDAttackGraph';
import { loadProviderConfig } from '@/services/webscanService';
import type { AIProviderConfig } from '@/types/webscan';

const CICD_API_URL = import.meta.env.VITE_CICD_API_URL || 'http://localhost:8403';
const CICD_CONN_KEY = 'cra_cicd_connection';
const CICD_HISTORY_KEY = 'cra_cicd_history';

// ── Types ────────────────────────────────────────────────────────────────────

interface GitHubConnection {
  connectionId: string;
  login: string;
  name: string;
  avatarUrl: string;
}

interface Repo {
  id: number;
  fullName: string;
  name: string;
  description: string;
  language: string | null;
  defaultBranch: string;
  private: boolean;
  stars: number;
  updatedAt: string;
  htmlUrl: string;
}

interface Branch { name: string; sha: string }

interface PipelineFinding {
  id?: string;
  title: string;
  severity: string;
  endpoint?: string;
  description?: string;
}

interface RepoFinding {
  path: string;
  label: string;
  severity: string;
}

interface PipelineResult {
  id: string;
  repo: string;
  branch: string;
  deploymentUrl?: string;
  status: string;
  technologies: string[];
  findings: PipelineFinding[];
  repoFindings: RepoFinding[];
  createdAt: string;
  endTime?: string;
}

interface TerminalLine {
  id: number;
  timestamp: string;
  type: string;
  message: string;
}

interface HistoryEntry {
  pipelineId: string;
  repo: string;
  branch: string;
  status: string;
  findingsCount: number;
  createdAt: string;
}

// ── Severity colours ─────────────────────────────────────────────────────────

const SEV: Record<string, { bg: string; text: string; border: string }> = {
  CRITICAL: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-red-500/30' },
  HIGH:     { bg: 'bg-orange-900/30', text: 'text-orange-400', border: 'border-orange-500/30' },
  MEDIUM:   { bg: 'bg-amber-900/30', text: 'text-amber-400', border: 'border-amber-500/30' },
  LOW:      { bg: 'bg-blue-900/30', text: 'text-blue-400', border: 'border-blue-500/30' },
  INFO:     { bg: 'bg-gray-800', text: 'text-gray-400', border: 'border-gray-700' },
  critical: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-red-500/30' },
  high:     { bg: 'bg-orange-900/30', text: 'text-orange-400', border: 'border-orange-500/30' },
  medium:   { bg: 'bg-amber-900/30', text: 'text-amber-400', border: 'border-amber-500/30' },
  low:      { bg: 'bg-blue-900/30', text: 'text-blue-400', border: 'border-blue-500/30' },
  info:     { bg: 'bg-gray-800', text: 'text-gray-400', border: 'border-gray-700' },
};

const LINE_COLORS: Record<string, string> = {
  system: 'text-gray-500',
  info: 'text-cyan-400',
  success: 'text-emerald-400',
  warning: 'text-amber-400',
  error: 'text-red-400',
  check: 'text-purple-400',
};

function loadHistory(): HistoryEntry[] {
  try { return JSON.parse(localStorage.getItem(CICD_HISTORY_KEY) || '[]'); } catch { return []; }
}
function saveHistory(h: HistoryEntry[]) {
  localStorage.setItem(CICD_HISTORY_KEY, JSON.stringify(h));
}
function loadConnection(): GitHubConnection | null {
  try { return JSON.parse(localStorage.getItem(CICD_CONN_KEY) || 'null'); } catch { return null; }
}

// ── Component ─────────────────────────────────────────────────────────────────

const CICDScan: React.FC = () => {
  // Connection state
  const [connection, setConnection] = useState<GitHubConnection | null>(loadConnection);
  const [githubToken, setGithubToken] = useState('');
  const [connecting, setConnecting] = useState(false);
  const [connectError, setConnectError] = useState('');

  // Repo/branch selection
  const [repos, setRepos] = useState<Repo[]>([]);
  const [loadingRepos, setLoadingRepos] = useState(false);
  const [selectedRepo, setSelectedRepo] = useState<Repo | null>(null);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranch, setSelectedBranch] = useState('');
  const [deploymentUrl, setDeploymentUrl] = useState('');
  const [repoSearch, setRepoSearch] = useState('');

  // Scan state
  const [scanStatus, setScanStatus] = useState<string>('idle');
  const [pipelineId, setPipelineId] = useState<string | null>(null);
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([]);
  const [result, setResult] = useState<PipelineResult | null>(null);

  // UI state
  const [activeTab, setActiveTab] = useState('scan');
  const [history, setHistory] = useState<HistoryEntry[]>(loadHistory);
  const [webhookCopied, setWebhookCopied] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [providerSettingsOpen, setProviderSettingsOpen] = useState(false);
  const [providerConfig, setProviderConfig] = useState<AIProviderConfig | null>(loadProviderConfig);
  const [selectedHistoryId, setSelectedHistoryId] = useState<string | null>(null);
  const [historyResults, setHistoryResults] = useState<Record<string, PipelineResult | null>>({});
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showConnectForm, setShowConnectForm] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const terminalRef = useRef<HTMLDivElement>(null);
  const isRunning = scanStatus === 'connecting' || scanStatus === 'scanning';

  // Auto-scroll terminal
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalLines]);

  // Load repos when connected
  useEffect(() => {
    if (connection) fetchRepos();
  }, [connection]);

  const fetchRepos = async () => {
    if (!connection) return;
    setLoadingRepos(true);
    try {
      const resp = await fetch(`${CICD_API_URL}/api/github/${connection.connectionId}/repos`);
      if (resp.status === 404) {
        // Server was restarted and lost in-memory state — clear stale connection
        setConnection(null);
        localStorage.removeItem(CICD_CONN_KEY);
        return;
      }
      if (resp.ok) setRepos(await resp.json());
    } catch { /* ignore */ } finally {
      setLoadingRepos(false);
    }
  };

  const fetchBranches = async (repo: Repo) => {
    if (!connection) return;
    const [owner, name] = repo.fullName.split('/');
    try {
      const resp = await fetch(`${CICD_API_URL}/api/github/${connection.connectionId}/repos/${owner}/${name}/branches`);
      if (resp.ok) {
        const data: Branch[] = await resp.json();
        setBranches(data);
        setSelectedBranch(repo.defaultBranch);
      }
    } catch { setBranches([]); }
  };

  const handleConnect = async () => {
    if (!githubToken.trim()) return;
    setConnecting(true);
    setConnectError('');
    try {
      const resp = await fetch(`${CICD_API_URL}/api/github/connect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: githubToken }),
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.detail || 'Connection failed');
      }
      const data: GitHubConnection = await resp.json();
      setConnection(data);
      localStorage.setItem(CICD_CONN_KEY, JSON.stringify(data));
      setGithubToken('');
      setShowConnectForm(false);
    } catch (e) {
      if (e instanceof TypeError) {
        setConnectError(`Cannot reach backend at ${CICD_API_URL} — check that the CI/CD service is running`);
      } else {
        setConnectError(e instanceof Error ? e.message : 'Connection failed');
      }
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = () => {
    setConnection(null);
    setRepos([]);
    setSelectedRepo(null);
    setBranches([]);
    localStorage.removeItem(CICD_CONN_KEY);
  };

  const handleSelectRepo = (repo: Repo) => {
    setSelectedRepo(repo);
    fetchBranches(repo);
    setDeploymentUrl('');
  };

  const handleStartScan = useCallback(async () => {
    if (!connection || !selectedRepo) return;

    setTerminalLines([]);
    setResult(null);
    setScanStatus('connecting');
    setActiveTab('terminal');

    try {
      const resp = await fetch(
        `${CICD_API_URL}/api/pipeline/scan?connection_id=${connection.connectionId}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            repoFullName: selectedRepo.fullName,
            branch: selectedBranch || selectedRepo.defaultBranch,
            deploymentUrl: deploymentUrl || undefined,
            scanType: 'full',
          }),
        },
      );
      if (!resp.ok) throw new Error(await resp.text());
      const data = await resp.json();
      const id = data.pipelineId;
      setPipelineId(id);

      // Connect WebSocket
      const wsUrl = CICD_API_URL.replace(/^http/, 'ws');
      const ws = new WebSocket(`${wsUrl}/ws/pipeline/${id}`);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'terminal') {
            setTerminalLines(prev => [...prev, msg.data as TerminalLine]);
          } else if (msg.type === 'status') {
            const status = msg.data.status;
            setScanStatus(status);
            if (status === 'completed' || status === 'error' || status === 'cancelled') {
              fetchResults(id);
            }
          }
        } catch { /* ignore */ }
      };
      ws.onclose = () => {};
      ws.onerror = () => ws.close();

    } catch (err) {
      setScanStatus('error');
      setTerminalLines([{ id: 1, timestamp: new Date().toLocaleTimeString(), type: 'error', message: `Failed: ${err instanceof Error ? err.message : String(err)}` }]);
    }
  }, [connection, selectedRepo, selectedBranch, deploymentUrl]);

  const fetchResults = async (id: string) => {
    try {
      const resp = await fetch(`${CICD_API_URL}/api/pipeline/${id}/results`);
      if (resp.ok) {
        const data: PipelineResult = await resp.json();
        setResult(data);
        const entry: HistoryEntry = {
          pipelineId: id,
          repo: data.repo,
          branch: data.branch,
          status: data.status,
          findingsCount: data.findings.length + data.repoFindings.length,
          createdAt: data.createdAt,
        };
        setHistory(prev => { const h = [entry, ...prev.slice(0, 49)]; saveHistory(h); return h; });
      }
    } catch { /* ignore */ }
  };

  const handleStop = () => {
    if (pipelineId) fetch(`${CICD_API_URL}/api/pipeline/${pipelineId}/cancel`, { method: 'POST' });
    wsRef.current?.close();
    setScanStatus('cancelled');
  };

  const handleCopyWebhook = () => {
    navigator.clipboard.writeText(`${CICD_API_URL}/api/github/webhook`);
    setWebhookCopied(true);
    setTimeout(() => setWebhookCopied(false), 2000);
  };

  const handleDeleteHistory = (id: string) => {
    setHistory(prev => { const h = prev.filter(e => e.pipelineId !== id); saveHistory(h); return h; });
    if (selectedHistoryId === id) setSelectedHistoryId(null);
    setDeleteConfirm(null);
  };

  const handleHistorySelect = async (entry: HistoryEntry) => {
    const id = entry.pipelineId;
    if (selectedHistoryId === id) { setSelectedHistoryId(null); return; }
    setSelectedHistoryId(id);
    if (id in historyResults) return;
    try {
      const resp = await fetch(`${CICD_API_URL}/api/pipeline/${id}/results`);
      if (resp.ok) {
        const data: PipelineResult = await resp.json();
        setHistoryResults(prev => ({ ...prev, [id]: data }));
      } else {
        setHistoryResults(prev => ({ ...prev, [id]: null }));
      }
    } catch {
      setHistoryResults(prev => ({ ...prev, [id]: null }));
    }
  };

  const filteredRepos = repos.filter(r =>
    r.fullName.toLowerCase().includes(repoSearch.toLowerCase()) ||
    (r.description || '').toLowerCase().includes(repoSearch.toLowerCase()),
  );

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <PageContainer title="">
      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h1 className="text-2xl font-bold text-white">CI/CD Pipeline</h1>
              <Badge className="bg-blue-600 text-white text-[10px] px-2 py-0.5">GITHUB</Badge>
            </div>
            <p className="text-sm text-gray-400">
              Connect GitHub repos, trigger security scans on push/PR, and monitor pipeline health
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setProviderSettingsOpen(true)}
              className="border-gray-700 text-gray-400 hover:text-white gap-2 h-9"
            >
              <Bot size={14} />
              <span className="text-xs">AI Provider</span>
              {providerConfig && (
                <span className="text-[10px] font-semibold text-emerald-400">
                  {providerConfig.name}
                </span>
              )}
            </Button>
            {connection && (
              <>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-cdm-darker rounded-lg border border-gray-700">
                  {connection.avatarUrl && (
                    <img src={connection.avatarUrl} alt="" className="w-5 h-5 rounded-full" />
                  )}
                  <span className="text-xs text-gray-300">{connection.login}</span>
                  <Badge className="bg-emerald-900/30 text-emerald-400 border-0 text-[9px]">connected</Badge>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDisconnect}
                  className="border-gray-700 text-gray-400 hover:text-red-400 gap-1.5"
                >
                  <Unlink size={13} />
                  Disconnect
                </Button>
              </>
            )}
          </div>
        </div>

        {/* GitHub Connection */}
        {!connection && (
          <div className="bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden">
            {!showConnectForm ? (
              /* Prominent connect landing */
              <div className="flex flex-col items-center justify-center py-14 px-6 text-center">
                <div className="w-16 h-16 rounded-full bg-gray-800 border border-gray-700 flex items-center justify-center mb-5">
                  <Github size={32} className="text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Connect to GitHub</h3>
                <p className="text-sm text-gray-400 max-w-sm mb-6">
                  Link your GitHub account to scan repositories, detect CI/CD vulnerabilities, and visualise attack paths from pipeline findings.
                </p>
                <Button
                  onClick={() => setShowConnectForm(true)}
                  className="bg-[#238636] hover:bg-[#2ea043] text-white gap-2 px-6 h-10 text-sm font-medium"
                >
                  <Github size={16} />
                  Connect to GitHub
                </Button>
                <p className="text-[11px] text-gray-600 mt-4">
                  Uses a Personal Access Token — no OAuth redirect required
                </p>
              </div>
            ) : (
              /* PAT form */
              <div className="p-6">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-8 h-8 rounded-full bg-gray-800 border border-gray-700 flex items-center justify-center">
                    <Github size={16} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">GitHub Personal Access Token</h3>
                    <p className="text-[11px] text-gray-500">Requires <code className="text-gray-400">repo</code> scope for private repos</p>
                  </div>
                </div>
                <div className="flex gap-3 max-w-lg">
                  <div className="flex-1">
                    <Input
                      type={showToken ? 'text' : 'password'}
                      value={githubToken}
                      onChange={e => setGithubToken(e.target.value)}
                      placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                      className="bg-cdm-dark border-gray-700 text-white font-mono text-sm"
                      onKeyDown={e => { if (e.key === 'Enter') handleConnect(); }}
                      autoFocus
                    />
                  </div>
                  <Button
                    onClick={handleConnect}
                    disabled={!githubToken.trim() || connecting}
                    className="bg-[#238636] hover:bg-[#2ea043] text-white gap-2"
                  >
                    {connecting ? <Loader2 size={14} className="animate-spin" /> : <Link2 size={14} />}
                    Authenticate
                  </Button>
                </div>
                {connectError && (
                  <p className="text-xs text-red-400 mt-2 flex items-center gap-1.5">
                    <XCircle size={12} /> {connectError}
                  </p>
                )}
                <div className="flex items-center gap-3 mt-4">
                  <p className="text-[10px] text-gray-600">
                    Generate at GitHub → Settings → Developer settings → Personal access tokens (classic)
                  </p>
                  <button
                    onClick={() => { setShowConnectForm(false); setConnectError(''); setGithubToken(''); }}
                    className="text-[10px] text-gray-500 hover:text-gray-300 ml-auto flex-shrink-0"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Main Content — only when connected */}
        {connection && (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="flex items-center justify-between">
              <TabsList className="bg-cdm-darker border border-gray-800">
                <TabsTrigger value="scan" className="text-xs data-[state=active]:bg-blue-900/30 data-[state=active]:text-blue-400 gap-1.5">
                  <Github size={12} />
                  Select Repository
                </TabsTrigger>
                <TabsTrigger value="terminal" className="text-xs data-[state=active]:bg-blue-900/30 data-[state=active]:text-blue-400 gap-1.5">
                  <Monitor size={12} />
                  Pipeline Terminal
                  {isRunning && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />}
                </TabsTrigger>
                <TabsTrigger value="results" className="text-xs data-[state=active]:bg-blue-900/30 data-[state=active]:text-blue-400 gap-1.5">
                  <Shield size={12} />
                  Results
                  {result && (result.findings.length + result.repoFindings.length) > 0 && (
                    <Badge className="bg-red-600 text-white text-[10px] px-1.5 py-0">
                      {result.findings.length + result.repoFindings.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="history" className="text-xs data-[state=active]:bg-blue-900/30 data-[state=active]:text-blue-400 gap-1.5">
                  <Clock size={12} />
                  History
                  {history.length > 0 && (
                    <Badge className="bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{history.length}</Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="webhook" className="text-xs data-[state=active]:bg-blue-900/30 data-[state=active]:text-blue-400 gap-1.5">
                  <Webhook size={12} />
                  Webhook
                </TabsTrigger>
              </TabsList>

              {isRunning ? (
                <Button onClick={handleStop} className="bg-gray-700 hover:bg-gray-600 text-white gap-2 h-9">
                  <Square size={13} /> STOP
                </Button>
              ) : (
                <Button
                  onClick={handleStartScan}
                  disabled={!selectedRepo}
                  className="bg-blue-600 hover:bg-blue-700 text-white gap-2 h-9"
                >
                  <Play size={13} /> RUN PIPELINE
                </Button>
              )}
            </div>

            {/* SELECT REPO TAB */}
            <TabsContent value="scan" className="mt-4 space-y-4">
              {/* Repo search + config */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Repositories ({repos.length})
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={fetchRepos}
                      disabled={loadingRepos}
                      className="text-gray-500 hover:text-white h-7 gap-1.5"
                    >
                      {loadingRepos ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                      Refresh
                    </Button>
                  </div>
                  <Input
                    value={repoSearch}
                    onChange={e => setRepoSearch(e.target.value)}
                    placeholder="Search repositories..."
                    className="bg-cdm-dark border-gray-700 text-white h-9 text-xs"
                  />
                  <div className="bg-cdm-darker rounded-lg border border-gray-800 divide-y divide-gray-800 max-h-80 overflow-y-auto">
                    {filteredRepos.length === 0 && (
                      <div className="py-8 text-center text-gray-600 text-sm">
                        {loadingRepos ? 'Loading repositories...' : 'No repositories found'}
                      </div>
                    )}
                    {filteredRepos.map(repo => (
                      <button
                        key={repo.id}
                        onClick={() => handleSelectRepo(repo)}
                        className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors ${
                          selectedRepo?.id === repo.id ? 'bg-blue-900/10 border-l-2 border-l-blue-500' : ''
                        }`}
                      >
                        <Github size={15} className="text-gray-500 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-white font-medium truncate">{repo.fullName}</span>
                            {repo.private && (
                              <Badge className="bg-gray-700 text-gray-400 text-[8px] border-0 px-1">private</Badge>
                            )}
                          </div>
                          {repo.description && (
                            <p className="text-[11px] text-gray-500 truncate">{repo.description}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {repo.language && (
                            <span className="text-[10px] text-gray-500">{repo.language}</span>
                          )}
                          <GitBranch size={11} className="text-gray-600" />
                          <span className="text-[10px] text-gray-600">{repo.defaultBranch}</span>
                        </div>
                        {selectedRepo?.id === repo.id && (
                          <CheckCircle2 size={15} className="text-blue-400 flex-shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Config panel */}
                <div className="space-y-4">
                  <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Scan Config</h3>

                  {selectedRepo ? (
                    <div className="bg-cdm-darker rounded-lg border border-blue-500/20 p-4 space-y-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <CheckCircle2 size={14} className="text-blue-400" />
                          <span className="text-xs text-white font-medium">{selectedRepo.name}</span>
                        </div>
                        <p className="text-[10px] text-gray-500">{selectedRepo.fullName}</p>
                      </div>

                      <div>
                        <label className="text-[10px] text-gray-500 mb-1 block">Branch</label>
                        <select
                          value={selectedBranch}
                          onChange={e => setSelectedBranch(e.target.value)}
                          className="w-full bg-cdm-dark border border-gray-700 text-gray-300 text-xs rounded-md px-2 py-1.5"
                        >
                          {branches.map(b => (
                            <option key={b.name} value={b.name}>{b.name}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] text-gray-500 mb-1 block flex items-center gap-1">
                          <Globe size={10} />
                          Deployment URL (optional)
                        </label>
                        <Input
                          value={deploymentUrl}
                          onChange={e => setDeploymentUrl(e.target.value)}
                          placeholder="https://your-app.com"
                          className="bg-cdm-dark border-gray-700 text-white text-xs h-8"
                        />
                        <p className="text-[9px] text-gray-600 mt-1">
                          If provided, runs a full web security scan against this URL
                        </p>
                      </div>

                      <div className="pt-2 border-t border-gray-800 space-y-1">
                        <div className="flex items-center gap-1.5 text-[10px] text-gray-500">
                          <FileCode size={10} />
                          Repository tree analysis (always)
                        </div>
                        <div className={`flex items-center gap-1.5 text-[10px] ${deploymentUrl ? 'text-blue-400' : 'text-gray-600'}`}>
                          <Shield size={10} />
                          Web security scan {deploymentUrl ? '✓' : '(requires deployment URL)'}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-cdm-darker rounded-lg border border-gray-800 p-6 flex flex-col items-center justify-center text-center">
                      <Github size={28} className="text-gray-700 mb-2" />
                      <p className="text-xs text-gray-600">Select a repository to configure</p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* TERMINAL TAB */}
            <TabsContent value="terminal" className="mt-4">
              <div className="bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2 border-b border-gray-800">
                  <div className="flex items-center gap-2">
                    <Monitor size={13} className="text-gray-500" />
                    <span className="text-xs text-gray-400">Pipeline Terminal</span>
                    {isRunning && (
                      <span className="flex items-center gap-1 text-[10px] text-cyan-400">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                        Running
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      scanStatus === 'completed' ? 'bg-emerald-900/30 text-emerald-400' :
                      scanStatus === 'error' ? 'bg-red-900/30 text-red-400' :
                      scanStatus === 'scanning' || scanStatus === 'connecting' ? 'bg-cyan-900/30 text-cyan-400' :
                      'bg-gray-800 text-gray-500'
                    }`}>
                      {scanStatus}
                    </span>
                  </div>
                </div>
                <div
                  ref={terminalRef}
                  className="font-mono text-[11px] p-4 h-80 overflow-y-auto space-y-0.5 bg-black/20"
                >
                  {terminalLines.length === 0 ? (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-gray-600">Run a pipeline scan to see output</p>
                    </div>
                  ) : terminalLines.map(line => (
                    <div key={line.id} className="flex gap-2">
                      <span className="text-gray-600 flex-shrink-0">[{line.timestamp}]</span>
                      <span className={LINE_COLORS[line.type] || 'text-gray-300'}>{line.message}</span>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* RESULTS TAB */}
            <TabsContent value="results" className="mt-4 space-y-4">
              {!result ? (
                <div className="flex flex-col items-center justify-center py-16 bg-cdm-darker rounded-lg border border-gray-800">
                  <Shield size={40} className="text-gray-700 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No results yet</h3>
                  <p className="text-sm text-gray-500">Run a pipeline scan to see security findings</p>
                </div>
              ) : (
                <>
                  {/* Summary */}
                  <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
                    <div className="flex items-center gap-4 flex-wrap">
                      <div>
                        <p className="text-[10px] text-gray-500">Repository</p>
                        <p className="text-sm font-medium text-white">{result.repo}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-500">Branch</p>
                        <p className="text-sm text-gray-300">{result.branch}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-500">Status</p>
                        <Badge className={`text-[10px] ${result.status === 'completed' ? 'bg-emerald-900/30 text-emerald-400 border-0' : 'bg-red-900/30 text-red-400 border-0'}`}>
                          {result.status}
                        </Badge>
                      </div>
                      {result.technologies.length > 0 && (
                        <div>
                          <p className="text-[10px] text-gray-500">Tech Stack</p>
                          <p className="text-sm text-gray-300">{result.technologies.join(', ')}</p>
                        </div>
                      )}
                      <div className="ml-auto">
                        <p className="text-[10px] text-gray-500">Total Issues</p>
                        <p className="text-2xl font-bold text-white">
                          {result.findings.length + result.repoFindings.length}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Web scan findings */}
                  {result.findings.length > 0 && (
                    <div>
                      <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                        Web Security Findings ({result.findings.length})
                      </h3>
                      <div className="bg-cdm-darker rounded-lg border border-gray-800 divide-y divide-gray-800">
                        {result.findings.map((f, i) => {
                          const s = SEV[f.severity] || SEV.info;
                          return (
                            <div key={i} className="flex items-start gap-3 px-4 py-3">
                              <Badge className={`${s.bg} ${s.text} border-0 text-[9px] uppercase w-16 justify-center flex-shrink-0 mt-0.5`}>
                                {f.severity}
                              </Badge>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm text-white">{f.title}</p>
                                {f.endpoint && <p className="text-[10px] text-gray-500 font-mono mt-0.5">{f.endpoint}</p>}
                                {f.description && <p className="text-[11px] text-gray-400 mt-1">{f.description}</p>}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Repo findings */}
                  {result.repoFindings.length > 0 && (
                    <div>
                      <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                        Repository Issues ({result.repoFindings.length})
                      </h3>
                      <div className="bg-cdm-darker rounded-lg border border-gray-800 divide-y divide-gray-800">
                        {result.repoFindings.map((f, i) => {
                          const s = SEV[f.severity] || SEV.info;
                          return (
                            <div key={i} className="flex items-start gap-3 px-4 py-3">
                              <Badge className={`${s.bg} ${s.text} border-0 text-[9px] uppercase w-16 justify-center flex-shrink-0 mt-0.5`}>
                                {f.severity}
                              </Badge>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm text-white">{f.label}</p>
                                <p className="text-[10px] text-gray-500 font-mono mt-0.5">{f.path}</p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              )}
            </TabsContent>

            {/* HISTORY TAB */}
            <TabsContent value="history" className="mt-4 space-y-4">
              {history.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 bg-cdm-darker rounded-lg border border-gray-800">
                  <Clock size={40} className="text-gray-700 mb-4" />
                  <p className="text-sm text-gray-500">No pipeline runs yet</p>
                </div>
              ) : (
                <>
                  <div className="bg-cdm-darker rounded-lg border border-gray-800 divide-y divide-gray-800 max-h-[420px] overflow-y-auto">
                    {history.map(h => (
                      <div
                        key={h.pipelineId}
                        className={`flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors ${
                          selectedHistoryId === h.pipelineId ? 'bg-blue-900/10 border-l-2 border-l-blue-500' : ''
                        }`}
                      >
                        <button onClick={() => handleHistorySelect(h)} className="flex items-center gap-3 flex-1 min-w-0 text-left">
                          <Github size={15} className="text-gray-500 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-white font-medium truncate">{h.repo}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <GitBranch size={10} className="text-gray-600" />
                              <span className="text-[10px] text-gray-500">{h.branch}</span>
                              <span className="text-[10px] text-gray-600">·</span>
                              <span className="text-[10px] text-gray-500">{new Date(h.createdAt).toLocaleString()}</span>
                            </div>
                          </div>
                          <Badge className={`text-[9px] border-0 ${h.findingsCount > 0 ? 'bg-red-900/30 text-red-400' : 'bg-emerald-900/30 text-emerald-400'}`}>
                            {h.findingsCount} issue(s)
                          </Badge>
                          <Badge className={`text-[9px] border-0 ${h.status === 'completed' ? 'bg-gray-800 text-gray-400' : 'bg-red-900/20 text-red-500'}`}>
                            {h.status}
                          </Badge>
                          <ChevronRight size={14} className={`text-gray-600 flex-shrink-0 transition-transform ${selectedHistoryId === h.pipelineId ? 'rotate-90' : ''}`} />
                        </button>
                        {deleteConfirm === h.pipelineId ? (
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <Button size="sm" onClick={() => handleDeleteHistory(h.pipelineId)} className="bg-red-600 hover:bg-red-700 text-white h-6 px-2 text-[10px]">Confirm</Button>
                            <Button variant="ghost" size="sm" onClick={() => setDeleteConfirm(null)} className="text-gray-400 h-6 w-6 p-0"><X size={11} /></Button>
                          </div>
                        ) : (
                          <button onClick={() => setDeleteConfirm(h.pipelineId)} className="p-1 rounded text-gray-600 hover:text-red-400 hover:bg-red-900/20 transition-colors flex-shrink-0" title="Delete">
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  {selectedHistoryId && historyResults[selectedHistoryId] != null && (
                    <div className="bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden">
                      <div className="px-4 py-2.5 border-b border-gray-800 flex items-center gap-2">
                        <Shield size={13} className="text-blue-400" />
                        <span className="text-xs font-medium text-gray-300">Attack Graph</span>
                        <span className="text-[10px] text-gray-500 ml-auto">{historyResults[selectedHistoryId]!.repo} / {historyResults[selectedHistoryId]!.branch}</span>
                      </div>
                      <CICDAttackGraph
                        result={historyResults[selectedHistoryId]!}
                        persistKey={selectedHistoryId}
                      />
                    </div>
                  )}

                  {selectedHistoryId && !(selectedHistoryId in historyResults) && (
                    <div className="flex items-center justify-center py-8 bg-cdm-darker rounded-lg border border-gray-800">
                      <Loader2 size={16} className="animate-spin text-gray-500 mr-2" />
                      <span className="text-sm text-gray-500">Loading attack graph...</span>
                    </div>
                  )}

                  {selectedHistoryId && historyResults[selectedHistoryId] === null && (
                    <div className="flex items-center justify-center py-8 bg-cdm-darker rounded-lg border border-gray-800">
                      <span className="text-sm text-gray-500">Attack graph unavailable — pipeline data not found on server.</span>
                    </div>
                  )}
                </>
              )}
            </TabsContent>

            {/* WEBHOOK TAB */}
            <TabsContent value="webhook" className="mt-4 space-y-4">
              <div className="bg-cdm-darker rounded-lg border border-gray-800 p-6 space-y-6">
                <div>
                  <h3 className="text-sm font-semibold text-white mb-1 flex items-center gap-2">
                    <Webhook size={16} className="text-blue-400" />
                    GitHub Webhook Integration
                  </h3>
                  <p className="text-xs text-gray-500">
                    Configure a webhook in your GitHub repo to automatically trigger pipeline scans on push or pull request events.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-gray-400">Webhook URL</label>
                  <div className="flex gap-2">
                    <Input
                      readOnly
                      value={`${CICD_API_URL}/api/github/webhook`}
                      className="bg-cdm-dark border-gray-700 text-gray-300 font-mono text-xs flex-1"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopyWebhook}
                      className="border-gray-700 text-gray-400 hover:text-white"
                    >
                      {webhookCopied ? <CheckCircle2 size={14} className="text-emerald-400" /> : 'Copy'}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-gray-400">
                  <p className="font-semibold text-gray-300">Setup Instructions</p>
                  <ol className="list-decimal list-inside space-y-1.5 text-gray-500">
                    <li>Go to your GitHub repository → Settings → Webhooks → Add webhook</li>
                    <li>Paste the Webhook URL above in the "Payload URL" field</li>
                    <li>Set Content type to <code className="text-gray-400">application/json</code></li>
                    <li>Select events: <strong className="text-gray-400">Pushes</strong> and <strong className="text-gray-400">Pull requests</strong></li>
                    <li>Click "Add webhook" — GitHub will send a ping to verify</li>
                  </ol>
                </div>

                <div className="bg-amber-900/10 border border-amber-500/20 rounded-md p-3">
                  <p className="text-[11px] text-amber-400 flex items-start gap-2">
                    <Info size={13} className="flex-shrink-0 mt-0.5" />
                    For webhooks to reach this service, ensure port 8403 is publicly accessible or use a reverse proxy. The webhook receiver logs events but requires a connected GitHub token for automated scans.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>

      <ProviderSettings
        open={providerSettingsOpen}
        onClose={() => setProviderSettingsOpen(false)}
        onSave={(cfg) => setProviderConfig(cfg)}
      />
    </PageContainer>
  );
};

export default CICDScan;
