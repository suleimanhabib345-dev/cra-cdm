import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  Radar, Zap, ArrowRight, Info, X, Clock, RotateCw, Trash2,
  Download, Eye, EyeOff, ExternalLink, Search, ArrowUpDown, FileDown, GitCompare,
  Settings2, Square, Network,
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import PageContainer from '@/components/PageContainer';
import ScanConfigPanel from '@/components/adscan/ScanConfigPanel';
import ScanTerminal from '@/components/adscan/ScanTerminal';
import ADNodeGraph from '@/components/adscan/ADNodeGraph';
import ScanResultsPanel from '@/components/adscan/ScanResultsPanel';
import FindingsTable from '@/components/adscan/FindingsTable';
import {
  getMockScanResult,
  getMockTerminalLines,
  getMockGraphData,
  startScanLive,
  connectScanWebSocket,
  pollScanUntilComplete,
  getScanResults,
  getGraphData,
  cancelScan,
} from '@/services/adscanService';
import ProviderSettings from '@/components/webscan/ProviderSettings';
import { loadProviderConfig } from '@/services/aiProviderService';
import type { AIProviderConfig } from '@/services/aiProviderService';
import { SCAN_MODULES } from '@/types/adscan';
import type { ScanConfig, ScanResult, TerminalLine, GraphData, ScanStatus, ScanSeverity } from '@/types/adscan';

interface ADScanHistory {
  id: string;
  domain: string;
  dcIp: string;
  date: string;
  findings: number;
  severities: { CRITICAL: number; HIGH: number; MEDIUM: number; LOW: number; INFO: number };
  riskScore: number;
  status: 'Completed' | 'Failed' | 'In Progress';
  scanType: string;
  duration: string;
  checksRun: number;
  topFindings?: { title: string; severity: ScanSeverity; category: string }[];
  graphData?: GraphData;
  fullResult?: ScanResult;
}

const SEVERITY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  CRITICAL: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-red-500/30' },
  HIGH: { bg: 'bg-orange-900/30', text: 'text-orange-400', border: 'border-orange-500/30' },
  MEDIUM: { bg: 'bg-amber-900/30', text: 'text-amber-400', border: 'border-amber-500/30' },
  LOW: { bg: 'bg-blue-900/30', text: 'text-blue-400', border: 'border-blue-500/30' },
  INFO: { bg: 'bg-gray-800', text: 'text-gray-400', border: 'border-gray-700' },
};

const AD_HISTORY_KEY = 'cra_adscan_history';

const MOCK_AD_HISTORY: ADScanHistory[] = [
  {
    id: 'adh1', domain: 'corp.acme.local', dcIp: '10.0.0.5', date: '2026-04-05 14:30',
    findings: 18, severities: { CRITICAL: 3, HIGH: 5, MEDIUM: 6, LOW: 4, INFO: 0 },
    riskScore: 78, status: 'Completed', scanType: 'Full Scan', duration: '4m 32s', checksRun: 42,
    topFindings: [
      { title: 'Unconstrained Delegation on SRV-FILE01', severity: 'CRITICAL', category: 'Delegation' },
      { title: 'Kerberoastable svc_sql with weak SPN', severity: 'CRITICAL', category: 'Kerberos' },
      { title: 'ZeroLogon — DC01 unpatched', severity: 'CRITICAL', category: 'CVE Detection' },
      { title: 'LAPS not deployed on 73% of workstations', severity: 'HIGH', category: 'Infrastructure' },
      { title: 'Password policy minimum length 6 chars', severity: 'HIGH', category: 'Identity & Access' },
    ],
  },
  {
    id: 'adh2', domain: 'dev.internal.io', dcIp: '172.16.1.10', date: '2026-04-04 09:15',
    findings: 8, severities: { CRITICAL: 1, HIGH: 2, MEDIUM: 3, LOW: 2, INFO: 0 },
    riskScore: 52, status: 'Completed', scanType: 'Full Scan', duration: '3m 18s', checksRun: 42,
    topFindings: [
      { title: 'ADCS ESC1 vulnerable template — WebServer', severity: 'CRITICAL', category: 'Certificates & PKI' },
      { title: 'SMB signing not required', severity: 'HIGH', category: 'Infrastructure' },
    ],
  },
  {
    id: 'adh3', domain: 'hq.contoso.local', dcIp: '192.168.10.1', date: '2026-04-03 16:45',
    findings: 24, severities: { CRITICAL: 4, HIGH: 7, MEDIUM: 8, LOW: 5, INFO: 0 },
    riskScore: 91, status: 'Completed', scanType: 'Full Scan', duration: '5m 47s', checksRun: 42,
    topFindings: [
      { title: 'NoPac — sAMAccountName spoofing possible', severity: 'CRITICAL', category: 'CVE Detection' },
      { title: 'PrintNightmare — Spooler active on DC', severity: 'CRITICAL', category: 'CVE Detection' },
      { title: 'GPO write access for DOMAIN\\HelpDesk', severity: 'CRITICAL', category: 'CVE Detection' },
      { title: 'Transitive admin via nested groups (12 paths)', severity: 'CRITICAL', category: 'CVE Detection' },
      { title: 'Bidirectional trust without SID filtering', severity: 'HIGH', category: 'Delegation & Trusts' },
    ],
  },
  {
    id: 'adh4', domain: 'lab.test.local', dcIp: '10.10.10.1', date: '2026-04-02 11:20',
    findings: 0, severities: { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 },
    riskScore: 5, status: 'Completed', scanType: 'Quick Scan', duration: '0m 38s', checksRun: 42,
  },
  {
    id: 'adh5', domain: 'legacy.bank.local', dcIp: '10.200.0.3', date: '2026-04-01 08:55',
    findings: 31, severities: { CRITICAL: 6, HIGH: 9, MEDIUM: 10, LOW: 6, INFO: 0 },
    riskScore: 97, status: 'Completed', scanType: 'Full Scan', duration: '6m 22s', checksRun: 42,
    topFindings: [
      { title: 'Windows Server 2008 R2 — 4 DCs end-of-life', severity: 'CRITICAL', category: 'Hardening' },
      { title: 'DES-only encryption enabled for 12 accounts', severity: 'CRITICAL', category: 'Kerberos' },
      { title: 'PetitPotam — EFS RPC endpoint exposed on DC', severity: 'CRITICAL', category: 'CVE Detection' },
    ],
  },
  {
    id: 'adh6', domain: 'offline.corp.local', dcIp: '10.99.0.1', date: '2026-03-31 17:10',
    findings: 0, severities: { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 },
    riskScore: 0, status: 'Failed', scanType: 'Full Scan', duration: '0m 05s', checksRun: 0,
  },
];

function loadADHistory(): ADScanHistory[] {
  try {
    const stored = localStorage.getItem(AD_HISTORY_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch { /* ignore parse errors */ }
  return MOCK_AD_HISTORY;
}

function saveADHistory(entries: ADScanHistory[]) {
  localStorage.setItem(AD_HISTORY_KEY, JSON.stringify(entries));
}

function hasMockADHistory(entries: ADScanHistory[]): boolean {
  return entries.some(h => MOCK_AD_HISTORY.some(m => m.id === h.id));
}

const ADSCAN_LIVE_KEY = 'cra_adscan_live';

function loadADLiveState() {
  try {
    const raw = localStorage.getItem(ADSCAN_LIVE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

const ADScan = () => {
  const saved = React.useMemo(loadADLiveState, []);

  const [scanStatus, setScanStatus] = useState<ScanStatus>(() => saved?.scanStatus || 'idle');
  const [scanResult, setScanResult] = useState<ScanResult | null>(() => saved?.scanResult || null);
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>(() => saved?.terminalLines || []);
  const [graphData, setGraphData] = useState<GraphData>(() => saved?.graphData || { nodes: [], edges: [] });
  const [activeTab, setActiveTab] = useState('overview');
  const [showModules, setShowModules] = useState(false);
  const [showProviderSettings, setShowProviderSettings] = useState(false);
  const [providerConfig, setProviderConfig] = useState<AIProviderConfig | null>(null);
  const wsCleanupRef = useRef<(() => void) | null>(null);
  const quickScanTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const savedScanIdRef = useRef<string | null>(saved?.scanId || null);

  // Persist active scan state so navigation away doesn't lose progress
  React.useEffect(() => {
    if (!savedScanIdRef.current) return;
    localStorage.setItem(ADSCAN_LIVE_KEY, JSON.stringify({
      scanId: savedScanIdRef.current,
      scanStatus,
      terminalLines: terminalLines.slice(-300),
      scanResult,
      graphData,
    }));
  }, [scanStatus, terminalLines, scanResult, graphData]);

  // Load provider config on mount; refresh when modal closes
  useEffect(() => {
    setProviderConfig(loadProviderConfig());
  }, [showProviderSettings]);

  // Cleanup Quick Scan timeouts on unmount
  React.useEffect(() => {
    return () => {
      quickScanTimersRef.current.forEach(clearTimeout);
      quickScanTimersRef.current = [];
      wsCleanupRef.current?.();
    };
  }, []);

  // History state — persisted in localStorage, mock data shown only until first real scan
  const [history, setHistory] = useState<ADScanHistory[]>(() => loadADHistory());
  const [historySearch, setHistorySearch] = useState('');
  const [expandedHistory, setExpandedHistory] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [compareSelection, setCompareSelection] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [historySortAsc, setHistorySortAsc] = useState(false);

  /** Helper to push a terminal line into state */
  const pushTerminalLine = useCallback((type: TerminalLine['type'], message: string) => {
    setTerminalLines((prev) => [
      ...prev,
      {
        id: prev.length + 1,
        timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false }),
        type,
        message,
      },
    ]);
  }, []);

  /**
   * Start Scan — LIVE ONLY.
   * Connects to the real backend. If the backend is unreachable or credentials
   * are wrong, the terminal shows the actual error. No mock fallback.
   */
  /** Record a completed or failed scan into persistent history */
  const recordADHistory = useCallback((entry: ADScanHistory) => {
    setHistory(prev => {
      const cleaned = hasMockADHistory(prev) ? [] : prev;
      const updated = [entry, ...cleaned];
      saveADHistory(updated);
      return updated;
    });
  }, []);

  const handleStartScan = useCallback(async (config: ScanConfig) => {
    quickScanTimersRef.current.forEach(clearTimeout);
    quickScanTimersRef.current = [];
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;

    // Clear any previously persisted state for a fresh scan
    savedScanIdRef.current = null;
    localStorage.removeItem(ADSCAN_LIVE_KEY);

    const scanStartTime = Date.now();

    setScanStatus('connecting');
    setTerminalLines([]);
    setScanResult(null);
    setGraphData({ nodes: [], edges: [] });
    setActiveTab('overview');

    pushTerminalLine('system', 'ADScan v2.0 — Active Directory Security Assessment');
    pushTerminalLine('system', '═══════════════════════════════════════════════════');
    pushTerminalLine('info', `[+] Target domain     : ${config.domain}`);
    pushTerminalLine('info', `[+] DC IP             : ${config.dcIp || '(auto-resolve)'}`);
    pushTerminalLine('info', `[+] Auth method       : ${config.authMethod}`);
    pushTerminalLine('info', '[*] Connecting to backend...');

    let scanId: string;
    try {
      const resp = await startScanLive(config);
      scanId = resp.scanId;
      savedScanIdRef.current = scanId;
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || msg.includes('fetch')) {
        pushTerminalLine('error', '✗ ERROR: Backend unreachable — ADScan API is not running');
        pushTerminalLine('error', `  Attempted: ${import.meta.env.VITE_ADSCAN_API_URL || 'http://localhost:8400'}`);
        pushTerminalLine('info', '  Ensure the ADScan Docker container is running:');
        pushTerminalLine('info', '  → cd docker/adscan && docker compose up -d');
      } else {
        pushTerminalLine('error', `✗ ERROR: ${msg}`);
      }
      pushTerminalLine('system', '═══════════════════════════════════════════════════');
      pushTerminalLine('error', 'Scan aborted — fix the issue above and retry.');
      setScanStatus('error');

      // Record failed scan in history
      const elapsed = Math.round((Date.now() - scanStartTime) / 1000);
      const mins = Math.floor(elapsed / 60);
      const secs = elapsed % 60;
      recordADHistory({
        id: `ad-${Date.now()}`,
        domain: config.domain,
        dcIp: config.dcIp || '(auto)',
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: 0,
        severities: { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 },
        riskScore: 0,
        status: 'Failed',
        scanType: 'Full Scan',
        duration: `${mins}m ${String(secs).padStart(2, '0')}s`,
        checksRun: 0,
      });
      return;
    }

    // Backend accepted the scan — connect for live streaming
    pushTerminalLine('success', `[+] Scan accepted (ID: ${scanId})`);
    setScanStatus('running');

    // 1. WebSocket for live terminal
    wsCleanupRef.current = connectScanWebSocket(
      scanId,
      (line) => setTerminalLines((prev) => [...prev, line]),
      () => pushTerminalLine('info', '[*] WebSocket stream closed — polling for final status...'),
    );

    // 2. Poll status until complete
    const finalStatus = await pollScanUntilComplete(scanId, (status) => {
      setScanStatus(status);
    });

    // 3. Fetch real results + record history
    const elapsed = Math.round((Date.now() - scanStartTime) / 1000);
    const mins = Math.floor(elapsed / 60);
    const secs = elapsed % 60;
    const duration = `${mins}m ${String(secs).padStart(2, '0')}s`;

    if (finalStatus === 'completed') {
      const [result, graph] = await Promise.all([
        getScanResults(scanId),
        getGraphData(scanId),
      ]);
      setScanResult(result);
      setGraphData(graph);

      // Build severity counts from real findings
      const sevCounts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
      result.findings.forEach((f: { severity: string }) => {
        const sev = f.severity as keyof typeof sevCounts;
        if (sev in sevCounts) sevCounts[sev]++;
      });

      recordADHistory({
        id: `ad-${Date.now()}`,
        domain: result.domain || config.domain,
        dcIp: result.dcIp || config.dcIp || '(auto)',
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: result.findings.length,
        severities: sevCounts,
        riskScore: result.stats?.riskScore || 0,
        status: 'Completed',
        scanType: 'Full Scan',
        duration,
        checksRun: result.stats?.completedChecks || 42,
        topFindings: [...result.findings]
          .sort((a: { severity: string }, b: { severity: string }) => {
            const order = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
            return order.indexOf(a.severity) - order.indexOf(b.severity);
          })
          .slice(0, 5)
          .map((f: { title: string; severity: ScanSeverity; category: string }) => ({
            title: f.title,
            severity: f.severity,
            category: f.category,
          })),
        graphData: graph,
        fullResult: result,
      });
    } else if (finalStatus === 'error') {
      pushTerminalLine('error', 'Scan finished with errors — check backend logs.');
      recordADHistory({
        id: `ad-${Date.now()}`,
        domain: config.domain,
        dcIp: config.dcIp || '(auto)',
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: 0,
        severities: { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 },
        riskScore: 0,
        status: 'Failed',
        scanType: 'Full Scan',
        duration,
        checksRun: 0,
      });
    }

    wsCleanupRef.current?.();
    wsCleanupRef.current = null;
  }, [pushTerminalLine, recordADHistory]);

  /**
   * Quick Scan — DEMO / MOCK.
   * Uses mock data to demonstrate the UI without a live backend.
   */
  const handleQuickScan = () => {
    // Cancel any in-flight Quick Scan timeouts
    quickScanTimersRef.current.forEach(clearTimeout);
    quickScanTimersRef.current = [];
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;

    setScanStatus('connecting');
    setTerminalLines([]);
    setScanResult(null);
    setGraphData({ nodes: [], edges: [] });
    setActiveTab('overview');

    const t1 = setTimeout(() => {
      setScanStatus('running');
      setTerminalLines(getMockTerminalLines());
    }, 500);

    const t2 = setTimeout(() => {
      setScanStatus('completed');
      const mockResult = getMockScanResult();
      const mockGraph = getMockGraphData();
      setScanResult(mockResult);
      setGraphData(mockGraph);
      const fc = mockResult.stats.findingsCount;
      recordADHistory({
        id: `ad-quick-${Date.now()}`,
        domain: mockResult.domain,
        dcIp: mockResult.dcIp || '10.0.0.1',
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: Object.values(fc).reduce((s, v) => s + v, 0),
        severities: { CRITICAL: fc.CRITICAL, HIGH: fc.HIGH, MEDIUM: fc.MEDIUM, LOW: fc.LOW, INFO: fc.INFO },
        riskScore: mockResult.stats.riskScore,
        status: 'Completed',
        scanType: 'Quick Scan',
        duration: '8s',
        checksRun: mockResult.stats.totalChecks,
        topFindings: [...mockResult.findings]
          .sort((a, b) => {
            const order = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
            return order.indexOf(a.severity) - order.indexOf(b.severity);
          })
          .slice(0, 5)
          .map((f) => ({ title: f.title, severity: f.severity as ScanSeverity, category: f.category })),
        graphData: mockGraph,
        fullResult: mockResult,
      });
    }, 8500);

    quickScanTimersRef.current = [t1, t2];
  };

  /** Stop an active scan: cancel backend, disconnect WS, clear state. */
  const handleStopScan = useCallback(() => {
    if (savedScanIdRef.current) {
      cancelScan(savedScanIdRef.current);
    }
    quickScanTimersRef.current.forEach(clearTimeout);
    quickScanTimersRef.current = [];
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;
    localStorage.removeItem(ADSCAN_LIVE_KEY);
    savedScanIdRef.current = null;
    setScanStatus('idle');
    setTerminalLines([]);
    setScanResult(null);
    setGraphData({ nodes: [], edges: [] });
  }, []);

  // History helpers
  const handleDeleteHistory = (id: string) => {
    setHistory(prev => {
      const updated = prev.filter(h => h.id !== id);
      saveADHistory(updated);
      return updated;
    });
    setDeleteConfirm(null);
    setCompareSelection(prev => prev.filter(s => s !== id));
  };

  const toggleCompareSelect = (id: string) => {
    setCompareSelection(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : prev.length < 2 ? [...prev, id] : [prev[1], id]
    );
  };

  const filteredHistory = history
    .filter(h => h.domain.toLowerCase().includes(historySearch.toLowerCase()) ||
                 h.dcIp.includes(historySearch) ||
                 h.scanType.toLowerCase().includes(historySearch.toLowerCase()))
    .sort((a, b) => historySortAsc
      ? new Date(a.date).getTime() - new Date(b.date).getTime()
      : new Date(b.date).getTime() - new Date(a.date).getTime()
    );

  const compareItems = compareSelection.map(id => history.find(h => h.id === id)).filter(Boolean) as ADScanHistory[];

  const isRunning = scanStatus === 'running' || scanStatus === 'connecting';

  return (
    <PageContainer title="">
      <div className="space-y-4">
        {/* Page Header */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold text-white flex items-center gap-3">
              <Radar className="text-red-400" size={28} />
              ADScan
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              Active Directory security assessment — 42 automated checks across identity, Kerberos, delegation, ADCS, CVE detection, and infrastructure
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowProviderSettings(true)}
              className="border-gray-700 text-gray-400 hover:text-white hover:border-gray-500 gap-1.5"
              title="AI Provider Settings"
            >
              <Settings2 size={14} />
              AI Provider
              {providerConfig && (
                <Badge className="bg-emerald-900/30 text-emerald-400 border-0 text-[9px] ml-1">
                  {providerConfig.name}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowModules(true)}
              className="border-gray-700 text-gray-400 hover:text-white hover:border-gray-500 gap-1.5"
            >
              <Info size={14} />
              Modules
            </Button>
            {isRunning ? (
              <Button
                onClick={handleStopScan}
                className="bg-gray-700 hover:bg-gray-600 text-white gap-2"
              >
                <Square size={14} />
                STOP
              </Button>
            ) : (
              <Button
                onClick={handleQuickScan}
                className="bg-red-600 hover:bg-red-700 text-white gap-2"
              >
                <Zap size={14} />
                QUICK SCAN
              </Button>
            )}
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="overflow-x-auto pb-0.5">
          <TabsList className="bg-cdm-darker border border-gray-800 min-w-max">
            <TabsTrigger value="overview" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400">
              Scan Config
            </TabsTrigger>
            <TabsTrigger value="results" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400" disabled={!scanResult}>
              Results {scanResult && <Badge className="ml-1.5 bg-red-900/30 text-red-400 border-0 text-[10px] px-1">{scanResult.findings?.length ?? 0}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="graph" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400" disabled={!scanResult}>
              Attack Graph
            </TabsTrigger>
            <TabsTrigger value="findings" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400" disabled={!scanResult}>
              Findings Detail
            </TabsTrigger>
            <TabsTrigger value="history" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400 gap-1.5">
              <Clock size={12} />
              History
              {history.length > 0 && (
                <Badge className="ml-1 bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{history.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>
          </div>

          {/* OVERVIEW TAB - Config + Terminal */}
          <TabsContent value="overview" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                <ScanConfigPanel onStartScan={handleStartScan} onStopScan={handleStopScan} isRunning={isRunning} />
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <ScanTerminal lines={terminalLines} isRunning={isRunning} />
              </div>
            </div>
          </TabsContent>

          {/* RESULTS TAB */}
          <TabsContent value="results" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                {scanResult && (
                  <ScanResultsPanel stats={scanResult.stats} domain={scanResult.domain} />
                )}
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <ScanTerminal lines={terminalLines} isRunning={false} />
              </div>
            </div>
          </TabsContent>

          {/* GRAPH TAB */}
          <TabsContent value="graph" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                <ADNodeGraph data={graphData} persistKey={scanResult?.domain} />
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <ScanTerminal lines={terminalLines} isRunning={false} />
              </div>
            </div>
          </TabsContent>

          {/* FINDINGS TAB */}
          <TabsContent value="findings" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                {scanResult && <FindingsTable findings={scanResult.findings} />}
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <div className="space-y-4">
                  {scanResult && (
                    <ScanResultsPanel stats={scanResult.stats} domain={scanResult.domain} />
                  )}
                  <ScanTerminal lines={terminalLines} isRunning={false} />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* HISTORY TAB */}
          <TabsContent value="history" className="mt-4 space-y-4">
            {/* Toolbar */}
            <div className="flex items-center gap-3">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <Input
                  value={historySearch}
                  onChange={e => setHistorySearch(e.target.value)}
                  placeholder="Search domain, DC IP, or scan type..."
                  className="bg-cdm-dark border-gray-700 text-white h-9 pl-9 text-xs"
                />
              </div>
              <Button
                variant="outline" size="sm"
                onClick={() => setHistorySortAsc(!historySortAsc)}
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5 h-9"
              >
                <ArrowUpDown size={12} />
                {historySortAsc ? 'Oldest first' : 'Newest first'}
              </Button>
              {compareSelection.length === 2 && (
                <Button
                  size="sm"
                  onClick={() => setShowCompare(true)}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white gap-1.5 h-9"
                >
                  <GitCompare size={12} />
                  Compare ({compareSelection.length})
                </Button>
              )}
              {compareSelection.length > 0 && compareSelection.length < 2 && (
                <span className="text-xs text-gray-500">Select 1 more scan to compare</span>
              )}
              <Button
                variant="outline" size="sm"
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5 h-9 ml-auto"
              >
                <FileDown size={12} />
                Export All
              </Button>
            </div>

            {/* History list */}
            {filteredHistory.length > 0 ? (
              <div className="bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden">
                <div className="divide-y divide-gray-800">
                  {filteredHistory.map(scan => {
                    const isExpanded = expandedHistory === scan.id;
                    const isSelected = compareSelection.includes(scan.id);
                    const statusColor = scan.status === 'Completed'
                      ? 'bg-emerald-900/30 text-emerald-400'
                      : scan.status === 'Failed'
                        ? 'bg-red-900/30 text-red-400'
                        : 'bg-amber-900/30 text-amber-400';

                    return (
                      <div key={scan.id} className={`${isSelected ? 'bg-cyan-900/10 border-l-2 border-l-cyan-500' : ''}`}>
                        <div className="flex items-center gap-3 p-4 hover:bg-white/[0.01] transition-colors">
                          {/* Compare checkbox */}
                          <button
                            onClick={() => toggleCompareSelect(scan.id)}
                            className={`w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
                              isSelected ? 'bg-cyan-600 border-cyan-600' : 'border-gray-600 hover:border-gray-400'
                            }`}
                          >
                            {isSelected && <span className="text-white text-[8px] font-bold">{compareSelection.indexOf(scan.id) + 1}</span>}
                          </button>

                          {/* Main info */}
                          <Radar size={16} className="text-red-400 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm text-white font-medium truncate">{scan.domain}</p>
                              <Badge variant="outline" className="border-gray-700 text-gray-500 text-[9px] flex-shrink-0">
                                {scan.scanType}
                              </Badge>
                              <span className="text-[10px] text-gray-600 font-mono">{scan.dcIp}</span>
                            </div>
                            <div className="flex items-center gap-3 mt-1">
                              <span className="text-[11px] text-gray-500">{scan.date}</span>
                              <span className="text-[11px] text-gray-600">|</span>
                              <span className="text-[11px] text-gray-500">{scan.duration}</span>
                              <span className="text-[11px] text-gray-600">|</span>
                              <span className="text-[11px] text-gray-500">{scan.checksRun}/42 checks</span>
                            </div>
                          </div>

                          {/* Risk score */}
                          <div className="flex-shrink-0 text-center">
                            <div className={`text-sm font-bold ${
                              scan.riskScore >= 80 ? 'text-red-400' :
                              scan.riskScore >= 50 ? 'text-amber-400' :
                              scan.riskScore >= 20 ? 'text-blue-400' : 'text-emerald-400'
                            }`}>
                              {scan.riskScore}
                            </div>
                            <div className="text-[9px] text-gray-600">Risk</div>
                          </div>

                          {/* Severity mini-badges */}
                          <div className="flex items-center gap-1 flex-shrink-0">
                            {scan.severities.CRITICAL > 0 && (
                              <span className="text-[10px] font-bold bg-red-900/40 text-red-400 px-1.5 py-0.5 rounded">{scan.severities.CRITICAL}C</span>
                            )}
                            {scan.severities.HIGH > 0 && (
                              <span className="text-[10px] font-bold bg-orange-900/40 text-orange-400 px-1.5 py-0.5 rounded">{scan.severities.HIGH}H</span>
                            )}
                            {scan.severities.MEDIUM > 0 && (
                              <span className="text-[10px] font-bold bg-amber-900/40 text-amber-400 px-1.5 py-0.5 rounded">{scan.severities.MEDIUM}M</span>
                            )}
                            {scan.severities.LOW > 0 && (
                              <span className="text-[10px] font-bold bg-blue-900/40 text-blue-400 px-1.5 py-0.5 rounded">{scan.severities.LOW}L</span>
                            )}
                            {scan.findings === 0 && scan.status === 'Completed' && (
                              <span className="text-[10px] text-emerald-400 bg-emerald-900/30 px-1.5 py-0.5 rounded">Clean</span>
                            )}
                          </div>

                          {/* Status */}
                          <Badge className={`${statusColor} border-0 text-[10px] flex-shrink-0`}>
                            {scan.status}
                          </Badge>

                          {/* Actions */}
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <Button
                              variant="ghost" size="sm"
                              disabled={isRunning}
                              onClick={() => {
                                setExpandedHistory(isExpanded ? null : scan.id);
                                if (!isExpanded) {
                                  if (scan.fullResult) {
                                    setScanResult(scan.fullResult);
                                    setGraphData(scan.graphData || { nodes: [], edges: [] });
                                  } else if (scan.graphData) {
                                    setGraphData(scan.graphData);
                                    setScanResult({ id: scan.id, domain: scan.domain, dcIp: scan.dcIp, scanTime: scan.date, status: 'completed', findings: [], stats: {} } as unknown as ScanResult);
                                  }
                                }
                              }}
                              className="text-gray-500 hover:text-white h-7 w-7 p-0"
                              title={isRunning ? 'Unavailable during active scan' : 'View details'}
                            >
                              {isRunning ? <EyeOff size={13} /> : <Eye size={13} />}
                            </Button>
                            <Button
                              variant="ghost" size="sm"
                              className="text-gray-500 hover:text-white h-7 w-7 p-0"
                              title="Export"
                            >
                              <Download size={13} />
                            </Button>
                            {deleteConfirm === scan.id ? (
                              <div className="flex items-center gap-1">
                                <Button
                                  size="sm"
                                  onClick={() => handleDeleteHistory(scan.id)}
                                  className="bg-red-600 hover:bg-red-700 text-white h-7 px-2 text-[10px]"
                                >
                                  Confirm
                                </Button>
                                <Button
                                  variant="ghost" size="sm"
                                  onClick={() => setDeleteConfirm(null)}
                                  className="text-gray-400 h-7 w-7 p-0"
                                >
                                  <X size={12} />
                                </Button>
                              </div>
                            ) : (
                              <Button
                                variant="ghost" size="sm"
                                onClick={() => setDeleteConfirm(scan.id)}
                                className="text-gray-500 hover:text-red-400 h-7 w-7 p-0"
                                title="Delete"
                              >
                                <Trash2 size={13} />
                              </Button>
                            )}
                          </div>
                        </div>

                        {/* Expanded detail */}
                        {isExpanded && (
                          <div className="px-4 pb-4 pt-1 border-t border-gray-800/50 ml-[52px]">
                            <div className="grid grid-cols-5 gap-3 mb-3">
                              {(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'] as const).map(sev => (
                                <div key={sev} className={`rounded border p-2 ${SEVERITY_COLORS[sev].bg} ${SEVERITY_COLORS[sev].border}`}>
                                  <div className={`text-lg font-bold ${SEVERITY_COLORS[sev].text}`}>{scan.severities[sev]}</div>
                                  <div className={`text-[10px] ${SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                                </div>
                              ))}
                            </div>
                            {scan.topFindings && scan.topFindings.length > 0 && (
                              <div className="space-y-1 mb-3">
                                <h5 className="text-xs font-semibold text-gray-400 mb-1.5">Top Findings</h5>
                                {scan.topFindings.map((f, i) => (
                                  <div key={i} className="flex items-center gap-2 text-xs">
                                    <Badge className={`${SEVERITY_COLORS[f.severity].bg} ${SEVERITY_COLORS[f.severity].text} border-0 text-[9px] px-1.5 uppercase w-16 justify-center`}>
                                      {f.severity}
                                    </Badge>
                                    <span className="text-gray-300 truncate">{f.title}</span>
                                    <span className="text-red-500 text-[10px] ml-auto flex-shrink-0">{f.category}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                            {(!scan.topFindings || scan.topFindings.length === 0) && scan.findings > 0 && (
                              <p className="text-xs text-gray-500 mb-3">{scan.findings} finding(s) recorded.</p>
                            )}
                            {scan.findings === 0 && scan.status === 'Completed' && (
                              <p className="text-xs text-emerald-400 mb-3">No vulnerabilities found — domain appears clean.</p>
                            )}
                            {scan.status === 'Failed' && (
                              <p className="text-xs text-red-400 mb-3">Scan failed — domain controller may be unreachable or credentials were rejected.</p>
                            )}
                            {scan.status === 'Completed' && (
                              <div className="flex items-center gap-2 pt-2 border-t border-gray-800/50">
                                <Button
                                  size="sm"
                                  onClick={() => setActiveTab('results')}
                                  className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs"
                                >
                                  View Results
                                </Button>
                                {(scan.fullResult?.findings?.length ?? 0) > 0 && (
                                  <Button
                                    size="sm"
                                    onClick={() => setActiveTab('findings')}
                                    className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs"
                                  >
                                    Finding Details
                                  </Button>
                                )}
                                {scan.graphData && scan.graphData.nodes.length > 0 && (
                                  <Button
                                    size="sm"
                                    onClick={() => setActiveTab('graph')}
                                    className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-800/50 gap-1.5 h-7 text-xs"
                                  >
                                    <Network size={12} />
                                    Attack Graph
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 bg-cdm-darker rounded-lg border border-gray-800">
                <Clock size={40} className="text-gray-700 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No scan history</h3>
                <p className="text-sm text-gray-500">
                  {historySearch ? 'No scans match your search' : 'Completed AD scans will appear here'}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Compare Modal */}
      {showCompare && compareItems.length === 2 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70" onClick={() => setShowCompare(false)} />
          <div className="relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-3xl max-h-[80vh] overflow-hidden flex flex-col m-4">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
              <div>
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <GitCompare size={18} className="text-cyan-400" />
                  AD Scan Comparison
                </h2>
                <p className="text-xs text-gray-500 mt-0.5">Side-by-side comparison of two AD scan runs</p>
              </div>
              <button
                onClick={() => setShowCompare(false)}
                className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-2 gap-6">
                {compareItems.map((item, idx) => (
                  <div key={item.id} className="space-y-4">
                    <div className="text-center">
                      <Badge className={`${idx === 0 ? 'bg-cyan-900/30 text-cyan-400' : 'bg-purple-900/30 text-purple-400'} border-0 text-xs mb-2`}>
                        Scan {idx + 1}
                      </Badge>
                      <p className="text-sm text-white font-medium truncate">{item.domain}</p>
                      <p className="text-[11px] text-gray-500">{item.date} · {item.duration}</p>
                      <p className="text-[11px] text-gray-600 font-mono">{item.dcIp}</p>
                    </div>
                    <div className="flex justify-center">
                      <div className={`text-2xl font-bold ${
                        item.riskScore >= 80 ? 'text-red-400' :
                        item.riskScore >= 50 ? 'text-amber-400' : 'text-emerald-400'
                      }`}>
                        {item.riskScore}
                        <span className="text-xs text-gray-500 ml-1 font-normal">risk</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'] as const).map(sev => {
                        const other = compareItems[1 - idx];
                        const diff = item.severities[sev] - other.severities[sev];
                        return (
                          <div key={sev} className={`rounded border p-2 ${SEVERITY_COLORS[sev].bg} ${SEVERITY_COLORS[sev].border}`}>
                            <div className="flex items-baseline gap-1.5">
                              <span className={`text-xl font-bold ${SEVERITY_COLORS[sev].text}`}>{item.severities[sev]}</span>
                              {diff !== 0 && (
                                <span className={`text-[10px] font-bold ${diff > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                                  {diff > 0 ? `+${diff}` : diff}
                                </span>
                              )}
                            </div>
                            <div className={`text-[10px] ${SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="text-center">
                      <span className="text-2xl font-bold text-white">{item.findings}</span>
                      <span className="text-xs text-gray-500 ml-1.5">total findings</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scan Modules Modal */}
      {showModules && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70" onClick={() => setShowModules(false)} />
          <div className="relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-5xl max-h-[80vh] overflow-hidden flex flex-col m-4">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
              <div>
                <h2 className="text-lg font-semibold text-white">All Scan Modules</h2>
                <p className="text-xs text-gray-500 mt-0.5">42 automated security checks across 7 categories</p>
              </div>
              <button
                onClick={() => setShowModules(false)}
                className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {SCAN_MODULES.map(mod => (
                  <div
                    key={mod.id}
                    className="bg-cdm-dark rounded-lg border border-gray-800 overflow-hidden hover:border-gray-700 transition-colors"
                  >
                    <div className="px-4 py-3 border-b border-gray-800/50">
                      <h3 className="text-sm font-semibold text-white">{mod.title}</h3>
                      <p className="text-[11px] text-gray-500 mt-0.5">{mod.description}</p>
                    </div>
                    <div className="divide-y divide-gray-800/30">
                      {mod.checks.map(check => (
                        <div
                          key={check.id}
                          className="flex items-center justify-between px-4 py-2.5 hover:bg-white/[0.02] transition-colors group"
                        >
                          <div>
                            <span className="text-xs text-gray-300 group-hover:text-white transition-colors">
                              {check.name}
                            </span>
                            <span className="hidden sm:inline text-[10px] text-gray-600 ml-2">
                              {check.description}
                            </span>
                          </div>
                          <ArrowRight size={12} className="text-gray-700 group-hover:text-gray-400 transition-colors" />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      <ProviderSettings
        open={showProviderSettings}
        onClose={() => setShowProviderSettings(false)}
        onSave={(cfg) => { setProviderConfig(cfg); setShowProviderSettings(false); }}
      />
    </PageContainer>
  );
};

export default ADScan;
