import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  Cloud, Zap, ArrowRight, Info, X, Shield, Database,
  Server, Globe, Lock, Network, Clock, RotateCw, Trash2,
  Download, Eye, EyeOff, Search, ArrowUpDown, FileDown, GitCompare, Settings2
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import PageContainer from '@/components/PageContainer';
import CloudScanConfig from '@/components/cloudscan/CloudScanConfig';
import CloudResultsPanel from '@/components/cloudscan/CloudResultsPanel';
import ProviderSettings from '@/components/webscan/ProviderSettings';
import AttackPathsTable from '@/components/cloudscan/AttackPathsTable';
import CloudResourceGraph from '@/components/cloudscan/CloudResourceGraph';
import ScanTerminal from '@/components/adscan/ScanTerminal';
import {
  getMockCloudScanResult,
  getMockTerminalLines,
  getMockModuleStatus,
  startCloudScanLive,
  connectCloudScanWebSocket,
  pollCloudScanUntilComplete,
  getCloudScanResults,
  getCloudScanStatus,
  getCloudGraphData,
  cancelCloudScan,
} from '@/services/cloudscanService';
import { loadProviderConfig } from '@/services/aiProviderService';
import type { AIProviderConfig } from '@/services/aiProviderService';
import { AWS_SCAN_MODULES } from '@/types/cloudscan';
import type { CloudScanConfig as CloudScanConfigType, CloudScanResult, CloudScanStatus, EnumModuleStatus } from '@/types/cloudscan';
import type { TerminalLine } from '@/types/adscan';

const moduleIcons: Record<string, React.ReactNode> = {
  identity: <Shield size={18} />,
  storage: <Database size={18} />,
  compute: <Server size={18} />,
  database: <Lock size={18} />,
  network: <Network size={18} />,
};

interface CloudScanHistory {
  id: string;
  accountId: string;
  provider: string;
  regions: string[];
  date: string;
  findings: number;
  severities: { critical: number; high: number; medium: number; low: number };
  riskScore: number;
  status: 'Completed' | 'Failed' | 'In Progress';
  scanType: string;
  duration: string;
  modulesScanned: number;
  topFindings?: { title: string; severity: string; service: string }[];
  graphData?: import('@/types/cloudscan').CloudGraphData;
  fullResult?: CloudScanResult;
}

const CLOUD_SEVERITY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  critical: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-red-500/30' },
  high: { bg: 'bg-orange-900/30', text: 'text-orange-400', border: 'border-orange-500/30' },
  medium: { bg: 'bg-amber-900/30', text: 'text-amber-400', border: 'border-amber-500/30' },
  low: { bg: 'bg-blue-900/30', text: 'text-blue-400', border: 'border-blue-500/30' },
};

const CLOUD_HISTORY_KEY = 'cra_cloudscan_history';

const MOCK_CLOUD_HISTORY: CloudScanHistory[] = [
  {
    id: 'ch1', accountId: '123456789012', provider: 'AWS', regions: ['us-east-1', 'eu-west-1'],
    date: '2026-04-05 14:30', findings: 14, severities: { critical: 2, high: 4, medium: 5, low: 3 },
    riskScore: 72, status: 'Completed', scanType: 'Full Scan', duration: '3m 45s', modulesScanned: 12,
    topFindings: [
      { title: 'S3 bucket "prod-logs" is publicly accessible', severity: 'critical', service: 'S3' },
      { title: 'Root account has no MFA enabled', severity: 'critical', service: 'IAM' },
      { title: 'Lambda function uses admin role', severity: 'high', service: 'Lambda' },
      { title: 'RDS instance publicly accessible', severity: 'high', service: 'RDS' },
      { title: 'KMS key rotation not enabled', severity: 'medium', service: 'KMS' },
    ],
  },
  {
    id: 'ch2', accountId: '987654321098', provider: 'AWS', regions: ['us-west-2'],
    date: '2026-04-04 09:15', findings: 6, severities: { critical: 0, high: 2, medium: 3, low: 1 },
    riskScore: 38, status: 'Completed', scanType: 'Full Scan', duration: '2m 12s', modulesScanned: 12,
    topFindings: [
      { title: 'Security group allows 0.0.0.0/0 on port 22', severity: 'high', service: 'EC2' },
      { title: 'CloudTrail not enabled in us-west-2', severity: 'high', service: 'CloudTrail' },
    ],
  },
  {
    id: 'ch3', accountId: '456789012345', provider: 'AWS', regions: ['us-east-1', 'us-west-2', 'eu-central-1'],
    date: '2026-04-03 16:45', findings: 22, severities: { critical: 4, high: 7, medium: 7, low: 4 },
    riskScore: 89, status: 'Completed', scanType: 'Full Scan', duration: '5m 18s', modulesScanned: 12,
    topFindings: [
      { title: 'IAM user "deploy-bot" has * permissions', severity: 'critical', service: 'IAM' },
      { title: 'Secrets Manager secret not rotated in 180d', severity: 'critical', service: 'Secrets' },
      { title: 'API Gateway with no authentication', severity: 'critical', service: 'API GW' },
      { title: 'SQS queue allows cross-account access', severity: 'critical', service: 'SQS' },
    ],
  },
  {
    id: 'ch4', accountId: '111222333444', provider: 'AWS', regions: ['us-east-1'],
    date: '2026-04-02 11:20', findings: 0, severities: { critical: 0, high: 0, medium: 0, low: 0 },
    riskScore: 3, status: 'Completed', scanType: 'Quick Scan', duration: '0m 42s', modulesScanned: 12,
  },
  {
    id: 'ch5', accountId: '555666777888', provider: 'AWS', regions: ['ap-southeast-1'],
    date: '2026-04-01 08:55', findings: 18, severities: { critical: 3, high: 5, medium: 6, low: 4 },
    riskScore: 76, status: 'Completed', scanType: 'Full Scan', duration: '4m 05s', modulesScanned: 12,
    topFindings: [
      { title: 'EC2 instance with IMDSv1 enabled', severity: 'critical', service: 'EC2' },
      { title: 'CodeBuild project with hardcoded secrets', severity: 'critical', service: 'CodeBuild' },
      { title: 'SNS topic allows publish from any AWS account', severity: 'critical', service: 'SNS' },
    ],
  },
  {
    id: 'ch6', accountId: '000111222333', provider: 'AWS', regions: ['us-east-1'],
    date: '2026-03-31 17:10', findings: 0, severities: { critical: 0, high: 0, medium: 0, low: 0 },
    riskScore: 0, status: 'Failed', scanType: 'Full Scan', duration: '0m 08s', modulesScanned: 0,
  },
];

function loadCloudHistory(): CloudScanHistory[] {
  try {
    const stored = localStorage.getItem(CLOUD_HISTORY_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch { /* ignore parse errors */ }
  return MOCK_CLOUD_HISTORY;
}

function saveCloudHistory(entries: CloudScanHistory[]) {
  localStorage.setItem(CLOUD_HISTORY_KEY, JSON.stringify(entries));
}

function hasMockCloudHistory(entries: CloudScanHistory[]): boolean {
  return entries.some(h => MOCK_CLOUD_HISTORY.some(m => m.id === h.id));
}

// ---------------------------------------------------------------------------
// Scan activity store — shared with AIAgents page via localStorage + events
// ---------------------------------------------------------------------------
const SCAN_ACTIVITY_KEY = 'cra_scan_activity';
type AgentRunStatus = 'pending' | 'executing' | 'completed' | 'error';
interface ScanActivity {
  type: 'cloudscan' | 'webscan';
  scanId: string;
  status: 'running' | 'completed' | 'error';
  agents: Record<string, AgentRunStatus>;
}
function writeScanActivity(payload: ScanActivity | null) {
  if (payload === null) localStorage.removeItem(SCAN_ACTIVITY_KEY);
  else localStorage.setItem(SCAN_ACTIVITY_KEY, JSON.stringify(payload));
  window.dispatchEvent(new CustomEvent('cra-scan-activity', { detail: payload }));
}
/** Parse a terminal message and return updated agent map, or null if no change. */
function parseScopeActivity(
  message: string,
  agents: Record<string, AgentRunStatus>,
): Record<string, AgentRunStatus> | null {
  const runMatch = message.match(/\[DV-CLOUD\] Running (cra-cl-[\w-]+)/);
  const doneMatch = message.match(/✓\s+(cra-cl-[\w-]+)\s+(?:complete|summary complete)/);
  if (runMatch && runMatch[1] in agents) return { ...agents, [runMatch[1]]: 'executing' };
  if (doneMatch && doneMatch[1] in agents) return { ...agents, [doneMatch[1]]: 'completed' };
  return null;
}

/** Convert backend moduleStatus map to EnumModuleStatus array */
function buildModuleStatusArray(backendStatus: Record<string, string>): EnumModuleStatus[] {
  const MODULE_NAMES: Record<string, string> = {
    iam: 'IAM', sts: 'STS', s3: 'S3', kms: 'KMS',
    secrets: 'Secrets Manager', lambda: 'Lambda', ec2: 'EC2',
    rds: 'RDS', sns: 'SNS', sqs: 'SQS',
    apigateway: 'API Gateway', codebuild: 'CodeBuild',
  };
  return Object.entries(backendStatus).map(([id, status]) => ({
    id,
    name: MODULE_NAMES[id] || id,
    status: (status === 'complete' || status === 'partial' || status === 'error' || status === 'running')
      ? status : 'pending' as const,
    findingsCount: 0,
  }));
}

/**
 * Build a minimal resource graph from findings when the AI phase didn't run.
 * One central account node, one node per unique service, edges from service → account.
 */
function buildGraphFromFindings(
  findings: { service?: string; severity?: string; resourceId?: string }[],
  accountId: string,
): import('@/types/cloudscan').CloudGraphData {
  if (!findings.length) return { nodes: [], edges: [] };
  const cx = 400; const cy = 300;
  const sevOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
  // Group findings by service
  const byService = new Map<string, string[]>();
  for (const f of findings) {
    const svc = (f.service || 'AWS').toUpperCase();
    const worst = byService.get(svc);
    const rank = sevOrder[f.severity?.toLowerCase() ?? 'info'] ?? 4;
    if (!worst || rank < (sevOrder[worst[0]] ?? 4)) {
      byService.set(svc, [f.severity?.toLowerCase() ?? 'info', f.resourceId ?? '']);
    }
  }
  const services = Array.from(byService.entries());
  const radius = Math.min(cx, cy) * 0.7;
  const nodes: import('@/types/cloudscan').CloudGraphNode[] = [
    { id: 'account', label: accountId || 'AWS Account', type: 'service', x: cx, y: cy, vx: 0, vy: 0, severity: 'low' },
    ...services.map(([svc, [sev]], i) => {
      const angle = (2 * Math.PI * i) / services.length - Math.PI / 2;
      return {
        id: `svc-${svc}`, label: svc, type: 'service' as const,
        x: cx + radius * Math.cos(angle), y: cy + radius * Math.sin(angle),
        vx: 0, vy: 0, severity: (sev || 'low') as import('@/types/cloudscan').CloudSeverity,
      };
    }),
  ];
  const edges: import('@/types/cloudscan').CloudGraphEdge[] = services.map(([svc, [sev]]) => ({
    source: `svc-${svc}`, target: 'account',
    edgeType: (sev === 'critical' || sev === 'high') ? 'priv_esc' : 'service',
    severity: (sev || 'low') as import('@/types/cloudscan').CloudSeverity,
    label: svc,
  }));
  return { nodes, edges };
}

const CLOUDSCAN_LIVE_KEY = 'cra_cloudscan_live';

function loadCloudLiveState() {
  try {
    const raw = localStorage.getItem(CLOUDSCAN_LIVE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

const CloudScan = () => {
  const saved = React.useMemo(loadCloudLiveState, []);

  const [scanStatus, setScanStatus] = useState<CloudScanStatus>(() => saved?.scanStatus || 'idle');
  const [scanResult, setScanResult] = useState<CloudScanResult | null>(() => saved?.scanResult || null);
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>(() => saved?.terminalLines || []);
  const [moduleStatus, setModuleStatus] = useState<EnumModuleStatus[]>(() => saved?.moduleStatus || []);
  const [activeTab, setActiveTab] = useState('overview');
  const [showModules, setShowModules] = useState(false);
  const [showProviderSettings, setShowProviderSettings] = useState(false);
  const [providerConfig, setProviderConfig] = useState<AIProviderConfig | null>(null);
  const wsCleanupRef = useRef<(() => void) | null>(null);
  const quickScanTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const savedScanIdRef = useRef<string | null>(saved?.scanId || null);
  const isRunningRef = useRef(false);
  const scanActivityRef = useRef<ScanActivity | null>(null);
  const [agentMetrics, setAgentMetrics] = useState({ total: 0, executing: 0, completed: 0 });

  // Load provider config; refresh when modal closes
  useEffect(() => {
    setProviderConfig(loadProviderConfig());
  }, [showProviderSettings]);

  // Persist active scan state so navigation away doesn't lose progress
  React.useEffect(() => {
    if (!savedScanIdRef.current) return;
    const activeStatuses: CloudScanStatus[] = ['connecting', 'enumerating', 'analyzing'];
    if (activeStatuses.includes(scanStatus) || scanStatus === 'completed' || scanStatus === 'error') {
      localStorage.setItem(CLOUDSCAN_LIVE_KEY, JSON.stringify({
        scanId: savedScanIdRef.current,
        scanStatus,
        terminalLines: terminalLines.slice(-300),
        scanResult,
        moduleStatus,
      }));
    }
  }, [scanStatus, terminalLines, scanResult, moduleStatus]);

  // Cleanup on unmount — leave WS/poll alive if a scan is actively running so
  // the user can navigate away and come back without losing the scan.
  React.useEffect(() => {
    return () => {
      quickScanTimersRef.current.forEach(clearTimeout);
      quickScanTimersRef.current = [];
      if (!isRunningRef.current) {
        wsCleanupRef.current?.();
        wsCleanupRef.current = null;
      }
    };
  }, []);

  // On mount: if a scan was running when the user navigated away, reconnect the
  // WebSocket so the terminal catches up with all lines from the backend buffer.
  React.useEffect(() => {
    const savedId = saved?.scanId as string | undefined;
    const savedScanStatus = saved?.scanStatus as string | undefined;
    if (!savedId || !['enumerating', 'analyzing'].includes(savedScanStatus || '')) return;

    savedScanIdRef.current = savedId;
    // Re-attach WS — the backend replays all historical lines on connect
    wsCleanupRef.current?.();
    wsCleanupRef.current = connectCloudScanWebSocket(
      savedId,
      (line) => {
        // Parse DV-CLOUD activity as lines arrive (outside setState for cleanliness)
        if (scanActivityRef.current) {
          const updated = parseScopeActivity(line.message, scanActivityRef.current.agents);
          if (updated) {
            scanActivityRef.current = { ...scanActivityRef.current, agents: updated };
            writeScanActivity(scanActivityRef.current);
            const vals = Object.values(updated);
            setAgentMetrics({
              total: vals.length,
              executing: vals.filter(s => s === 'executing').length,
              completed: vals.filter(s => s === 'completed' || s === 'error').length,
            });
          }
        }
        // Deduplicate by ID to avoid replaying lines already in saved state
        setTerminalLines(prev => {
          const seen = new Set(prev.map(l => l.id));
          if (seen.has(line.id ?? -1)) return prev;
          return [...prev, line];
        });
      },
      () => { /* WS closed — HTTP poll already started by the onclose fix */ },
    );
    // Re-attach status poll
    pollCloudScanUntilComplete(savedId, (status, backendModStatus) => {
      setScanStatus(status);
      if (Object.keys(backendModStatus).length > 0) {
        setModuleStatus(buildModuleStatusArray(backendModStatus));
      }
    }).then(finalStatus => {
      if (finalStatus === 'completed') {
        Promise.all([getCloudScanResults(savedId), getCloudGraphData(savedId)])
          .then(([result, graph]) => {
            setScanResult({ ...result, graph: result.graph?.nodes?.length ? result.graph : graph });
          }).catch(() => {/* ignore fetch error on reconnect */});
        writeScanActivity(null); // clear activity on completion
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // History state — persisted in localStorage, mock data shown only until first real scan
  const [history, setHistory] = useState<CloudScanHistory[]>(() => loadCloudHistory());
  const [historySearch, setHistorySearch] = useState('');
  const [expandedHistory, setExpandedHistory] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [compareSelection, setCompareSelection] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [historySortAsc, setHistorySortAsc] = useState(false);

  const isRunning = scanStatus === 'enumerating' || scanStatus === 'analyzing' || scanStatus === 'connecting';

  // Keep isRunningRef in sync so the unmount cleanup closure reads the latest value
  React.useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  /** Helper to push a terminal line into state */
  const pushTerminalLine = useCallback((type: TerminalLine['type'], message: string) => {
    setTerminalLines((prev) => [
      ...prev,
      {
        id: prev.length + 1,
        timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false }),
        type,
        message,
      },
    ]);
  }, []);

  /** Record a completed or failed scan into persistent history */
  const recordCloudHistory = useCallback((entry: CloudScanHistory) => {
    setHistory(prev => {
      const cleaned = hasMockCloudHistory(prev) ? [] : prev;
      const updated = [entry, ...cleaned];
      saveCloudHistory(updated);
      return updated;
    });
  }, []);

  /**
   * Start Scan — LIVE ONLY.
   * Requires real backend + valid AWS credentials. Shows real errors on failure.
   */
  const handleStartScan = useCallback(async (config: CloudScanConfigType) => {
    quickScanTimersRef.current.forEach(clearTimeout);
    quickScanTimersRef.current = [];
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;

    // Clear any previously persisted state for a fresh scan
    savedScanIdRef.current = null;
    localStorage.removeItem(CLOUDSCAN_LIVE_KEY);

    const scanStartTime = Date.now();

    setScanStatus('connecting');
    setTerminalLines([]);  // clear previous output (Item 9)
    setScanResult(null);
    setModuleStatus([]);
    setActiveTab('overview');
    pushTerminalLine('info', '[*] Connecting to backend...');

    const CLOUDSCAN_URL = import.meta.env.VITE_CLOUDSCAN_API_URL || 'http://localhost:8401';

    let scanId: string;
    try {
      const resp = await startCloudScanLive(config);
      scanId = resp.scanId;
      savedScanIdRef.current = scanId;
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const isNetworkError = (
        msg === 'Load failed' ||
        msg === 'Failed to fetch' ||
        msg.includes('NetworkError') ||
        msg.includes('network') ||
        msg.includes('ECONNREFUSED') ||
        msg.includes('ERR_CONNECTION') ||
        msg.includes('timeout') ||
        msg.includes('timed out')
      );
      pushTerminalLine('system', '═══════════════════════════════════════════════════════════');
      if (isNetworkError) {
        pushTerminalLine('error', '✗ Cannot reach CloudScan backend');
        pushTerminalLine('error', `  URL attempted : ${CLOUDSCAN_URL}`);
        pushTerminalLine('error', `  Network error : ${msg}`);
        pushTerminalLine('info',  '  Possible causes:');
        pushTerminalLine('info',  '  (1) Docker container not running — run: docker compose up -d --build');
        pushTerminalLine('info',  '  (2) HTTPS → HTTP mixed-content block — backend needs SSL/nginx');
        pushTerminalLine('info',  '  (3) Firewall / security group blocking the port');
      } else {
        pushTerminalLine('error', `✗ Scan start failed: ${msg}`);
      }
      pushTerminalLine('system', '═══════════════════════════════════════════════════════════');
      pushTerminalLine('error', 'Scan aborted — fix the issue above and retry.');
      setScanStatus('error');

      // Record failed scan in history
      const elapsed = Math.round((Date.now() - scanStartTime) / 1000);
      const mins = Math.floor(elapsed / 60);
      const secs = elapsed % 60;
      recordCloudHistory({
        id: `cs-${Date.now()}`,
        accountId: config.accountId || '(unknown)',
        provider: config.provider || 'AWS',
        regions: config.regions || [],
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: 0,
        severities: { critical: 0, high: 0, medium: 0, low: 0 },
        riskScore: 0,
        status: 'Failed',
        scanType: 'Full Scan',
        duration: `${mins}m ${String(secs).padStart(2, '0')}s`,
        modulesScanned: 0,
      });
      return;
    }

    // Backend accepted the scan
    pushTerminalLine('success', `[+] Scan accepted (ID: ${scanId})`);
    setScanStatus('enumerating');

    // Initialise DV-CLOUD activity tracking if AI is enabled
    if ((config as { aiEnabled?: boolean }).aiEnabled && (config as { selectedAgents?: string[] }).selectedAgents?.length) {
      const selectedAgents = (config as { selectedAgents: string[] }).selectedAgents;
      const initialAgents = Object.fromEntries(selectedAgents.map(id => [id, 'pending' as AgentRunStatus]));
      scanActivityRef.current = { type: 'cloudscan', scanId, status: 'running', agents: initialAgents };
      writeScanActivity(scanActivityRef.current);
      setAgentMetrics({ total: selectedAgents.length, executing: 0, completed: 0 });
    }

    // 1. WebSocket for live terminal
    wsCleanupRef.current = connectCloudScanWebSocket(
      scanId,
      (line) => {
        // Parse DV-CLOUD agent start/complete messages to update live activity
        if (scanActivityRef.current) {
          const updated = parseScopeActivity(line.message, scanActivityRef.current.agents);
          if (updated) {
            scanActivityRef.current = { ...scanActivityRef.current, agents: updated };
            writeScanActivity(scanActivityRef.current);
            const vals = Object.values(updated);
            setAgentMetrics({
              total: vals.length,
              executing: vals.filter(s => s === 'executing').length,
              completed: vals.filter(s => s === 'completed' || s === 'error').length,
            });
          }
        }
        setTerminalLines((prev) => [...prev, line]);
      },
      () => {
        pushTerminalLine('info', '[*] WebSocket stream closed — polling for final status...');
        // Immediately probe status so we can surface the real error without waiting
        getCloudScanStatus(scanId).then(({ status }) => {
          if (status === 'error') {
            pushTerminalLine('error', '✗ Backend reported scan error — check CloudScan container logs:');
            pushTerminalLine('error', `  docker logs cra-cloudscan --tail 50`);
          }
        }).catch((probeErr) => {
          pushTerminalLine('error', `✗ Backend unreachable after WebSocket closed: ${probeErr instanceof Error ? probeErr.message : String(probeErr)}`);
          pushTerminalLine('error', '  The container may have crashed. Check: docker ps | grep cloudscan');
        });
      },
    );

    // 2. Poll status, update module status
    const finalStatus = await pollCloudScanUntilComplete(scanId, (status, backendModStatus) => {
      setScanStatus(status);
      if (Object.keys(backendModStatus).length > 0) {
        setModuleStatus(buildModuleStatusArray(backendModStatus));
      }
    });

    // 3. Fetch real results + record history
    const elapsed = Math.round((Date.now() - scanStartTime) / 1000);
    const mins = Math.floor(elapsed / 60);
    const secs = elapsed % 60;
    const duration = `${mins}m ${String(secs).padStart(2, '0')}s`;

    // Clear scan activity — scan is done
    if (scanActivityRef.current) {
      writeScanActivity(null);
      scanActivityRef.current = null;
      setAgentMetrics({ total: 0, executing: 0, completed: 0 });
    }

    if (finalStatus === 'completed') {
      let result: CloudScanResult;
      let graph: import('@/types/cloudscan').CloudGraphData;
      try {
        [result, graph] = await Promise.all([
          getCloudScanResults(scanId),
          getCloudGraphData(scanId),
        ]);
      } catch (fetchErr) {
        pushTerminalLine('error', `✗ Could not retrieve results: ${fetchErr instanceof Error ? fetchErr.message : String(fetchErr)}`);
        setScanStatus('error');
        return;
      }
      const fullResult: CloudScanResult = {
        ...result,
        graph: result.graph?.nodes?.length ? result.graph : graph,
      };
      setScanResult(fullResult);

      if (fullResult.findings?.length) {
        setModuleStatus((prev) =>
          prev.map((mod) => ({
            ...mod,
            status: 'complete' as const,
            findingsCount: fullResult.findings.filter(
              (f) => f.service?.toLowerCase() === mod.id || f.resourceType?.includes(mod.id)
            ).length,
          }))
        );
      }

      // Build severity counts from real findings
      const sevCounts = { critical: 0, high: 0, medium: 0, low: 0 };
      (fullResult.findings || []).forEach((f: { severity?: string }) => {
        const sev = f.severity?.toLowerCase() as keyof typeof sevCounts;
        if (sev && sev in sevCounts) sevCounts[sev]++;
      });

      recordCloudHistory({
        id: `cs-${Date.now()}`,
        accountId: fullResult.accountId || config.accountId || '(unknown)',
        provider: config.provider || 'AWS',
        regions: config.regions || [],
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: fullResult.findings?.length || 0,
        severities: sevCounts,
        riskScore: fullResult.summary?.riskScore || 0,
        status: 'Completed',
        scanType: 'Full Scan',
        duration,
        modulesScanned: 12,
        topFindings: [...(fullResult.findings || [])]
          .sort((a, b) => {
            const o = ['critical', 'high', 'medium', 'low', 'info'];
            return o.indexOf(a.severity?.toLowerCase() || 'info') - o.indexOf(b.severity?.toLowerCase() || 'info');
          })
          .slice(0, 5)
          .map((f: { title?: string; severity?: string; service?: string }) => ({
            title: f.title || 'Untitled finding',
            severity: f.severity?.toLowerCase() || 'medium',
            service: f.service || 'Unknown',
          })),
        graphData: fullResult.graph,
        fullResult,
      });
    } else if (finalStatus === 'error') {
      pushTerminalLine('system', '═══════════════════════════════════════════════════════════');
      pushTerminalLine('error', '✗ Scan finished with errors. Possible causes:');
      pushTerminalLine('error', '  • AWS credentials invalid or expired (check Access Key ID / Secret)');
      pushTerminalLine('error', '  • Insufficient IAM permissions (need read-only across services)');
      pushTerminalLine('error', '  • Network/timeout reaching selected AWS regions');
      pushTerminalLine('error', '  • Backend container crashed — run: docker logs cra-cloudscan --tail 50');
      recordCloudHistory({
        id: `cs-${Date.now()}`,
        accountId: config.accountId || '(unknown)',
        provider: config.provider || 'AWS',
        regions: config.regions || [],
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: 0,
        severities: { critical: 0, high: 0, medium: 0, low: 0 },
        riskScore: 0,
        status: 'Failed',
        scanType: 'Full Scan',
        duration,
        modulesScanned: 0,
      });
    }

    wsCleanupRef.current?.();
    wsCleanupRef.current = null;
  }, [pushTerminalLine, recordCloudHistory]);

  /** Stop an active scan: cancel backend, disconnect WS, clear terminal + live state. */
  const handleStopScan = useCallback(() => {
    if (savedScanIdRef.current) {
      cancelCloudScan(savedScanIdRef.current);
    }
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;
    quickScanTimersRef.current.forEach(clearTimeout);
    quickScanTimersRef.current = [];
    if (scanActivityRef.current) {
      writeScanActivity(null);
      scanActivityRef.current = null;
    }
    localStorage.removeItem(CLOUDSCAN_LIVE_KEY);
    savedScanIdRef.current = null;
    setAgentMetrics({ total: 0, executing: 0, completed: 0 });
    setScanStatus('idle');
    setTerminalLines([]);
    setScanResult(null);
    setModuleStatus([]);
  }, []);

  /**
   * Quick Scan — DEMO / MOCK.
   * Uses mock data to demonstrate the UI without a live backend.
   */
  const handleQuickScan = () => {
    // Cancel any in-flight Quick Scan timeouts
    quickScanTimersRef.current.forEach(clearTimeout);
    quickScanTimersRef.current = [];
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;

    setScanStatus('connecting');
    setTerminalLines([]);
    setScanResult(null);
    setModuleStatus([]);
    setActiveTab('overview');

    const t1 = setTimeout(() => {
      setScanStatus('enumerating');
      setTerminalLines(getMockTerminalLines());
      const mods = getMockModuleStatus().map(m => ({ ...m, status: 'running' as const, findingsCount: 0 }));
      setModuleStatus(mods);
    }, 500);

    const t2 = setTimeout(() => {
      setScanStatus('analyzing');
      setModuleStatus(getMockModuleStatus());
    }, 5500);

    const t3 = setTimeout(() => {
      setScanStatus('completed');
      const mockResult = getMockCloudScanResult();
      setScanResult(mockResult);
      setModuleStatus(getMockModuleStatus());
      const sevCounts = { critical: 0, high: 0, medium: 0, low: 0 };
      (mockResult.findings || []).forEach((f) => {
        const sev = f.severity?.toLowerCase() as keyof typeof sevCounts;
        if (sev && sev in sevCounts) sevCounts[sev]++;
      });
      recordCloudHistory({
        id: `cs-quick-${Date.now()}`,
        accountId: mockResult.accountId,
        provider: mockResult.provider?.toUpperCase() || 'AWS',
        regions: ['us-east-1'],
        date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
        findings: mockResult.findings?.length || 0,
        severities: sevCounts,
        riskScore: typeof mockResult.summary?.riskScore === 'number' ? mockResult.summary.riskScore : 72,
        status: 'Completed',
        scanType: 'Quick Scan',
        duration: '9s',
        modulesScanned: 12,
        topFindings: [...(mockResult.findings || [])]
          .sort((a, b) => {
            const o = ['critical', 'high', 'medium', 'low', 'info'];
            return o.indexOf(a.severity?.toLowerCase() || 'info') - o.indexOf(b.severity?.toLowerCase() || 'info');
          })
          .slice(0, 5)
          .map((f) => ({
            title: f.title || 'Untitled finding',
            severity: f.severity?.toLowerCase() || 'medium',
            service: f.service || 'Unknown',
          })),
        graphData: mockResult.graph,
        fullResult: mockResult,
      });
    }, 9500);

    quickScanTimersRef.current = [t1, t2, t3];
  };

  // History helpers
  const handleDeleteHistory = (id: string) => {
    setHistory(prev => {
      const updated = prev.filter(h => h.id !== id);
      saveCloudHistory(updated);
      return updated;
    });
    setDeleteConfirm(null);
    setCompareSelection(prev => prev.filter(s => s !== id));
  };

  const toggleCompareSelect = (id: string) => {
    setCompareSelection(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : prev.length < 2 ? [...prev, id] : [prev[1], id]
    );
  };

  const filteredHistory = history
    .filter(h => h.accountId.includes(historySearch) ||
                 h.provider.toLowerCase().includes(historySearch.toLowerCase()) ||
                 h.regions.some(r => r.includes(historySearch.toLowerCase())) ||
                 h.scanType.toLowerCase().includes(historySearch.toLowerCase()))
    .sort((a, b) => historySortAsc
      ? new Date(a.date).getTime() - new Date(b.date).getTime()
      : new Date(b.date).getTime() - new Date(a.date).getTime()
    );

  const compareItems = compareSelection.map(id => history.find(h => h.id === id)).filter(Boolean) as CloudScanHistory[];

  const totalAttackPaths = scanResult?.attackPaths?.length || 0;

  return (
    <PageContainer title="">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold text-white flex items-center gap-3">
              <Cloud className="text-cyan-400" size={28} />
              CloudScan
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              Cloud security assessment — 12 AWS service modules with attack path analysis, trust mapping, and reachability computation
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowProviderSettings(true)}
              className="border-gray-700 text-gray-400 hover:text-white hover:border-gray-500 gap-1.5"
              title="AI Provider Settings"
            >
              <Settings2 size={14} />
              AI Provider
              {providerConfig && (
                <Badge className="bg-emerald-900/30 text-emerald-400 border-0 text-[9px] ml-1">
                  {providerConfig.name}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowModules(true)}
              className="border-gray-700 text-gray-400 hover:text-white hover:border-gray-500 gap-1.5"
            >
              <Info size={14} />
              Modules
            </Button>
            <Button
              onClick={handleQuickScan}
              disabled={isRunning}
              className="bg-cyan-600 hover:bg-cyan-700 text-white gap-2"
            >
              <Zap size={14} />
              QUICK SCAN
            </Button>
          </div>
        </div>

        {/* Agent Execution Metrics — shown while a DV-CLOUD AI scan is active */}
        {isRunning && agentMetrics.total > 0 && (
          <div className="flex items-center gap-6 px-4 py-2.5 bg-cdm-darker rounded-lg border border-gray-800 text-sm">
            <span className="text-gray-500 text-[10px] uppercase tracking-widest font-semibold">Agent Metrics</span>
            <div className="flex items-center gap-6">
              <span className="text-gray-400 text-xs">TOTAL AGENTS <span className="text-white font-mono font-bold ml-1.5">{agentMetrics.total}</span></span>
              <span className="text-gray-400 text-xs">IN EXECUTION <span className="text-cyan-400 font-mono font-bold ml-1.5">{agentMetrics.executing}</span></span>
              <span className="text-gray-400 text-xs">TASKS COMPLETED <span className="text-emerald-400 font-mono font-bold ml-1.5">{agentMetrics.completed}</span></span>
            </div>
          </div>
        )}

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="overflow-x-auto pb-0.5">
          <TabsList className="bg-cdm-darker border border-gray-800 min-w-max">
            <TabsTrigger value="overview" className="text-xs data-[state=active]:bg-cyan-900/30 data-[state=active]:text-cyan-400">
              Scan Config
            </TabsTrigger>
            <TabsTrigger value="results" className="text-xs data-[state=active]:bg-cyan-900/30 data-[state=active]:text-cyan-400" disabled={!scanResult}>
              Results {scanResult && <Badge className="ml-1.5 bg-cyan-900/30 text-cyan-400 border-0 text-[10px] px-1">{scanResult.findings?.length ?? 0}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="graph" className="text-xs data-[state=active]:bg-cyan-900/30 data-[state=active]:text-cyan-400" disabled={!scanResult}>
              Attack Graph
            </TabsTrigger>
            <TabsTrigger value="paths" className="text-xs data-[state=active]:bg-cyan-900/30 data-[state=active]:text-cyan-400" disabled={!scanResult}>
              Attack Paths {scanResult && <Badge className="ml-1.5 bg-red-900/30 text-red-400 border-0 text-[10px] px-1">{totalAttackPaths}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="history" className="text-xs data-[state=active]:bg-cyan-900/30 data-[state=active]:text-cyan-400 gap-1.5">
              <Clock size={12} />
              History
              {history.length > 0 && (
                <Badge className="ml-1 bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{history.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>
          </div>

          {/* OVERVIEW */}
          <TabsContent value="overview" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                <CloudScanConfig onStartScan={handleStartScan} onStopScan={handleStopScan} isRunning={isRunning} />
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <ScanTerminal lines={terminalLines} isRunning={isRunning} />
              </div>
            </div>
          </TabsContent>

          {/* RESULTS */}
          <TabsContent value="results" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                {scanResult && (
                  <CloudResultsPanel
                    summary={scanResult.summary}
                    accountId={scanResult.accountId}
                    modules={moduleStatus}
                    findings={scanResult.findings}
                  />
                )}
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <ScanTerminal lines={terminalLines} isRunning={false} />
              </div>
            </div>
          </TabsContent>

          {/* GRAPH */}
          <TabsContent value="graph" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                {scanResult && (
                  <CloudResourceGraph
                    data={
                      scanResult.graph?.nodes?.length
                        ? scanResult.graph
                        : buildGraphFromFindings(scanResult.findings || [], scanResult.accountId)
                    }
                    persistKey={scanResult.accountId}
                  />
                )}
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <ScanTerminal lines={terminalLines} isRunning={false} />
              </div>
            </div>
          </TabsContent>

          {/* ATTACK PATHS */}
          <TabsContent value="paths" className="mt-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 min-w-0">
                {scanResult && <AttackPathsTable paths={scanResult.attackPaths || []} />}
              </div>
              <div className="w-full lg:w-[380px] lg:flex-shrink-0">
                <div className="space-y-4">
                  {scanResult && (
                    <CloudResultsPanel
                      summary={scanResult.summary}
                      accountId={scanResult.accountId}
                      modules={moduleStatus}
                      findings={scanResult.findings}
                    />
                  )}
                  <ScanTerminal lines={terminalLines} isRunning={false} />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* HISTORY TAB */}
          <TabsContent value="history" className="mt-4 space-y-4">
            {/* Toolbar */}
            <div className="flex items-center gap-3">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <Input
                  value={historySearch}
                  onChange={e => setHistorySearch(e.target.value)}
                  placeholder="Search account ID, region, or scan type..."
                  className="bg-cdm-dark border-gray-700 text-white h-9 pl-9 text-xs"
                />
              </div>
              <Button
                variant="outline" size="sm"
                onClick={() => setHistorySortAsc(!historySortAsc)}
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5 h-9"
              >
                <ArrowUpDown size={12} />
                {historySortAsc ? 'Oldest first' : 'Newest first'}
              </Button>
              {compareSelection.length === 2 && (
                <Button
                  size="sm"
                  onClick={() => setShowCompare(true)}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white gap-1.5 h-9"
                >
                  <GitCompare size={12} />
                  Compare ({compareSelection.length})
                </Button>
              )}
              {compareSelection.length > 0 && compareSelection.length < 2 && (
                <span className="text-xs text-gray-500">Select 1 more scan to compare</span>
              )}
              <Button
                variant="outline" size="sm"
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5 h-9 ml-auto"
              >
                <FileDown size={12} />
                Export All
              </Button>
            </div>

            {/* History list */}
            {filteredHistory.length > 0 ? (
              <div className="bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden">
                <div className="divide-y divide-gray-800">
                  {filteredHistory.map(scan => {
                    const isExpanded = expandedHistory === scan.id;
                    const isSelected = compareSelection.includes(scan.id);
                    const statusColor = scan.status === 'Completed'
                      ? 'bg-emerald-900/30 text-emerald-400'
                      : scan.status === 'Failed'
                        ? 'bg-red-900/30 text-red-400'
                        : 'bg-amber-900/30 text-amber-400';

                    return (
                      <div key={scan.id} className={`${isSelected ? 'bg-cyan-900/10 border-l-2 border-l-cyan-500' : ''}`}>
                        <div className="flex items-center gap-3 p-4 hover:bg-white/[0.01] transition-colors">
                          {/* Compare checkbox */}
                          <button
                            onClick={() => toggleCompareSelect(scan.id)}
                            className={`w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
                              isSelected ? 'bg-cyan-600 border-cyan-600' : 'border-gray-600 hover:border-gray-400'
                            }`}
                          >
                            {isSelected && <span className="text-white text-[8px] font-bold">{compareSelection.indexOf(scan.id) + 1}</span>}
                          </button>

                          {/* Main info */}
                          <Cloud size={16} className="text-cyan-400 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm text-white font-medium font-mono">{scan.accountId}</p>
                              <Badge variant="outline" className="border-gray-700 text-gray-500 text-[9px] flex-shrink-0">
                                {scan.scanType}
                              </Badge>
                              <Badge className="bg-cyan-900/20 text-cyan-400 border-0 text-[9px] flex-shrink-0">
                                {scan.provider}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-3 mt-1">
                              <span className="text-[11px] text-gray-500">{scan.date}</span>
                              <span className="text-[11px] text-gray-600">|</span>
                              <span className="text-[11px] text-gray-500">{scan.duration}</span>
                              <span className="text-[11px] text-gray-600">|</span>
                              <span className="text-[11px] text-gray-500">{scan.regions.join(', ')}</span>
                              <span className="text-[11px] text-gray-600">|</span>
                              <span className="text-[11px] text-gray-500">{scan.modulesScanned} modules</span>
                            </div>
                          </div>

                          {/* Risk score */}
                          <div className="flex-shrink-0 text-center">
                            <div className={`text-sm font-bold ${
                              scan.riskScore >= 80 ? 'text-red-400' :
                              scan.riskScore >= 50 ? 'text-amber-400' :
                              scan.riskScore >= 20 ? 'text-blue-400' : 'text-emerald-400'
                            }`}>
                              {scan.riskScore}
                            </div>
                            <div className="text-[9px] text-gray-600">Risk</div>
                          </div>

                          {/* Severity mini-badges */}
                          <div className="flex items-center gap-1 flex-shrink-0">
                            {scan.severities.critical > 0 && (
                              <span className="text-[10px] font-bold bg-red-900/40 text-red-400 px-1.5 py-0.5 rounded">{scan.severities.critical}C</span>
                            )}
                            {scan.severities.high > 0 && (
                              <span className="text-[10px] font-bold bg-orange-900/40 text-orange-400 px-1.5 py-0.5 rounded">{scan.severities.high}H</span>
                            )}
                            {scan.severities.medium > 0 && (
                              <span className="text-[10px] font-bold bg-amber-900/40 text-amber-400 px-1.5 py-0.5 rounded">{scan.severities.medium}M</span>
                            )}
                            {scan.severities.low > 0 && (
                              <span className="text-[10px] font-bold bg-blue-900/40 text-blue-400 px-1.5 py-0.5 rounded">{scan.severities.low}L</span>
                            )}
                            {scan.findings === 0 && scan.status === 'Completed' && (
                              <span className="text-[10px] text-emerald-400 bg-emerald-900/30 px-1.5 py-0.5 rounded">Clean</span>
                            )}
                          </div>

                          {/* Status */}
                          <Badge className={`${statusColor} border-0 text-[10px] flex-shrink-0`}>
                            {scan.status}
                          </Badge>

                          {/* Actions */}
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <Button
                              variant="ghost" size="sm"
                              disabled={isRunning}
                              onClick={() => {
                                setExpandedHistory(isExpanded ? null : scan.id);
                                if (!isExpanded) {
                                  if (scan.fullResult) {
                                    setScanResult(scan.fullResult);
                                  } else if (scan.graphData) {
                                    setScanResult({ id: scan.id, accountId: scan.accountId, provider: scan.provider as CloudScanResult['provider'], scanTime: scan.date, status: 'completed' as CloudScanStatus, summary: {} as CloudScanResult['summary'], graph: scan.graphData!, attackPaths: [], findings: [], trustRelationships: [] });
                                  }
                                }
                              }}
                              className="text-gray-500 hover:text-white h-7 w-7 p-0"
                              title={isRunning ? 'Unavailable during active scan' : 'View details'}
                            >
                              {isRunning ? <EyeOff size={13} /> : <Eye size={13} />}
                            </Button>
                            <Button
                              variant="ghost" size="sm"
                              className="text-gray-500 hover:text-white h-7 w-7 p-0"
                              title="Export"
                            >
                              <Download size={13} />
                            </Button>
                            {deleteConfirm === scan.id ? (
                              <div className="flex items-center gap-1">
                                <Button
                                  size="sm"
                                  onClick={() => handleDeleteHistory(scan.id)}
                                  className="bg-red-600 hover:bg-red-700 text-white h-7 px-2 text-[10px]"
                                >
                                  Confirm
                                </Button>
                                <Button
                                  variant="ghost" size="sm"
                                  onClick={() => setDeleteConfirm(null)}
                                  className="text-gray-400 h-7 w-7 p-0"
                                >
                                  <X size={12} />
                                </Button>
                              </div>
                            ) : (
                              <Button
                                variant="ghost" size="sm"
                                onClick={() => setDeleteConfirm(scan.id)}
                                className="text-gray-500 hover:text-red-400 h-7 w-7 p-0"
                                title="Delete"
                              >
                                <Trash2 size={13} />
                              </Button>
                            )}
                          </div>
                        </div>

                        {/* Expanded detail */}
                        {isExpanded && (
                          <div className="px-4 pb-4 pt-1 border-t border-gray-800/50 ml-[52px]">
                            <div className="grid grid-cols-4 gap-3 mb-3">
                              {(['critical', 'high', 'medium', 'low'] as const).map(sev => (
                                <div key={sev} className={`rounded border p-2 ${CLOUD_SEVERITY_COLORS[sev].bg} ${CLOUD_SEVERITY_COLORS[sev].border}`}>
                                  <div className={`text-lg font-bold ${CLOUD_SEVERITY_COLORS[sev].text}`}>{scan.severities[sev]}</div>
                                  <div className={`text-[10px] capitalize ${CLOUD_SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                                </div>
                              ))}
                            </div>
                            {scan.topFindings && scan.topFindings.length > 0 && (
                              <div className="space-y-1 mb-3">
                                <h5 className="text-xs font-semibold text-gray-400 mb-1.5">Top Findings</h5>
                                {scan.topFindings.map((f, i) => (
                                  <div key={i} className="flex items-center gap-2 text-xs">
                                    <Badge className={`${CLOUD_SEVERITY_COLORS[f.severity]?.bg || 'bg-gray-800'} ${CLOUD_SEVERITY_COLORS[f.severity]?.text || 'text-gray-400'} border-0 text-[9px] px-1.5 uppercase w-16 justify-center`}>
                                      {f.severity}
                                    </Badge>
                                    <span className="text-gray-300 truncate">{f.title}</span>
                                    <span className="text-cyan-600 text-[10px] ml-auto flex-shrink-0">{f.service}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                            {(!scan.topFindings || scan.topFindings.length === 0) && scan.findings > 0 && (
                              <p className="text-xs text-gray-500 mb-3">{scan.findings} finding(s) recorded.</p>
                            )}
                            {scan.findings === 0 && scan.status === 'Completed' && (
                              <p className="text-xs text-emerald-400 mb-3">No misconfigurations found — account appears clean.</p>
                            )}
                            {scan.status === 'Failed' && (
                              <div className="text-xs text-red-400 space-y-0.5 mb-3">
                                <p className="font-medium">Scan failed. Check terminal output for the exact error:</p>
                                <p className="text-gray-500">Common causes: invalid/expired credentials, insufficient IAM permissions, backend container not running.</p>
                              </div>
                            )}
                            {scan.status === 'Completed' && (
                              <div className="flex items-center gap-2 pt-2 border-t border-gray-800/50">
                                <Button
                                  size="sm"
                                  onClick={() => setActiveTab('results')}
                                  className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs gap-1.5"
                                >
                                  View Results
                                </Button>
                                {(scan.fullResult?.attackPaths?.length ?? 0) > 0 && (
                                  <Button
                                    size="sm"
                                    onClick={() => setActiveTab('paths')}
                                    className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs gap-1.5"
                                  >
                                    Finding Details
                                  </Button>
                                )}
                                {scan.graphData && scan.graphData.nodes.length > 0 && (
                                  <Button
                                    size="sm"
                                    onClick={() => setActiveTab('graph')}
                                    className="bg-cyan-900/30 hover:bg-cyan-900/50 text-cyan-400 border border-cyan-800/50 gap-1.5 h-7 text-xs"
                                  >
                                    <Network size={12} />
                                    Attack Graph
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 bg-cdm-darker rounded-lg border border-gray-800">
                <Clock size={40} className="text-gray-700 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No scan history</h3>
                <p className="text-sm text-gray-500">
                  {historySearch ? 'No scans match your search' : 'Completed cloud scans will appear here'}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Compare Modal */}
      {showCompare && compareItems.length === 2 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70" onClick={() => setShowCompare(false)} />
          <div className="relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-3xl max-h-[80vh] overflow-hidden flex flex-col m-4">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
              <div>
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <GitCompare size={18} className="text-cyan-400" />
                  Cloud Scan Comparison
                </h2>
                <p className="text-xs text-gray-500 mt-0.5">Side-by-side comparison of two cloud scan runs</p>
              </div>
              <button
                onClick={() => setShowCompare(false)}
                className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-2 gap-6">
                {compareItems.map((item, idx) => (
                  <div key={item.id} className="space-y-4">
                    <div className="text-center">
                      <Badge className={`${idx === 0 ? 'bg-cyan-900/30 text-cyan-400' : 'bg-purple-900/30 text-purple-400'} border-0 text-xs mb-2`}>
                        Scan {idx + 1}
                      </Badge>
                      <p className="text-sm text-white font-medium font-mono">{item.accountId}</p>
                      <p className="text-[11px] text-gray-500">{item.date} · {item.duration}</p>
                      <p className="text-[11px] text-gray-600">{item.regions.join(', ')}</p>
                    </div>
                    <div className="flex justify-center">
                      <div className={`text-2xl font-bold ${
                        item.riskScore >= 80 ? 'text-red-400' :
                        item.riskScore >= 50 ? 'text-amber-400' : 'text-emerald-400'
                      }`}>
                        {item.riskScore}
                        <span className="text-xs text-gray-500 ml-1 font-normal">risk</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {(['critical', 'high', 'medium', 'low'] as const).map(sev => {
                        const other = compareItems[1 - idx];
                        const diff = item.severities[sev] - other.severities[sev];
                        return (
                          <div key={sev} className={`rounded border p-2 ${CLOUD_SEVERITY_COLORS[sev].bg} ${CLOUD_SEVERITY_COLORS[sev].border}`}>
                            <div className="flex items-baseline gap-1.5">
                              <span className={`text-xl font-bold ${CLOUD_SEVERITY_COLORS[sev].text}`}>{item.severities[sev]}</span>
                              {diff !== 0 && (
                                <span className={`text-[10px] font-bold ${diff > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                                  {diff > 0 ? `+${diff}` : diff}
                                </span>
                              )}
                            </div>
                            <div className={`text-[10px] capitalize ${CLOUD_SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="text-center">
                      <span className="text-2xl font-bold text-white">{item.findings}</span>
                      <span className="text-xs text-gray-500 ml-1.5">total findings</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scan Modules Modal */}
      {showModules && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70" onClick={() => setShowModules(false)} />
          <div className="relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-5xl max-h-[80vh] overflow-hidden flex flex-col m-4">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
              <div>
                <h2 className="text-lg font-semibold text-white">AWS Scan Modules</h2>
                <p className="text-xs text-gray-500 mt-0.5">{AWS_SCAN_MODULES.reduce((a, m) => a + m.services.length, 0)} services across {AWS_SCAN_MODULES.length} categories</p>
              </div>
              <button
                onClick={() => setShowModules(false)}
                className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {AWS_SCAN_MODULES.map(mod => (
                  <div key={mod.id} className="bg-cdm-dark rounded-lg border border-gray-800 overflow-hidden hover:border-gray-700 transition-colors">
                    <div className="px-4 py-3 border-b border-gray-800/50 flex items-center gap-2">
                      <div className="text-cyan-400">{moduleIcons[mod.id] || <Globe size={16} />}</div>
                      <div>
                        <h3 className="text-sm font-semibold text-white">{mod.title}</h3>
                        <p className="text-[11px] text-gray-500">{mod.description}</p>
                      </div>
                    </div>
                    <div className="divide-y divide-gray-800/30">
                      {mod.services.map(svc => {
                        const modStat = moduleStatus.find(m => m.id === svc.id);
                        return (
                          <div key={svc.id} className="flex items-center justify-between px-4 py-2.5 hover:bg-white/[0.02] transition-colors group">
                            <div className="flex items-center gap-2">
                              {modStat && (
                                <span className={`w-1.5 h-1.5 rounded-full ${
                                  modStat.status === 'complete' ? 'bg-emerald-400' :
                                  modStat.status === 'running' ? 'bg-cyan-400 animate-pulse' :
                                  modStat.status === 'error' ? 'bg-red-400' : 'bg-gray-600'
                                }`} />
                              )}
                              <span className="text-xs text-gray-300 group-hover:text-white transition-colors">{svc.name}</span>
                              <span className="hidden sm:inline text-[10px] text-gray-600">{svc.description}</span>
                            </div>
                            {modStat && modStat.findingsCount > 0 ? (
                              <Badge className="bg-amber-900/20 text-amber-400 border-0 text-[10px] px-1.5">{modStat.findingsCount}</Badge>
                            ) : (
                              <ArrowRight size={12} className="text-gray-700 group-hover:text-gray-400 transition-colors" />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI Provider Settings Modal */}
      <ProviderSettings
        open={showProviderSettings}
        onClose={() => setShowProviderSettings(false)}
        onSave={(cfg) => { setProviderConfig(cfg); setShowProviderSettings(false); }}
      />
    </PageContainer>
  );
};

export default CloudScan;
