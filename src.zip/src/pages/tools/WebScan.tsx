import React, { useState, useCallback, useEffect, useRef } from 'react';
import {
  Globe, Play, Download, ChevronDown, ExternalLink, Square,
  Shield, AlertTriangle, Info, Clock, Bot, RotateCw, Trash2,
  Search, ArrowUpDown, FileDown, GitCompare, Eye, EyeOff, X,
  Settings2, Wrench, Monitor, ChevronRight, Zap,
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import PageContainer from '@/components/PageContainer';
import BrowserOverlay from '@/components/webscan/BrowserOverlay';
import ScanTerminal from '@/components/webscan/ScanTerminal';
import ProviderSettings from '@/components/webscan/ProviderSettings';
import ToolCallsPanel from '@/components/webscan/ToolCallsPanel';
import FindingsPanel from '@/components/webscan/FindingsPanel';
import type { TerminalLine } from '@/types/adscan';
import type {
  WebVulnerability, MCPToolCall, AIProviderConfig, WebScanHistoryEntry,
  WebScanStatus, WebVulnSeverity,
} from '@/types/webscan';
import {
  startWebScanLive,
  connectWebScanWebSocket, pollWebScanUntilComplete, cancelWebScan,
  loadWebScanHistory, saveWebScanHistory, loadProviderConfig,
} from '@/services/webscanService';
import { loadAIModelSettings } from '@/services/aiModelSettingsService';

// ── Agent types from AIAgents module ────────────────────────────────────────

interface AIAgentOption {
  id: string;
  name: string;
  type: string;
  instructions?: string;
}

const AGENT_STORAGE_KEY = 'cra_ai_agents';

function loadAgentsFromStorage(): AIAgentOption[] {
  try {
    const stored = localStorage.getItem(AGENT_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        return parsed.map((a: Record<string, unknown>) => ({
          id: String(a.id),
          name: String(a.name),
          type: String(a.type),
          instructions: a.instructions ? String(a.instructions) : undefined,
        }));
      }
    }
  } catch { /* ignore */ }
  return [];
}

// Built-in templates (always available) — instructions shape what the AI focuses on
const BUILTIN_AGENTS: AIAgentOption[] = [
  {
    id: 'red-team',
    name: 'Red Team Agent',
    type: 'red-team',
    instructions: 'You are a red team operator. Focus on finding authentication bypasses, privilege escalation, remote code execution, and critical injection vulnerabilities. Attempt to chain findings into full exploitation paths.',
  },
  {
    id: 'bug-bounty',
    name: 'Bug Bounty Hunter',
    type: 'bug-bounty',
    instructions: 'You are a bug bounty hunter. Focus on high-impact, reproducible findings: XSS, SSRF, SQLi, IDOR, broken auth. Provide clear proof-of-concept evidence and CVSS scores.',
  },
  {
    id: 'blue-team',
    name: 'Blue Team Agent',
    type: 'blue-team',
    instructions: 'You are a defensive security analyst. Document all findings with detection guidance, log sources, and recommended mitigations. Focus on security header gaps, data exposure, and hardening opportunities.',
  },
  {
    id: 'dfir',
    name: 'DFIR Analyst',
    type: 'dfir',
    instructions: 'You are a DFIR analyst performing forensic web analysis. Look for indicators of compromise, exposed credentials, sensitive data leakage, and server-side information disclosure.',
  },
];

// ── Severity helpers ─────────────────────────────────────────────────────────

const SEV_ORDER: WebVulnSeverity[] = ['critical', 'high', 'medium', 'low', 'info'];

const sortBySeverity = (arr: WebVulnerability[]) =>
  [...arr].sort((a, b) => SEV_ORDER.indexOf(a.severity) - SEV_ORDER.indexOf(b.severity));

function mergeIncomingFinding(prev: WebVulnerability[], incoming: WebVulnerability): WebVulnerability[] {
  const titleKey = incoming.title.trim().toLowerCase();
  const idx = prev.findIndex(e => e.title.trim().toLowerCase() === titleKey);
  if (idx !== -1) {
    const existing = prev[idx];
    const newEp = incoming.endpoint;
    const existingEps = existing.affectedEndpoints?.length
      ? existing.affectedEndpoints
      : [existing.endpoint].filter(Boolean);
    if (!newEp || existingEps.includes(newEp)) return prev;
    const updated = [...prev];
    updated[idx] = { ...existing, affectedEndpoints: [...existingEps, newEp] };
    return sortBySeverity(updated);
  }
  const withEps: WebVulnerability = {
    ...incoming,
    affectedEndpoints: incoming.affectedEndpoints?.length
      ? incoming.affectedEndpoints
      : [incoming.endpoint].filter(Boolean) as string[],
  };
  return sortBySeverity([...prev, withEps]);
}

const SEVERITY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  critical: { bg: 'bg-red-900/30', text: 'text-red-400', border: 'border-red-500/30' },
  high: { bg: 'bg-orange-900/30', text: 'text-orange-400', border: 'border-orange-500/30' },
  medium: { bg: 'bg-amber-900/30', text: 'text-amber-400', border: 'border-amber-500/30' },
  low: { bg: 'bg-blue-900/30', text: 'text-blue-400', border: 'border-blue-500/30' },
  info: { bg: 'bg-gray-800', text: 'text-gray-400', border: 'border-gray-700' },
};

// ═════════════════════════════════════════════════════════════════════════════

const WEBSCAN_LIVE_KEY = 'cra_webscan_live';
const SCAN_ACTIVITY_KEY = 'cra_scan_activity';

function writeScanActivity(payload: { type: string; scanId: string; status: string; agents: Record<string, string> } | null) {
  if (payload === null) localStorage.removeItem(SCAN_ACTIVITY_KEY);
  else localStorage.setItem(SCAN_ACTIVITY_KEY, JSON.stringify(payload));
  window.dispatchEvent(new CustomEvent('cra-scan-activity', { detail: payload }));
}

function loadWebLiveState() {
  try {
    const raw = localStorage.getItem(WEBSCAN_LIVE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

const WebScan = () => {
  const saved = React.useMemo(loadWebLiveState, []);

  // ── Scan config state ───────────────────────────────────────────────────
  const [targetUrl, setTargetUrl] = useState(() => saved?.targetUrl || '');
  const [scanType, setScanType] = useState('full');
  const [selectedAgent, setSelectedAgent] = useState(() => saved?.selectedAgent || 'none');
  const [maxDepth, setMaxDepth] = useState(3);
  const [maxPages, setMaxPages] = useState(50);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // ── Scan runtime state ──────────────────────────────────────────────────
  const [scanStatus, setScanStatus] = useState<WebScanStatus>(() => saved?.scanStatus || 'idle');
  const [scanId, setScanId] = useState<string | null>(() => saved?.scanId || null);
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>(() => saved?.terminalLines || []);
  const [findings, setFindings] = useState<WebVulnerability[]>(() => saved?.findings || []);
  const [toolCalls, setToolCalls] = useState<MCPToolCall[]>(() => saved?.toolCalls || []);
  const [screenshotB64, setScreenshotB64] = useState<string | null>(() => saved?.screenshotB64 || null);
  const [currentUrl, setCurrentUrl] = useState(() => saved?.currentUrl || '');
  const [pageTitle, setPageTitle] = useState(() => saved?.pageTitle || '');
  const [isNavigating, setIsNavigating] = useState(false);
  const [tasksCompleted, setTasksCompleted] = useState(0);
  const [findingsFound, setFindingsFound] = useState(0);

  // ── UI state ────────────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState('live');
  const [showProviderSettings, setShowProviderSettings] = useState(false);
  const [providerConfig, setProviderConfig] = useState<AIProviderConfig | null>(null);
  const [availableAgents, setAvailableAgents] = useState<AIAgentOption[]>([]);

  // ── History state ───────────────────────────────────────────────────────
  const [history, setHistory] = useState<WebScanHistoryEntry[]>(() => loadWebScanHistory());
  const [historySearch, setHistorySearch] = useState('');
  const [expandedHistory, setExpandedHistory] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [historySortAsc, setHistorySortAsc] = useState(false);
  const [compareSelection, setCompareSelection] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);

  const wsCleanupRef = useRef<(() => void) | null>(null);
  const wsSeqRef = useRef<number>(saved?.wsSeq ?? 0); // tracks last synced output-line sequence

  // Refs always point to latest state — used by memoised callbacks to avoid stale closures
  const findingsRef = useRef<WebVulnerability[]>(findings);
  findingsRef.current = findings;
  const terminalLinesRef = useRef<TerminalLine[]>(terminalLines);
  terminalLinesRef.current = terminalLines;
  const toolCallsRef = useRef<MCPToolCall[]>(toolCalls);
  toolCallsRef.current = toolCalls;

  // Track scan config and whether history has been recorded for the current scan.
  // historyRecordedRef starts true so a saved "completed" state on mount doesn't duplicate history.
  const scanConfigRef = useRef<{ targetUrl: string; scanType: string } | null>(null);
  const historyRecordedRef = useRef(true);

  const isScanning = scanStatus === 'connecting' || scanStatus === 'crawling' || scanStatus === 'auditing';

  // ── Persist scan state across navigation ──────────────────────────────
  useEffect(() => {
    if (!scanId) return;
    localStorage.setItem(WEBSCAN_LIVE_KEY, JSON.stringify({
      scanId,
      scanStatus,
      terminalLines: terminalLines.slice(-300),
      findings,
      toolCalls: toolCalls.slice(-100),
      targetUrl,
      selectedAgent,
      screenshotB64,
      currentUrl,
      pageTitle,
      wsSeq: wsSeqRef.current,
    }));
  }, [scanId, scanStatus, terminalLines, findings, toolCalls, targetUrl, selectedAgent, screenshotB64, currentUrl, pageTitle]);

  // Keep findingsFound in sync with actual findings array length
  useEffect(() => { setFindingsFound(findings.length); }, [findings]);

  // ── Reconnect WebSocket if returning to a running scan ────────────────
  useEffect(() => {
    if (!saved?.scanId) return;
    const activeStatuses: WebScanStatus[] = ['connecting', 'crawling', 'auditing'];
    if (!activeStatuses.includes(saved.scanStatus)) return;

    historyRecordedRef.current = false;
    scanConfigRef.current = { targetUrl: saved.targetUrl || '', scanType: 'full' };

    const cleanup = connectWebScanWebSocket(saved.scanId, {
      onTerminal: (line) => setTerminalLines(prev => [...prev, line]),
      onScreenshot: (b64) => setScreenshotB64(b64),
      onBrowserState: (state) => {
        setCurrentUrl(state.currentUrl || '');
        setPageTitle(state.pageTitle || '');
        setIsNavigating(state.isNavigating || false);
      },
      onFinding: (f) => setFindings(prev => mergeIncomingFinding(prev, f as WebVulnerability)),
      onToolCall: (tc) => setToolCalls(prev => [...prev, tc as MCPToolCall]),
      onStatus: (status) => {
        setScanStatus(status);
        if (status === 'completed') { setTasksCompleted(1); writeScanActivity(null); }
        else if (status === 'error' || status === 'cancelled') writeScanActivity(null);
      },
      onSync: (seq) => { wsSeqRef.current = seq; },
      onClose: () => {},
    }, wsSeqRef.current);
    wsCleanupRef.current = cleanup;

    pollWebScanUntilComplete(saved.scanId, (status) => {
      setScanStatus(status);
      if (status === 'completed') { setTasksCompleted(1); writeScanActivity(null); }
      else if (status === 'error' || status === 'cancelled') writeScanActivity(null);
    });

    return () => { cleanup(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Record history when scan reaches a terminal state ─────────────────
  // Runs post-render so all refs (findings, terminalLines, toolCalls) are
  // guaranteed to reflect the latest state — avoids the batching race where
  // onStatus fires before React has flushed the final setFindings updates.
  useEffect(() => {
    if (scanStatus !== 'completed' && scanStatus !== 'error' && scanStatus !== 'cancelled') return;
    if (!scanConfigRef.current) return;
    if (historyRecordedRef.current) return;
    historyRecordedRef.current = true;
    recordHistoryRef.current(scanConfigRef.current, scanStatus);
  }, [scanStatus]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Load saved provider config and agents ─────────────────────────────
  useEffect(() => {
    setProviderConfig(loadProviderConfig());
    const custom = loadAgentsFromStorage();
    // Custom agents override built-ins (same id wins for custom)
    const mergeMap = new Map(BUILTIN_AGENTS.map(a => [a.id, a]));
    for (const a of custom) mergeMap.set(a.id, a);
    setAvailableAgents(Array.from(mergeMap.values()));
  }, []);

  // ── Start scan ────────────────────────────────────────────────────────
  const handleStartScan = useCallback(async () => {
    if (!targetUrl.trim()) return;

    // Clear any previously persisted scan state
    localStorage.removeItem(WEBSCAN_LIVE_KEY);

    // Ensure URL has a scheme
    const rawUrl = targetUrl.trim();
    const normalizedUrl = /^https?:\/\//i.test(rawUrl) ? rawUrl : `https://${rawUrl}`;

    // Reset state
    wsSeqRef.current = 0;
    setTerminalLines([]);
    setFindings([]);
    setToolCalls([]);
    setScreenshotB64(null);
    setCurrentUrl('');
    setPageTitle('');
    setTasksCompleted(0);
    setFindingsFound(0);
    setScanStatus('connecting');
    setActiveTab('live');

    historyRecordedRef.current = false;
    scanConfigRef.current = { targetUrl: normalizedUrl, scanType };

    const agentInfo = availableAgents.find(a => a.id === selectedAgent);
    const aiModelSettings = loadAIModelSettings();

    const config = {
      targetUrl: normalizedUrl,
      scanType,
      maxDepth: scanType === 'quick' ? 1 : maxDepth,
      maxPages: scanType === 'quick' ? 10 : maxPages,
      headless: true,
      includeSubdomains: false,
      excludePatterns: [] as string[],
      agentId: selectedAgent !== 'none' ? selectedAgent : undefined,
      agentName: agentInfo?.name,
      agentInstructions: agentInfo?.instructions,
      aiProvider: selectedAgent !== 'none' && providerConfig ? providerConfig.type : undefined,
      aiApiKey: selectedAgent !== 'none' && providerConfig ? providerConfig.apiKey : undefined,
      aiModel: selectedAgent !== 'none' && providerConfig ? providerConfig.model : undefined,
      aiBaseUrl: selectedAgent !== 'none' && providerConfig?.baseUrl ? providerConfig.baseUrl : undefined,
      // AI model behavior settings from Settings → AI Model Settings
      aiMaxSteps: aiModelSettings.maxSteps,
      aiMaxInputTokens: aiModelSettings.maxInputTokens ?? undefined,
      aiMaxOutputTokens: aiModelSettings.maxOutputTokens ?? undefined,
      aiTemperature: aiModelSettings.temperature ?? undefined,
      aiTopP: aiModelSettings.topP ?? undefined,
      aiSafeTokenThreshold: aiModelSettings.safeTokenThreshold,
      aiAutoTokenShrinking: aiModelSettings.autoTokenShrinking,
      aiChunkingEnabled: aiModelSettings.chunkingEnabled,
      aiToolCallRetries: aiModelSettings.maxToolCallRetries,
    };

    try {
      const result = await startWebScanLive(config);
      const id = result.scanId;
      setScanId(id);

      // Emit scan activity so AIAgents page can show live status
      const agentInfo = availableAgents.find(a => a.id === selectedAgent);
      writeScanActivity({
        type: 'webscan',
        scanId: id,
        status: 'running',
        agents: selectedAgent !== 'none'
          ? { [selectedAgent]: agentInfo?.name || selectedAgent }
          : {},
      });

      // Connect WebSocket for live streaming
      wsSeqRef.current = 0;
      const cleanup = connectWebScanWebSocket(id, {
        onTerminal: (line) => setTerminalLines(prev => [...prev, line]),
        onScreenshot: (b64) => setScreenshotB64(b64),
        onBrowserState: (state) => {
          setCurrentUrl(state.currentUrl || '');
          setPageTitle(state.pageTitle || '');
          setIsNavigating(state.isNavigating || false);
        },
        onFinding: (f) => setFindings(prev => mergeIncomingFinding(prev, f as WebVulnerability)),
        onToolCall: (tc) => setToolCalls(prev => [...prev, tc as MCPToolCall]),
        onSync: (seq) => { wsSeqRef.current = seq; },
        onStatus: (status) => {
          setScanStatus(status);
          if (status === 'completed') {
            setTasksCompleted(prev => prev + 1);
            writeScanActivity(null);
          } else if (status === 'error' || status === 'cancelled') {
            writeScanActivity(null);
          }
        },
        onClose: () => {},
      });
      wsCleanupRef.current = cleanup;

      // Poll status as backup
      pollWebScanUntilComplete(id, (status) => setScanStatus(status));
    } catch (err) {
      setScanStatus('error');
      setTerminalLines([{
        id: 1,
        timestamp: new Date().toLocaleTimeString('en-GB'),
        type: 'error',
        message: `Failed to start scan: ${err instanceof Error ? err.message : String(err)}`,
      }]);
    }
  }, [targetUrl, scanType, selectedAgent, maxDepth, maxPages, providerConfig, availableAgents]);

  // ── Cancel scan ───────────────────────────────────────────────────────
  const handleCancelScan = useCallback(() => {
    if (scanId) cancelWebScan(scanId);
    wsCleanupRef.current?.();
    wsCleanupRef.current = null;
    setScanStatus('cancelled');
    writeScanActivity(null);
  }, [scanId]);

  // Cleanup on unmount
  useEffect(() => {
    return () => { wsCleanupRef.current?.(); };
  }, []);

  // ── History management ────────────────────────────────────────────────
  const recordHistory = (config: { targetUrl: string; scanType: string }, status: WebScanStatus) => {
    const curFindings = findingsRef.current;
    const curTerminalLines = terminalLinesRef.current;
    const curToolCalls = toolCallsRef.current;
    const entry: WebScanHistoryEntry = {
      id: `ws-${Date.now()}`,
      url: config.targetUrl,
      date: new Date().toLocaleString('sv-SE', { hour12: false }).replace('T', ' '),
      findings: curFindings.length,
      severities: {
        critical: curFindings.filter(f => f.severity === 'critical').length,
        high: curFindings.filter(f => f.severity === 'high').length,
        medium: curFindings.filter(f => f.severity === 'medium').length,
        low: curFindings.filter(f => f.severity === 'low').length,
        info: curFindings.filter(f => f.severity === 'info').length,
      },
      status,
      scanType: config.scanType === 'full' ? 'Full Scan' : config.scanType === 'quick' ? 'Quick Scan' : config.scanType === 'api' ? 'API Only' : config.scanType === 'ai_only' ? 'AI Only' : config.scanType === 'passive' ? 'Passive' : config.scanType,
      agent: selectedAgent === 'none' ? 'None' : (availableAgents.find(a => a.id === selectedAgent)?.name || selectedAgent),
      duration: '—',
      vulnerabilities: sortBySeverity(curFindings),
      terminalLines: curTerminalLines.slice(-300),
      toolCalls: curToolCalls.slice(-100),
    };
    setHistory(prev => {
      const updated = [entry, ...prev];
      saveWebScanHistory(updated);
      return updated;
    });
  };

  // Stable ref so memoised handleStartScan always calls the latest recordHistory
  const recordHistoryRef = useRef(recordHistory);
  recordHistoryRef.current = recordHistory;

  const handleRescan = (entry: WebScanHistoryEntry) => {
    setTargetUrl(entry.url);
    setActiveTab('live');
    setTimeout(() => handleStartScan(), 100);
  };

  const handleDeleteHistory = (id: string) => {
    setHistory(prev => {
      const updated = prev.filter(h => h.id !== id);
      saveWebScanHistory(updated);
      return updated;
    });
    setDeleteConfirm(null);
    setCompareSelection(prev => prev.filter(s => s !== id));
  };

  const toggleCompareSelect = (id: string) => {
    setCompareSelection(prev =>
      prev.includes(id)
        ? prev.filter(s => s !== id)
        : prev.length < 2 ? [...prev, id] : [prev[1], id]
    );
  };

  const filteredHistory = history
    .filter(h => h.url.toLowerCase().includes(historySearch.toLowerCase()) ||
                 h.scanType.toLowerCase().includes(historySearch.toLowerCase()) ||
                 h.agent.toLowerCase().includes(historySearch.toLowerCase()))
    .sort((a, b) => historySortAsc
      ? new Date(a.date).getTime() - new Date(b.date).getTime()
      : new Date(b.date).getTime() - new Date(a.date).getTime()
    );

  const compareItems = compareSelection.map(id => history.find(h => h.id === id)).filter(Boolean) as WebScanHistoryEntry[];

  // ── Export findings as Markdown ───────────────────────────────────────
  const handleExport = useCallback(() => {
    const agentInfo = availableAgents.find(a => a.id === selectedAgent);
    const agentLabel = agentInfo ? `${agentInfo.name} (${agentInfo.type})` : 'None — rule-based only';
    const providerLabel = providerConfig
      ? `${providerConfig.name} / ${providerConfig.model}`
      : 'N/A';
    const scanDate = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

    const severityOrder: WebVulnSeverity[] = ['critical', 'high', 'medium', 'low', 'info'];
    const countBySev = (sev: WebVulnSeverity) => findings.filter(f => f.severity === sev).length;

    const summaryTable = [
      '| Severity | Count |',
      '|----------|-------|',
      ...severityOrder.map(s => `| ${s.charAt(0).toUpperCase() + s.slice(1)} | ${countBySev(s)} |`),
      `| **Total** | **${findings.length}** |`,
    ].join('\n');

    const findingBlocks = severityOrder.flatMap(sev =>
      findings
        .filter(f => f.severity === sev)
        .map((f, i) => [
          `### ${i + 1}. ${f.title}`,
          '',
          `| Field | Value |`,
          `|-------|-------|`,
          `| **Severity** | ${f.severity.toUpperCase()}${f.cvss ? ` (CVSS ${f.cvss})` : ''} |`,
          f.cwe ? `| **CWE** | ${f.cwe} |` : null,
          f.endpoint ? `| **Endpoint** | \`${f.method || 'GET'} ${f.endpoint}\` |` : null,
          f.parameter ? `| **Parameter** | \`${f.parameter}\` |` : null,
          '',
          `**Description**`,
          f.description || '_No description provided._',
          f.evidence ? `\n**Evidence**\n\`\`\`\n${f.evidence}\n\`\`\`` : null,
          '',
          `**Remediation**`,
          f.remediation || '_No remediation provided._',
          f.references?.length ? `\n**References**\n${f.references.map(r => `- ${r}`).join('\n')}` : null,
          '',
          '---',
        ].filter(Boolean).join('\n'))
    );

    const md = [
      `# WebScan Report`,
      '',
      `## Scan Metadata`,
      '',
      `| Field | Value |`,
      `|-------|-------|`,
      `| **Date** | ${scanDate} |`,
      `| **Target** | ${targetUrl} |`,
      `| **Scan Type** | ${scanType} |`,
      `| **AI Agent** | ${agentLabel} |`,
      `| **AI Provider** | ${providerLabel} |`,
      `| **Status** | ${scanStatus} |`,
      `| **Scan ID** | ${scanId || 'N/A'} |`,
      '',
      `## Summary`,
      '',
      summaryTable,
      '',
      `## Findings`,
      '',
      findings.length > 0 ? findingBlocks.join('\n') : '_No findings recorded._',
      '',
      `## Terminal Log`,
      '',
      '```',
      terminalLines.map(l => `[${l.timestamp}] ${l.message}`).join('\n'),
      '```',
      '',
      `---`,
      `*Generated by CRA CDM WebScan — ${scanDate}*`,
    ].join('\n');

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeTarget = targetUrl.replace(/https?:\/\//, '').replace(/[^a-z0-9]/gi, '_').slice(0, 40);
    a.href = url;
    a.download = `webscan_${safeTarget}_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [findings, terminalLines, targetUrl, scanType, scanStatus, scanId, selectedAgent, availableAgents, providerConfig]);

  // ═════════════════════════════════════════════════════════════════════════
  // RENDER
  // ═════════════════════════════════════════════════════════════════════════

  return (
    <PageContainer title="">
      <div className="space-y-5">
        {/* ── Header ─────────────────────────────────────────────────────── */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h1 className="text-2xl font-bold text-white">Web / API Scanner</h1>
              <Badge className="bg-emerald-600 text-white text-[10px] px-2 py-0.5">AI-POWERED</Badge>
            </div>
            <p className="text-sm text-gray-400">
              Playwright-based AI agent engine for automated web security auditing
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowProviderSettings(true)}
            className="border-gray-700 text-gray-400 hover:text-white gap-2"
          >
            <Settings2 size={14} />
            AI Provider
            {providerConfig && (
              <Badge className="bg-emerald-900/30 text-emerald-400 border-0 text-[9px] ml-1">
                {providerConfig.name}
              </Badge>
            )}
          </Button>
        </div>

        {/* ── Scan Configuration Bar ─────────────────────────────────────── */}
        <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
          <div className="flex flex-col lg:flex-row gap-3">
            {/* Target URL */}
            <div className="flex-1">
              <label className="text-xs text-gray-500 mb-1.5 block">Target URL</label>
              <Input
                value={targetUrl}
                onChange={e => setTargetUrl(e.target.value)}
                placeholder="https://example.com"
                className="bg-cdm-dark border-gray-700 text-white h-10"
                onKeyDown={e => { if (e.key === 'Enter' && !isScanning) handleStartScan(); }}
              />
            </div>

            {/* Scan Type */}
            <div className="w-36">
              <label className="text-xs text-gray-500 mb-1.5 block">Scan Type</label>
              <Select value={scanType} onValueChange={setScanType}>
                <SelectTrigger className="bg-cdm-dark border-gray-700 text-gray-300 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700 text-gray-300">
                  <SelectItem value="full">Full Scan</SelectItem>
                  <SelectItem value="quick">Quick Scan</SelectItem>
                  <SelectItem value="api">API Only</SelectItem>
                  <SelectItem value="passive">Passive</SelectItem>
                  <SelectItem value="authenticated">Authenticated</SelectItem>
                  <SelectItem value="ai_only">AI Only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Agent Selector — Dynamic from AI Agents module */}
            <div className="w-52">
              <label className="text-xs text-gray-500 mb-1.5 block flex items-center gap-1">
                <Bot size={12} />
                AI Agent / Skill
              </label>
              <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                <SelectTrigger className="bg-cdm-dark border-gray-700 text-gray-300 h-10">
                  <SelectValue placeholder="Select agent..." />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700 text-gray-300">
                  <SelectItem value="none">No Agent (Rule-based only)</SelectItem>
                  {availableAgents.map(agent => (
                    <SelectItem key={agent.id} value={agent.id}>
                      {agent.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Start / Cancel button */}
            <div className="flex items-end">
              {isScanning ? (
                <Button
                  onClick={handleCancelScan}
                  className="bg-gray-700 hover:bg-gray-600 text-white gap-2 h-10 px-6"
                >
                  <Square size={14} />
                  STOP
                </Button>
              ) : (
                <Button
                  onClick={handleStartScan}
                  disabled={!targetUrl.trim()}
                  className="bg-red-600 hover:bg-red-700 text-white gap-2 h-10 px-6"
                >
                  <Play size={14} />
                  START SCAN
                </Button>
              )}
            </div>
          </div>

          {/* Advanced options toggle */}
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center gap-1 text-[10px] text-gray-600 hover:text-gray-400 mt-3 transition-colors"
          >
            <ChevronRight size={10} className={`transition-transform ${showAdvanced ? 'rotate-90' : ''}`} />
            Advanced options
          </button>

          {showAdvanced && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3 pt-3 border-t border-gray-800/50">
              <div>
                <label className="text-[10px] text-gray-500 mb-1 block">Max Depth</label>
                <Input
                  type="number"
                  min={1}
                  max={10}
                  value={maxDepth}
                  onChange={e => setMaxDepth(Number(e.target.value))}
                  className="bg-cdm-dark border-gray-700 text-white h-8 text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] text-gray-500 mb-1 block">Max Pages</label>
                <Input
                  type="number"
                  min={1}
                  max={500}
                  value={maxPages}
                  onChange={e => setMaxPages(Number(e.target.value))}
                  className="bg-cdm-dark border-gray-700 text-white h-8 text-xs"
                />
              </div>
              <div className="col-span-2">
                <label className="text-[10px] text-gray-500 mb-1 block">AI Provider</label>
                <div className="flex items-center gap-2">
                  {providerConfig ? (
                    <div className="flex items-center gap-2 bg-cdm-dark rounded-md border border-gray-700 px-3 py-1.5 flex-1">
                      <Zap size={12} className="text-emerald-400" />
                      <span className="text-xs text-gray-300">{providerConfig.name} / {providerConfig.model}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 bg-cdm-dark rounded-md border border-gray-700 px-3 py-1.5 flex-1">
                      <AlertTriangle size={12} className="text-amber-500" />
                      <span className="text-xs text-gray-500">No AI provider configured</span>
                    </div>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowProviderSettings(true)}
                    className="border-gray-700 text-gray-400 h-8 text-[10px]"
                  >
                    Configure
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Agent requires provider warning */}
          {selectedAgent !== 'none' && !providerConfig && (
            <div className="flex items-center gap-2 mt-3 px-3 py-2 rounded-md bg-amber-900/10 border border-amber-500/20">
              <AlertTriangle size={12} className="text-amber-400 flex-shrink-0" />
              <span className="text-[11px] text-amber-400">
                AI agent selected but no provider configured. The scan will run rule-based checks only.{' '}
                <button onClick={() => setShowProviderSettings(true)} className="underline hover:no-underline">
                  Configure provider
                </button>
              </span>
            </div>
          )}
        </div>

        {/* Agent Execution Metrics — shown while scan is active or just completed with an agent */}
        {(isScanning || scanStatus === 'completed') && selectedAgent !== 'none' && (() => {
          const agentInfo = availableAgents.find(a => a.id === selectedAgent);
          return (
            <div className="flex items-center gap-6 px-4 py-2.5 bg-cdm-darker rounded-lg border border-gray-800 text-sm">
              <span className="text-gray-500 text-[10px] uppercase tracking-widest font-semibold">Agent Metrics</span>
              <div className="flex items-center gap-6">
                <span className="text-gray-400 text-xs">
                  TOTAL AGENTS <span className="text-white font-mono font-bold ml-1.5">{availableAgents.length}</span>
                </span>
                <span className="text-gray-400 text-xs flex items-center gap-1.5">
                  IN EXECUTION
                  {isScanning ? (
                    <span className="flex items-center gap-1 ml-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                      <span className="text-blue-400 font-mono font-bold">{agentInfo?.name || selectedAgent}</span>
                    </span>
                  ) : (
                    <span className="text-gray-600 font-mono font-bold ml-1.5">—</span>
                  )}
                </span>
                <span className="text-gray-400 text-xs">
                  FINDINGS <span className="text-amber-400 font-mono font-bold ml-1.5">{findingsFound}</span>
                </span>
                <span className="text-gray-400 text-xs">
                  TASKS COMPLETED <span className="text-emerald-400 font-mono font-bold ml-1.5">{tasksCompleted}</span>
                </span>
              </div>
            </div>
          );
        })()}

        {/* ── Main Tabs ──────────────────────────────────────────────────── */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex items-center justify-between">
            <TabsList className="bg-cdm-darker border border-gray-800">
              <TabsTrigger value="live" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400 gap-1.5">
                <Monitor size={12} />
                Live View
                {isScanning && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />}
              </TabsTrigger>
              <TabsTrigger value="findings" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400 gap-1.5">
                <Shield size={12} />
                Findings
                {findings.length > 0 && (
                  <Badge className="bg-red-600 text-white text-[10px] px-1.5 py-0">{findings.length}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="tools" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400 gap-1.5">
                <Wrench size={12} />
                Tool Calls
                {toolCalls.length > 0 && (
                  <Badge className="bg-cyan-700 text-white text-[10px] px-1.5 py-0">{toolCalls.length}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="history" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400 gap-1.5">
                <Clock size={12} />
                History
                {history.length > 0 && (
                  <Badge className="ml-1 bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{history.length}</Badge>
                )}
              </TabsTrigger>
            </TabsList>

            {(findings.length > 0 || terminalLines.length > 0) && scanStatus !== 'idle' && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5"
              >
                <Download size={14} />
                Export .md
              </Button>
            )}
          </div>

          {/* ── LIVE VIEW TAB ──────────────────────────────────────────── */}
          <TabsContent value="live" className="mt-4 space-y-4">
            {/* Status bar */}
            {scanStatus !== 'idle' && (
              <div className={`flex items-center gap-3 px-4 py-2.5 rounded-lg border ${
                scanStatus === 'completed' ? 'bg-emerald-900/10 border-emerald-500/20' :
                scanStatus === 'error' ? 'bg-red-900/10 border-red-500/20' :
                scanStatus === 'cancelled' ? 'bg-gray-800 border-gray-700' :
                'bg-cyan-900/10 border-cyan-500/20'
              }`}>
                {isScanning && <div className="w-2.5 h-2.5 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />}
                {scanStatus === 'completed' && <Shield size={14} className="text-emerald-400" />}
                {scanStatus === 'error' && <AlertTriangle size={14} className="text-red-400" />}
                <span className={`text-xs font-medium ${
                  isScanning ? 'text-cyan-400' :
                  scanStatus === 'completed' ? 'text-emerald-400' :
                  scanStatus === 'error' ? 'text-red-400' : 'text-gray-400'
                }`}>
                  {scanStatus === 'connecting' && 'Connecting to target...'}
                  {scanStatus === 'crawling' && 'Crawling pages...'}
                  {scanStatus === 'auditing' && 'Running security audit...'}
                  {scanStatus === 'completed' && `Scan complete — ${findings.length} finding(s)`}
                  {scanStatus === 'error' && 'Scan encountered an error'}
                  {scanStatus === 'cancelled' && 'Scan cancelled'}
                </span>
                {findings.length > 0 && isScanning && (
                  <Badge className="bg-red-600 text-white text-[10px] px-1.5 py-0 ml-auto">
                    {findings.length} findings
                  </Badge>
                )}
              </div>
            )}

            {/* Browser + Terminal split */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              {/* Browser overlay */}
              <BrowserOverlay
                screenshotBase64={screenshotB64}
                currentUrl={currentUrl}
                pageTitle={pageTitle}
                isNavigating={isNavigating}
                isRunning={isScanning}
              />

              {/* Terminal log */}
              <ScanTerminal
                lines={terminalLines}
                isRunning={isScanning}
              />
            </div>

            {/* Live findings preview */}
            {findings.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xs uppercase tracking-wider text-gray-500">Live Findings ({findings.length})</h3>
                  <button
                    onClick={() => setActiveTab('findings')}
                    className="text-[10px] text-red-400 hover:text-red-300"
                  >
                    View all →
                  </button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  {(['critical', 'high', 'medium', 'low', 'info'] as const).map(sev => {
                    const count = findings.filter(f => f.severity === sev).length;
                    return (
                      <div key={sev} className={`rounded-lg border p-3 ${SEVERITY_COLORS[sev].bg} ${SEVERITY_COLORS[sev].border}`}>
                        <div className={`text-2xl font-bold ${SEVERITY_COLORS[sev].text}`}>{count}</div>
                        <div className={`text-[10px] capitalize ${SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Empty state */}
            {scanStatus === 'idle' && (
              <div className="flex flex-col items-center justify-center py-16 bg-cdm-darker rounded-lg border border-gray-800">
                <Globe size={40} className="text-gray-700 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Ready to scan</h3>
                <p className="text-sm text-gray-500 mb-1">Enter a target URL and start a scan to see live browser interactions</p>
                <p className="text-xs text-gray-600">The Playwright browser engine will crawl and audit the target in real-time</p>
              </div>
            )}
          </TabsContent>

          {/* ── FINDINGS TAB ───────────────────────────────────────────── */}
          <TabsContent value="findings" className="mt-4">
            <FindingsPanel findings={findings} />
          </TabsContent>

          {/* ── TOOL CALLS TAB ─────────────────────────────────────────── */}
          <TabsContent value="tools" className="mt-4">
            <ToolCallsPanel toolCalls={toolCalls} />
          </TabsContent>

          {/* ── HISTORY TAB ────────────────────────────────────────────── */}
          <TabsContent value="history" className="mt-4 space-y-4">
            {/* History toolbar */}
            <div className="flex items-center gap-3">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <Input
                  value={historySearch}
                  onChange={e => setHistorySearch(e.target.value)}
                  placeholder="Search URL, type, or agent..."
                  className="bg-cdm-dark border-gray-700 text-white h-9 pl-9 text-xs"
                />
              </div>
              <Button
                variant="outline" size="sm"
                onClick={() => setHistorySortAsc(!historySortAsc)}
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5 h-9"
              >
                <ArrowUpDown size={12} />
                {historySortAsc ? 'Oldest first' : 'Newest first'}
              </Button>
              {compareSelection.length === 2 && (
                <Button
                  size="sm" onClick={() => setShowCompare(true)}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white gap-1.5 h-9"
                >
                  <GitCompare size={12} />
                  Compare ({compareSelection.length})
                </Button>
              )}
              {compareSelection.length === 1 && (
                <span className="text-xs text-gray-500">Select 1 more scan to compare</span>
              )}
              <Button
                variant="outline" size="sm"
                className="border-gray-700 text-gray-400 hover:text-white gap-1.5 h-9 ml-auto"
              >
                <FileDown size={12} />
                Export All
              </Button>
            </div>

            {/* History list */}
            {filteredHistory.length > 0 ? (
              <div className="bg-cdm-darker rounded-lg border border-gray-800 overflow-hidden">
                <div className="divide-y divide-gray-800">
                  {filteredHistory.map(scan => {
                    const isExpanded = expandedHistory === scan.id;
                    const isSelected = compareSelection.includes(scan.id);
                    const statusColor = scan.status === 'completed'
                      ? 'bg-emerald-900/30 text-emerald-400'
                      : scan.status === 'error'
                        ? 'bg-red-900/30 text-red-400'
                        : 'bg-amber-900/30 text-amber-400';

                    return (
                      <div key={scan.id} className={`${isSelected ? 'bg-cyan-900/10 border-l-2 border-l-cyan-500' : ''}`}>
                        <div className="flex items-center gap-3 p-4 hover:bg-white/[0.01] transition-colors">
                          <button
                            onClick={() => toggleCompareSelect(scan.id)}
                            className={`w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
                              isSelected ? 'bg-cyan-600 border-cyan-600' : 'border-gray-600 hover:border-gray-400'
                            }`}
                          >
                            {isSelected && <span className="text-white text-[8px] font-bold">{compareSelection.indexOf(scan.id) + 1}</span>}
                          </button>

                          <Globe size={16} className="text-gray-500 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm text-white font-medium truncate">{scan.url}</p>
                              <Badge variant="outline" className="border-gray-700 text-gray-500 text-[9px] flex-shrink-0">
                                {scan.scanType}
                              </Badge>
                              {scan.agent !== 'None' && (
                                <Badge className="bg-purple-900/30 text-purple-400 border-0 text-[9px] flex-shrink-0">
                                  <Bot size={9} className="mr-0.5" />
                                  {scan.agent}
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-3 mt-1">
                              <span className="text-[11px] text-gray-500">{scan.date}</span>
                              <span className="text-[11px] text-gray-600">|</span>
                              <span className="text-[11px] text-gray-500">{scan.duration}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 flex-shrink-0">
                            {scan.severities.critical > 0 && (
                              <span className="text-[10px] font-bold bg-red-900/40 text-red-400 px-1.5 py-0.5 rounded">{scan.severities.critical}C</span>
                            )}
                            {scan.severities.high > 0 && (
                              <span className="text-[10px] font-bold bg-orange-900/40 text-orange-400 px-1.5 py-0.5 rounded">{scan.severities.high}H</span>
                            )}
                            {scan.severities.medium > 0 && (
                              <span className="text-[10px] font-bold bg-amber-900/40 text-amber-400 px-1.5 py-0.5 rounded">{scan.severities.medium}M</span>
                            )}
                            {scan.severities.low > 0 && (
                              <span className="text-[10px] font-bold bg-blue-900/40 text-blue-400 px-1.5 py-0.5 rounded">{scan.severities.low}L</span>
                            )}
                            {scan.findings === 0 && scan.status === 'completed' && (
                              <span className="text-[10px] text-emerald-400 bg-emerald-900/30 px-1.5 py-0.5 rounded">Clean</span>
                            )}
                          </div>

                          <Badge className={`${statusColor} border-0 text-[10px] flex-shrink-0`}>
                            {scan.status === 'completed' ? 'Completed' : scan.status === 'error' ? 'Failed' : 'In Progress'}
                          </Badge>

                          <div className="flex items-center gap-1 flex-shrink-0">
                            <Button
                              variant="ghost"
                              size="sm"
                              disabled={isScanning}
                              onClick={() => {
                                const opening = expandedHistory !== scan.id;
                                setExpandedHistory(opening ? scan.id : null);
                                if (opening) {
                                  setFindings(sortBySeverity(scan.vulnerabilities || []));
                                  setFindingsFound((scan.vulnerabilities || []).length);
                                  setToolCalls(scan.toolCalls || []);
                                  setTerminalLines(scan.terminalLines || []);
                                }
                              }}
                              className="text-gray-500 hover:text-white h-7 w-7 p-0"
                              title={isScanning ? 'Unavailable during active scan' : 'View details'}
                            >
                              {isScanning ? <EyeOff size={13} /> : <Eye size={13} />}
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleRescan(scan)} className="text-gray-500 hover:text-cyan-400 h-7 w-7 p-0" title="Re-scan">
                              <RotateCw size={13} />
                            </Button>
                            {deleteConfirm === scan.id ? (
                              <div className="flex items-center gap-1">
                                <Button size="sm" onClick={() => handleDeleteHistory(scan.id)} className="bg-red-600 hover:bg-red-700 text-white h-7 px-2 text-[10px]">Confirm</Button>
                                <Button variant="ghost" size="sm" onClick={() => setDeleteConfirm(null)} className="text-gray-400 h-7 w-7 p-0"><X size={12} /></Button>
                              </div>
                            ) : (
                              <Button variant="ghost" size="sm" onClick={() => setDeleteConfirm(scan.id)} className="text-gray-500 hover:text-red-400 h-7 w-7 p-0" title="Delete">
                                <Trash2 size={13} />
                              </Button>
                            )}
                          </div>
                        </div>

                        {isExpanded && (
                          <div className="px-4 pb-4 pt-1 border-t border-gray-800/50 ml-[52px]">
                            {/* Severity grid */}
                            <div className="grid grid-cols-5 gap-2 mb-3">
                              {(['critical', 'high', 'medium', 'low', 'info'] as const).map(sev => (
                                <div key={sev} className={`rounded border p-2 ${SEVERITY_COLORS[sev].bg} ${SEVERITY_COLORS[sev].border}`}>
                                  <div className={`text-lg font-bold ${SEVERITY_COLORS[sev].text}`}>{scan.severities[sev] || 0}</div>
                                  <div className={`text-[10px] capitalize ${SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                                </div>
                              ))}
                            </div>

                            {/* All findings */}
                            {scan.vulnerabilities && scan.vulnerabilities.length > 0 && (
                              <div className="mb-3">
                                <h5 className="text-xs font-semibold text-gray-400 mb-1.5">
                                  All Findings ({scan.vulnerabilities.length})
                                </h5>
                                <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                                  {sortBySeverity(scan.vulnerabilities).map(v => (
                                    <div key={v.id} className="flex items-center gap-2 text-xs">
                                      <Badge className={`${SEVERITY_COLORS[v.severity].bg} ${SEVERITY_COLORS[v.severity].text} border-0 text-[9px] px-1.5 uppercase w-16 justify-center flex-shrink-0`}>
                                        {v.severity}
                                      </Badge>
                                      <span className="text-gray-300 truncate flex-1">{v.title}</span>
                                      <span className="text-gray-600 font-mono text-[10px] flex-shrink-0 truncate max-w-[140px]">{v.endpoint}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {scan.findings === 0 && scan.status === 'completed' && (
                              <p className="text-xs text-emerald-400 mb-3">No vulnerabilities found — target appears clean.</p>
                            )}
                            {scan.status === 'error' && (
                              <p className="text-xs text-red-400 mb-3">Scan failed — target may be unreachable or returned an unexpected response.</p>
                            )}

                            {/* Navigation buttons */}
                            {scan.status === 'completed' && (
                              <div className="flex items-center gap-2 pt-2 border-t border-gray-800/50">
                                <Button
                                  size="sm"
                                  onClick={() => setActiveTab('findings')}
                                  className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs"
                                >
                                  View Findings
                                </Button>
                                {(scan.toolCalls?.length ?? 0) > 0 && (
                                  <Button
                                    size="sm"
                                    onClick={() => setActiveTab('tools')}
                                    className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs gap-1"
                                  >
                                    <Wrench size={11} />
                                    Tool Calls
                                  </Button>
                                )}
                                {(scan.terminalLines?.length ?? 0) > 0 && (
                                  <Button
                                    size="sm"
                                    onClick={() => setActiveTab('live')}
                                    className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 h-7 text-xs gap-1"
                                  >
                                    <Monitor size={11} />
                                    View Logs
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 bg-cdm-darker rounded-lg border border-gray-800">
                <Clock size={40} className="text-gray-700 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No scan history</h3>
                <p className="text-sm text-gray-500">
                  {historySearch ? 'No scans match your search' : 'Completed scans will appear here'}
                </p>
              </div>
            )}
          </TabsContent>

          {/* ── COMPARE MODAL ──────────────────────────────────────────── */}
          {showCompare && compareItems.length === 2 && (
            <div className="fixed inset-0 z-50 flex items-center justify-center">
              <div className="fixed inset-0 bg-black/70" onClick={() => setShowCompare(false)} />
              <div className="relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-3xl max-h-[80vh] overflow-hidden flex flex-col m-4">
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
                  <div>
                    <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                      <GitCompare size={18} className="text-cyan-400" />
                      Scan Comparison
                    </h2>
                    <p className="text-xs text-gray-500 mt-0.5">Side-by-side comparison of two scan runs</p>
                  </div>
                  <button onClick={() => setShowCompare(false)} className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white transition-colors">
                    <X size={18} />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-6">
                  <div className="grid grid-cols-2 gap-6">
                    {compareItems.map((item, idx) => (
                      <div key={item.id} className="space-y-4">
                        <div className="text-center">
                          <Badge className={`${idx === 0 ? 'bg-cyan-900/30 text-cyan-400' : 'bg-purple-900/30 text-purple-400'} border-0 text-xs mb-2`}>
                            Scan {idx + 1}
                          </Badge>
                          <p className="text-sm text-white font-medium truncate">{item.url}</p>
                          <p className="text-[11px] text-gray-500">{item.date} · {item.duration}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {(['critical', 'high', 'medium', 'low'] as const).map(sev => {
                            const other = compareItems[1 - idx];
                            const diff = (item.severities[sev] || 0) - (other.severities[sev] || 0);
                            return (
                              <div key={sev} className={`rounded border p-2 ${SEVERITY_COLORS[sev].bg} ${SEVERITY_COLORS[sev].border}`}>
                                <div className="flex items-baseline gap-1.5">
                                  <span className={`text-xl font-bold ${SEVERITY_COLORS[sev].text}`}>{item.severities[sev] || 0}</span>
                                  {diff !== 0 && (
                                    <span className={`text-[10px] font-bold ${diff > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                                      {diff > 0 ? `+${diff}` : diff}
                                    </span>
                                  )}
                                </div>
                                <div className={`text-[10px] capitalize ${SEVERITY_COLORS[sev].text} opacity-80`}>{sev}</div>
                              </div>
                            );
                          })}
                        </div>
                        <div className="text-center">
                          <span className="text-2xl font-bold text-white">{item.findings}</span>
                          <span className="text-xs text-gray-500 ml-1.5">total findings</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </Tabs>
      </div>

      {/* ── Provider Settings Modal ──────────────────────────────────────── */}
      <ProviderSettings
        open={showProviderSettings}
        onClose={() => setShowProviderSettings(false)}
        onSave={(config) => setProviderConfig(config)}
      />
    </PageContainer>
  );
};

export default WebScan;
