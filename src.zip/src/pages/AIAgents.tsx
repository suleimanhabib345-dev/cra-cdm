import React, { useState, useEffect, useCallback } from 'react';
import {
  Bot, Plus, Search, AlertCircle, CheckCircle2,
  Shield, Crosshair, FileSearch, Bug, Cpu, Zap, Settings2,
  ChevronRight, X, Trash2, Pencil, Save, Cloud, Network,
  Lock, Loader2, RefreshCw,
} from 'lucide-react';
import PageContainer from '@/components/PageContainer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { fetchAgentContent } from '@/services/cloudscanService';
import { getWebScanStatus } from '@/services/webscanService';

type AgentStatus = 'idle' | 'executing' | 'inactive' | 'error';
type AgentScope = 'web' | 'ad' | 'cloud';

export interface AIAgent {
  id: string;
  name: string;
  description: string;
  status: AgentStatus;
  type: string;
  scope: AgentScope;
  tasksCompleted: number;
  successRate: number;
  lastRun: string;
  capabilities: string[];
  instructions: string;
  isTemplate?: boolean; // SCOPE built-in templates
}

// Storage keys per scope — each tab has independent persistence
export const AGENT_STORAGE_KEY = 'cra_ai_agents'; // web (legacy compat)
const AGENT_STORAGE_KEYS: Record<AgentScope, string> = {
  web: 'cra_ai_agents_web',
  ad: 'cra_ai_agents_ad',
  cloud: 'cra_ai_agents_cloud',
};

// ---------------------------------------------------------------------------
// Web templates (existing)
// ---------------------------------------------------------------------------

const WEB_TEMPLATES: Omit<AIAgent, 'tasksCompleted' | 'successRate' | 'lastRun' | 'status' | 'scope'>[] = [
  {
    id: 'red-team',
    name: 'Red Team Agent',
    description: 'Offensive security operations, penetration testing, and attack simulation',
    type: 'red-team',
    capabilities: ['XSS', 'SQLi', 'RCE', 'Auth Bypass', 'Priv Esc'],
    instructions:
      'You are a red team operator. Focus on finding authentication bypasses, privilege escalation, remote code execution, and critical injection vulnerabilities. Attempt to chain findings into full exploitation paths. Prioritise impact over stealth.',
  },
  {
    id: 'blue-team',
    name: 'Blue Team Agent',
    description: 'Defensive security, threat detection, and incident mitigation',
    type: 'blue-team',
    capabilities: ['Header Auditing', 'Data Exposure', 'Hardening', 'Detection Rules'],
    instructions:
      'You are a defensive security analyst. Document all findings with detection guidance, log sources, and recommended mitigations. Focus on security header gaps, data exposure, and hardening opportunities.',
  },
  {
    id: 'dfir',
    name: 'DFIR Analyst',
    description: 'Digital forensics and incident response investigations',
    type: 'dfir',
    capabilities: ['IOC Detection', 'Log Analysis', 'Credential Exposure', 'Forensics'],
    instructions:
      'You are a DFIR analyst. Look for indicators of compromise, exposed credentials, sensitive data leakage, and server-side information disclosure. Provide artifact-level evidence for every finding.',
  },
  {
    id: 'bug-bounty',
    name: 'Bug Bounty Hunter',
    description: 'Vulnerability research and bug hunting operations',
    type: 'bug-bounty',
    capabilities: ['XSS', 'SSRF', 'SQLi', 'IDOR', 'Open Redirect'],
    instructions:
      'You are a bug bounty hunter. Focus on high-impact, reproducible findings: XSS, SSRF, SQLi, IDOR, broken auth. Provide clear proof-of-concept evidence and CVSS scores for each finding.',
  },
];

// ---------------------------------------------------------------------------
// AD templates
// ---------------------------------------------------------------------------

const AD_TEMPLATES: Omit<AIAgent, 'tasksCompleted' | 'successRate' | 'lastRun' | 'status' | 'scope'>[] = [
  {
    id: 'ad-auditor',
    name: 'AD Auditor',
    description: 'Active Directory security posture assessment and misconfiguration detection',
    type: 'audit',
    capabilities: ['ACL Analysis', 'Delegation', 'GPO Review', 'Password Policy'],
    instructions:
      'You are an Active Directory security auditor. Identify dangerous delegation settings, misconfigured ACLs, weak password policies, and Kerberoastable service accounts. Map all paths to Domain Admin.',
  },
  {
    id: 'ad-red-team',
    name: 'AD Red Team',
    description: 'Active Directory attack path exploitation and lateral movement',
    type: 'red-team',
    capabilities: ['BloodHound Paths', 'Kerberoast', 'AS-REP Roast', 'DCSync', 'Pass-the-Hash'],
    instructions:
      'You are an AD penetration tester. Find shortest paths to Domain Admin via BloodHound-style analysis. Identify Kerberoastable accounts, AS-REP roasting targets, unconstrained delegation, and DCSync rights. Chain findings into full attack paths.',
  },
];

// ---------------------------------------------------------------------------
// SCOPE Cloud agent templates
// instructions: backend loads the real .md file content at edit time.
// These descriptions/capabilities are accurate; the full system prompts live in
// docker/cloudscan/agents/*.md and are served by the backend /api/agents endpoint.
// ---------------------------------------------------------------------------

/** Strip YAML frontmatter (--- block) from a .md file string. */
function stripFrontmatter(md: string): string {
  if (!md.startsWith('---')) return md;
  const end = md.indexOf('\n---', 3);
  if (end === -1) return md;
  return md.slice(end + 4).replace(/^[\n]+/, '');
}

/** Replace residual SCOPE/scope- references in loaded agent content (Item 2). */
function renameScopeRefs(text: string): string {
  return text
    .replace(/\bscope-audit\b/g, 'cra-cl-audit')
    .replace(/\bscope-defend\b/g, 'cra-cl-defend')
    .replace(/\bscope-exploit\b/g, 'cra-cl-exploit')
    .replace(/\bscope-hunt\b/g, 'cra-cl-hunt')
    .replace(/\bscope-(enum-\w+|attack-paths|verify|pipeline)\b/g, 'cra-cl-$1')
    .replace(/\bSCOPE engine\b/g, 'DV-CLOUD engine')
    .replace(/\bSCOPE AI\b/g, 'DV-CLOUD AI')
    .replace(/\bSCOPE agents?\b/g, 'DV-CLOUD agent');
}

const CLOUD_SCOPE_TEMPLATES: Omit<AIAgent, 'tasksCompleted' | 'successRate' | 'lastRun' | 'status' | 'scope'>[] = [
  {
    id: 'cra-cl-audit',
    name: 'cra-cl-audit',
    description: 'DV-CLOUD audit orchestrator — single entry point for the full audit pipeline. Dispatches parallel enumeration subagents (12 modules), chains attack-paths reasoning, verification, defensive controls, data pipeline, and dashboard generation.',
    type: 'audit',
    capabilities: ['IAM', 'STS', 'S3', 'KMS', 'Secrets', 'Lambda', 'EC2', 'RDS', 'SNS', 'SQS', 'API GW', 'CodeBuild', 'Attack Paths', 'cra-cl-defend'],
    instructions: '[Loading from DV-CLOUD engine — click Edit to fetch full agent content]',
    isTemplate: true,
  },
  {
    id: 'cra-cl-defend',
    name: 'cra-cl-defend',
    description: 'Defensive controls generation — reads audit output and generates SCPs/RCPs, security controls, SPL detections, and prioritized remediation. Dispatched by the audit orchestrator after audit completes, or invoked directly by the operator.',
    type: 'blue-team',
    capabilities: ['SCP Generation', 'RCP Policies', 'SPL Detections', 'Config Rules', 'GuardDuty', 'Access Analyzer', 'MITRE ATT&CK'],
    instructions: '[Loading from DV-CLOUD engine — click Edit to fetch full agent content]',
    isTemplate: true,
  },
  {
    id: 'cra-cl-hunt',
    name: 'cra-cl-hunt',
    description: 'SOC alert investigation assistant. Guides analysts through CloudTrail-based alert investigation in Splunk — step-by-step guided queries, investigation timelines, and IOC correlation. Dual-mode: hunt (from audit run) or detection investigation (alert-driven).',
    type: 'dfir',
    capabilities: ['CloudTrail', 'Splunk SPL', 'Alert Investigation', 'IOC Correlation', 'Timeline Building', 'Hypothesis Generation'],
    instructions: '[Loading from DV-CLOUD engine — click Edit to fetch full agent content]',
    isTemplate: true,
  },
  {
    id: 'cra-cl-exploit',
    name: 'cra-cl-exploit',
    description: 'AWS privilege escalation policy generator, control circumvention advisor, and lateral movement planner. Given a principal ARN, produces a red team playbook with deployable IAM policy JSON and ready-to-execute CLI commands.',
    type: 'red-team',
    capabilities: ['PassRole', 'CreateAccessKey', 'AssumeRole', 'Lambda Escalation', 'IAM Abuse', 'CloudTrail Tags', 'Lateral Movement'],
    instructions: '[Loading from DV-CLOUD engine — click Edit to fetch full agent content]',
    isTemplate: true,
  },
];

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

const TEMPLATE_ICONS: Record<string, { icon: React.ReactNode; color: string; bg: string }> = {
  'red-team': { icon: <Crosshair size={20} />, color: 'text-red-400', bg: 'bg-red-900/20' },
  'blue-team': { icon: <Shield size={20} />, color: 'text-blue-400', bg: 'bg-blue-900/20' },
  dfir: { icon: <FileSearch size={20} />, color: 'text-purple-400', bg: 'bg-purple-900/20' },
  'bug-bounty': { icon: <Bug size={20} />, color: 'text-amber-400', bg: 'bg-amber-900/20' },
  audit: { icon: <Search size={20} />, color: 'text-cyan-400', bg: 'bg-cyan-900/20' },
  custom: { icon: <Settings2 size={20} />, color: 'text-gray-400', bg: 'bg-gray-800' },
};

const statusColors: Record<AgentStatus, string> = {
  idle: 'bg-gray-500',
  executing: 'bg-emerald-500 animate-pulse',
  inactive: 'bg-gray-600',
  error: 'bg-red-500',
};

const statusLabels: Record<AgentStatus, string> = {
  idle: 'Idle',
  executing: 'Executing',
  inactive: 'Inactive',
  error: 'Error',
};

function migrateAgentIds(agents: AIAgent[]): AIAgent[] {
  // Migrate old scope-* IDs to cra-cl-* (one-time rename)
  return agents.map(a => ({
    ...a,
    id: a.id.replace(/^scope-/, 'cra-cl-'),
    name: a.name.replace(/^scope-/, 'cra-cl-'),
  }));
}

function loadAgents(scope: AgentScope): AIAgent[] {
  try {
    const key = AGENT_STORAGE_KEYS[scope];
    const stored = localStorage.getItem(key);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return migrateAgentIds(parsed);
    }
    // Legacy compat: migrate old 'cra_ai_agents' into web scope
    if (scope === 'web') {
      const legacy = localStorage.getItem(AGENT_STORAGE_KEY);
      if (legacy) {
        const parsed = JSON.parse(legacy);
        if (Array.isArray(parsed) && parsed.length > 0) return migrateAgentIds(parsed);
      }
    }
  } catch { /* ignore */ }
  return [];
}

function saveAgents(scope: AgentScope, agents: AIAgent[]) {
  localStorage.setItem(AGENT_STORAGE_KEYS[scope], JSON.stringify(agents));
  if (scope === 'web') {
    localStorage.setItem(AGENT_STORAGE_KEY, JSON.stringify(agents));
  }
  window.dispatchEvent(new CustomEvent('cra-agents-changed'));
}

// ---------------------------------------------------------------------------
// AgentCard
// ---------------------------------------------------------------------------

interface AgentCardProps {
  agent: AIAgent;
  onEdit: (a: AIAgent) => void;
  onDelete: (id: string) => void;
  scope: AgentScope;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent, onEdit, onDelete, scope }) => {
  const tmpl = TEMPLATE_ICONS[agent.type] || TEMPLATE_ICONS.custom;
  const isCloudTemplate = scope === 'cloud' && agent.isTemplate;

  return (
    <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4 hover:border-gray-700 transition-colors group relative">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {tmpl && (
            <div className={`w-7 h-7 rounded-md ${tmpl.bg} flex items-center justify-center ${tmpl.color} flex-shrink-0`}>
              {React.cloneElement(tmpl.icon as React.ReactElement, { size: 14 })}
            </div>
          )}
          <span className="text-sm font-semibold text-white font-mono leading-tight truncate">{agent.name}</span>
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${statusColors[agent.status]}`} />
        </div>
        {/* Edit + Delete icons — always visible, no overlap with DV-CLOUD badge */}
        <div className="flex items-center gap-1 flex-shrink-0 ml-2">
          {isCloudTemplate && (
            <Badge className="bg-cyan-900/20 text-cyan-400 border-cyan-500/20 text-[9px] px-1.5 mr-1">DV-CLOUD</Badge>
          )}
          <button
            onClick={() => onEdit(agent)}
            className="p-1 rounded hover:bg-gray-700 text-gray-600 hover:text-blue-400 transition-colors"
            title="Edit agent"
          >
            <Pencil size={13} />
          </button>
          <button
            onClick={() => onDelete(agent.id)}
            className="p-1 rounded hover:bg-gray-700 text-gray-600 hover:text-red-400 transition-colors"
            title="Delete agent"
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>
      <p className="text-xs text-gray-500 mb-2 line-clamp-2 leading-relaxed">
        {agent.description}
      </p>
      {agent.capabilities.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-2">
          {agent.capabilities.slice(0, 4).map(cap => (
            <span key={cap} className="text-[9px] px-1.5 py-0.5 rounded bg-gray-800 text-gray-500 border border-gray-700">{cap}</span>
          ))}
          {agent.capabilities.length > 4 && (
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-gray-800 text-gray-600">+{agent.capabilities.length - 4}</span>
          )}
        </div>
      )}
      <div className="flex items-center justify-between text-[11px] text-gray-600">
        <span>{agent.tasksCompleted} tasks</span>
        <span>{agent.successRate}% success</span>
        <Badge variant="outline" className="text-[10px] border-gray-700 text-gray-500">
          {statusLabels[agent.status]}
        </Badge>
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// Per-scope agent panel
// ---------------------------------------------------------------------------

interface AgentPanelProps {
  scope: AgentScope;
  templates: Omit<AIAgent, 'tasksCompleted' | 'successRate' | 'lastRun' | 'status' | 'scope'>[];
  accentColor: string;
}

const AgentPanel: React.FC<AgentPanelProps> = ({ scope, templates, accentColor }) => {
  const [agents, setAgents] = useState<AIAgent[]>(() => loadAgents(scope));
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formType, setFormType] = useState('custom');
  const [formInstructions, setFormInstructions] = useState('');
  const [formCaps, setFormCaps] = useState('');
  const [loadingContent, setLoadingContent] = useState(false);
  const loadingTemplateRef = React.useRef<string | null>(null);

  useEffect(() => {
    saveAgents(scope, agents);
  }, [agents, scope]);

  const filteredAgents = agents.filter(a =>
    searchQuery === '' ||
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  /** For SCOPE Cloud agents, try to load full .md content from backend. */
  const loadScopeContent = useCallback(async (agentId: string, currentInstructions: string): Promise<string> => {
    if (scope !== 'cloud') return currentInstructions;
    setLoadingContent(true);
    try {
      const raw = await fetchAgentContent(agentId);
      if (raw) return renameScopeRefs(stripFrontmatter(raw));
    } catch { /* fall through */ }
    finally { setLoadingContent(false); }
    return currentInstructions;
  }, [scope]);

  const openCreate = () => {
    setEditingId(null);
    setFormName(''); setFormDesc(''); setFormType('custom');
    setFormInstructions(''); setFormCaps('');
    setShowCreateModal(true);
  };

  const openEdit = async (agent: AIAgent) => {
    setEditingId(agent.id);
    setFormName(agent.name);
    setFormDesc(agent.description);
    setFormType(agent.type);
    setFormCaps(agent.capabilities.join(', '));
    setShowCreateModal(true);
    // Load full content — for SCOPE agents fetch from backend; for others use stored value
    const instructions = await loadScopeContent(agent.id, agent.instructions || '');
    setFormInstructions(instructions);
    // If we fetched fresh content, update the stored agent so next open is instant
    if (instructions !== agent.instructions && agent.instructions?.startsWith('[Loading')) {
      setAgents(prev => prev.map(a => a.id === agent.id ? { ...a, instructions } : a));
    }
  };

  const handleSave = () => {
    if (!formName.trim()) return;
    const caps = formCaps.split(',').map(c => c.trim()).filter(Boolean);
    if (editingId) {
      setAgents(prev =>
        prev.map(a => a.id === editingId
          ? { ...a, name: formName, description: formDesc, type: formType, instructions: formInstructions, capabilities: caps }
          : a
        )
      );
    } else {
      // Prevent duplicate: if an agent with the same name already exists, just edit it (Item 3)
      const duplicate = agents.find(a => a.name.toLowerCase() === formName.trim().toLowerCase());
      if (duplicate) {
        setAgents(prev =>
          prev.map(a => a.id === duplicate.id
            ? { ...a, description: formDesc, type: formType, instructions: formInstructions, capabilities: caps }
            : a
          )
        );
        setShowCreateModal(false);
        return;
      }
      const agent: AIAgent = {
        id: `agent-${Date.now()}`,
        name: formName,
        description: formDesc || 'Custom AI agent',
        status: 'idle',
        type: formType,
        scope,
        tasksCompleted: 0,
        successRate: 100,
        lastRun: 'Never',
        capabilities: caps,
        instructions: formInstructions,
      };
      setAgents(prev => [...prev, agent]);
    }
    setShowCreateModal(false);
  };

  const handleFromTemplate = async (template: typeof templates[0]) => {
    // Lock: ignore rapid multi-clicks while a fetch is in progress
    if (loadingTemplateRef.current !== null) return;

    // Check both in-memory state and localStorage before adding
    const existing = agents.find(a => a.id === template.id)
      ?? loadAgents(scope).find(a => a.id === template.id);
    if (existing) {
      if (!agents.some(a => a.id === existing.id)) {
        setAgents(prev => [...prev, existing]);
      }
      openEdit(existing);
      return;
    }

    // For SCOPE templates: fetch real content; lock prevents concurrent adds
    let instructions = template.instructions || '';
    if (scope === 'cloud' && template.isTemplate) {
      loadingTemplateRef.current = template.id;
      setLoadingContent(true);
      try {
        const raw = await fetchAgentContent(template.id);
        if (raw) instructions = renameScopeRefs(stripFrontmatter(raw));
      } catch { /* keep placeholder */ }
      finally {
        setLoadingContent(false);
        loadingTemplateRef.current = null;
      }
    }

    const agent: AIAgent = {
      ...template,
      instructions,
      scope,
      status: 'idle',
      tasksCompleted: 0,
      successRate: 100,
      lastRun: 'Never',
    };
    // Functional updater guarantees dedup even if two near-simultaneous calls both pass the check above
    setAgents(prev => prev.some(a => a.id === agent.id) ? prev : [...prev, agent]);
  };

  const handleDelete = (id: string) => {
    setAgents(prev => prev.filter(a => a.id !== id));
  };

  const scopeLabel = scope === 'web' ? 'WebScan' : scope === 'ad' ? 'ADScan' : 'CloudScan';

  return (
    <div className="space-y-5 mt-4">
      {/* Search + New */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <Input
            placeholder={`Search ${scopeLabel} agents...`}
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="bg-cdm-darker border-gray-700 text-gray-300 pl-9 h-9"
          />
        </div>
        <Button
          onClick={openCreate}
          className={`${accentColor} text-white gap-2 ml-auto`}
          size="sm"
        >
          <Plus size={14} />
          NEW AGENT
        </Button>
      </div>

      {/* Agent list */}
      <div>
        <h2 className="text-xs uppercase tracking-wider text-gray-500 mb-3">
          Your Agents ({filteredAgents.length})
        </h2>

        {filteredAgents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 bg-cdm-darker rounded-lg border border-gray-800">
            <div className="w-14 h-14 rounded-2xl bg-gray-800 flex items-center justify-center mb-3">
              <Bot size={24} className="text-gray-600" />
            </div>
            <h3 className="text-base font-semibold text-white mb-1">
              {agents.length === 0 ? 'No agents yet' : 'No matching agents'}
            </h3>
            <p className="text-xs text-gray-500 mb-4">
              {agents.length === 0
                ? `Create an agent or add one from the ${scopeLabel} templates below`
                : 'Try adjusting your search'}
            </p>
            {agents.length === 0 && (
              <Button onClick={openCreate} className={`${accentColor} text-white gap-2`} size="sm">
                <Plus size={14} />
                CREATE AGENT
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAgents.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                onEdit={openEdit}
                onDelete={handleDelete}
                scope={scope}
              />
            ))}
            <button
              onClick={openCreate}
              className="bg-cdm-darker rounded-lg border border-dashed border-gray-700 p-4 flex flex-col items-center justify-center gap-2 hover:border-gray-600 hover:bg-gray-900/5 transition-all min-h-[140px]"
            >
              <Plus size={20} className="text-gray-600" />
              <span className="text-xs text-gray-500">Create Agent</span>
            </button>
          </div>
        )}
      </div>

      {/* Templates */}
      {templates.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xs uppercase tracking-wider text-gray-500">
              {scope === 'cloud' ? 'DV-CLOUD Agent Templates' : 'Quick Start Templates'}
            </h2>
            {scope === 'cloud' && (
              <Badge className="bg-cyan-900/20 text-cyan-400 border-cyan-500/20 text-[9px] px-2">
                DV-CLOUD — AWS Purple Team Engine
              </Badge>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {templates.map(template => {
              const tmpl = TEMPLATE_ICONS[template.type] || TEMPLATE_ICONS.custom;
              // Check both in-memory state and localStorage so checkmark is correct
              // even when agents were added by CloudScan auto-sync without navigating here
              const alreadyAdded = agents.some(a => a.id === template.id)
                || loadAgents(scope).some(a => a.id === template.id);
              return (
                <button
                  key={template.id}
                  onClick={() => handleFromTemplate(template)}
                  disabled={loadingContent}
                  className="bg-cdm-darker rounded-lg border border-gray-800 p-4 text-left hover:border-gray-700 transition-all group disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 rounded-lg ${tmpl.bg} flex items-center justify-center ${tmpl.color}`}>
                      {tmpl.icon}
                    </div>
                    {alreadyAdded ? (
                      <CheckCircle2 size={14} className="text-emerald-500" />
                    ) : (
                      <ChevronRight size={14} className="text-gray-700 group-hover:text-gray-400 transition-colors" />
                    )}
                  </div>
                  <h3 className="text-sm font-semibold text-white mb-1 font-mono">{template.name}</h3>
                  <p className="text-[11px] text-gray-500 leading-relaxed line-clamp-2">{template.description}</p>
                </button>
              );
            })}
          </div>
          {scope === 'cloud' && (
            <p className="text-[10px] text-gray-600 mt-2">
              DV-CLOUD templates contain the real agent instructions from the DV-CLOUD security engine. Click to add to your agents — editing opens the full instruction set.
              Subagents (cra-cl-enum-iam, cra-cl-enum-s3, etc.) run in the background during CloudScan and are not listed here.
            </p>
          )}
        </div>
      )}

      {/* Create / Edit Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70" onClick={() => setShowCreateModal(false)} />
          <div className="relative bg-cdm-darker border border-gray-700 rounded-xl w-full max-w-lg overflow-hidden m-4">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
              <h2 className="text-lg font-semibold text-white">
                {editingId ? 'Edit Agent' : `Create ${scopeLabel} Agent`}
              </h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Agent Name *</label>
                <Input
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="e.g., cra-cl-audit"
                  className="bg-cdm-dark border-gray-700 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Description</label>
                <Input
                  value={formDesc}
                  onChange={e => setFormDesc(e.target.value)}
                  placeholder="What does this agent do?"
                  className="bg-cdm-dark border-gray-700 text-white"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Agent Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'red-team', label: 'Red Team', icon: <Crosshair size={13} /> },
                    { id: 'blue-team', label: 'Blue Team', icon: <Shield size={13} /> },
                    { id: 'bug-bounty', label: 'Bug Bounty', icon: <Bug size={13} /> },
                    { id: 'dfir', label: 'DFIR', icon: <FileSearch size={13} /> },
                    { id: 'audit', label: 'Audit', icon: <Search size={13} /> },
                    { id: 'custom', label: 'Custom', icon: <Settings2 size={13} /> },
                  ].map(t => (
                    <button
                      key={t.id}
                      onClick={() => setFormType(t.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-md border text-xs transition-colors ${
                        formType === t.id
                          ? 'border-red-500 bg-red-900/10 text-white'
                          : 'border-gray-700 text-gray-400 hover:border-gray-600'
                      }`}
                    >
                      {t.icon}
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Capabilities (comma-separated)</label>
                <Input
                  value={formCaps}
                  onChange={e => setFormCaps(e.target.value)}
                  placeholder="IAM, S3, EC2, Attack Paths"
                  className="bg-cdm-dark border-gray-700 text-white"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs text-gray-400 flex items-center gap-2">
                    <Settings2 size={11} />
                    Instructions / Agent Prompt
                    <span className="text-gray-600">(sent to AI as system context)</span>
                    {scope !== 'cloud' && (
                      <label
                        className="flex items-center gap-1 text-[10px] text-gray-500 hover:text-gray-200 cursor-pointer ml-1"
                        title="Load instructions from a .md or .txt file"
                      >
                        <FileSearch size={11} />
                        Load from file
                        <input
                          type="file"
                          accept=".md,.txt,.text"
                          className="hidden"
                          onChange={e => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            const reader = new FileReader();
                            reader.onload = ev => { if (ev.target?.result) setFormInstructions(String(ev.target.result)); };
                            reader.readAsText(file);
                            e.target.value = '';
                          }}
                        />
                      </label>
                    )}
                  </label>
                  {scope === 'cloud' && editingId && (
                    <button
                      type="button"
                      onClick={async () => {
                        const fresh = await loadScopeContent(editingId, formInstructions);
                        setFormInstructions(fresh);
                      }}
                      className="flex items-center gap-1 text-[10px] text-cyan-400 hover:text-cyan-300"
                      disabled={loadingContent}
                    >
                      {loadingContent ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />}
                      {loadingContent ? 'Loading...' : 'Reload from DV-CLOUD engine'}
                    </button>
                  )}
                </div>
                {loadingContent ? (
                  <div className="w-full bg-cdm-dark border border-gray-700 rounded-md p-4 flex items-center gap-2 text-xs text-gray-400 h-40">
                    <Loader2 size={14} className="animate-spin text-cyan-400" />
                    Fetching full agent content from DV-CLOUD engine...
                  </div>
                ) : (
                  <textarea
                    value={formInstructions}
                    onChange={e => setFormInstructions(e.target.value)}
                    placeholder="Describe what this agent should focus on, what to look for, and how to report findings..."
                    rows={12}
                    className="w-full bg-cdm-dark border border-gray-700 rounded-md text-white text-xs p-3 resize-y focus:outline-none focus:ring-1 focus:ring-red-500/50 placeholder:text-gray-600 font-mono"
                  />
                )}
                {scope === 'cloud' && editingId && (
                  <p className="text-[10px] text-gray-600 mt-1">
                    Full .md content loaded from <code className="text-gray-500">agents/{editingId}.md</code> — unmodified DV-CLOUD source.
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-800">
              <Button variant="outline" onClick={() => setShowCreateModal(false)} className="border-gray-700 text-gray-400">
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={!formName.trim()}
                className="bg-red-600 hover:bg-red-700 text-white gap-2"
              >
                <Save size={14} />
                {editingId ? 'Save Changes' : 'Create Agent'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ---------------------------------------------------------------------------
// Main AIAgents page
// ---------------------------------------------------------------------------

const SCAN_ACTIVITY_KEY = 'cra_scan_activity';
interface ScanActivitySnapshot {
  type: string;
  scanId: string;
  status: string;
  agents: Record<string, string>;
}
function readScanActivity(): ScanActivitySnapshot | null {
  try { const r = localStorage.getItem(SCAN_ACTIVITY_KEY); return r ? JSON.parse(r) : null; } catch { return null; }
}

const AIAgents = () => {
  // Aggregate stats across all scopes — refreshed whenever any AgentPanel saves
  const [webAgents, setWebAgents] = useState(() => loadAgents('web'));
  const [adAgents, setAdAgents] = useState(() => loadAgents('ad'));
  const [cloudAgents, setCloudAgents] = useState(() => loadAgents('cloud'));

  // Live scan activity — updated by CloudScan/WebScan via localStorage + custom event
  const [scanActivity, setScanActivity] = useState<ScanActivitySnapshot | null>(readScanActivity);

  useEffect(() => {
    const sync = () => setScanActivity(readScanActivity());
    window.addEventListener('storage', sync);
    window.addEventListener('cra-scan-activity', sync);
    return () => {
      window.removeEventListener('storage', sync);
      window.removeEventListener('cra-scan-activity', sync);
    };
  }, []);

  useEffect(() => {
    const refresh = () => {
      setWebAgents(loadAgents('web'));
      setAdAgents(loadAgents('ad'));
      setCloudAgents(loadAgents('cloud'));
    };
    window.addEventListener('cra-agents-changed', refresh);
    return () => window.removeEventListener('cra-agents-changed', refresh);
  }, []);

  // Auto-clear stale webscan activity when this page mounts or when activity appears
  useEffect(() => {
    if (!scanActivity || scanActivity.status !== 'running' || scanActivity.type !== 'webscan') return;
    getWebScanStatus(scanActivity.scanId).then(({ status }) => {
      if (status === 'completed' || status === 'error' || status === 'cancelled') {
        localStorage.removeItem(SCAN_ACTIVITY_KEY);
        window.dispatchEvent(new CustomEvent('cra-scan-activity', { detail: null }));
      }
    }).catch(() => {
      // If we can't reach the backend, clear stale activity to avoid stuck UI
      localStorage.removeItem(SCAN_ACTIVITY_KEY);
      window.dispatchEvent(new CustomEvent('cra-scan-activity', { detail: null }));
    });
  }, [scanActivity?.scanId]); // eslint-disable-line react-hooks/exhaustive-deps

  const totalAgents = webAgents.length + adAgents.length + cloudAgents.length;
  const storedExecuting = [...webAgents, ...adAgents, ...cloudAgents].filter(a => a.status === 'executing').length;
  const storedTasksCompleted = [...webAgents, ...adAgents, ...cloudAgents].reduce((s, a) => s + a.tasksCompleted, 0);

  // Live scan overrides
  const liveAgentValues = scanActivity?.status === 'running' ? Object.values(scanActivity.agents) : [];
  const liveExecuting = liveAgentValues.filter(s => s === 'executing').length;
  const liveCompleted = liveAgentValues.filter(s => s === 'completed').length;
  const executing = storedExecuting + liveExecuting;
  const tasksCompleted = storedTasksCompleted + liveCompleted;

  return (
    <PageContainer title="">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-3">
              <Bot className="text-red-400" size={28} />
              AI Agents / Skills
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              Create and manage AI agents for automated cybersecurity tasks. Each scan module has its own agent context.
              Cloud tab includes DV-CLOUD purple team agents (cra-cl-audit, cra-cl-defend, cra-cl-hunt, cra-cl-exploit).
            </p>
          </div>
        </div>

        {/* Active scan banner */}
        {scanActivity?.status === 'running' && (
          <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-cyan-900/10 border border-cyan-500/20">
            <Loader2 size={14} className="text-cyan-400 animate-spin shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-xs text-cyan-400 font-medium">
                {scanActivity.type === 'cloudscan' ? 'CloudScan' : 'WebScan'} active — scan ID: {scanActivity.scanId}
              </span>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {Object.entries(scanActivity.agents).map(([id, status]) => (
                  <span key={id} className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    status === 'executing' ? 'border-cyan-500/50 text-cyan-300 bg-cyan-900/20' :
                    status === 'completed' ? 'border-emerald-500/40 text-emerald-400 bg-emerald-900/15' :
                    'border-gray-700 text-gray-600'
                  }`}>
                    {status === 'executing' && <span className="inline-block w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse mr-1" />}
                    {status === 'completed' && <span className="mr-1">✓</span>}
                    {id}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Stat Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={16} className="text-gray-500" />
              <span className="text-xs text-gray-500 uppercase tracking-wider">Total Agents</span>
            </div>
            <span className="text-2xl font-bold text-white">{totalAgents}</span>
          </div>
          <div className={`bg-cdm-darker rounded-lg border p-4 ${executing > 0 ? 'border-emerald-500/30' : 'border-gray-800'}`}>
            <div className="flex items-center gap-2 mb-1">
              <Zap size={16} className={executing > 0 ? 'text-emerald-400' : 'text-emerald-500'} />
              <span className="text-xs text-gray-500 uppercase tracking-wider">In Execution</span>
            </div>
            <span className={`text-2xl font-bold ${executing > 0 ? 'text-emerald-400' : 'text-white'}`}>{executing}</span>
          </div>
          <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle2 size={16} className="text-blue-500" />
              <span className="text-xs text-gray-500 uppercase tracking-wider">Tasks Completed</span>
            </div>
            <span className="text-2xl font-bold text-white">{tasksCompleted}</span>
          </div>
          <div className="bg-cdm-darker rounded-lg border border-gray-800 p-4">
            <div className="flex items-center gap-2 mb-1">
              <Cloud size={16} className="text-cyan-500" />
              <span className="text-xs text-gray-500 uppercase tracking-wider">DV-CLOUD Agents</span>
            </div>
            <span className="text-2xl font-bold text-white">4</span>
          </div>
        </div>

        {/* Scoped tabs */}
        <Tabs defaultValue="web">
          <TabsList className="bg-cdm-darker border border-gray-800">
            <TabsTrigger value="web" className="text-xs data-[state=active]:bg-red-900/30 data-[state=active]:text-red-400 gap-1.5">
              <Network size={12} />
              Web
              {webAgents.length > 0 && (
                <Badge className="ml-1 bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{webAgents.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="ad" className="text-xs data-[state=active]:bg-blue-900/30 data-[state=active]:text-blue-400 gap-1.5">
              <Lock size={12} />
              AD
              {adAgents.length > 0 && (
                <Badge className="ml-1 bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{adAgents.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="cloud" className="text-xs data-[state=active]:bg-cyan-900/30 data-[state=active]:text-cyan-400 gap-1.5">
              <Cloud size={12} />
              Cloud
              {cloudAgents.length > 0 && (
                <Badge className="ml-1 bg-gray-700 text-gray-300 text-[10px] px-1.5 py-0">{cloudAgents.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="web">
            <AgentPanel scope="web" templates={WEB_TEMPLATES} accentColor="bg-red-600 hover:bg-red-700" />
          </TabsContent>

          <TabsContent value="ad">
            <AgentPanel scope="ad" templates={AD_TEMPLATES} accentColor="bg-blue-600 hover:bg-blue-700" />
          </TabsContent>

          <TabsContent value="cloud">
            <AgentPanel scope="cloud" templates={CLOUD_SCOPE_TEMPLATES} accentColor="bg-cyan-600 hover:bg-cyan-700" />
          </TabsContent>
        </Tabs>
      </div>
    </PageContainer>
  );
};

export default AIAgents;
