
import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { 
  Network, 
  Filter, 
  Search, 
  Download,
  ChevronDown,
  Database,
  Calendar,
  X
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { usePortEventsData } from '@/hooks/usePortEventsData';
import type { PortStatusDevice } from '@/hooks/usePortEventsData';

const PortEvents = () => {
  const [activeTab, setActiveTab] = useState('port-status');
  const [portHistoryDialog, setPortHistoryDialog] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<PortStatusDevice | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeviceFilter, setSelectedDeviceFilter] = useState('all');
  const [selectedDateRange, setSelectedDateRange] = useState('today');
  const [selectedEvents, setSelectedEvents] = useState({
    opened: true,
    closed: true,
    modified: true
  });
  
  const { portEvents, portStatusDevices, isLoading, error } = usePortEventsData();
  
  const itemsPerPage = 10;
  
  const handleViewPortHistory = (device: PortStatusDevice) => {
    setSelectedDevice(device);
    setPortHistoryDialog(true);
  };

  const getDateRangeFilter = () => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    switch (selectedDateRange) {
      case 'today':
        return today;
      case 'yesterday':
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return yesterday;
      case 'last7days':
        const sevenDaysAgo = new Date(today);
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        return sevenDaysAgo;
      case 'last30days':
        const thirtyDaysAgo = new Date(today);
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return thirtyDaysAgo;
      default:
        return null;
    }
  };

  const filteredChanges = portEvents.filter(item => {
    // Search filter
    const matchesSearch = 
      item.agent?.hostname?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.process_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.status?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.service?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.address?.toLowerCase().includes(searchQuery.toLowerCase());

    // Device filter
    const matchesDevice = selectedDeviceFilter === 'all' || 
      item.agent?.hostname === selectedDeviceFilter;

    // Event type filter
    const matchesEventType = 
      (selectedEvents.opened && item.status === 'open') ||
      (selectedEvents.closed && item.status === 'closed') ||
      (selectedEvents.modified && item.status !== 'open' && item.status !== 'closed');

    // Date range filter
    const dateFilter = getDateRangeFilter();
    let matchesDate = true;
    if (dateFilter && item.timestamp) {
      const eventDate = new Date(item.timestamp);
      const eventDateOnly = new Date(eventDate.getFullYear(), eventDate.getMonth(), eventDate.getDate());
      
      if (selectedDateRange === 'today') {
        matchesDate = eventDateOnly.getTime() === dateFilter.getTime();
      } else if (selectedDateRange === 'yesterday') {
        matchesDate = eventDateOnly.getTime() === dateFilter.getTime();
      } else {
        matchesDate = eventDateOnly >= dateFilter;
      }
    }
      
    return matchesSearch && matchesDevice && matchesEventType && matchesDate;
  });
  
  const paginatedChanges = filteredChanges.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const totalPages = Math.ceil(filteredChanges.length / itemsPerPage);

  // Reset pagination when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, selectedDeviceFilter, selectedDateRange, selectedEvents]);
  
  const handleDownloadCSV = () => {
    // Create CSV content
    const headers = ['Host', 'Process Name', 'Port', 'Address', 'Socket', 'Status', 'Timestamp'];
    const csvContent = [
      headers.join(','),
      ...filteredChanges.map(item => [
        item.agent?.hostname || 'Unknown',
        item.process_name || '',
        item.port_number,
        item.address || '',
        item.socket || '',
        item.status,
        formatDate(item.timestamp)
      ].join(','))
    ].join('\n');

    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `port-events-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const formatDate = (dateString: string) => {
    if (!dateString || dateString === 'Never') return 'Never';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const handleFindEvents = () => {
    // This will trigger the filtering automatically due to the dependency on filter states
    console.log('Finding events with current filters...');
  };
  
  if (isLoading) {
    return (
      <PageContainer title="Port Events">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500" />
        </div>
      </PageContainer>
    );
  }

  if (error) {
    return (
      <PageContainer title="Port Events">
        <div className="text-center p-8 text-red-400">
          <h3 className="text-xl font-semibold">Error loading port events</h3>
          <p className="text-gray-400">{(error as Error).message}</p>
        </div>
      </PageContainer>
    );
  }
  
  return (
    <PageContainer title="Port Events">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="port-status" className="data-[state=active]:bg-gray-700">Port Status</TabsTrigger>
          <TabsTrigger value="port-changes" className="data-[state=active]:bg-gray-700">Port Changes</TabsTrigger>
        </TabsList>
        
        <TabsContent value="port-status" className="mt-4">
          <div className="bg-cdm-darker rounded-lg p-6">
            <div className="flex items-center mb-5 text-gray-300">
              <Network className="mr-2 text-blue-400" />
              <h2 className="text-xl">Device Port Status and Events</h2>
            </div>
            <p className="text-gray-400 mb-5">
              Each server's past and present network port states are highlighted as either Open, Closed, or Modified.
            </p>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-850">
                  <TableRow>
                    <TableHead className="text-gray-300">Port History</TableHead>
                    <TableHead className="text-gray-300">Hostname</TableHead>
                    <TableHead className="text-gray-300">Operating System</TableHead>
                    <TableHead className="text-gray-300">Version</TableHead>
                    <TableHead className="text-gray-300">Last Port Transaction</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {portStatusDevices.map((device) => (
                    <TableRow key={device.id} className="hover:bg-gray-750 border-gray-700">
                      <TableCell>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleViewPortHistory(device)}
                          className="bg-gray-700 text-gray-300 hover:bg-gray-600"
                        >
                          View Port History
                        </Button>
                      </TableCell>
                      <TableCell className="font-medium text-gray-300">{device.hostname}</TableCell>
                      <TableCell className="text-gray-300">{device.platform}</TableCell>
                      <TableCell className="text-gray-300">{device.version}</TableCell>
                      <TableCell className="text-gray-300">{formatDate(device.lastPortTransaction)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="port-changes" className="mt-4">
          <div className="bg-cdm-darker rounded-lg p-6">
            <div className="flex items-center mb-5 text-gray-300">
              <Network className="mr-2 text-green-400" />
              <h2 className="text-xl">Change Events</h2>
            </div>
            <p className="text-gray-400 mb-5">
              Processed for each reporting CRA agent. Showing {filteredChanges.length} of {portEvents.length} events.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-gray-800 p-4 rounded-lg">
                <h3 className="text-gray-300 mb-2 flex items-center">
                  <Database className="mr-2" size={18} />
                  Devices
                </h3>
                <Select value={selectedDeviceFilter} onValueChange={setSelectedDeviceFilter}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                    <SelectValue placeholder="Select device" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                    <SelectItem value="all">All Devices</SelectItem>
                    {portStatusDevices.map(device => (
                      <SelectItem key={device.id} value={device.hostname}>
                        {device.hostname}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="bg-gray-800 p-4 rounded-lg">
                <h3 className="text-gray-300 mb-2">Event Type</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="opened" 
                      checked={selectedEvents.opened}
                      onCheckedChange={(checked) => 
                        setSelectedEvents({...selectedEvents, opened: checked === true})
                      }
                      className="border-gray-500"
                    />
                    <label htmlFor="opened" className="text-gray-300 cursor-pointer">
                      <Badge className="bg-green-600">Open</Badge>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="closed" 
                      checked={selectedEvents.closed}
                      onCheckedChange={(checked) => 
                        setSelectedEvents({...selectedEvents, closed: checked === true})
                      }
                      className="border-gray-500"
                    />
                    <label htmlFor="closed" className="text-gray-300 cursor-pointer">
                      <Badge className="bg-red-600">Closed</Badge>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="modified" 
                      checked={selectedEvents.modified}
                      onCheckedChange={(checked) => 
                        setSelectedEvents({...selectedEvents, modified: checked === true})
                      }
                      className="border-gray-500"
                    />
                    <label htmlFor="modified" className="text-gray-300 cursor-pointer">
                      <Badge className="bg-yellow-600">Other</Badge>
                    </label>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col space-y-4">
                <div className="bg-gray-800 p-4 rounded-lg flex-1">
                  <h3 className="text-gray-300 mb-2 flex items-center">
                    <Calendar className="mr-2" size={18} />
                    Date Range
                  </h3>
                  <Select value={selectedDateRange} onValueChange={setSelectedDateRange}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                      <SelectValue placeholder="Select date range" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="yesterday">Yesterday</SelectItem>
                      <SelectItem value="last7days">Last 7 Days</SelectItem>
                      <SelectItem value="last30days">Last 30 Days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={handleFindEvents}
                >
                  Find Events
                </Button>
              </div>
            </div>
            
            <div className="flex justify-between items-center mb-4">
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input 
                  placeholder="Search events..." 
                  className="pl-10 bg-gray-800 border-gray-700 text-white"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button 
                variant="outline" 
                onClick={handleDownloadCSV}
                className="bg-gray-700 text-gray-300 hover:bg-gray-600"
              >
                <Download className="mr-2" size={16} />
                Download CSV
              </Button>
            </div>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-850">
                  <TableRow>
                    <TableHead className="text-gray-300">Host</TableHead>
                    <TableHead className="text-gray-300">Process Name</TableHead>
                    <TableHead className="text-gray-300">Port</TableHead>
                    <TableHead className="text-gray-300">Address</TableHead>
                    <TableHead className="text-gray-300">Socket</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Timestamp</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedChanges.map((item) => (
                    <TableRow key={item.id} className="hover:bg-gray-750 border-gray-700">
                      <TableCell className="font-medium text-gray-300">{item.agent?.hostname || 'Unknown'}</TableCell>
                      <TableCell className="text-gray-300">{item.process_name}</TableCell>
                      <TableCell className="text-gray-300">{item.port_number}</TableCell>
                      <TableCell className="text-gray-300">{item.address}</TableCell>
                      <TableCell className="text-gray-300">{item.socket}</TableCell>
                      <TableCell>
                        <Badge 
                          className={
                            item.status === 'open' ? 'bg-green-600' : 
                            item.status === 'closed' ? 'bg-red-600' : 
                            'bg-yellow-600'
                          }
                        >
                          {item.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-300">{formatDate(item.timestamp)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            
            {totalPages > 1 && (
              <div className="flex items-center justify-center space-x-2 mt-4">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="bg-gray-700 text-gray-300 hover:bg-gray-600"
                >
                  Previous
                </Button>
                <div className="text-gray-300">
                  Page {currentPage} of {totalPages}
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="bg-gray-700 text-gray-300 hover:bg-gray-600"
                >
                  Next
                </Button>
              </div>
            )}
            
            {filteredChanges.length === 0 && (
              <div className="text-center py-8 text-gray-400">
                <p>No port events found matching the current filters.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      <Dialog open={portHistoryDialog} onOpenChange={setPortHistoryDialog}>
        <DialogContent className="bg-gray-800 text-white border-gray-700 max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center">
              <Network className="mr-2 text-blue-400" size={20} />
              <span>Port History: {selectedDevice?.hostname}</span>
            </DialogTitle>
            <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </DialogClose>
          </DialogHeader>
          
          <div className="mt-4 overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-850">
                <TableRow>
                  <TableHead className="text-gray-300">Service</TableHead>
                  <TableHead className="text-gray-300">Port</TableHead>
                  <TableHead className="text-gray-300">Address</TableHead>
                  <TableHead className="text-gray-300">Protocol</TableHead>
                  <TableHead className="text-gray-300">Socket</TableHead>
                  <TableHead className="text-gray-300">Family</TableHead>
                  <TableHead className="text-gray-300">PID</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedDevice?.ports.map((port) => (
                  <TableRow key={port.id} className="hover:bg-gray-750 border-gray-700">
                    <TableCell className="font-medium text-gray-300">{port.service}</TableCell>
                    <TableCell className="text-gray-300">{port.port_number}</TableCell>
                    <TableCell className="text-gray-300">{port.address}</TableCell>
                    <TableCell className="text-gray-300">{port.protocol}</TableCell>
                    <TableCell className="text-gray-300">{port.socket}</TableCell>
                    <TableCell className="text-gray-300">{port.family}</TableCell>
                    <TableCell className="text-gray-300">{port.pid}</TableCell>
                    <TableCell>
                      <Badge 
                        className={
                          port.status === 'open' ? 'bg-green-600' : 
                          port.status === 'closed' ? 'bg-red-600' : 
                          'bg-yellow-600'
                        }
                      >
                        {port.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
};

export default PortEvents;
