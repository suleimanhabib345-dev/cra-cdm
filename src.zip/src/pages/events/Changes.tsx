
import React from 'react';
import PageContainer from '@/components/PageContainer';

const Changes = () => {
  return (
    <PageContainer title="System Changes">
      <div className="bg-cdm-darker rounded-lg p-6">
        <p className="text-gray-300">System changes detection and monitoring will be displayed here.</p>
      </div>
    </PageContainer>
  );
};

export default Changes;
