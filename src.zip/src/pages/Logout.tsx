
import React, { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

const Logout = () => {
  useEffect(() => {
    const performLogout = async () => {
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (error) {
        console.error('Logout error:', error);
      }

      // Force-clear all Supabase auth data from localStorage
      // in case signOut() failed to reach the server
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith('sb-')) {
          localStorage.removeItem(key);
        }
      });

      // Full page reload to clear all in-memory state
      window.location.href = '/';
    };

    performLogout();
  }, []);

  return (
    <div className="flex min-h-screen bg-cdm-dark text-white items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">Logging Out</h1>
        <p className="text-gray-300">Please wait while we securely log you out...</p>
        <div className="mt-6 animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
      </div>
    </div>
  );
};

export default Logout;
