import React, { useState, useEffect } from 'react';
import PageContainer from '@/components/PageContainer';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

const STAFF_ROLES = [
  { value: 'admin', label: 'Admin', hint: 'Full access; can invite more staff' },
  { value: 'staff_editor', label: 'Editor', hint: 'Run scans and edit data' },
  { value: 'staff_viewer', label: 'Viewer', hint: 'Read-only access' },
] as const;

type StaffRole = (typeof STAFF_ROLES)[number]['value'];

interface Staff {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
}

const staffFormSchema = z.object({
  email: z.string().email({ message: "Invalid email address" }),
  first_name: z.string().min(1, { message: "First name is required" }),
  last_name: z.string().min(1, { message: "Last name is required" }),
  role: z.enum(['admin', 'staff_editor', 'staff_viewer'], {
    errorMap: () => ({ message: "Role is required" }),
  }),
});

const companyFormSchema = z.object({
  name: z.string().min(1, { message: "Company name is required" }),
  contact_email: z.string().email().optional().or(z.literal('')),
  contact_phone: z.string().optional().or(z.literal('')),
  address: z.string().optional().or(z.literal('')),
});

const Company = () => {
  const [companyInfo, setCompanyInfo] = useState<{
    id: string;
    name: string;
    contact_email: string | null;
    contact_phone: string | null;
    address: string | null;
  } | null>(null);
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [companyDialogOpen, setCompanyDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof staffFormSchema>>({
    resolver: zodResolver(staffFormSchema),
    defaultValues: {
      email: "",
      first_name: "",
      last_name: "",
      role: 'staff_viewer',
    },
  });

  const companyForm = useForm<z.infer<typeof companyFormSchema>>({
    resolver: zodResolver(companyFormSchema),
    defaultValues: {
      name: '',
      contact_email: '',
      contact_phone: '',
      address: '',
    },
  });

  useEffect(() => {
    const fetchCompanyInfo = async () => {
      setLoading(true);
      try {
        // Load the current user's profile to get company_id
        const { data: userData } = await supabase.auth.getUser();
        const userId = userData.user?.id;
        let companyId: string | null = null;
        if (userId) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('company_id')
            .eq('id', userId)
            .single();
          companyId = profile?.company_id || null;
        }

        // Use edge function to fetch companies list to bypass RLS
        const { data: sessionData } = await supabase.auth.getSession();
        const jwt = sessionData.session?.access_token;
        const { data, error } = await supabase.functions.invoke('api', {
          headers: { 'x-path': 'companies', 'x-method': 'GET', ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) }
        });
        if (error) throw error;
        const companies = Array.isArray(data) ? (data as any[]) : [];
        let selected = null;
        if (companyId) {
          selected = companies.find((c) => c.id === companyId) || null;
        }
        if (!selected && companies.length > 0) {
          selected = companies[0];
        }
        setCompanyInfo(selected);
      } catch (error) {
        console.error('Error fetching company info:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load company information"
        });
      } finally {
        setLoading(false);
      }
    };

    const fetchStaffList = async () => {
      try {
        // Use Edge Function to get company-scoped users
        const { data, error } = await supabase.functions.invoke('api', {
          method: 'GET',
          headers: { 'x-path': 'users' }
        });

        if (error) throw error;

        setStaffList(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error('Error fetching staff list:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load staff list"
        });
      }
    };

    fetchCompanyInfo();
    fetchStaffList();
  }, []);

  const handleAddStaff = async (values: z.infer<typeof staffFormSchema>) => {
    setSubmitting(true);
    try {
      const redirectTo = `${import.meta.env.VITE_SITE_URL || window.location.origin}/auth/accept-invite`;
      const { error } = await supabase.functions.invoke('api', {
        headers: { 'x-path': 'users', 'x-method': 'POST' },
        body: {
          email: values.email,
          first_name: values.first_name,
          last_name: values.last_name,
          role: values.role,
          redirect_to: redirectTo,
        },
      });

      if (error) {
        let message = error.message;
        const anyErr = error as any;
        try {
          const resp = anyErr?.context?.response ?? anyErr?.context;
          if (resp && typeof resp.text === 'function') {
            const text = await resp.text();
            try {
              const parsed = JSON.parse(text);
              message = parsed?.error || parsed?.message || text;
            } catch {
              message = text;
            }
          }
        } catch {
          // fall through with default message
        }
        throw new Error(message);
      }

      const { data: newStaffList, error: listError } = await supabase.functions.invoke('api', {
        method: 'GET',
        headers: { 'x-path': 'users' }
      });

      if (listError) throw listError;
      setStaffList(Array.isArray(newStaffList) ? newStaffList : []);

      toast({
        title: "Invitation sent",
        description: `An invite email has been sent to ${values.email}.`
      });
      setDialogOpen(false);
      form.reset();
    } catch (error) {
      console.error('Error inviting staff:', error);
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        variant: "destructive",
        title: "Error inviting staff",
        description: errorMessage
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateCompany = async (values: z.infer<typeof companyFormSchema>) => {
    setSubmitting(true);
    try {
      const payload = {
        name: values.name.trim(),
        contact_email: values.contact_email || undefined,
        contact_phone: values.contact_phone || undefined,
        address: values.address || undefined,
      };
      const { data: sessionData } = await supabase.auth.getSession();
      const jwt = sessionData.session?.access_token;
      const { data, error } = await supabase.functions.invoke('api', {
        headers: { 'x-path': 'companies', 'x-method': 'POST', ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) },
        body: payload,
      });
      if (error) {
        let message = error.message;
        const anyErr = error as any;
        try {
          // Supabase error context can include a Response with a ReadableStream body
          const resp = anyErr?.context?.response ?? anyErr?.context;
          if (resp && typeof resp.text === 'function') {
            const text = await resp.text();
            try {
              const parsed = JSON.parse(text);
              message = parsed?.error || parsed?.message || text;
              if (parsed?.details) message = `${message} (${parsed.details})`;
            } catch {
              message = text;
            }
          } else if (typeof anyErr?.context?.body === 'string') {
            try {
              const parsed = JSON.parse(anyErr.context.body);
              message = parsed?.error || parsed?.message || anyErr.context.body;
              if (parsed?.details) message = `${message} (${parsed.details})`;
            } catch {
              message = anyErr.context.body;
            }
          }
        } catch {
          // Fallback to default error message
        }
        throw new Error(message);
      }
      setCompanyInfo(data as any);
      toast({ title: 'Company created', description: 'Company has been created successfully' });
      setCompanyDialogOpen(false);
      companyForm.reset();
    } catch (error) {
      console.error('Error creating company:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
      toast({ variant: 'destructive', title: 'Error creating company', description: errorMessage });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PageContainer title="Company Information">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <div className="text-gray-300">
          <h2 className="text-xl mb-5">Company Details</h2>
          {loading ? (
            <div className="flex justify-center items-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : companyInfo ? (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4">
                <div className="mb-2">
                  <span className="text-sm text-gray-400">Name:</span>
                  <p className="text-white">{companyInfo.name}</p>
                </div>
                <div className="mb-2">
                  <span className="text-sm text-gray-400">Contact Email:</span>
                  <p className="text-white">{companyInfo.contact_email || 'N/A'}</p>
                </div>
                <div className="mb-2">
                  <span className="text-sm text-gray-400">Contact Phone:</span>
                  <p className="text-white">{companyInfo.contact_phone || 'N/A'}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-400">Address:</span>
                  <p className="text-white">{companyInfo.address || 'N/A'}</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center text-gray-400 space-y-4">
              <p>No company information available.</p>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setCompanyDialogOpen(true)}>
                Create Company
              </Button>
            </div>
          )}
        </div>

        <div className="text-gray-300">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-xl">Staff List</h2>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setDialogOpen(true)}>
              Invite Staff
            </Button>
          </div>
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              {loading ? (
                <div className="flex justify-center items-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : staffList.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left">
                        <th className="py-2 text-gray-400">Name</th>
                        <th className="py-2 text-gray-400">Email</th>
                        <th className="py-2 text-gray-400">Role</th>
                      </tr>
                    </thead>
                    <tbody>
                      {staffList.map((staff) => {
                        const roleLabel =
                          STAFF_ROLES.find((r) => r.value === staff.role)?.label ?? staff.role;
                        return (
                          <tr key={staff.id} className="hover:bg-gray-750">
                            <td className="py-2 text-white">{staff.first_name} {staff.last_name}</td>
                            <td className="py-2 text-white">{staff.email}</td>
                            <td className="py-2 text-white">{roleLabel}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center text-gray-400">No staff members added yet.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-gray-800 text-white border-gray-700 max-w-xl">
          <DialogHeader>
            <DialogTitle className="text-white">Invite New Staff Member</DialogTitle>
            <DialogDescription className="text-gray-400">
              They'll receive an email with a link to set their password and join your company.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleAddStaff)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="staff@example.com"
                        type="email"
                        className="bg-gray-700 border-gray-600 text-gray-300"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="first_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="John"
                        className="bg-gray-700 border-gray-600 text-gray-300"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="last_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Doe"
                        className="bg-gray-700 border-gray-600 text-gray-300"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-gray-800 border-gray-700 text-gray-200">
                        {STAFF_ROLES.map((r) => (
                          <SelectItem key={r.value} value={r.value} className="focus:bg-gray-700">
                            <div className="flex flex-col">
                              <span>{r.label}</span>
                              <span className="text-xs text-gray-400">{r.hint}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700"
                  disabled={submitting}
                >
                  {submitting ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Sending invite...
                    </span>
                  ) : (
                    'Send Invite'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      <Dialog open={companyDialogOpen} onOpenChange={setCompanyDialogOpen}>
        <DialogContent className="bg-gray-800 text-white border-gray-700 max-w-xl">
          <DialogHeader>
            <DialogTitle className="text-white">Create Company</DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a new company and assign it to your profile
            </DialogDescription>
          </DialogHeader>
          <Form {...companyForm}>
            <form onSubmit={companyForm.handleSubmit(handleCreateCompany)} className="space-y-4">
              <FormField
                control={companyForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Acme Corp" className="bg-gray-700 border-gray-600 text-gray-300" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={companyForm.control}
                name="contact_email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="ops@acme.com" className="bg-gray-700 border-gray-600 text-gray-300" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={companyForm.control}
                name="contact_phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Phone</FormLabel>
                    <FormControl>
                      <Input placeholder="+1-555-0100" className="bg-gray-700 border-gray-600 text-gray-300" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={companyForm.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Input placeholder="123 Main St" className="bg-gray-700 border-gray-600 text-gray-300" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={submitting}>
                  {submitting ? 'Creating...' : 'Create Company'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
};

export default Company;
