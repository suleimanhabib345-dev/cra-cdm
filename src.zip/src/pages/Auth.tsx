import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Building2, User, CheckCircle, Loader2 } from 'lucide-react';

// ── Techy grid + scanline background ────────────────────────────────────────

const BG_STYLES = `
  @keyframes scanline {
    0%   { transform: translateY(-100%); }
    100% { transform: translateY(100vh); }
  }
  @keyframes pulse-dot {
    0%, 100% { opacity: 0.15; }
    50%       { opacity: 0.45; }
  }
  @keyframes flicker {
    0%, 100% { opacity: 1; }
    92%       { opacity: 1; }
    93%       { opacity: 0.4; }
    94%       { opacity: 1; }
    96%       { opacity: 0.6; }
    97%       { opacity: 1; }
  }
  .auth-scanline {
    animation: scanline 6s linear infinite;
    pointer-events: none;
  }
  .auth-logo {
    animation: flicker 8s ease-in-out infinite;
  }
`;

// ASCII grid characters repeated as a faint background texture
const ASCII_CHARS = '01  ░▒  10  ▓  01  ░  10  ▒  ';

function AsciiBackground() {
  // 20 rows × ~70 chars — rendered as fixed overlay
  const rows = Array.from({ length: 22 }, (_, i) => {
    const offset = i * 7;
    let row = '';
    for (let c = 0; c < 80; c++) {
      row += ASCII_CHARS[(offset + c) % ASCII_CHARS.length];
    }
    return row;
  });

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 overflow-hidden select-none"
      style={{ zIndex: 0 }}
    >
      {/* Fine grid lines */}
      <svg
        className="absolute inset-0 w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="0.3"
              strokeOpacity="0.12"
            />
          </pattern>
          <pattern id="grid-lg" width="200" height="200" patternUnits="userSpaceOnUse">
            <path
              d="M 200 0 L 0 0 0 200"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="0.6"
              strokeOpacity="0.07"
            />
          </pattern>
          {/* Radial vignette — darker at corners, lighter in center */}
          <radialGradient id="vignette" cx="50%" cy="50%" r="70%">
            <stop offset="0%"   stopColor="#1a1e2c" stopOpacity="0" />
            <stop offset="100%" stopColor="#1a1e2c" stopOpacity="0.85" />
          </radialGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid-lg)" />
        <rect width="100%" height="100%" fill="url(#grid)" />
        <rect width="100%" height="100%" fill="url(#vignette)" />
      </svg>

      {/* ASCII text texture */}
      <div
        className="absolute inset-0 flex flex-col justify-around opacity-[0.028] overflow-hidden"
        style={{ fontFamily: 'monospace', fontSize: '11px', lineHeight: '1.7', letterSpacing: '0.05em', color: '#06b6d4' }}
      >
        {rows.map((row, i) => (
          <div key={i} style={{ whiteSpace: 'pre', paddingLeft: `${(i % 4) * 12}px` }}>
            {row}
          </div>
        ))}
      </div>

      {/* Horizontal scanline sweep */}
      <div
        className="auth-scanline absolute left-0 right-0 h-[2px]"
        style={{
          background: 'linear-gradient(90deg, transparent, #06b6d4 30%, #06b6d4 70%, transparent)',
          opacity: 0.06,
        }}
      />

      {/* Corner accent — top-left */}
      <svg className="absolute top-0 left-0 w-32 h-32 opacity-20" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 48 L0 0 L48 0" stroke="#06b6d4" strokeWidth="1.5" />
        <path d="M0 24 L0 0 L24 0" stroke="#06b6d4" strokeWidth="0.5" opacity="0.5" />
        <circle cx="0" cy="0" r="3" fill="#06b6d4" />
      </svg>

      {/* Corner accent — bottom-right */}
      <svg className="absolute bottom-0 right-0 w-32 h-32 opacity-20" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M128 80 L128 128 L80 128" stroke="#06b6d4" strokeWidth="1.5" />
        <path d="M128 104 L128 128 L104 128" stroke="#06b6d4" strokeWidth="0.5" opacity="0.5" />
        <circle cx="128" cy="128" r="3" fill="#06b6d4" />
      </svg>
    </div>
  );
}

// ── Main Auth component ──────────────────────────────────────────────────────

const Auth = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [accountType, setAccountType] = useState<'personal' | 'company'>('personal');
  const [companyName, setCompanyName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSignUp, setIsSignUp] = useState(false);
  const [signUpSuccess, setSignUpSuccess] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
    setLoading(false);
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    if (password !== confirmPassword) { setError('Passwords do not match'); setLoading(false); return; }
    if (password.length < 6)          { setError('Password must be at least 6 characters'); setLoading(false); return; }
    if (!firstName.trim() || !lastName.trim()) { setError('First name and last name are required'); setLoading(false); return; }
    if (accountType === 'company' && !companyName.trim()) { setError('Company name is required'); setLoading(false); return; }

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          first_name: firstName.trim(),
          last_name: lastName.trim(),
          account_type: accountType,
          company_name: accountType === 'company' ? companyName.trim() : undefined,
        },
      },
    });

    if (error) setError(error.message);
    else setSignUpSuccess(true);
    setLoading(false);
  };

  const toggleMode = () => { setIsSignUp(!isSignUp); setError(null); setSignUpSuccess(false); };

  // Shared input style
  const inputCls = 'bg-[#111111] border-[#1e1e1e] focus:border-[#06b6d4]/50 focus:ring-[#06b6d4]/20 text-white placeholder:text-gray-600 transition-colors';

  // Shared primary button
  const PrimaryBtn = ({ children, disabled }: { children: React.ReactNode; disabled?: boolean }) => (
    <button
      type="submit"
      disabled={disabled}
      className="w-full h-10 rounded-md text-sm font-semibold text-black transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      style={{
        background: disabled ? '#1e1e1e' : 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)',
        boxShadow: disabled ? 'none' : '0 0 18px rgba(6,182,212,0.25)',
      }}
    >
      {children}
    </button>
  );

  // ── Success screen ──────────────────────────────────────────────────────
  if (signUpSuccess) {
    return (
      <>
        <style>{BG_STYLES}</style>
        <div className="relative flex min-h-screen items-center justify-center" style={{ backgroundColor: '#1a1e2c' }}>
          <AsciiBackground />
          <div className="relative z-10 w-full max-w-sm px-4 text-center space-y-6">
            <LogoHeader />
            <div
              className="rounded-xl border p-8 space-y-4"
              style={{ background: 'rgba(12,12,12,0.9)', borderColor: '#1e1e1e', backdropFilter: 'blur(12px)' }}
            >
              <CheckCircle className="h-12 w-12 mx-auto" style={{ color: '#06b6d4' }} />
              <h2 className="text-lg font-semibold text-white">Account Created</h2>
              <p className="text-sm text-gray-400">
                Check your email to verify your account before signing in.
              </p>
              <button
                type="button"
                onClick={() => { setSignUpSuccess(false); setIsSignUp(false); }}
                className="text-sm transition-colors hover:opacity-80"
                style={{ color: '#06b6d4' }}
              >
                Back to Sign In
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }

  // ── Main form ────────────────────────────────────────────────────────────
  return (
    <>
      <style>{BG_STYLES}</style>
      <div
        className="relative flex min-h-screen items-center justify-center"
        style={{ backgroundColor: '#1a1e2c' }}
      >
        <AsciiBackground />

        <div className="relative z-10 w-full max-w-sm px-4 space-y-6">
          <LogoHeader isSignUp={isSignUp} />

          {/* Card */}
          <div
            className="rounded-xl border p-6 space-y-4"
            style={{ background: 'rgba(10,10,10,0.92)', borderColor: '#1c1c1c', backdropFilter: 'blur(16px)' }}
          >
            <form onSubmit={isSignUp ? handleSignUp : handleLogin} className="space-y-4">
              {isSignUp && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label htmlFor="firstName" className="text-xs text-gray-400">First Name</Label>
                      <Input id="firstName" type="text" placeholder="John" value={firstName}
                        onChange={e => setFirstName(e.target.value)} required className={inputCls} />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="lastName" className="text-xs text-gray-400">Last Name</Label>
                      <Input id="lastName" type="text" placeholder="Doe" value={lastName}
                        onChange={e => setLastName(e.target.value)} required className={inputCls} />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-xs text-gray-400">Account Type</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {(['personal', 'company'] as const).map(type => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setAccountType(type)}
                          className="flex items-center justify-center gap-2 p-2.5 rounded-lg border text-sm transition-all"
                          style={accountType === type
                            ? { borderColor: '#06b6d4', background: 'rgba(6,182,212,0.08)', color: '#06b6d4' }
                            : { borderColor: '#1e1e1e', background: '#111111', color: '#6b7280' }
                          }
                        >
                          {type === 'personal' ? <User className="h-3.5 w-3.5" /> : <Building2 className="h-3.5 w-3.5" />}
                          <span className="capitalize">{type}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {accountType === 'company' && (
                    <div className="space-y-1.5">
                      <Label htmlFor="companyName" className="text-xs text-gray-400">Company Name</Label>
                      <Input id="companyName" type="text" placeholder="Acme Corp" value={companyName}
                        onChange={e => setCompanyName(e.target.value)} required className={inputCls} />
                    </div>
                  )}
                </>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs text-gray-400">Email</Label>
                <Input id="email" type="email" placeholder="you@example.com" value={email}
                  onChange={e => setEmail(e.target.value)} required className={inputCls} />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs text-gray-400">Password</Label>
                <Input id="password" type="password" placeholder="••••••••" value={password}
                  onChange={e => setPassword(e.target.value)} required className={inputCls} />
              </div>

              {isSignUp && (
                <div className="space-y-1.5">
                  <Label htmlFor="confirmPassword" className="text-xs text-gray-400">Confirm Password</Label>
                  <Input id="confirmPassword" type="password" placeholder="••••••••" value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)} required className={inputCls} />
                </div>
              )}

              {error && (
                <p className="text-xs text-red-400 bg-red-900/10 border border-red-500/20 rounded-md px-3 py-2">
                  {error}
                </p>
              )}

              <PrimaryBtn disabled={loading}>
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {loading
                  ? (isSignUp ? 'Creating account...' : 'Signing in...')
                  : (isSignUp ? 'Create Account' : 'Sign In')
                }
              </PrimaryBtn>
            </form>
          </div>

          {/* Toggle sign-in / sign-up */}
          <p className="text-center text-sm text-gray-500">
            {isSignUp ? 'Already have an account?' : "Don't have an account?"}
            {' '}
            <button
              type="button"
              onClick={toggleMode}
              className="transition-colors hover:opacity-80 font-medium"
              style={{ color: '#06b6d4' }}
            >
              {isSignUp ? 'Sign In' : 'Sign Up'}
            </button>
          </p>

          {/* Footer tag */}
          <p className="text-center text-[10px] text-gray-700 tracking-widest uppercase">
            Continuous Detection &amp; Monitoring
          </p>
        </div>
      </div>
    </>
  );
};

// ── Logo / header ────────────────────────────────────────────────────────────

function LogoHeader({ isSignUp }: { isSignUp?: boolean }) {
  return (
    <div className="text-center space-y-2">
      {/* Hexagonal icon with cyan accent */}
      <div className="flex items-center justify-center mb-3">
        <div className="relative">
          <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">
            <polygon
              points="26,2 48,14 48,38 26,50 4,38 4,14"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="1.5"
              opacity="0.9"
            />
            <polygon
              points="26,10 40,18 40,34 26,42 12,34 12,18"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="0.5"
              opacity="0.4"
            />
            {/* Inner shield/lock mark */}
            <path
              d="M26 16 L33 19.5 V27 C33 31 26 35 26 35 C26 35 19 31 19 27 V19.5 Z"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="1.2"
              opacity="0.85"
            />
            <circle cx="26" cy="26" r="1.5" fill="#06b6d4" opacity="0.7" />
          </svg>
          {/* Glow */}
          <div
            className="absolute inset-0 rounded-full"
            style={{ boxShadow: '0 0 24px rgba(6,182,212,0.3)', zIndex: -1 }}
          />
        </div>
      </div>

      <h1 className="auth-logo text-2xl font-bold tracking-tight text-white">
        CRA <span style={{ color: '#06b6d4' }}>CDM</span>
      </h1>

      <p className="text-xs text-gray-500">
        {isSignUp ? 'Create your account' : 'Sign in to your account'}
      </p>
    </div>
  );
}

export default Auth;
