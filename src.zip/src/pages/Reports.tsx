import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { 
  FileText, 
  Filter, 
  Search, 
  Download,
  ChevronDown,
  Database,
  Calendar,
  BarChart4,
  PieChart,
  Shield,
  ArrowUpRight,
  FileSpreadsheet,
  Eye,
  Link,
  ExternalLink,
  AlertTriangle,
  CheckCircle,
  Monitor
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend,
  ResponsiveContainer,
  PieChart as RechartsPieChart, 
  Pie, 
  Cell
} from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DateRange } from 'react-day-picker';

const platformData = [
  { name: 'Windows Server', count: 42 },
  { name: 'Windows', count: 68 },
  { name: 'Ubuntu', count: 37 },
  { name: 'CentOS', count: 19 },
  { name: 'RHEL', count: 25 },
  { name: 'macOS', count: 14 }
];

const vulnerabilityData = [
  { name: 'Critical', value: 24, color: '#e53e3e' },
  { name: 'High', value: 45, color: '#dd6b20' },
  { name: 'Medium', value: 78, color: '#d69e2e' },
  { name: 'Low', value: 53, color: '#38a169' }
];

const categoryData = [
  { name: 'OS', count: 87 },
  { name: 'Applications', count: 65 },
  { name: 'Web Services', count: 42 },
  { name: 'Database', count: 31 },
  { name: 'Network', count: 22 }
];

const hostData = [
  { id: 'srv-001', name: 'APP-SERVER-001', ip: '192.168.1.10' },
  { id: 'srv-002', name: 'DB-SERVER-001', ip: '192.168.1.11' },
  { id: 'srv-003', name: 'APP-SERVER-002', ip: '192.168.1.12' },
  { id: 'srv-004', name: 'WEB-SERVER-001', ip: '192.168.1.13' },
  { id: 'srv-005', name: 'FILE-SERVER-001', ip: '192.168.1.14' },
  { id: 'wrk-001', name: 'WORKSTATION-001', ip: '192.168.2.10' },
  { id: 'wrk-002', name: 'WORKSTATION-002', ip: '192.168.2.11' }
];

const vulnerabilityDetails = [
  {
    id: 'CVE-2021-44228',
    title: 'Apache Log4j2 JNDI features vulnerability allowing arbitrary code execution',
    severity: 'Critical',
    cvss: 10.0,
    affectedSystems: 5,
    publishedDate: '2021-12-10',
    status: 'In Progress',
    description: 'Apache Log4j2 2.0-beta9 through 2.15.0 (excluding security releases 2.12.2, 2.12.3, and 2.3.1) JNDI features used in configuration, log messages, and parameters do not protect against attacker controlled LDAP and other JNDI related endpoints. An attacker who can control log messages or log message parameters can execute arbitrary code loaded from LDAP servers when message lookup substitution is enabled.',
    attackVector: 'The attack vector is through user-controlled input that is logged by an application using a vulnerable version of Log4j. This could be through HTTP headers, form fields, or any other input that gets logged.',
    impactAssessment: 'The impact of this vulnerability is severe as it allows for complete system compromise. In your environment, 5 servers are currently affected, including critical application servers that process customer data.',
    affectedDevices: [
      { id: 'SRV-001', hostname: 'APP-SERVER-001', ip: '192.168.1.10', platform: 'Ubuntu 20.04 LTS', status: 'Vulnerable' },
      { id: 'SRV-002', hostname: 'DB-SERVER-001', ip: '192.168.1.11', platform: 'CentOS 8.5', status: 'In Progress' },
      { id: 'SRV-003', hostname: 'APP-SERVER-002', ip: '192.168.1.12', platform: 'Ubuntu 20.04 LTS', status: 'Vulnerable' },
      { id: 'SRV-004', hostname: 'APP-SERVER-003', ip: '192.168.1.13', platform: 'Ubuntu 20.04 LTS', status: 'Vulnerable' },
      { id: 'SRV-005', hostname: 'APP-SERVER-004', ip: '192.168.1.14', platform: 'Ubuntu 20.04 LTS', status: 'Vulnerable' }
    ],
    affectedSoftware: [
      { vendor: 'Apache', product: 'Log4j', version: '2.0-beta9 through 2.15.0', cpe: 'cpe:2.3:a:apache:log4j:*:*:*:*:*:*:*:*' }
    ],
    remediationSteps: [
      { 
        title: 'Upgrade to Log4j 2.15.0 or later', 
        description: 'The recommended solution is to upgrade to Log4j 2.15.0 or later, which fixes the vulnerability.',
        confidence: 'High',
        details: [
          '# For Maven projects, update the dependency in pom.xml',
          '<dependency>',
          '    <groupId>org.apache.logging.log4j</groupId>',
          '    <artifactId>log4j-core</artifactId>',
          '    <version>2.15.0</version>',
          '</dependency>'
        ]
      },
      {
        title: 'Remove JndiLookup class from the classpath',
        description: 'If upgrading is not immediately possible, you can mitigate the vulnerability by removing the JndiLookup class from the classpath.',
        confidence: 'Medium',
        details: [
          'zip -q -d log4j-core-*.jar org/apache/logging/log4j/core/lookup/JndiLookup.class'
        ]
      },
      {
        title: 'Set system property to disable JNDI',
        description: 'For Log4j 2.10 and later, you can set the following system property to disable JNDI functionality.',
        confidence: 'Medium',
        details: [
          '-Dlog4j2.formatMsgNoLookups=true'
        ]
      }
    ],
    references: [
      { title: 'NVD - CVE-2021-44228', url: 'https://nvd.nist.gov/vuln/detail/CVE-2021-44228', description: 'National Vulnerability Database entry for CVE-2021-44228' },
      { title: 'Apache Log4j Security Vulnerabilities', url: 'https://logging.apache.org/log4j/2.x/security.html', description: 'Official Apache Log4j security page with details about the vulnerability and fixes' },
      { title: 'CISA Alert AA21-356A', url: 'https://www.cisa.gov/uscert/ncas/alerts/aa21-356a', description: 'CISA Alert: Mitigating Log4Shell and Other Log4j-Related Vulnerabilities' },
      { title: 'GitHub - Apache Log4j Security Vulnerabilities', url: 'https://github.com/apache/logging-log4j2/security/advisories', description: 'GitHub security advisories for Apache Log4j' }
    ]
  },
  {
    id: 'CVE-2023-23397',
    title: 'Microsoft Outlook for Windows vulnerability that could allow an attacker to access a user\'s Net-NTLMv2 hash',
    severity: 'Critical',
    cvss: 9.8,
    affectedSystems: 3,
    publishedDate: '2023-03-14',
    status: 'Open'
  },
  {
    id: 'CVE-2022-22965',
    title: 'Spring Framework RCE vulnerability via data binding on JDK 9+',
    severity: 'High',
    cvss: 8.5,
    affectedSystems: 2,
    publishedDate: '2022-03-31',
    status: 'Remediated'
  }
];

const Reports = () => {
  const [showReportSummary, setShowReportSummary] = useState(false);
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: undefined,
    to: undefined,
  });
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [selectedVulnerability, setSelectedVulnerability] = useState<any>(null);
  const [showVulnerabilityDetails, setShowVulnerabilityDetails] = useState(false);
  
  const totalVulnerabilities = vulnerabilityData.reduce((sum, item) => sum + item.value, 0);
  const riskScore = 76; // Sample risk score
  
  const handleGenerateReport = () => {
    setShowReportSummary(true);
  };
  
  const handleDownloadPDF = () => {
    // In a real application, this would generate and download a PDF file
    alert('Downloading PDF report...');
  };

  const handleViewDetails = (vulnerability: any) => {
    setSelectedVulnerability(vulnerability);
    setShowVulnerabilityDetails(true);
  };
  
  return (
    <PageContainer title="Reports">
      <div className="bg-cdm-darker rounded-lg p-6">
        <div className="flex items-center mb-5 text-gray-300">
          <FileText className="mr-2 text-blue-400" />
          <h2 className="text-xl">Security Reports</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <h3 className="text-gray-300 mb-2 flex items-center">
                <Database className="mr-2" size={18} />
                Categories
              </h3>
              <Select defaultValue="all">
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Platforms</SelectItem>
                  <SelectItem value="windows">Windows</SelectItem>
                  <SelectItem value="windows-server">Windows Server</SelectItem>
                  <SelectItem value="ubuntu">Ubuntu</SelectItem>
                  <SelectItem value="centos">CentOS</SelectItem>
                  <SelectItem value="rhel">RHEL</SelectItem>
                  <SelectItem value="macos">macOS</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <h3 className="text-gray-300 mb-2 flex items-center">
                <Database className="mr-2" size={18} />
                Devices
              </h3>
              <Select defaultValue="all">
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectValue placeholder="Select devices" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300 max-h-60">
                  <SelectItem value="all">All Devices</SelectItem>
                  {hostData.map((host) => (
                    <SelectItem key={host.id} value={host.id}>
                      {host.name} ({host.ip})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <h3 className="text-gray-300 mb-2 flex items-center">
                <Calendar className="mr-2" size={18} />
                Date
              </h3>
              <Select 
                defaultValue="last30days"
                onValueChange={(value) => {
                  if (value === 'custom') {
                    setIsCalendarOpen(true);
                  }
                }}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="last7days">Last 7 Days</SelectItem>
                  <SelectItem value="last30days">Last 30 Days</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
              {isCalendarOpen && (
                <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-2 bg-gray-700 border-gray-600 text-gray-300">
                      <Calendar className="mr-2 h-4 w-4" />
                      {dateRange?.from ? (
                        dateRange.to ? (
                          <>
                            {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                          </>
                        ) : (
                          format(dateRange.from, "LLL dd, y")
                        )
                      ) : (
                        <span>Pick a date range</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-gray-800 border-gray-700" align="start">
                    <CalendarComponent
                      initialFocus
                      mode="range"
                      defaultMonth={dateRange?.from}
                      selected={dateRange}
                      onSelect={setDateRange}
                      numberOfMonths={2}
                      className="bg-gray-800 text-white"
                    />
                  </PopoverContent>
                </Popover>
              )}
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <h3 className="text-gray-300 mb-2 flex items-center">
                <Shield className="mr-2" size={18} />
                Events
              </h3>
              <Select defaultValue="all">
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectValue placeholder="Select events" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Events</SelectItem>
                  <SelectItem value="vulnerabilities">Vulnerabilities</SelectItem>
                  <SelectItem value="ports">Port Events</SelectItem>
                  <SelectItem value="system">System Changes</SelectItem>
                  <SelectItem value="users">User Changes</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
          
          <div className="flex flex-col gap-2">
            <Button onClick={handleGenerateReport} className="bg-blue-600 hover:bg-blue-700">
              <Filter className="mr-2" size={16} />
              Generate Report
            </Button>
          </div>
        </div>
        
        {showReportSummary && (
          <>
            <div className="bg-gray-800 p-4 rounded-lg mb-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg text-white font-semibold">Report Summary</h3>
                <Button onClick={handleDownloadPDF} className="bg-green-600 hover:bg-green-700">
                  <FileSpreadsheet className="mr-2" size={16} />
                  Generate PDF Report
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card className="bg-gray-750 border-gray-600">
                  <CardContent className="p-4">
                    <h4 className="text-gray-300 text-sm uppercase">Total Vulnerabilities</h4>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-3xl font-bold text-white">{totalVulnerabilities}</span>
                      <Shield className="text-red-500" size={24} />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-750 border-gray-600">
                  <CardContent className="p-4">
                    <h4 className="text-gray-300 text-sm uppercase">Devices with Issues</h4>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-3xl font-bold text-white">38</span>
                      <Database className="text-yellow-500" size={24} />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-750 border-gray-600">
                  <CardContent className="p-4">
                    <h4 className="text-gray-300 text-sm uppercase">Cumulative Risk Score</h4>
                    <div className="flex items-center justify-between mt-2">
                      <span className={`text-3xl font-bold ${
                        riskScore > 75 ? 'text-red-500' : 
                        riskScore > 50 ? 'text-yellow-500' : 
                        'text-green-500'
                      }`}>{riskScore}</span>
                      <div className="relative w-24 h-6 bg-gray-700 rounded-full overflow-hidden">
                        <div 
                          className={`absolute top-0 left-0 h-full ${
                            riskScore > 75 ? 'bg-red-500' : 
                            riskScore > 50 ? 'bg-yellow-500' : 
                            'bg-green-500'
                          }`}
                          style={{ width: `${riskScore}%` }}
                        ></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Tabs defaultValue="vulnerabilities" className="w-full">
                <TabsList className="bg-gray-700 border-gray-600">
                  <TabsTrigger value="vulnerabilities" className="data-[state=active]:bg-gray-600">
                    Vulnerabilities
                  </TabsTrigger>
                  <TabsTrigger value="platforms" className="data-[state=active]:bg-gray-600">
                    Platforms
                  </TabsTrigger>
                  <TabsTrigger value="categories" className="data-[state=active]:bg-gray-600">
                    Categories
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="vulnerabilities" className="mt-4">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsPieChart>
                        <Pie
                          data={vulnerabilityData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {vulnerabilityData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Legend />
                        <RechartsTooltip />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </div>
                </TabsContent>
                
                <TabsContent value="platforms" className="mt-4">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={platformData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                        <XAxis dataKey="name" stroke="#aaa" />
                        <YAxis stroke="#aaa" />
                        <RechartsTooltip />
                        <Legend />
                        <Bar dataKey="count" name="Vulnerabilities" fill="#4299e1" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </TabsContent>
                
                <TabsContent value="categories" className="mt-4">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={categoryData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                        <XAxis dataKey="name" stroke="#aaa" />
                        <YAxis stroke="#aaa" />
                        <RechartsTooltip />
                        <Legend />
                        <Bar dataKey="count" name="Issues" fill="#48bb78" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg">
              <h3 className="text-lg text-white font-semibold mb-4">Vulnerability Details</h3>
              
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-850">
                    <TableRow>
                      <TableHead className="text-gray-300">CVE ID</TableHead>
                      <TableHead className="text-gray-300">Description</TableHead>
                      <TableHead className="text-gray-300">Severity</TableHead>
                      <TableHead className="text-gray-300">CVSS</TableHead>
                      <TableHead className="text-gray-300">Affected Systems</TableHead>
                      <TableHead className="text-gray-300">Published Date</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {vulnerabilityDetails.map((vuln) => (
                      <TableRow key={vuln.id} className="hover:bg-gray-750 border-gray-700">
                        <TableCell className="font-medium text-gray-300">{vuln.id}</TableCell>
                        <TableCell className="text-gray-300 max-w-sm truncate">{vuln.title}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            vuln.severity === 'Critical' ? 'bg-red-900 text-red-300' :
                            vuln.severity === 'High' ? 'bg-orange-900 text-orange-300' :
                            vuln.severity === 'Medium' ? 'bg-yellow-900 text-yellow-300' :
                            'bg-green-900 text-green-300'
                          }`}>
                            {vuln.severity}
                          </span>
                        </TableCell>
                        <TableCell className="text-gray-300">{vuln.cvss}</TableCell>
                        <TableCell className="text-gray-300">{vuln.affectedSystems} devices</TableCell>
                        <TableCell className="text-gray-300">{vuln.publishedDate}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            vuln.status === 'Open' ? 'bg-red-900 text-red-300' :
                            vuln.status === 'In Progress' ? 'bg-yellow-900 text-yellow-300' :
                            'bg-green-900 text-green-300'
                          }`}>
                            {vuln.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" onClick={() => handleViewDetails(vuln)} className="h-8 px-2 text-blue-400 hover:text-blue-300 hover:bg-gray-700">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </>
        )}
      </div>

      <Dialog open={showVulnerabilityDetails} onOpenChange={setShowVulnerabilityDetails}>
        <DialogContent className="bg-gray-800 text-white border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center">
              <span className="mr-2">Vulnerability Details: {selectedVulnerability?.id}</span>
              <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
                selectedVulnerability?.severity === 'Critical' ? 'bg-red-900 text-red-300' :
                selectedVulnerability?.severity === 'High' ? 'bg-orange-900 text-orange-300' :
                selectedVulnerability?.severity === 'Medium' ? 'bg-yellow-900 text-yellow-300' :
                'bg-green-900 text-green-300'
              }`}>
                {selectedVulnerability?.severity}
              </span>
            </DialogTitle>
          </DialogHeader>

          {selectedVulnerability?.id === 'CVE-2021-44228' && (
            <div className="mt-4 space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <div>
                    <p className="text-sm text-gray-400">CVSS Score: {selectedVulnerability.cvss}</p>
                    <p className="text-sm text-gray-400">Published: {selectedVulnerability.publishedDate}</p>
                    <p className="text-sm text-gray-400">Last Modified: Dec 20, 2021</p>
                    <p className="text-sm text-gray-400">Source: NVD</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      <FileSpreadsheet className="mr-2 h-4 w-4" />
                      Export
                    </Button>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Remediate
                    </Button>
                  </div>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Description</h3>
                <p className="text-gray-300">{selectedVulnerability.description}</p>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">AI Analysis</h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-md font-medium text-gray-300">Vulnerability Summary</h4>
                    <p className="text-gray-400">This is a critical remote code execution vulnerability in Apache Log4j, a popular Java logging library. The vulnerability allows attackers to execute arbitrary code on affected systems by sending specially crafted requests that include malicious JNDI lookup patterns.</p>
                  </div>
                  
                  <div>
                    <h4 className="text-md font-medium text-gray-300">Attack Vector</h4>
                    <p className="text-gray-400">{selectedVulnerability.attackVector}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-md font-medium text-gray-300">Impact Assessment</h4>
                    <p className="text-gray-400">{selectedVulnerability.impactAssessment}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">CVSS Metrics</h3>
                <p className="text-xl font-bold text-white mb-2">10.0</p>
                <p className="text-gray-400 mb-2">CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H</p>
                
                <div className="space-y-1">
                  <h4 className="text-md font-medium text-gray-300">Base Score Metrics</h4>
                  <p className="text-gray-400">Attack Vector: Network</p>
                  <p className="text-gray-400">Attack Complexity: Low</p>
                  <p className="text-gray-400">User Interaction: None</p>
                </div>

                <div className="mt-4 space-y-1">
                  <h4 className="text-md font-medium text-gray-300">Impact Metrics</h4>
                  <p className="text-gray-400">Scope: Changed</p>
                  <p className="text-gray-400">Confidentiality: High</p>
                  <p className="text-gray-400">Integrity: High</p>
                  <p className="text-gray-400">Availability: High</p>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Affected Software</h3>
                <Table>
                  <TableHeader className="bg-gray-800">
                    <TableRow>
                      <TableHead className="text-gray-300">Vendor</TableHead>
                      <TableHead className="text-gray-300">Product</TableHead>
                      <TableHead className="text-gray-300">Version</TableHead>
                      <TableHead className="text-gray-300">CPE</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedVulnerability.affectedSoftware.map((software, index) => (
                      <TableRow key={index} className="border-gray-700">
                        <TableCell className="text-gray-300">{software.vendor}</TableCell>
                        <TableCell className="text-gray-300">{software.product}</TableCell>
                        <TableCell className="text-gray-300">{software.version}</TableCell>
                        <TableCell className="text-gray-300 font-mono text-xs">{software.cpe}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-medium">Affected Devices</h3>
                  <Button variant="outline" size="sm" className="h-8 px-2 text-gray-300 hover:text-white hover:bg-gray-700">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
                <Table>
                  <TableHeader className="bg-gray-800">
                    <TableRow>
                      <TableHead className="text-gray-300">Device ID</TableHead>
                      <TableHead className="text-gray-300">Hostname</TableHead>
                      <TableHead className="text-gray-300">IP Address</TableHead>
                      <TableHead className="text-gray-300">Platform</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedVulnerability.affectedDevices.map((device) => (
                      <TableRow key={device.id} className="border-gray-700">
                        <TableCell className="text-gray-300">{device.id}</TableCell>
                        <TableCell className="text-gray-300">{device.hostname}</TableCell>
                        <TableCell className="text-gray-300">{device.ip}</TableCell>
                        <TableCell className="text-gray-300">{device.platform}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            device.status === 'Vulnerable' ? 'bg-red-900 text-red-300' :
                            device.status === 'In Progress' ? 'bg-yellow-900 text-yellow-300' :
                            'bg-green-900 text-green-300'
                          }`}>
                            {device.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" className="h-8 px-2 text-gray-300 hover:text-white hover:bg-gray-700">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Remediation Steps</h3>
                <div className="space-y-4">
                  {selectedVulnerability.remediationSteps.map((step, index) => (
                    <div key={index} className="border border-gray-700 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-blue-900 rounded-full p-2">
                          <Shield className="h-5 w-5 text-blue-300" />
                        </div>
                        <div>
                          <div className="flex items-center mb-1">
                            <h4 className="font-medium text-white">{step.title}</h4>
                            <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                              step.confidence === 'High' ? 'bg-green-900 text-green-300' :
                              step.confidence === 'Medium' ? 'bg-yellow-900 text-yellow-300' :
                              'bg-orange-900 text-orange-300'
                            }`}>
                              Confidence: {step.confidence}
                            </span>
                          </div>
                          <p className="text-gray-400 mb-2">{step.description}</p>
                          <div className="bg-gray-900 p-3 rounded font-mono text-sm text-gray-300 mt-2">
                            {step.details.map((line, i) => (
                              <div key={i}>{line}</div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Automated Remediation</h3>
                <p className="text-gray-300 mb-4">CRA CDM can automatically apply the recommended remediation to affected systems. Select the systems to remediate and click "Start Remediation".</p>
                
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="selectAll" className="rounded bg-gray-700 border-gray-600 text-blue-500" />
                    <label htmlFor="selectAll" className="ml-2 text-gray-300">Select All</label>
                  </div>
                  <p className="text-gray-400 text-sm">5 systems selected</p>
                  
                  {selectedVulnerability.affectedDevices.map((device) => (
                    <div key={device.id} className="flex items-center">
                      <input type="checkbox" id={device.id} className="rounded bg-gray-700 border-gray-600 text-blue-500" defaultChecked />
                      <label htmlFor={device.id} className="ml-2 text-gray-300">{device.id} ({device.hostname}) - {device.platform}</label>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                    Schedule
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Start Remediation
                  </Button>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">References</h3>
                <div className="space-y-3">
                  {selectedVulnerability.references.map((ref, index) => (
                    <div key={index} className="flex items-start">
                      <Link className="text-gray-400 mr-2 mt-1 flex-shrink-0" size={16} />
                      <div>
                        <a href={ref.url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline flex items-center">
                          {ref.title}
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                        <p className="text-gray-400 text-sm">{ref.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="mt-6">
            <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700" onClick={() => setShowVulnerabilityDetails(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
};

export default Reports;
