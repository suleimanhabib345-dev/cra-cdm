
import React, { useEffect, useState } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import MetricCard from '@/components/MetricCard';
import VulnerabilityPieChart from '@/components/VulnerabilityPieChart';
import AlertsTable from '@/components/AlertsTable';
import TopRiskHosts from '@/components/TopRiskHosts';
import { Shield, Monitor, AlertTriangle, Users } from 'lucide-react';
import { api } from '@/utils/api';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

const Index = () => {
  const { user } = useAuth();
  const [dashboardStats, setDashboardStats] = useState({
    criticalVulnerabilities: 0,
    criticalVulnTrend: 0,
    connectedAgents: 0,
    connectedAgentsTrend: 0,
    activeIncidents: 0,
    activeIncidentsTrend: 0,
    totalUsers: 0,
    totalUsersTrend: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get company ID for filtering
        let companyId: string | null = null;
        
        try {
          // Attempt to get the current user's company ID
          const { data: profile } = await supabase
            .from('profiles')
            .select('company_id')
            .eq('id', user?.id || '')
            .single();
          
          companyId = profile?.company_id || null;
        } catch (error) {
          console.error("Error fetching user company:", error);
        }
        
        // Fetch critical vulnerabilities (filtered by company agents)
        let vulnQuery = supabase
          .from('device_vulnerabilities')
          .select('id, vulnerability:vulnerabilities!inner(*), agent:agents!device_id(company_id)')
          .eq('vulnerability.severity', 'critical')
          .is('patched_at', null);
        if (companyId) {
          vulnQuery = vulnQuery.eq('agent.company_id', companyId);
        }
        const { data: criticalVulns } = await vulnQuery;
        
        // Fetch connected agents
        let agentQuery = supabase
          .from('agents')
          .select('id')
          .eq('status', 'online');
        if (companyId) {
          agentQuery = agentQuery.eq('company_id', companyId);
        }
        const { data: connectedDevices } = await agentQuery;
        
        // Fetch active incidents
        const { data: incidents } = await supabase
          .from('incidents')
          .select('id')
          .in('status', ['open', 'in_progress']);
        
        // Fetch users (filtered by company)
        let usersQuery = supabase
          .from('profiles')
          .select('id');
        if (companyId) {
          usersQuery = usersQuery.eq('company_id', companyId);
        }
        const { data: users } = await usersQuery;
        
        // Set dashboard stats
        setDashboardStats({
          criticalVulnerabilities: criticalVulns?.length || 0,
          criticalVulnTrend: -12, // Hardcoded for now, could be calculated
          connectedAgents: connectedDevices?.length || 0,
          connectedAgentsTrend: 5, // Hardcoded for now
          activeIncidents: incidents?.length || 0,
          activeIncidentsTrend: -2, // Hardcoded for now
          totalUsers: users?.length || 0,
          totalUsersTrend: 8 // Hardcoded for now
        });
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
        // Use default values in case of error
        setDashboardStats({
          criticalVulnerabilities: 12,
          criticalVulnTrend: -5,
          connectedAgents: 45,
          connectedAgentsTrend: 8,
          activeIncidents: 7,
          activeIncidentsTrend: -3,
          totalUsers: 24,
          totalUsersTrend: 6
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  return (
    <div className="flex h-screen bg-cdm-dark text-white overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6 grid-bg">
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">Dashboard</h1>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="card bg-cdm-darker p-4 rounded-lg">
                <MetricCard 
                  title="Critical Vulnerabilities" 
                  value={dashboardStats.criticalVulnerabilities} 
                  trend={dashboardStats.criticalVulnTrend} 
                  icon={<Shield size={20} className="text-white" />} 
                  iconColor="bg-destructive"
                />
              </div>
              
              <div className="card bg-cdm-darker p-4 rounded-lg">
                <MetricCard 
                  title="Connected Agents" 
                  value={dashboardStats.connectedAgents} 
                  trend={dashboardStats.connectedAgentsTrend} 
                  icon={<Monitor size={20} className="text-white" />} 
                  iconColor="bg-chart-green"
                />
              </div>
              
              <div className="card bg-cdm-darker p-4 rounded-lg">
                <MetricCard 
                  title="Active Incidents" 
                  value={dashboardStats.activeIncidents} 
                  trend={dashboardStats.activeIncidentsTrend} 
                  icon={<AlertTriangle size={20} className="text-white" />} 
                  iconColor="bg-chart-yellow"
                />
              </div>
              
              <div className="card bg-cdm-darker p-4 rounded-lg">
                <MetricCard 
                  title="Total Users" 
                  value={dashboardStats.totalUsers} 
                  trend={dashboardStats.totalUsersTrend} 
                  icon={<Users size={20} className="text-white" />} 
                  iconColor="bg-chart-blue"
                />
              </div>
            </div>
            
            <TopRiskHosts />

            <div className="bg-cdm-darker p-6 rounded-lg">
              <VulnerabilityPieChart />
            </div>

            <div className="bg-cdm-darker p-6 rounded-lg">
              <AlertsTable />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;
