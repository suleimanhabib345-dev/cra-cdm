import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { 
  Download, 
  Monitor, 
  Terminal, 
  Apple, 
  Github,
  Server,
  ChevronDown,
  ChevronUp,
  Calendar,
  Laptop,
  Monitor as WindowsIcon
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const DownloadAgents = () => {
  const [activeTab, setActiveTab] = useState('download');
  const [showRequirements, setShowRequirements] = useState(false);
  
  const handleDownload = (platform: string) => {
    alert(`Downloading CRA agent for ${platform}...`);
  };
  
  return (
    <PageContainer title="Download Agents">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="download" className="data-[state=active]:bg-gray-700">
            Download Agent
          </TabsTrigger>
          <TabsTrigger value="installation" className="data-[state=active]:bg-gray-700">
            Installation Instructions
          </TabsTrigger>
          <TabsTrigger value="management" className="data-[state=active]:bg-gray-700">
            Agent Management
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="download" className="mt-4">
          <div className="bg-cdm-darker rounded-lg p-6">
            <div className="flex items-center mb-5 text-gray-300">
              <Download className="mr-2 text-blue-400" />
              <h2 className="text-xl">Download CRA Agent</h2>
            </div>
            <p className="text-gray-400 mb-5">
              Download the CRA monitoring agent for your operating system. Our agents are built using Go and are compatible with all major platforms.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <div className="bg-gray-700 p-4 rounded-full mb-4">
                      <Laptop className="text-blue-400" size={32} />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">Linux Agent</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Compatible with Ubuntu, CentOS, RHEL, Debian and other major Linux distributions.
                    </p>
                    <Button 
                      onClick={() => handleDownload('Linux')}
                      className="bg-blue-600 hover:bg-blue-700 w-full mb-2"
                    >
                      <Download className="mr-2" size={16} />
                      cra-agent-linux.sh
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setShowRequirements(true)}
                      className="bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-300 w-full"
                    >
                      View Requirements
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <div className="bg-gray-700 p-4 rounded-full mb-4">
                      <WindowsIcon className="text-blue-400" size={32} />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">Windows Agent</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Compatible with Windows Server and Windows desktop operating systems.
                    </p>
                    <Button 
                      onClick={() => handleDownload('Windows')}
                      className="bg-blue-600 hover:bg-blue-700 w-full mb-2"
                    >
                      <Download className="mr-2" size={16} />
                      cra-agent-windows.exe
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setShowRequirements(true)}
                      className="bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-300 w-full"
                    >
                      View Requirements
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <div className="bg-gray-700 p-4 rounded-full mb-4">
                      <Apple className="text-blue-400" size={32} />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">macOS Agent</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Compatible with macOS 11 Big Sur and newer versions.
                    </p>
                    <Button 
                      onClick={() => handleDownload('macOS')}
                      className="bg-blue-600 hover:bg-blue-700 w-full mb-2"
                    >
                      <Download className="mr-2" size={16} />
                      cra-agent-macos.pkg
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setShowRequirements(true)}
                      className="bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-300 w-full"
                    >
                      View Requirements
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="mt-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center mb-2">
                    <Github className="mr-2 text-gray-300" size={20} />
                    <h3 className="text-lg font-semibold text-white">Source Code</h3>
                  </div>
                  <p className="text-gray-400 mb-4">
                    CRA agent is open-source. You can access the source code on GitHub and build it yourself.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button variant="outline" className="bg-gray-700 text-gray-300 hover:bg-gray-600">
                      <Github className="mr-2" size={16} />
                      View on GitHub
                    </Button>
                    <Button variant="outline" className="bg-gray-700 text-gray-300 hover:bg-gray-600">
                      <Download className="mr-2" size={16} />
                      Download Source (.zip)
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Dialog open={showRequirements} onOpenChange={setShowRequirements}>
              <DialogContent className="bg-gray-800 text-white border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-xl">Agent Requirements</DialogTitle>
                </DialogHeader>
                <div className="my-4">
                  <h3 className="text-lg font-medium mb-2">System Requirements</h3>
                  <Card className="bg-gray-750 border-gray-700 mb-4">
                    <CardContent className="p-4">
                      <h4 className="text-md font-medium mb-2">Minimum Hardware Requirements</h4>
                      <ul className="list-disc pl-5 text-gray-300 space-y-1">
                        <li>CPU: 1 core</li>
                        <li>RAM: 256MB free memory</li>
                        <li>Disk: 100MB free space</li>
                        <li>Network: Internet connection for updates and reporting</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-750 border-gray-700">
                    <CardContent className="p-4">
                      <h4 className="text-md font-medium mb-2">Software Dependencies</h4>
                      <div className="space-y-4">
                        <pre className="bg-gray-850 p-3 rounded text-sm overflow-x-auto text-gray-300">
{`# CRA Agent requirements.txt
go >= 1.16.0  # Go runtime
openssl >= 1.1.1  # For secure communications
`}
                        </pre>
                        <p className="text-gray-400 text-sm">
                          The CRA agent binary is self-contained and does not require additional runtime dependencies 
                          after installation. The Go runtime is only required for building from source.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </TabsContent>
        
        <TabsContent value="installation" className="mt-4">
          <div className="bg-cdm-darker rounded-lg p-6">
            <div className="flex items-center mb-5 text-gray-300">
              <Terminal className="mr-2 text-green-400" />
              <h2 className="text-xl">Installation Instructions</h2>
            </div>
            <p className="text-gray-400 mb-5">
              Follow these instructions to install the CRA agent on your system. The agent is built with Go and requires minimal setup.
            </p>
            
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="golang" className="border-gray-700">
                <AccordionTrigger className="text-white hover:bg-gray-750 px-4 py-2 rounded-md">
                  Installing Go (Required for Building from Source)
                </AccordionTrigger>
                <AccordionContent className="bg-gray-750 p-4 rounded-md mt-2 text-gray-300">
                  <div className="space-y-4">
                    <p>If you want to build the agent from source, you'll need to install Go first. The prebuilt agents do not require Go to be installed.</p>
                    
                    <div>
                      <h4 className="font-semibold mb-2">Linux (Ubuntu/Debian)</h4>
                      <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Install Go
sudo apt update
sudo apt install golang-go

# Verify installation
go version`}
                      </pre>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold mb-2">Linux (RHEL/CentOS)</h4>
                      <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Install Go
sudo yum install golang

# Verify installation
go version`}
                      </pre>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold mb-2">macOS (using Homebrew)</h4>
                      <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Go
brew update
brew install go

# Verify installation
go version`}
                      </pre>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold mb-2">Windows</h4>
                      <p className="mb-2">Download and install Go from the official website:</p>
                      <p className="mb-4 text-blue-400 hover:underline cursor-pointer">https://golang.org/dl/</p>
                      <p className="mb-2">After installation, verify Go is installed by opening Command Prompt and typing:</p>
                      <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`go version`}
                      </pre>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="linux" className="border-gray-700 mt-2">
                <AccordionTrigger className="text-white hover:bg-gray-750 px-4 py-2 rounded-md">
                  Installing on Linux
                </AccordionTrigger>
                <AccordionContent className="bg-gray-750 p-4 rounded-md mt-2 text-gray-300">
                  <h4 className="font-semibold mb-2">Using the Installation Script</h4>
                  <p className="mb-2">The easiest way to install the CRA agent on Linux is using our installation script:</p>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Download the installation script
wget https://cra.com/downloads/cra-agent-linux.sh
chmod +x cra-agent-linux.sh

# Install the agent (requires sudo privileges)
sudo ./cra-agent-linux.sh install --server-url=https://your-cra-server.com --api-key=YOUR_API_KEY`}
                  </pre>
                  
                  <h4 className="font-semibold mb-2 mt-4">Manual Installation</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Download the binary
wget https://cra.com/downloads/cra-agent-linux.tar.gz
tar -xzf cra-agent-linux.tar.gz
cd cra-agent

# Configure the agent
cp config.example.yaml config.yaml
# Edit config.yaml with your favorite editor to set server URL and API key

# Install the agent as a service
sudo ./install.sh

# Start the service
sudo systemctl start cra-agent

# Enable on boot
sudo systemctl enable cra-agent`}
                  </pre>
                  
                  <h4 className="font-semibold mb-2 mt-4">Verify Installation</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Check service status
sudo systemctl status cra-agent

# View logs
sudo journalctl -u cra-agent -f`}
                  </pre>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="windows" className="border-gray-700 mt-2">
                <AccordionTrigger className="text-white hover:bg-gray-750 px-4 py-2 rounded-md">
                  Installing on Windows
                </AccordionTrigger>
                <AccordionContent className="bg-gray-750 p-4 rounded-md mt-2 text-gray-300">
                  <h4 className="font-semibold mb-2">Using the Windows Installer</h4>
                  <p className="mb-4">
                    The CRA agent for Windows comes with an easy-to-use installer:
                  </p>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>Download the Windows installer (cra-agent-windows.exe) from the download section</li>
                    <li>Right-click the installer and select "Run as administrator"</li>
                    <li>Follow the installation wizard</li>
                    <li>When prompted, enter your CRA server URL and API key</li>
                    <li>Complete the installation</li>
                  </ol>
                  
                  <h4 className="font-semibold mb-2 mt-4">Manual Installation</h4>
                  <p className="mb-2">Advanced users can manually install the agent:</p>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Open PowerShell as Administrator

# Download the ZIP package
Invoke-WebRequest -Uri "https://cra.com/downloads/cra-agent-windows.zip" -OutFile "cra-agent-windows.zip"

# Extract the ZIP file
Expand-Archive -Path "cra-agent-windows.zip" -DestinationPath "C:\\Program Files\\CRA"

# Navigate to the agent directory
cd "C:\\Program Files\\CRA"

# Edit the configuration file
notepad config.yaml

# Install the service
.\\install-service.ps1

# Start the service
Start-Service CRAAgent`}
                  </pre>
                  
                  <h4 className="font-semibold mb-2 mt-4">Verify Installation</h4>
                  <p className="mb-2">To verify the agent is running properly:</p>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>Open Services (services.msc)</li>
                    <li>Look for "CRA Agent" service</li>
                    <li>Verify it's running with "Started" status</li>
                    <li>Check logs at C:\Program Files\CRA\logs\cra-agent.log</li>
                  </ol>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="macos" className="border-gray-700 mt-2">
                <AccordionTrigger className="text-white hover:bg-gray-750 px-4 py-2 rounded-md">
                  Installing on macOS
                </AccordionTrigger>
                <AccordionContent className="bg-gray-750 p-4 rounded-md mt-2 text-gray-300">
                  <h4 className="font-semibold mb-2">Using the macOS Package Installer</h4>
                  <p className="mb-4">
                    The CRA agent for macOS comes with a standard .pkg installer:
                  </p>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>Download the macOS package (cra-agent-macos.pkg) from the download section</li>
                    <li>Double-click the package file to start the installer</li>
                    <li>Follow the installation instructions</li>
                    <li>When prompted, enter your CRA server URL and API key</li>
                    <li>Provide administrator credentials when requested</li>
                    <li>Complete the installation</li>
                  </ol>
                  
                  <h4 className="font-semibold mb-2 mt-4">Using the Terminal</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Download the installation script
curl -O https://cra.com/downloads/cra-agent-macos.sh
chmod +x cra-agent-macos.sh

# Install the agent (requires sudo privileges)
sudo ./cra-agent-macos.sh install --server-url=https://your-cra-server.com --api-key=YOUR_API_KEY`}
                  </pre>
                  
                  <h4 className="font-semibold mb-2 mt-4">Verify Installation</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Check if the agent is running
launchctl list | grep cra

# View logs
cat /Library/Logs/CRA/agent.log`}
                  </pre>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="build" className="border-gray-700 mt-2">
                <AccordionTrigger className="text-white hover:bg-gray-750 px-4 py-2 rounded-md">
                  Building from Source
                </AccordionTrigger>
                <AccordionContent className="bg-gray-750 p-4 rounded-md mt-2 text-gray-300">
                  <p className="mb-4">
                    Advanced users can build the CRA agent from source code. This requires Go 1.16 or later.
                  </p>
                  
                  <h4 className="font-semibold mb-2">Clone the Repository</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`git clone https://github.com/cra/agent.git
cd agent`}
                  </pre>
                  
                  <h4 className="font-semibold mb-2">Build the Agent</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Install dependencies
go mod download

# Build for your current platform
go build -o cra-agent cmd/agent/main.go

# Cross-compile for other platforms (optional)
# For Windows
GOOS=windows GOARCH=amd64 go build -o cra-agent.exe cmd/agent/main.go

# For macOS
GOOS=darwin GOARCH=amd64 go build -o cra-agent-macos cmd/agent/main.go

# For Linux
GOOS=linux GOARCH=amd64 go build -o cra-agent-linux cmd/agent/main.go`}
                  </pre>
                  
                  <h4 className="font-semibold mb-2">Configure and Run</h4>
                  <pre className="bg-gray-800 p-3 rounded text-sm mb-4 overflow-x-auto">
{`# Copy the example config
cp config.example.yaml config.yaml

# Edit the config file with your details
# Then run the agent
./cra-agent --config=config.yaml`}
                  </pre>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="troubleshooting" className="border-gray-700 mt-2">
                <AccordionTrigger className="text-white hover:bg-gray-750 px-4 py-2 rounded-md">
                  Troubleshooting
                </AccordionTrigger>
                <AccordionContent className="bg-gray-750 p-4 rounded-md mt-2 text-gray-300">
                  <h4 className="font-semibold mb-2">Common Issues</h4>
                  <ul className="list-disc pl-6 space-y-4">
                    <li>
                      <strong>Agent not connecting to server:</strong>
                      <p className="mt-1">Check your network connectivity and firewall settings. The agent needs to connect to the server on port 443 (HTTPS).</p>
                      <pre className="bg-gray-800 p-2 rounded text-sm mt-2 overflow-x-auto">
{`# Test connectivity to the server
curl -v https://your-cra-server.com/api/v1/health`}
                      </pre>
                    </li>
                    <li>
                      <strong>Installation fails with permission errors:</strong>
                      <p className="mt-1">Make sure you're running the installer with administrator/root privileges.</p>
                    </li>
                    <li>
                      <strong>Agent crashes or stops unexpectedly:</strong>
                      <p className="mt-1">Check the agent logs for more information:</p>
                      <pre className="bg-gray-800 p-2 rounded text-sm mt-2 overflow-x-auto">
{`# Linux
journalctl -u cra-agent

# Windows
Check Event Viewer under Application logs or
Review C:\\Program Files\\CRA\\logs\\cra-agent.log

# macOS
cat /Library/Logs/CRA/agent.log`}
                      </pre>
                    </li>
                    <li>
                      <strong>API Key validation error:</strong>
                      <p className="mt-1">Verify that you're using the correct API key for your environment. API keys are environment-specific and cannot be reused across different environments.</p>
                    </li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </TabsContent>
        
        <TabsContent value="management" className="mt-4">
          <div className="bg-cdm-darker rounded-lg p-6">
            <div className="flex items-center mb-5 text-gray-300">
              <Monitor className="mr-2 text-purple-400" />
              <h2 className="text-xl">Agent Management</h2>
            </div>
            <p className="text-gray-400 mb-5">
              Manage and monitor your deployed CRA agents.
            </p>
            
            <div className="bg-gray-800 border-gray-700 p-6 rounded-lg text-center">
              <p className="text-gray-300">Agent management interface will be displayed here once you have agents deployed.</p>
              <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                <Download className="mr-2" size={16} />
                Deploy Your First Agent
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
};

export default DownloadAgents;
