import React, { useState, lazy, Suspense } from 'react';
import PageContainer from '@/components/PageContainer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  BarChart,
  Download,
  Search,
  Info,
  CheckCircle,
  XCircle,
  AlertCircle,
  Monitor,
  Laptop,
  Apple
} from 'lucide-react';
import { useAgentsData } from '@/hooks/useAgentsData';

const Agents = () => {
  const [searchValue, setSearchValue] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [platformFilter, setPlatformFilter] = useState('all');

  const {
    agents,
    recentInstallations,
    platforms,
    statusOverview,
    isLoading
  } = useAgentsData();

  const filteredAgents = agents.filter(agent => {
    const matchesSearch = searchValue === '' ||
      agent.hostname.toLowerCase().includes(searchValue.toLowerCase()) ||
      agent.ip_address.toLowerCase().includes(searchValue.toLowerCase());

    const matchesStatus = statusFilter === 'all' || agent.status === statusFilter;
    const matchesPlatform = platformFilter === 'all' ||
      (platformFilter === 'windows' && agent.platform.includes('Windows')) ||
      (platformFilter === 'linux' && (agent.platform.includes('Ubuntu') || agent.platform.includes('CentOS'))) ||
      (platformFilter === 'macos' && agent.platform.includes('macOS'));

    return matchesSearch && matchesStatus && matchesPlatform;
  });

  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-900 text-green-300';
      case 'Inactive': return 'bg-red-900 text-red-300';
      case 'Needs Update': return 'bg-yellow-900 text-yellow-300';
      default: return 'bg-gray-900 text-gray-300';
    }
  };

  if (isLoading) {
    return (
      <PageContainer title="Agents Management">
        <div className="flex items-center justify-center h-64 text-gray-400">
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 border-2 border-gray-600 border-t-red-500 rounded-full animate-spin" />
            <span>Loading agents...</span>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer title="Agents Management">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
            <BarChart className="mr-2 h-4 w-4" />
            Agent Management
          </TabsTrigger>
          <TabsTrigger value="download" className="data-[state=active]:bg-gray-700">
            <Download className="mr-2 h-4 w-4" />
            Download Agent
          </TabsTrigger>
          <TabsTrigger value="installation" className="data-[state=active]:bg-gray-700">
            <Info className="mr-2 h-4 w-4" />
            Installation Guide
          </TabsTrigger>
        </TabsList>

        {/* AGENT MANAGEMENT TAB */}
        <TabsContent value="overview">
          <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
            <div className="bg-gray-800 p-6 rounded-lg">
              <h2 className="text-xl text-white font-semibold mb-4">Agent Status Overview</h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {statusOverview.map((item, index) => (
                  <Card key={index} className="bg-gray-750 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-sm text-gray-400">Agents</h3>
                          <div className="text-2xl font-bold text-white">{item.count}</div>
                          <div className="text-xs text-gray-500">{item.percentage}% of total</div>
                        </div>
                        <div className="rounded-full p-2 bg-gray-700">
                          {item.status === 'Active' && <CheckCircle className="h-6 w-6 text-green-500" />}
                          {item.status === 'Inactive' && <XCircle className="h-6 w-6 text-red-500" />}
                          {item.status === 'Needs Update' && <AlertCircle className="h-6 w-6 text-yellow-500" />}
                        </div>
                      </div>
                      <div className="mt-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${getStatusBadgeStyle(item.status)}`}>
                          {item.status}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-2">
                <h3 className="text-lg text-white font-semibold">All Agents</h3>
                <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
                  <Select defaultValue="all" onValueChange={setPlatformFilter}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                      <SelectValue placeholder="Filter by platform" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                      {platforms.map((platform) => (
                        <SelectItem key={platform.id} value={platform.name}>
                          {platform.display_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select defaultValue="all" onValueChange={setStatusFilter}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                      <SelectItem value="Needs Update">Needs Update</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Search agents..."
                      className="bg-gray-700 border-gray-600 text-gray-300 pl-8"
                      value={searchValue}
                      onChange={(e) => setSearchValue(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-850">
                    <TableRow>
                      <TableHead className="text-gray-300">Hostname</TableHead>
                      <TableHead className="text-gray-300">IP Address</TableHead>
                      <TableHead className="text-gray-300">Platform</TableHead>
                      <TableHead className="text-gray-300">Last Seen</TableHead>
                      <TableHead className="text-gray-300">Version</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAgents.slice(0, 10).map((agent, idx) => (
                      <TableRow key={idx} className="hover:bg-gray-750 border-gray-700">
                        <TableCell className="font-medium text-white">{agent.hostname}</TableCell>
                        <TableCell className="text-gray-300">{agent.ip_address}</TableCell>
                        <TableCell className="text-gray-300">{agent.platform}</TableCell>
                        <TableCell className="text-gray-300">{agent.last_seen}</TableCell>
                        <TableCell className="text-gray-300">{agent.version}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getStatusBadgeStyle(agent.status)}>
                            {agent.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" className="h-8 px-2 text-blue-400 hover:text-blue-300 hover:bg-gray-700">
                              <Info className="h-4 w-4" />
                            </Button>
                            {agent.status === 'Needs Update' && (
                              <Button variant="outline" size="sm" className="h-8 px-2 text-yellow-400 hover:text-yellow-300 hover:bg-gray-700">
                                <Download className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="bg-gray-800 p-6 rounded-lg">
              <h2 className="text-xl text-white font-semibold mb-4">Recent Agent Installations</h2>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-850">
                    <TableRow>
                      <TableHead className="text-gray-300">Hostname</TableHead>
                      <TableHead className="text-gray-300">IP Address</TableHead>
                      <TableHead className="text-gray-300">Platform</TableHead>
                      <TableHead className="text-gray-300">Installed At</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentInstallations.map((agent, idx) => (
                      <TableRow key={idx} className="hover:bg-gray-750 border-gray-700">
                        <TableCell className="font-medium text-white">{agent.hostname}</TableCell>
                        <TableCell className="text-gray-300">{agent.ip_address}</TableCell>
                        <TableCell className="text-gray-300">{agent.platform}</TableCell>
                        <TableCell className="text-gray-300">{new Date(agent.installed_at).toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getStatusBadgeStyle(agent.status)}>
                            {agent.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* DOWNLOAD AGENT TAB */}
        <TabsContent value="download">
          <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
            <div className="flex items-center mb-2 text-gray-300">
              <Download className="mr-2 text-blue-400" />
              <h2 className="text-xl">Download CRA Agent</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-colors cursor-pointer">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <Monitor className="h-16 w-16 text-blue-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">Windows Agent</h3>
                  <p className="text-gray-400 mb-4">Compatible with Windows 10, 11, Server 2019, and Server 2022</p>
                  <p className="text-xs text-gray-500 mb-4">Version 1.4.2 | 12.5 MB</p>
                  <Button className="bg-destructive hover:bg-destructive/90 text-white w-full mb-2">
                    <Download className="mr-2" size={16} />
                    Download
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-colors cursor-pointer">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <Laptop className="h-16 w-16 text-blue-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">Linux Agent</h3>
                  <p className="text-gray-400 mb-4">Compatible with Ubuntu, CentOS, Debian, RHEL, and more</p>
                  <p className="text-xs text-gray-500 mb-4">Version 1.4.2 | 8.7 MB</p>
                  <Button className="bg-destructive hover:bg-destructive/90 text-white w-full mb-2">
                    <Download className="mr-2" size={16} />
                    Download
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-colors cursor-pointer">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <Apple className="h-16 w-16 text-blue-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">MacOS Agent</h3>
                  <p className="text-gray-400 mb-4">Compatible with macOS Big Sur, Monterey, and Ventura</p>
                  <p className="text-xs text-gray-500 mb-4">Version 1.4.2 | 10.3 MB</p>
                  <Button className="bg-destructive hover:bg-destructive/90 text-white w-full mb-2">
                    <Download className="mr-2" size={16} />
                    Download
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-lg text-white font-semibold mb-4">System Requirements</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h4 className="text-md font-medium text-white mb-2">Windows</h4>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 text-sm">
                    <li>Windows 10/11 (x64) or Server 2019/2022</li>
                    <li>2GB RAM, 50MB disk</li>
                    <li>.NET Framework 4.7.2+</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-md font-medium text-white mb-2">Linux</h4>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 text-sm">
                    <li>Ubuntu 18.04+, CentOS/RHEL 7+, Debian 10+</li>
                    <li>1GB RAM, 30MB disk</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-md font-medium text-white mb-2">macOS</h4>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 text-sm">
                    <li>macOS Big Sur (11)+</li>
                    <li>Intel or Apple Silicon</li>
                    <li>2GB RAM, 40MB disk</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* INSTALLATION GUIDE TAB */}
        <TabsContent value="installation">
          <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
            <h2 className="text-xl text-white font-semibold mb-2">Installation Instructions</h2>

            <div className="space-y-4">
              <div className="border border-gray-700 rounded-lg p-4">
                <h4 className="text-md font-medium text-white mb-2 flex items-center">
                  <Monitor className="mr-2 h-5 w-5 text-blue-400" />
                  Windows Installation
                </h4>
                <ol className="list-decimal list-inside text-gray-300 space-y-2 text-sm">
                  <li>Download the Windows Agent installer.</li>
                  <li>Right-click the installer and select "Run as administrator".</li>
                  <li>Follow the on-screen instructions to complete the installation.</li>
                  <li>Enter your organization's API key when prompted.</li>
                  <li>The agent will start automatically after installation.</li>
                </ol>
              </div>

              <div className="border border-gray-700 rounded-lg p-4">
                <h4 className="text-md font-medium text-white mb-2 flex items-center">
                  <Laptop className="mr-2 h-5 w-5 text-blue-400" />
                  Linux Installation
                </h4>
                <ol className="list-decimal list-inside text-gray-300 space-y-2 text-sm">
                  <li>Download the Linux Agent installer script.</li>
                  <li>Open a terminal and navigate to the download location.</li>
                  <li>Make executable: <code className="bg-gray-700 px-1 rounded text-blue-300">chmod +x cra-agent-linux.sh</code></li>
                  <li>Run with sudo: <code className="bg-gray-700 px-1 rounded text-blue-300">sudo ./cra-agent-linux.sh</code></li>
                  <li>Enter your organization's API key when prompted.</li>
                </ol>
              </div>

              <div className="border border-gray-700 rounded-lg p-4">
                <h4 className="text-md font-medium text-white mb-2 flex items-center">
                  <Apple className="mr-2 h-5 w-5 text-blue-400" />
                  macOS Installation
                </h4>
                <ol className="list-decimal list-inside text-gray-300 space-y-2 text-sm">
                  <li>Download the macOS Agent installer package.</li>
                  <li>Double-click the .pkg file to begin installation.</li>
                  <li>You may need to allow the installer in System Preferences &gt; Security &amp; Privacy.</li>
                  <li>Enter your organization's API key when prompted.</li>
                  <li>The agent will start automatically after installation.</li>
                </ol>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
};

export default Agents;
