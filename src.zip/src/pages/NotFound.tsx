
import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { ShieldAlert } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-cdm-dark">
      <div className="text-center p-8 bg-cdm-darker rounded-lg shadow-lg max-w-md">
        <div className="flex justify-center mb-4">
          <ShieldAlert size={64} className="text-critical" />
        </div>
        <h1 className="text-4xl font-bold mb-4 text-white">404</h1>
        <p className="text-xl text-gray-400 mb-6">Access Denied: Resource Not Found</p>
        <p className="text-gray-500 mb-6">The requested URL {location.pathname} was not found on this server.</p>
        <a
          href="/"
          className="inline-block bg-cdm-darker border border-critical text-white px-6 py-2 rounded-md hover:bg-critical/20 transition-colors"
        >
          Return to Secure Zone
        </a>
      </div>
    </div>
  );
};

export default NotFound;
