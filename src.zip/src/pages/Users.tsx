
import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Users as UsersIcon, 
  UserPlus, 
  Search, 
  ChevronLeft, 
  ChevronRight,
  Check,
  X,
  Eye,
  Edit,
  Trash
} from 'lucide-react';

const usersData = [
  {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@example.com',
    role: 'Administrator',
    status: 'Active',
    lastLogin: '2023-12-01 09:45:23'
  },
  {
    id: 2,
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    role: 'User',
    status: 'Active',
    lastLogin: '2023-12-01 10:23:45'
  },
  {
    id: 3,
    name: 'Bob Johnson',
    email: 'bob.johnson@example.com',
    role: 'Analyst',
    status: 'Active',
    lastLogin: '2023-11-30 16:12:09'
  },
  {
    id: 4,
    name: 'Alice Brown',
    email: 'alice.brown@example.com',
    role: 'Administrator',
    status: 'Inactive',
    lastLogin: '2023-11-28 11:05:32'
  },
  {
    id: 5,
    name: 'Charlie Wilson',
    email: 'charlie.wilson@example.com',
    role: 'User',
    status: 'Active',
    lastLogin: '2023-12-01 08:30:14'
  },
  {
    id: 6,
    name: 'Diana Miller',
    email: 'diana.miller@example.com',
    role: 'Analyst',
    status: 'Active',
    lastLogin: '2023-11-29 14:45:20'
  },
  {
    id: 7,
    name: 'Edward Davis',
    email: 'edward.davis@example.com',
    role: 'User',
    status: 'Inactive',
    lastLogin: '2023-11-25 09:15:07'
  },
  {
    id: 8,
    name: 'Fiona Clark',
    email: 'fiona.clark@example.com',
    role: 'Administrator',
    status: 'Active',
    lastLogin: '2023-12-01 11:30:55'
  },
];

const Users = () => {
  const [searchValue, setSearchValue] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  
  const filteredUsers = usersData.filter(user => {
    const matchesSearch = searchValue === '' || 
      user.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      user.email.toLowerCase().includes(searchValue.toLowerCase());
    
    const matchesRole = roleFilter === 'all' || user.role.toLowerCase() === roleFilter.toLowerCase();
    const matchesStatus = statusFilter === 'all' || user.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesRole && matchesStatus;
  });
  
  const paginatedUsers = filteredUsers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const pageCount = Math.ceil(filteredUsers.length / itemsPerPage);
  
  return (
    <PageContainer title="Users Management">
      <div className="bg-cdm-darker rounded-lg p-6">
        <div className="flex items-center mb-5 text-gray-300">
          <UsersIcon className="mr-2 text-blue-400" />
          <h2 className="text-xl">User Management</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Total Users</div>
              <div className="text-2xl font-bold text-white">{usersData.length}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Active Users</div>
              <div className="text-2xl font-bold text-green-500">
                {usersData.filter(user => user.status === 'Active').length}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Administrators</div>
              <div className="text-2xl font-bold text-blue-500">
                {usersData.filter(user => user.role === 'Administrator').length}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Last Login</div>
              <div className="text-sm font-medium text-gray-300">
                {new Date().toLocaleDateString()}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
            <h3 className="text-lg text-white font-semibold flex items-center">
              <UsersIcon className="mr-2 text-blue-400" />
              User List
            </h3>
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              <Select 
                defaultValue="all" 
                onValueChange={setRoleFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="administrator">Administrator</SelectItem>
                  <SelectItem value="analyst">Analyst</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue="all" 
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input 
                  placeholder="Search users..." 
                  className="bg-gray-700 border-gray-600 text-gray-300 pl-8"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
              </div>
              
              <Button className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap">
                <UserPlus className="mr-2 h-4 w-4" />
                Add User
              </Button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-850">
                <TableRow>
                  <TableHead className="text-gray-300">Name</TableHead>
                  <TableHead className="text-gray-300">Email</TableHead>
                  <TableHead className="text-gray-300">Role</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">Last Login</TableHead>
                  <TableHead className="text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedUsers.map((user) => (
                  <TableRow key={user.id} className="hover:bg-gray-750 border-gray-700">
                    <TableCell className="font-medium text-gray-300">{user.name}</TableCell>
                    <TableCell className="text-gray-300">{user.email}</TableCell>
                    <TableCell className="text-gray-300">{user.role}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        {user.status === 'Active' ? (
                          <Check className="mr-2 h-4 w-4 text-green-500" />
                        ) : (
                          <X className="mr-2 h-4 w-4 text-red-500" />
                        )}
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          user.status === 'Active' 
                            ? 'bg-green-900 text-green-300' 
                            : 'bg-red-900 text-red-300'
                        }`}>
                          {user.status}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-300">{user.lastLogin}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-gray-700">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-yellow-400 hover:text-yellow-300 hover:bg-gray-700">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-red-400 hover:text-red-300 hover:bg-gray-700">
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {pageCount > 1 && (
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm text-gray-400">
                Showing {paginatedUsers.length} of {filteredUsers.length} users
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="border-gray-600 text-gray-300 hover:bg-gray-700" 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="flex items-center text-sm text-gray-300">
                  Page {currentPage} of {pageCount}
                </span>
                <Button 
                  variant="outline" 
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, pageCount))}
                  disabled={currentPage === pageCount}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </PageContainer>
  );
};

export default Users;
