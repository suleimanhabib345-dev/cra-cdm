import React, { useState, useEffect } from 'react';
import PageContainer from '@/components/PageContainer';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, XCircle, UserCheck, Key, Calendar, Plus, Search } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { cn } from "@/lib/utils";

interface LicenseWithCompany {
  id: string;
  license_key: string;
  company_id: string;
  volume: number;
  date_created: string;
  expiration_date: string;
  hostname: string | null;
  is_active: boolean;
  companies?: {
    name: string;
    account_type?: string;
  };
}

// Generate license key function
const generateLicenseKey = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = 'CRA-CDM-';
  for (let i = 0; i < 15; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Define the form schema
const licenseFormSchema = z.object({
  company_id: z.string().min(1, { message: "Company is required" }),
  license_key: z.string().min(1, { message: "License key is required" }),
  volume: z.number().min(1, { message: "Volume must be at least 1" }),
  date_created: z.date(),
  expiration_date: z.date(),
  hostname: z.string().optional(),
  is_active: z.boolean().default(true)
});

const License = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [companies, setCompanies] = useState<{id: string, name: string, account_type?: string}[]>([]);
  const [currentCompanyId, setCurrentCompanyId] = useState<string>("");
  const [currentRole, setCurrentRole] = useState<string>("");
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [licenses, setLicenses] = useState<LicenseWithCompany[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  
  // Initialize form with generated license key
  const form = useForm<z.infer<typeof licenseFormSchema>>({
    resolver: zodResolver(licenseFormSchema),
    defaultValues: {
      company_id: "",
      license_key: generateLicenseKey(),
      volume: 1,
      date_created: new Date(),
      expiration_date: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
      hostname: "",
      is_active: true
    },
  });
  
  // Fetch licenses via Edge Function (respects role-based access)
  const fetchLicenses = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('api', {
        method: 'GET',
        headers: { 'x-path': 'licenses' }
      });

      if (error) throw error;

      if (Array.isArray(data)) {
        setLicenses(data as LicenseWithCompany[]);
      }
    } catch (error) {
      console.error('Error fetching licenses:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLicenses();
  }, []);
  
  // Fetch companies via edge function to bypass RLS for admins
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('api', {
          method: 'GET',
          headers: { 'x-path': 'companies' }
        });
        if (error) throw error;
        if (Array.isArray(data)) {
          setCompanies(data as { id: string; name: string }[]);
          // If single company, preselect it
          if (data.length === 1 && data[0]?.id) {
            form.setValue('company_id', data[0].id);
          }
          // If multiple companies and no selection yet, default to first
          if (data.length > 1 && !form.getValues('company_id')) {
            const firstId = (data[0] as any)?.id;
            if (firstId) form.setValue('company_id', firstId);
          }
        }
      } catch (error) {
        console.error('Error fetching companies:', error);
      }
    };
    fetchCompanies();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch current user's company and role, and preselect company when available
  useEffect(() => {
    const loadProfile = async () => {
      try {
        const { data: userData } = await supabase.auth.getUser();
        const userId = userData.user?.id;
        if (!userId) return;
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('company_id, role')
          .eq('id', userId)
          .single();
        if (profileError) {
          console.error('Error loading profile:', profileError);
          return;
        }
        if (profile?.company_id) {
          setCurrentCompanyId(profile.company_id);
          // Preselect the company in the form if not set
          const existingCompany = form.getValues('company_id');
          if (!existingCompany) {
            form.setValue('company_id', profile.company_id);
          }
          // If companies list failed to load, add the user's company as a fallback option
          if (!companies || companies.length === 0) {
            // Fetch company name for display
            const { data: company, error: companyError } = await supabase
              .from('companies')
              .select('id,name')
              .eq('id', profile.company_id)
              .single();
            if (!companyError && company) {
              setCompanies([company]);
            }
          }
        }
        if (profile?.role) {
          setCurrentRole(profile.role);
          setIsSuperAdmin(profile.role === 'super_admin');
        }
      } catch (e) {
        console.error('Error initializing profile/company selection:', e);
      }
    };
    loadProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Filter licenses based on search term
  const filteredLicenses = !licenses ? [] : licenses.filter(license => 
    (license.companies?.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    license.license_key.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (license.hostname || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate license statistics
  const totalLicenses = licenses?.length || 0;
  const activeLicenses = licenses?.filter(license => license.is_active)?.length || 0;
  const unsignedLicenses = licenses?.filter(license => !license.hostname)?.length || 0;
  const assignedLicenses = licenses?.filter(license => license.hostname)?.length || 0;
  const unassignedLicenses = totalLicenses - assignedLicenses;

  // Chart data
  const licenseData = [
    { name: 'Active Licenses', value: activeLicenses, color: '#22c55e' },
    { name: 'Unsigned Licenses', value: unsignedLicenses, color: '#f59e0b' },
    { name: 'Assigned Licenses', value: assignedLicenses, color: '#3b82f6' },
    { name: 'Unassigned Licenses', value: unassignedLicenses, color: '#64748b' },
  ].filter(item => item.value > 0);

  // Format date for display
  const formatDate = (dateString?: string) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // YYYY-MM-DD format
  };

  const handleAddLicense = async (values: z.infer<typeof licenseFormSchema>) => {
    setSubmitting(true);
    try {
      const licensePayload = {
        company_id: values.company_id,
        license_key: values.license_key,
        volume: values.volume,
        date_created: values.date_created.toISOString(),
        expiration_date: values.expiration_date.toISOString(),
        hostname: values.hostname || null,
        is_active: values.is_active
      };

      const { data, error } = await supabase.functions.invoke('api', {
        method: 'POST',
        headers: { 'x-path': 'licenses' },
        body: licensePayload
      });

      if (error) {
        const errorMessage = typeof error === 'string' ? error : error.message || "An unexpected error occurred";
        toast({
          variant: "destructive",
          title: "Error creating license",
          description: errorMessage
        });
      } else {
        toast({
          title: "License created",
          description: "License has been created successfully"
        });

        // Reset form and close dialog
        form.reset({
          company_id: "",
          license_key: generateLicenseKey(),
          volume: 1,
          date_created: new Date(),
          expiration_date: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
          hostname: "",
          is_active: true
        });
        setDialogOpen(false);

        // Refresh data via Edge Function
        await fetchLicenses();
      }
    } catch (error) {
      console.error('Error adding license:', error);
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        variant: "destructive",
        title: "Error creating license",
        description: errorMessage
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleRevokeLicense = async (licenseId: string) => {
    try {
      const { error } = await supabase.functions.invoke('api', {
        method: 'DELETE',
        headers: { 'x-path': `licenses/${licenseId}` },
      });

      if (error) throw error;

      toast({
        title: "License revoked",
        description: "License has been revoked successfully"
      });
      await fetchLicenses();
    } catch (error) {
      console.error('Error revoking license:', error);
      toast({
        variant: "destructive",
        title: "Error revoking license",
        description: error instanceof Error ? error.message : "An unexpected error occurred"
      });
    }
  };

  return (
    <PageContainer title="License Management">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <div className="flex items-center mb-5 text-gray-300">
          <Key className="mr-2 text-blue-400" />
          <h2 className="text-xl">License Key Management</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Total Licenses</div>
              <div className="text-2xl font-bold text-white">{totalLicenses}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Active Licenses</div>
              <div className="text-2xl font-bold text-green-500 flex items-center">
                <CheckCircle className="mr-2" size={18} />
                {activeLicenses}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Unsigned Licenses</div>
              <div className="text-2xl font-bold text-yellow-500 flex items-center">
                <XCircle className="mr-2" size={18} />
                {unsignedLicenses}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Assigned Licenses</div>
              <div className="text-2xl font-bold text-blue-500 flex items-center">
                <UserCheck className="mr-2" size={18} />
                {assignedLicenses}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="bg-gray-800 p-6 rounded-lg mb-6">
          <h3 className="text-lg text-white font-semibold mb-4">License Distribution</h3>
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={licenseData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {licenseData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Legend />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg text-white font-semibold">License Keys</h3>
            <div className="flex gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={16} />
                <Input 
                  placeholder="Search licenses..." 
                  className="pl-10 bg-gray-700 border-gray-600 text-gray-300 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                {isSuperAdmin && (
                  <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setDialogOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add License
                  </Button>
                )}
                <DialogContent className="bg-gray-800 text-white border-gray-700 max-w-xl max-h-[90vh] overflow-y-auto pointer-events-auto">
                  <DialogHeader>
                    <DialogTitle className="text-white">Add New License</DialogTitle>
                    <DialogDescription className="text-gray-400">
                      Create a new license key for a company
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleAddLicense)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="company_id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company Name</FormLabel>
                          <FormControl>
                              <select 
                                className="w-full rounded-md p-2 bg-gray-700 border-gray-600 text-gray-300"
                                {...field}
                              >
                                <option value="">Select Company</option>
                                {companies.map(company => (
                                  <option key={company.id} value={company.id}>
                                    {company.name}{company.account_type === 'personal' ? ' (Personal)' : company.account_type === 'company' ? ' (Company)' : ''}
                                  </option>
                                ))}
                                {/* Fallback: ensure current company is selectable if not in list */}
                                {currentCompanyId && !companies.find(c => c.id === currentCompanyId) && (
                                  <option value={currentCompanyId}>
                                    Your Company
                                  </option>
                                )}
                              </select>
                            </FormControl>
                            {(!companies || companies.length === 0) && (
                              <p className="text-xs text-yellow-400 mt-1">
                                No companies available from list. Using your company as fallback.
                              </p>
                            )}
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="license_key"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>License Key</FormLabel>
                            <FormControl>
                              <Input 
                                readOnly
                                className="bg-gray-700 border-gray-600 text-gray-300 font-mono"
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription className="text-gray-500">
                              Auto-generated license key
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="volume"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Volume</FormLabel>
                            <FormControl>
                              <Input 
                                type="number"
                                min="1"
                                className="bg-gray-700 border-gray-600 text-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormDescription className="text-gray-500">
                              Number of devices this license can be used on
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="date_created"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date Created</FormLabel>
                            <FormControl>
                              <Input 
                                readOnly
                                value={format(field.value, 'yyyy-MM-dd')}
                                className="bg-gray-700 border-gray-600 text-gray-300"
                              />
                            </FormControl>
                            <FormDescription className="text-gray-500">
                              Auto-populated with today's date
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="expiration_date"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Expiration Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={cn(
                                      "pl-3 text-left font-normal bg-gray-700 border-gray-600 text-gray-300",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <Calendar className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <CalendarComponent
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date < new Date()}
                                  initialFocus
                                  className="p-3 pointer-events-auto bg-gray-800 text-white"
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="hostname"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Device/Hostname</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Optional - can be assigned later"
                                className="bg-gray-700 border-gray-600 text-gray-300"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription className="text-gray-500">
                              Optional - you can assign this license to a device later
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                      
                      <DialogFooter>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setDialogOpen(false)}
                          className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                          disabled={submitting}
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="submit" 
                          className="bg-blue-600 hover:bg-blue-700"
                          disabled={submitting}
                        >
                          {submitting ? (
                            <span className="flex items-center">
                              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Creating...
                            </span>
                          ) : (
                            'Create License'
                          )}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            {loading ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : (
              <Table>
                <TableHeader className="bg-gray-850">
                  <TableRow>
                    <TableHead className="text-gray-300">Company Name</TableHead>
                    <TableHead className="text-gray-300">License Key</TableHead>
                    <TableHead className="text-gray-300">Volume</TableHead>
                    <TableHead className="text-gray-300">Date Created</TableHead>
                    <TableHead className="text-gray-300">Expiration Date</TableHead>
                    <TableHead className="text-gray-300">Device/Hostname</TableHead>
                    {isSuperAdmin && <TableHead className="text-gray-300">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLicenses.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={isSuperAdmin ? 7 : 6} className="text-center py-6 text-gray-400">
                        {searchTerm ? 'No licenses match your search' : 'No licenses found'}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredLicenses.map((license) => (
                      <TableRow key={license.id} className="hover:bg-gray-750 border-gray-700">
                        <TableCell className="font-medium text-gray-300">
                          {license.companies?.name || 'Unknown'}
                          {license.companies?.account_type && (
                            <span className={`ml-2 text-xs px-2 py-0.5 rounded ${
                              license.companies.account_type === 'personal'
                                ? 'bg-purple-500/20 text-purple-300'
                                : 'bg-blue-500/20 text-blue-300'
                            }`}>
                              {license.companies.account_type === 'personal' ? 'Personal' : 'Company'}
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-gray-300 font-mono">{license.license_key}</TableCell>
                        <TableCell className="text-gray-300">{license.volume}</TableCell>
                        <TableCell className="text-gray-300">{formatDate(license.date_created)}</TableCell>
                        <TableCell className="text-gray-300">{formatDate(license.expiration_date)}</TableCell>
                        <TableCell className="text-gray-300">{license.hostname || 'Unassigned'}</TableCell>
                        {isSuperAdmin && (
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 px-2 text-red-400 hover:text-red-300 hover:bg-gray-700"
                                onClick={() => handleRevokeLicense(license.id)}
                              >
                                Revoke
                              </Button>
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default License;
