
import React, { useState } from 'react';
import { useDevicesData } from '@/hooks/useDevicesData';
import PageContainer from '@/components/PageContainer';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import DeviceDetails from '@/components/devices/DeviceDetails';
import VulnerabilityBadge from '@/components/devices/VulnerabilityBadge';
import { AlertCircle } from 'lucide-react';

const AllDevices = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<any | null>(null);
  const { devices, deviceCategories, isLoading, error } = useDevicesData();

  // Filter devices based on selected category (platform-based)
  const filteredDevices = selectedCategory 
    ? devices.filter(device => {
        if (!device.platform) return selectedCategory === 'unknown';
        if (selectedCategory === 'windows_server') {
          return device.platform.toLowerCase().includes('windows') && 
                 device.platform.toLowerCase().includes('server');
        }
        return device.platform.toLowerCase() === selectedCategory;
      })
    : [];

  // Format the date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const handleDeviceClick = (device: any) => {
    setSelectedDevice(device);
  };

  const handleBackToDevices = () => {
    setSelectedDevice(null);
  };

  // Map device data to the component expected format
  const mapDeviceToViewModel = (device: any) => {
    const vulnerabilities = {
      critical: Math.floor(Math.random() * 5), // Placeholder for demonstration
      high: Math.floor(Math.random() * 8),
      medium: Math.floor(Math.random() * 10),
      low: Math.floor(Math.random() * 15),
      informational: Math.floor(Math.random() * 7)
    };

    return {
      id: device.id,
      hostname: device.hostname,
      ips: device.ip_address ? [device.ip_address] : [],
      os: device.platform || 'Unknown',
      version: 'Unknown', // Agents table doesn't have os_version
      vulnerabilities,
      lastTransaction: device.last_seen || device.updated_at
    };
  };

  if (isLoading) {
    return (
      <PageContainer title="All Devices">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500" />
        </div>
      </PageContainer>
    );
  }

  if (error) {
    return (
      <PageContainer title="All Devices">
        <div className="text-center p-8 text-red-400 flex flex-col items-center">
          <AlertCircle className="mb-2 h-10 w-10" />
          <h3 className="text-xl font-semibold">Error loading devices</h3>
          <p className="text-gray-400">{(error as Error).message}</p>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer title="All Devices">
      <div className="bg-cdm-darker rounded-lg p-6">
        {selectedDevice ? (
          <DeviceDetails device={mapDeviceToViewModel(selectedDevice)} onBack={handleBackToDevices} />
        ) : !selectedCategory ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {deviceCategories.length === 0 ? (
              <div className="col-span-full text-center p-8 text-gray-400">
                <p className="mb-4">No device categories found.</p>
                <p className="text-sm">
                  {devices.length === 0 
                    ? "Add agents to get started." 
                    : `Found ${devices.length} devices but no platform categories. Please check agent platform data.`}
                </p>
              </div>
            ) : (
              deviceCategories.map(category => (
                <div 
                  key={category.id}
                  className="bg-cdm-dark p-4 rounded-lg border border-gray-700 hover:border-blue-500 cursor-pointer transition-all"
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <h3 className="text-lg font-semibold text-white mb-2">{category.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Devices</span>
                    <span className="bg-blue-900 text-blue-300 px-2 py-1 rounded-full text-xs font-medium">
                      {category.count}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          <div>
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-xl font-semibold">
                {deviceCategories.find(c => c.id === selectedCategory)?.name} Devices
              </h2>
              <button 
                className="text-blue-400 hover:text-blue-300 flex items-center gap-1 text-sm"
                onClick={() => setSelectedCategory(null)}
              >
                Back to Categories
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-cdm-dark">
                  <TableRow>
                    <TableHead>Host</TableHead>
                    <TableHead>IPs</TableHead>
                    <TableHead>OS</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Vulnerabilities</TableHead>
                    <TableHead>Last Seen</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDevices.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6 text-gray-400">
                        No devices found in this category
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredDevices.map(device => {
                      const viewModel = mapDeviceToViewModel(device);
                      return (
                        <TableRow 
                          key={device.id} 
                          className="border-gray-700 hover:bg-cdm-dark cursor-pointer"
                          onClick={() => handleDeviceClick(device)}
                        >
                          <TableCell className="font-medium">{device.hostname}</TableCell>
                          <TableCell>{device.ip_address || '-'}</TableCell>
                          <TableCell>{device.platform || 'Unknown'}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded text-xs ${
                              device.status === 'active' ? 'bg-green-900 text-green-300' :
                              device.status === 'inactive' ? 'bg-red-900 text-red-300' :
                              'bg-gray-900 text-gray-300'
                            }`}>
                              {device.status || 'Unknown'}
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1 flex-wrap">
                              <VulnerabilityBadge count={viewModel.vulnerabilities.critical} type="critical" />
                              <VulnerabilityBadge count={viewModel.vulnerabilities.high} type="high" />
                              <VulnerabilityBadge count={viewModel.vulnerabilities.medium} type="medium" />
                              <VulnerabilityBadge count={viewModel.vulnerabilities.low} type="low" />
                              <VulnerabilityBadge count={viewModel.vulnerabilities.informational} type="informational" />
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(device.last_seen || device.updated_at)}</TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="mt-6 p-4 border border-gray-700 rounded-lg bg-cdm-dark">
              <h3 className="text-lg font-semibold mb-2">API Endpoint Information</h3>
              <p className="text-gray-400 mb-3">Connect your Golang agent to the following endpoint to update device data:</p>
              
              <div className="font-mono text-sm bg-black p-3 rounded overflow-x-auto mb-2">
                POST /api/devices?os={'{os_type}'}
              </div>
              
              <h4 className="font-medium mt-4 mb-2">Response Format:</h4>
              <div className="font-mono text-sm bg-black p-3 rounded overflow-x-auto">
{`{
  "data": [
    {
      "id": "string",
      "hostname": "string",
      "ips": ["string"],
      "os": "string",
      "version": "string",
      "vulnerabilities": {
        "critical": "number",
        "high": "number",
        "medium": "number",
        "low": "number",
        "informational": "number"
      },
      "lastTransaction": "ISO-8601 timestamp"
    }
  ],
  "meta": {
    "total": "number",
    "page": "number",
    "limit": "number"
  }
}`}
              </div>
            </div>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default AllDevices;
