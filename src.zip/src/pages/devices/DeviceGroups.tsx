
import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { Search, Plus, Laptop } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { DeviceService } from '@/services';
import { useDevicesData } from '@/hooks/useDevicesData';

const groupFormSchema = z.object({
  name: z.string().min(1, { message: "Group name is required" }),
  description: z.string().optional()
});

const DeviceGroups = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();
  const { deviceGroups, isLoading, error, refetchGroups } = useDevicesData();

  const form = useForm<z.infer<typeof groupFormSchema>>({
    resolver: zodResolver(groupFormSchema),
    defaultValues: {
      name: "",
      description: ""
    },
  });

  const handleAddGroup = async (values: z.infer<typeof groupFormSchema>) => {
    setSubmitting(true);
    try {
      const response = await DeviceService.create({
        name: values.name,
        description: values.description
      });
      
      if (response.error) {
        toast({
          variant: "destructive",
          title: "Error creating group",
          description: response.error
        });
      } else {
        toast({
          title: "Group created",
          description: `${values.name} has been added successfully`
        });
        // Refresh the groups data
        refetchGroups();
        setDialogOpen(false);
        form.reset();
      }
    } catch (error) {
      console.error("Error creating group:", error);
      toast({
        variant: "destructive",
        title: "Error creating group",
        description: "An unexpected error occurred"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const filteredGroups = deviceGroups.filter(group => 
    group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (group.description || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (dateString?: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  };

  return (
    <PageContainer title="Device Groups">
      <div className="bg-cdm-darker rounded-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input 
              placeholder="Search device groups..." 
              className="pl-10 bg-gray-800 border-gray-700 text-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <Button className="w-full sm:w-auto" onClick={() => setDialogOpen(true)}>
              <Plus className="mr-2" size={16} />
              Add Device Group
            </Button>
            <DialogContent className="bg-gray-800 text-white border-gray-700">
              <DialogHeader>
                <DialogTitle className="text-white">Add New Device Group</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Create a new device group to organize your devices
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleAddGroup)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Group Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Group name" 
                            className="bg-gray-700 border-gray-600 text-gray-300"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Description (optional)" 
                            className="bg-gray-700 border-gray-600 text-gray-300"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setDialogOpen(false)}
                      className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                      disabled={submitting}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      className="bg-blue-600 hover:bg-blue-700"
                      disabled={submitting}
                    >
                      {submitting ? (
                        <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Creating...
                        </span>
                      ) : (
                        'Create Group'
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
        
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : error ? (
              <div className="text-center p-8 text-red-400">
                Error loading device groups: {(error as Error).message}
              </div>
            ) : (
              <Table>
                <TableHeader className="bg-gray-850">
                  <TableRow>
                    <TableHead className="text-gray-300">Name</TableHead>
                    <TableHead className="text-gray-300">Devices</TableHead>
                    <TableHead className="text-gray-300 hidden md:table-cell">Description</TableHead>
                    <TableHead className="text-gray-300 hidden md:table-cell">Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredGroups.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-6 text-gray-400">
                        {searchQuery ? 'No device groups match your search' : 'No device groups found'}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredGroups.map(group => (
                      <TableRow key={group.id} className="hover:bg-gray-750 border-gray-700">
                        <TableCell className="font-medium text-gray-300 flex items-center">
                          <Laptop className="mr-2 text-blue-400" size={16} />
                          {group.name}
                        </TableCell>
                        <TableCell className="text-gray-300">{group.device_count || 0}</TableCell>
                        <TableCell className="text-gray-300 hidden md:table-cell">{group.description || '-'}</TableCell>
                        <TableCell className="text-gray-300 hidden md:table-cell">{formatDate(group.created_at)}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
};

export default DeviceGroups;
