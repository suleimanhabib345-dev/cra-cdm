import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useDevicesData } from '@/hooks/useDevicesData';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';

const InactiveDevices = () => {
  const { inactiveDevices, isLoading, error, refetchDevices } = useDevicesData();
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const filteredDevices = searchQuery
    ? inactiveDevices.filter(device =>
        device.hostname?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.ip_address?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.platform?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : inactiveDevices;

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const getInactivityDuration = (lastSeen: string | undefined) => {
    if (!lastSeen) return 'Unknown';
    
    const lastSeenDate = new Date(lastSeen);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - lastSeenDate.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (diffDays > 0) {
      return `${diffDays} day${diffDays !== 1 ? 's' : ''} ${diffHours} hour${diffHours !== 1 ? 's' : ''}`;
    } else {
      return `${diffHours} hour${diffHours !== 1 ? 's' : ''}`;
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await refetchDevices();
      toast({
        title: "Data refreshed",
        description: "The inactive devices list has been updated"
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Error refreshing data",
        description: (err as Error).message
      });
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <PageContainer title="Inactive Devices">
      <div className="bg-cdm-darker rounded-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input 
              placeholder="Search inactive devices..." 
              className="pl-10 bg-gray-800 border-gray-700 text-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Button 
            onClick={handleRefresh} 
            disabled={refreshing || isLoading}
            className="w-full sm:w-auto"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              Failed to load inactive devices: {(error as Error).message}
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-cdm-dark">
                  <TableRow>
                    <TableHead>Hostname</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>OS</TableHead>
                    <TableHead>Last Seen</TableHead>
                    <TableHead>Inactive For</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDevices.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6 text-gray-400">
                        {searchQuery ? 'No inactive devices match your search' : 'No inactive devices found'}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredDevices.map(device => (
                      <TableRow key={device.id} className="hover:bg-cdm-dark">
                        <TableCell className="font-medium">{device.hostname}</TableCell>
                        <TableCell>{device.ip_address || '-'}</TableCell>
                        <TableCell>{`${device.platform || 'Unknown'} ${device.os_version || ''}`}</TableCell>
                        <TableCell>{formatDate(device.last_seen || device.updated_at)}</TableCell>
                        <TableCell>{getInactivityDuration(device.last_seen || device.updated_at)}</TableCell>
                        <TableCell>
                          <span className="px-2 py-1 rounded bg-red-900/30 text-red-300 text-xs">
                            {device.status || 'Inactive'}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
            
            <div className="mt-6">
              <Alert className="bg-orange-900/20 border-orange-800 text-orange-300">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Information</AlertTitle>
                <AlertDescription className="text-orange-200">
                  Devices are considered inactive if they have not communicated with the server in the last 24 hours or have been manually marked as inactive.
                </AlertDescription>
              </Alert>
            </div>
          </>
        )}
      </div>
    </PageContainer>
  );
};

export default InactiveDevices;
