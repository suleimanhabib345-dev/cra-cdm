import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import PageContainer from '@/components/PageContainer';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { Search, Calendar, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';

type AgentTransaction = {
  id: string;
  agent_id: string;
  hostname: string | null;
  endpoint: string;
  record_count: number;
  status: 'success' | 'error';
  error_message: string | null;
  created_at: string;
};

const ENDPOINT_LABELS: Record<string, string> = {
  heartbeat: 'Heartbeat',
  'report-vulnerability': 'Vulnerabilities',
  'report-software': 'Software',
  'report-ports': 'Open Ports',
  'report-groups': 'System Groups',
  'report-users': 'System Users',
  'report-file-permissions': 'File Permissions',
  'report-kb-updates': 'Windows KB Updates',
  'report-processes': 'Processes',
  'report-network-connections': 'Network Connections',
  'report-scheduled-tasks': 'Scheduled Tasks',
  'report-security-policies': 'Security Policies',
  'report-firewall-rules': 'Firewall Rules',
  'report-services': 'Services',
  'report-certificates': 'Certificates',
  'report-env-variables': 'Environment Variables',
};

const labelFor = (endpoint: string) => ENDPOINT_LABELS[endpoint] ?? endpoint;

const formatDate = (iso: string) => (iso ? new Date(iso).toLocaleString() : '');

const Transactions = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'success' | 'error'>('all');

  const { data: transactions, isLoading, error, refetch, isFetching } = useQuery<AgentTransaction[]>({
    queryKey: ['agent_transactions'],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke('api', {
        method: 'GET',
        headers: { 'x-path': 'device-transactions' },
      });
      if (error) throw error;
      return Array.isArray(data) ? (data as AgentTransaction[]) : [];
    },
  });

  const filtered = useMemo(() => {
    if (!transactions) return [];
    const q = searchQuery.trim().toLowerCase();
    return transactions.filter((t) => {
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (!q) return true;
      return (
        (t.hostname ?? '').toLowerCase().includes(q) ||
        t.endpoint.toLowerCase().includes(q) ||
        labelFor(t.endpoint).toLowerCase().includes(q)
      );
    });
  }, [transactions, searchQuery, statusFilter]);

  const statusBadge = (status: string) =>
    status === 'success' ? (
      <Badge className="bg-green-700 hover:bg-green-700 text-green-100">Success</Badge>
    ) : (
      <Badge className="bg-red-700 hover:bg-red-700 text-red-100">Error</Badge>
    );

  return (
    <PageContainer title="Device Transactions">
      <div className="bg-cdm-darker rounded-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              placeholder="Search by host or endpoint..."
              className="pl-10 bg-gray-800 border-gray-700 text-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex gap-2">
            <Button
              variant={statusFilter === 'all' ? 'default' : 'outline'}
              onClick={() => setStatusFilter('all')}
              className={statusFilter !== 'all' ? 'bg-gray-800 text-gray-300' : ''}
            >
              All
            </Button>
            <Button
              variant={statusFilter === 'success' ? 'default' : 'outline'}
              onClick={() => setStatusFilter('success')}
              className={statusFilter !== 'success' ? 'bg-gray-800 text-gray-300' : 'bg-green-700 hover:bg-green-600'}
            >
              Success
            </Button>
            <Button
              variant={statusFilter === 'error' ? 'default' : 'outline'}
              onClick={() => setStatusFilter('error')}
              className={statusFilter !== 'error' ? 'bg-gray-800 text-gray-300' : 'bg-red-700 hover:bg-red-600'}
            >
              Errors
            </Button>
            <Button
              variant="outline"
              onClick={() => refetch()}
              disabled={isFetching}
              className="bg-gray-800 text-gray-300"
            >
              <RefreshCw className={`h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : error ? (
          <div className="text-red-400 text-center p-8">
            Error loading transactions: {(error as Error).message}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-cdm-dark">
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Agent</TableHead>
                  <TableHead>Endpoint</TableHead>
                  <TableHead className="text-right">Records</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">Error</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-6 text-gray-400">
                      {searchQuery || statusFilter !== 'all'
                        ? 'No transactions match your search/filter'
                        : 'No agent activity recorded yet'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filtered.map((tx) => (
                    <TableRow key={tx.id} className="hover:bg-cdm-dark border-gray-700">
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="mr-2 h-4 w-4 text-gray-400" />
                          {formatDate(tx.created_at)}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{tx.hostname ?? <span className="text-gray-500">unknown</span>}</TableCell>
                      <TableCell>{labelFor(tx.endpoint)}</TableCell>
                      <TableCell className="text-right">{tx.record_count}</TableCell>
                      <TableCell>{statusBadge(tx.status)}</TableCell>
                      <TableCell className="hidden md:table-cell text-gray-400 truncate max-w-md">
                        {tx.error_message ?? '-'}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default Transactions;
