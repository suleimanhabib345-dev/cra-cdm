
import React, { useState, useEffect } from 'react';
import PageContainer from '@/components/PageContainer';
import { Card } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Edit, Trash, UserPlus, Users } from 'lucide-react';
import { DeviceService } from '@/services'; // Updated import
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

// Define the form schema
const groupFormSchema = z.object({
  name: z.string().min(1, { message: "Group name is required" }),
  description: z.string().optional()
});

type DeviceGroup = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
  company_id: string;
  user_count?: number;
  admin?: string;
  adminEmail?: string;
  status?: string;
};

const ManageGroups = () => {
  const [groups, setGroups] = useState<DeviceGroup[]>([]);
  const [searchValue, setSearchValue] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();
  
  // Initialize the form
  const form = useForm<z.infer<typeof groupFormSchema>>({
    resolver: zodResolver(groupFormSchema),
    defaultValues: {
      name: "",
      description: ""
    },
  });

  // Fetch groups on component mount
  useEffect(() => {
    fetchGroups();
  }, []);

  const fetchGroups = async () => {
    setLoading(true);
    try {
      const response = await DeviceService.getAll();
      
      if (response.error) {
        toast({
          variant: "destructive",
          title: "Error loading groups",
          description: response.error
        });
      } else if (response.data) {
        // Transform the data
        const processedGroups = response.data.map(group => ({
          ...group,
          user_count: 0, // Replace with actual count when API available
          admin: 'System Admin', // Replace with actual admin when API available
          adminEmail: 'admin@example.com', // Replace with actual email when API available
          status: 'Active'
        }));
        setGroups(processedGroups);
      }
    } catch (error) {
      console.error("Error fetching groups:", error);
      toast({
        variant: "destructive",
        title: "Error loading groups",
        description: "Failed to load device groups"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddGroup = async (values: z.infer<typeof groupFormSchema>) => {
    setSubmitting(true);
    try {
      const response = await DeviceService.create({
        name: values.name,
        description: values.description
      });
      
      if (response.error) {
        toast({
          variant: "destructive",
          title: "Error creating group",
          description: response.error
        });
      } else {
        toast({
          title: "Group created",
          description: `${values.name} has been added successfully`
        });
        await fetchGroups();
        setDialogOpen(false);
        form.reset();
      }
    } catch (error) {
      console.error("Error creating group:", error);
      toast({
        variant: "destructive",
        title: "Error creating group",
        description: "An unexpected error occurred"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteGroup = async (groupId: string, groupName: string) => {
    if (!confirm(`Are you sure you want to delete ${groupName}?`)) {
      return;
    }
    
    setLoading(true);
    try {
      const response = await DeviceService.delete(groupId);
      
      if (response.error) {
        toast({
          variant: "destructive",
          title: "Error deleting group",
          description: response.error
        });
      } else {
        toast({
          title: "Group deleted",
          description: `${groupName} has been removed successfully`
        });
        await fetchGroups();
      }
    } catch (error) {
      console.error("Error deleting group:", error);
      toast({
        variant: "destructive",
        title: "Error deleting group",
        description: "An unexpected error occurred"
      });
    } finally {
      setLoading(false);
    }
  };

  // Filter groups based on search value
  const filteredGroups = groups.filter(group =>
    group.name.toLowerCase().includes(searchValue.toLowerCase()) ||
    (group.admin && group.admin.toLowerCase().includes(searchValue.toLowerCase())) ||
    (group.adminEmail && group.adminEmail.toLowerCase().includes(searchValue.toLowerCase())) ||
    (group.description && group.description.toLowerCase().includes(searchValue.toLowerCase()))
  );

  // Format date for display
  const formatDate = (dateString?: string) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // YYYY-MM-DD format
  };

  return (
    <PageContainer title="Manage Groups">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center">
            <Users className="mr-2 text-blue-400" />
            <h2 className="text-xl">Company Groups</h2>
          </div>
          
          <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
              <Input 
                placeholder="Search groups..." 
                className="bg-gray-700 border-gray-600 text-gray-300 pl-8"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
              />
            </div>
            
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setDialogOpen(true)}
              >
                <UserPlus className="mr-2 h-4 w-4" />
                Add Group
              </Button>
              <DialogContent className="bg-gray-800 text-white border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-white">Add New Company Group</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Create a new company group to organize your users
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleAddGroup)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Group Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Group name" 
                              className="bg-gray-700 border-gray-600 text-gray-300"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Description (optional)" 
                              className="bg-gray-700 border-gray-600 text-gray-300"
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription className="text-gray-500">
                            Optional description for this company group
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setDialogOpen(false)}
                        className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                        disabled={submitting}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={submitting}
                      >
                        {submitting ? (
                          <span className="flex items-center">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Creating...
                          </span>
                        ) : (
                          'Create Group'
                        )}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card className="bg-cdm-darker p-6">
          <div className="overflow-x-auto">
            {loading ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : filteredGroups.length === 0 ? (
              <div className="text-center p-8 text-gray-400">
                {searchValue 
                  ? 'No groups match your search' 
                  : 'No company groups found. Create your first group to get started.'}
              </div>
            ) : (
              <Table>
                <TableHeader className="bg-gray-850">
                  <TableRow>
                    <TableHead className="text-gray-300">Company Group</TableHead>
                    <TableHead className="text-gray-300">Users</TableHead>
                    <TableHead className="text-gray-300">Group Admin</TableHead>
                    <TableHead className="text-gray-300">Admin Email</TableHead>
                    <TableHead className="text-gray-300">Created</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredGroups.map((group) => (
                    <TableRow key={group.id} className="hover:bg-gray-750 border-gray-700">
                      <TableCell className="font-medium text-gray-300">{group.name}</TableCell>
                      <TableCell className="text-gray-300">{group.user_count || 0}</TableCell>
                      <TableCell className="text-gray-300">{group.admin || 'Not assigned'}</TableCell>
                      <TableCell className="text-gray-300">{group.adminEmail || '-'}</TableCell>
                      <TableCell className="text-gray-300">{formatDate(group.created_at)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-900 text-green-300">
                          Active
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-yellow-400 hover:text-yellow-300 hover:bg-gray-700">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-red-400 hover:text-red-300 hover:bg-gray-700"
                            onClick={() => handleDeleteGroup(group.id, group.name)}
                            disabled={loading}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
};

export default ManageGroups;
