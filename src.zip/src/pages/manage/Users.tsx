import React, { useState, useEffect } from 'react';
import PageContainer from '@/components/PageContainer';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  UserPlus, 
  Users, 
  Shield, 
  Key,
  Edit,
  Trash,
  Eye,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from '@/components/ui/use-toast';
import { UserService } from '@/services';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

const userFormSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  first_name: z.string().min(1, { message: "First name is required" }),
  last_name: z.string().min(1, { message: "Last name is required" }),
  role: z.enum(["admin", "security_analyst", "auditor", "user"]),
  password: z.string().min(8, { message: "Password must be at least 8 characters" })
    .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter" })
    .regex(/[a-z]/, { message: "Password must contain at least one lowercase letter" })
    .regex(/[0-9]/, { message: "Password must contain at least one number" })
});

type User = {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  created_at: string;
  last_sign_in_at?: string;
};

const ManageUsers = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [pendingUsers, setPendingUsers] = useState<any[]>([]);
  const [searchValue, setSearchValue] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  const { toast } = useToast();
  const { user: authUser } = useAuth();

  const form = useForm<z.infer<typeof userFormSchema>>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      email: "",
      first_name: "",
      last_name: "",
      role: "user",
      password: ""
    },
  });

  useEffect(() => {
    fetchUsers();
    fetchCurrentUserRole();
    fetchPendingUsers();
  }, [authUser]);

  const fetchCurrentUserRole = async () => {
    if (!authUser?.id) return;
    const { data } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', authUser.id)
      .single();
    setCurrentUserRole(data?.role || null);
  };

  const fetchUsers = async () => {
    setLoading(true);
    const response = await UserService.getAll();

    if (response.error) {
      toast({
        variant: "destructive",
        title: "Error loading users",
        description: response.error
      });
    } else if (response.data) {
      setUsers(response.data);
    }

    setLoading(false);
  };

  const fetchPendingUsers = async () => {
    if (!authUser?.id) return;
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', authUser.id)
      .single();

    // Only super_admin and admin can see pending users
    if (profile?.role !== 'super_admin' && profile?.role !== 'admin') return;

    const { data } = await supabase
      .from('profiles')
      .select('*, company:companies(name)')
      .eq('is_approved', false)
      .order('created_at', { ascending: false });

    setPendingUsers(data || []);
  };

  const handleApproveUser = async (userId: string, userName: string) => {
    const { error } = await supabase
      .from('profiles')
      .update({ is_approved: true })
      .eq('id', userId);

    if (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
      toast({ title: "User approved", description: `${userName} can now access the platform` });
      fetchPendingUsers();
      fetchUsers();
    }
  };

  const handleRejectUser = async (userId: string, userName: string) => {
    if (!confirm(`Are you sure you want to reject and remove ${userName}?`)) return;

    // Delete profile (cascade will handle related data)
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', userId);

    if (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
      toast({ title: "User rejected", description: `${userName} has been removed` });
      fetchPendingUsers();
    }
  };

  const handleAddUser = async (values: z.infer<typeof userFormSchema>) => {
    const response = await UserService.create({
      email: values.email,
      password: values.password,
      first_name: values.first_name,
      last_name: values.last_name,
      role: values.role
    });
    
    if (response.error) {
      toast({
        variant: "destructive",
        title: "Error creating user",
        description: response.error
      });
    } else {
      toast({
        title: "User created",
        description: `${values.first_name} ${values.last_name} has been added successfully`
      });
      fetchUsers();
      setDialogOpen(false);
      form.reset();
    }
  };

  const handleDeleteUser = async (userId: string, userName: string) => {
    if (!confirm(`Are you sure you want to delete ${userName}?`)) {
      return;
    }
    
    const response = await UserService.delete(userId);
    
    if (response.error) {
      toast({
        variant: "destructive",
        title: "Error deleting user",
        description: response.error
      });
    } else {
      toast({
        title: "User deleted",
        description: `${userName} has been removed successfully`
      });
      fetchUsers();
    }
  };

  const filteredUsers = users.filter(user => {
    const fullName = `${user.first_name} ${user.last_name}`.toLowerCase();
    const matchesSearch = searchValue === '' || 
      fullName.includes(searchValue.toLowerCase()) ||
      user.email.toLowerCase().includes(searchValue.toLowerCase());
    
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    
    const isActive = !!user.last_sign_in_at;
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'active' && isActive) || 
      (statusFilter === 'inactive' && !isActive);
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  const formatDate = (isoDate: string | undefined) => {
    if (!isoDate) return 'Never';
    return new Date(isoDate).toLocaleString();
  };

  return (
    <PageContainer title="User Management">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <Shield className="h-8 w-8 text-blue-400 mb-2" />
              <div className="text-sm text-gray-400 mb-2">Total Users</div>
              <div className="text-2xl font-bold text-white">{users.length}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <CheckCircle className="h-8 w-8 text-green-400 mb-2" />
              <div className="text-sm text-gray-400 mb-2">Active Users</div>
              <div className="text-2xl font-bold text-green-500">
                {users.filter(user => !!user.last_sign_in_at).length}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <Key className="h-8 w-8 text-yellow-400 mb-2" />
              <div className="text-sm text-gray-400 mb-2">Admin Users</div>
              <div className="text-2xl font-bold text-yellow-500">
                {users.filter(user => user.role === 'admin').length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Approvals Section - only for super_admin/admin */}
        {(currentUserRole === 'super_admin' || currentUserRole === 'admin') && pendingUsers.length > 0 && (
          <div className="bg-yellow-900/20 border border-yellow-700/50 p-6 rounded-lg">
            <h3 className="text-lg text-yellow-400 font-semibold flex items-center mb-4">
              <AlertCircle className="mr-2" />
              Pending Approvals ({pendingUsers.length})
            </h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-gray-300">User</TableHead>
                  <TableHead className="text-gray-300">Email</TableHead>
                  <TableHead className="text-gray-300">Company</TableHead>
                  <TableHead className="text-gray-300">Signed Up</TableHead>
                  <TableHead className="text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingUsers.map((pu) => (
                  <TableRow key={pu.id} className="border-gray-700">
                    <TableCell className="text-gray-300 font-medium">
                      {pu.first_name || ''} {pu.last_name || ''}
                    </TableCell>
                    <TableCell className="text-gray-300">{pu.email}</TableCell>
                    <TableCell className="text-gray-300">{pu.company?.name || 'N/A'}</TableCell>
                    <TableCell className="text-gray-300">
                      {new Date(pu.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          className="bg-green-700 hover:bg-green-600 text-white"
                          onClick={() => handleApproveUser(pu.id, `${pu.first_name || ''} ${pu.last_name || pu.email}`)}
                        >
                          <CheckCircle className="mr-1 h-4 w-4" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-700 text-red-400 hover:bg-red-900/50"
                          onClick={() => handleRejectUser(pu.id, `${pu.first_name || ''} ${pu.last_name || pu.email}`)}
                        >
                          <XCircle className="mr-1 h-4 w-4" />
                          Reject
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
            <h3 className="text-lg text-white font-semibold flex items-center">
              <Users className="mr-2 text-blue-400" />
              Manage Users
            </h3>
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              <Select 
                defaultValue="all" 
                onValueChange={setRoleFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="admin">Administrator</SelectItem>
                  <SelectItem value="security_analyst">Security Analyst</SelectItem>
                  <SelectItem value="auditor">Auditor</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue="all" 
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input 
                  placeholder="Search users..." 
                  className="bg-gray-700 border-gray-600 text-gray-300 pl-8"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
              </div>
              
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Add User
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gray-800 text-white border-gray-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Add New User</DialogTitle>
                    <DialogDescription className="text-gray-400">
                      Create a new user account. They'll receive an email with their login details.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleAddUser)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Email address" 
                                className="bg-gray-700 border-gray-600 text-gray-300"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="first_name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="First name" 
                                  className="bg-gray-700 border-gray-600 text-gray-300"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="last_name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Last Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Last name" 
                                  className="bg-gray-700 border-gray-600 text-gray-300"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="role"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Role</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300">
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                                <SelectItem value="admin">Administrator</SelectItem>
                                <SelectItem value="security_analyst">Security Analyst</SelectItem>
                                <SelectItem value="auditor">Auditor</SelectItem>
                                <SelectItem value="user">User</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription className="text-gray-500">
                              Determines what actions they can perform in the system
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password"
                                placeholder="Enter password" 
                                className="bg-gray-700 border-gray-600 text-gray-300"
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription className="text-gray-500">
                              Must be at least 8 characters with uppercase, lowercase, and numbers
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <DialogFooter>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setDialogOpen(false)}
                          className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="submit" 
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Create User
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-850">
                <TableRow>
                  <TableHead className="text-gray-300">User</TableHead>
                  <TableHead className="text-gray-300">Email</TableHead>
                  <TableHead className="text-gray-300">Role</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">Last Active</TableHead>
                  <TableHead className="text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10">
                      <div className="flex justify-center items-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10 text-gray-400">
                      {searchValue || roleFilter !== 'all' || statusFilter !== 'all'
                        ? 'No users match your search criteria'
                        : 'No users found. Add your first user to get started.'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id} className="hover:bg-gray-750 border-gray-700">
                      <TableCell className="font-medium text-gray-300">
                        {user.first_name} {user.last_name}
                      </TableCell>
                      <TableCell className="text-gray-300">{user.email}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={
                          user.role === 'admin' 
                            ? 'bg-blue-900 text-blue-300' 
                            : user.role === 'security_analyst'
                              ? 'bg-yellow-900 text-yellow-300'
                              : user.role === 'auditor'
                                ? 'bg-purple-900 text-purple-300'
                                : 'bg-green-900 text-green-300'
                        }>
                          {user.role === 'admin' 
                            ? 'Administrator' 
                            : user.role === 'security_analyst'
                              ? 'Security Analyst'
                              : user.role === 'auditor'
                                ? 'Auditor'
                                : 'User'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.last_sign_in_at ? (
                          <Badge variant="outline" className="bg-green-900 text-green-300">
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-900 text-red-300">
                            Inactive
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {formatDate(user.last_sign_in_at)}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-gray-700">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-yellow-400 hover:text-yellow-300 hover:bg-gray-700">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-red-400 hover:text-red-300 hover:bg-gray-700"
                            onClick={() => handleDeleteUser(user.id, `${user.first_name} ${user.last_name}`)}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default ManageUsers;
