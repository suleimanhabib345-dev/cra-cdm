
import React from 'react';
import PageContainer from '@/components/PageContainer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Shield,
  Bell,
  Mail,
  Key,
  Clock,
  Database,
  RefreshCw,
  Server,
  Lock,
  Brain,
} from 'lucide-react';
import AIModelSettingsPanel from '@/components/settings/AIModelSettingsPanel';

const Settings = () => {
  return (
    <PageContainer title="System Settings">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <h2 className="text-xl font-semibold text-white mb-4">System Configuration</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-400" />
                <CardTitle className="text-white">Security Settings</CardTitle>
              </div>
              <CardDescription>Configure security and authentication settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Require 2FA</p>
                  <p className="text-sm text-gray-400">Force two-factor authentication for all users</p>
                </div>
                <Switch />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Session Timeout</p>
                  <p className="text-sm text-gray-400">Auto-logout after inactivity</p>
                </div>
                <Input 
                  type="number" 
                  className="w-24 bg-gray-700 border-gray-600 text-gray-300" 
                  placeholder="Minutes"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Password Rotation</p>
                  <p className="text-sm text-gray-400">Force password change every 90 days</p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-yellow-400" />
                <CardTitle className="text-white">Notifications</CardTitle>
              </div>
              <CardDescription>Configure system notifications and alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Email Alerts</p>
                  <p className="text-sm text-gray-400">Send critical alerts via email</p>
                </div>
                <Switch />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Slack Integration</p>
                  <p className="text-sm text-gray-400">Send alerts to Slack channel</p>
                </div>
                <Switch />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Daily Reports</p>
                  <p className="text-sm text-gray-400">Send daily summary reports</p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Database className="h-5 w-5 text-purple-400" />
                <CardTitle className="text-white">Data Management</CardTitle>
              </div>
              <CardDescription>Configure data retention and backup settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Auto Backup</p>
                  <p className="text-sm text-gray-400">Enable automatic daily backups</p>
                </div>
                <Switch />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Data Retention</p>
                  <p className="text-sm text-gray-400">Keep data for specified days</p>
                </div>
                <Input 
                  type="number" 
                  className="w-24 bg-gray-700 border-gray-600 text-gray-300" 
                  placeholder="Days"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Server className="h-5 w-5 text-green-400" />
                <CardTitle className="text-white">System Maintenance</CardTitle>
              </div>
              <CardDescription>Configure system maintenance settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Auto Updates</p>
                  <p className="text-sm text-gray-400">Enable automatic system updates</p>
                </div>
                <Switch />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white">Maintenance Window</p>
                  <p className="text-sm text-gray-400">Set maintenance schedule</p>
                </div>
                <Input
                  type="time"
                  className="w-32 bg-gray-700 border-gray-600 text-gray-300"
                />
              </div>

              <Button variant="destructive" className="w-full">
                <RefreshCw className="mr-2 h-4 w-4" />
                Run System Maintenance
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* AI Model Settings — full width */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-400" />
              <CardTitle className="text-white">AI Model Settings</CardTitle>
            </div>
            <CardDescription>
              Fine-grained control over AI model behavior across WebScan, CloudScan, ADScan, and CI/CD workflows.
              Changes persist across sessions and apply immediately to new scans.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AIModelSettingsPanel />
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
};

export default Settings;
