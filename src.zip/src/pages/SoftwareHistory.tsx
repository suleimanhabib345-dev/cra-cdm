import React, { useState, useMemo } from 'react';
import PageContainer from '@/components/PageContainer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Calendar } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

// Mock data for software changes
const softwareChangesData = [
  {
    id: 1,
    device: 'Device 1',
    software: 'Chrome',
    version: '95.0.4638.69',
    action: 'added',
    date: '10/04/2025, 14:32:00'
  },
  {
    id: 2,
    device: 'Device 2',
    software: 'Firefox',
    version: '93.0',
    action: 'modified',
    date: '11/04/2025, 09:45:00'
  },
  {
    id: 3,
    device: 'Device 1',
    software: 'VS Code',
    version: '1.62.0',
    action: 'removed',
    date: '12/04/2025, 16:20:00'
  },
  {
    id: 4,
    device: 'Device 3',
    software: 'Node.js',
    version: '16.13.0',
    action: 'added',
    date: '12/04/2025, 11:10:00'
  },
  {
    id: 5,
    device: 'Device 4',
    software: 'Python',
    version: '3.10.0',
    action: 'modified',
    date: '13/04/2025, 08:30:00'
  }
];

// List of devices for the select dropdown
const devicesList = [
  { id: 'all', name: 'All Devices' },
  { id: 'device1', name: 'Device 1' },
  { id: 'device2', name: 'Device 2' },
  { id: 'device3', name: 'Device 3' },
  { id: 'device4', name: 'Device 4' },
];

// Event types for the select dropdown
const eventTypes = [
  { id: 'all', name: 'All Events' },
  { id: 'added', name: 'Added' },
  { id: 'modified', name: 'Modified' },
  { id: 'removed', name: 'Removed' },
];

const SoftwareHistory = () => {
  const [selectedDevice, setSelectedDevice] = useState('all');
  const [selectedEventType, setSelectedEventType] = useState('all');
  const [dateRange, setDateRange] = useState('');
  
  // Filter software changes based on selected event type
  const filteredSoftwareChanges = useMemo(() => {
    if (selectedEventType === 'all') return softwareChangesData;
    return softwareChangesData.filter(change => change.action === selectedEventType);
  }, [selectedEventType]);

  // Function to get badge color based on action
  const getActionBadgeStyle = (action) => {
    switch(action) {
      case 'added':
        return 'bg-green-900 text-green-300';
      case 'modified':
        return 'bg-blue-900 text-blue-300';
      case 'removed':
        return 'bg-red-900 text-red-300';
      default:
        return 'bg-gray-900 text-gray-300';
    }
  };

  return (
    <PageContainer title="Software History">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <Card className="bg-cdm-dark border-gray-700">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Device Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Choose a Device</label>
                <Select value={selectedDevice} onValueChange={setSelectedDevice}>
                  <SelectTrigger className="w-full bg-cdm-dark border-gray-700">
                    <SelectValue placeholder="All Devices" />
                  </SelectTrigger>
                  <SelectContent className="bg-cdm-darker border-gray-700">
                    {devicesList.map(device => (
                      <SelectItem key={device.id} value={device.id}>
                        {device.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Date Range */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Date Range</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="w-full justify-between bg-cdm-dark border-gray-700 text-left font-normal"
                    >
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {dateRange || "Select date range"}
                      </div>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-4 bg-cdm-darker border-gray-700" align="start">
                    <div className="space-y-2">
                      <p className="text-sm text-gray-400">Date range picker would go here</p>
                      <Button className="w-full" onClick={() => setDateRange("Last 7 days")}>
                        Apply
                      </Button>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>

              {/* Event Type */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Event Type</label>
                <Select value={selectedEventType} onValueChange={setSelectedEventType}>
                  <SelectTrigger className="w-full bg-cdm-dark border-gray-700">
                    <SelectValue placeholder="All Events" />
                  </SelectTrigger>
                  <SelectContent className="bg-cdm-darker border-gray-700">
                    <SelectItem value="all">All Events</SelectItem>
                    <SelectItem value="added">Added</SelectItem>
                    <SelectItem value="modified">Modified</SelectItem>
                    <SelectItem value="removed">Removed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-cdm-dark border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Software Changes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-800">
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">DEVICE</TableHead>
                    <TableHead className="text-gray-300">SOFTWARE</TableHead>
                    <TableHead className="text-gray-300">VERSION</TableHead>
                    <TableHead className="text-gray-300">ACTION</TableHead>
                    <TableHead className="text-gray-300">DATE</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSoftwareChanges.map((change) => (
                    <TableRow key={change.id} className="border-gray-700 hover:bg-gray-750">
                      <TableCell className="font-medium text-gray-300">{change.device}</TableCell>
                      <TableCell className="text-gray-300">{change.software}</TableCell>
                      <TableCell className="text-gray-300">{change.version}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getActionBadgeStyle(change.action)}>
                          {change.action}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-300">{change.date}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* API Endpoint Information */}
        <Card className="bg-cdm-dark border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">API Endpoint Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-gray-300">Connect your Golang agent to the following endpoints:</p>
              
              <div className="font-mono text-sm bg-black p-3 rounded overflow-x-auto">
                GET /api/software-history?device={'{deviceId}'}&from={'{fromDate}'}&to={'{toDate}'}&action={'{actionType}'}
              </div>
              
              <div className="space-y-1">
                <h4 className="font-medium text-white">Parameters:</h4>
                <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
                  <li><span className="text-blue-400">deviceId</span>: Optional. Filter by device identifier</li>
                  <li><span className="text-blue-400">fromDate</span>: Optional. Start date in ISO format (YYYY-MM-DD)</li>
                  <li><span className="text-blue-400">toDate</span>: Optional. End date in ISO format (YYYY-MM-DD)</li>
                  <li><span className="text-blue-400">actionType</span>: Optional. Filter by action type: added, modified, removed</li>
                </ul>
              </div>
              
              <div className="space-y-1">
                <h4 className="font-medium text-white">Response Format:</h4>
                <div className="font-mono text-sm bg-black p-3 rounded overflow-x-auto">
                  {`{ "data": [ { "id": "string", "device": "string", "software": "string", "version": "string", "action": "added|modified|removed", "date": "ISO-8601 timestamp" } ], "meta": { "total": "number", "page": "number", "limit": "number" } }`}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
};

export default SoftwareHistory;
