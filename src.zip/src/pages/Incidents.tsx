import React, { useState } from 'react';
import PageContainer from '@/components/PageContainer';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { useIncidentsData } from '@/hooks/useIncidentsData';
import { 
  AlertTriangle, 
  Search, 
  Calendar,
  Eye,
  FileText,
  Shield,
  ChevronLeft,
  ChevronRight,
  Clock,
  Check,
  X,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { format } from 'date-fns';

const Incidents = () => {
  const [searchValue, setSearchValue] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const { 
    incidents,
    statusCounts,
    severityCounts,
    trendData,
    isLoading,
    error 
  } = useIncidentsData();

  if (error) {
    console.error('Error fetching incidents data:', error);
  }

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'Open':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'In Progress':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'Closed':
        return <Check className="h-4 w-4 text-green-500" />;
      default:
        return <X className="h-4 w-4 text-gray-500" />;
    }
  };
  
  const getStatusBadgeColor = (status: string) => {
    switch(status) {
      case 'Open':
        return 'bg-red-900 text-red-300';
      case 'In Progress':
        return 'bg-yellow-900 text-yellow-300';
      case 'Closed':
        return 'bg-green-900 text-green-300';
      default:
        return 'bg-gray-900 text-gray-300';
    }
  };
  
  const getSeverityBadgeColor = (severity: string) => {
    switch(severity) {
      case 'Critical':
        return 'bg-red-900 text-red-300';
      case 'High':
        return 'bg-orange-900 text-orange-300';
      case 'Medium':
        return 'bg-yellow-900 text-yellow-300';
      case 'Low':
        return 'bg-green-900 text-green-300';
      default:
        return 'bg-gray-900 text-gray-300';
    }
  };

  const filteredIncidents = incidents.filter(incident => {
    const matchesSearch = searchValue === '' || 
      incident.title.toLowerCase().includes(searchValue.toLowerCase()) ||
      incident.device_id?.toLowerCase().includes(searchValue.toLowerCase()) ||
      incident.id.toLowerCase().includes(searchValue.toLowerCase());
    
    const matchesSeverity = severityFilter === 'all' || incident.severity.toLowerCase() === severityFilter.toLowerCase();
    const matchesStatus = statusFilter === 'all' || incident.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const paginatedIncidents = filteredIncidents.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const pageCount = Math.ceil(filteredIncidents.length / itemsPerPage);

  const openCount = statusCounts.find(s => s.status === 'Open')?.count || 0;
  const inProgressCount = statusCounts.find(s => s.status === 'In Progress')?.count || 0;
  const closedCount = statusCounts.find(s => s.status === 'Closed')?.count || 0;

  return (
    <PageContainer title="Incidents Management">
      <div className="bg-cdm-darker rounded-lg p-6">
        <div className="flex items-center mb-5 text-gray-300">
          <AlertTriangle className="mr-2 text-red-400" />
          <h2 className="text-xl">Security Incidents</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Total Incidents</div>
              <div className="text-2xl font-bold text-white">{incidents.length}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Open</div>
              <div className="text-2xl font-bold text-red-500">{openCount}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">In Progress</div>
              <div className="text-2xl font-bold text-yellow-500">{inProgressCount}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="text-sm text-gray-400 mb-2">Closed</div>
              <div className="text-2xl font-bold text-green-500">{closedCount}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-gray-800 p-6 rounded-lg">
            <h3 className="text-lg text-white font-semibold mb-4">Incidents by Severity</h3>
            <div className="grid grid-cols-2 gap-4 mb-4">
              {severityCounts.map(({ severity, count }) => {
                const severityColors = {
                  'Critical': {
                    background: 'bg-red-900/30 border-red-900',
                    text: 'text-red-300',
                    numberColor: 'text-red-500',
                    iconColor: 'text-red-500/50'
                  },
                  'High': {
                    background: 'bg-orange-900/30 border-orange-900',
                    text: 'text-orange-300',
                    numberColor: 'text-orange-500',
                    iconColor: 'text-orange-500/50'
                  },
                  'Medium': {
                    background: 'bg-yellow-900/30 border-yellow-900',
                    text: 'text-yellow-300',
                    numberColor: 'text-yellow-500',
                    iconColor: 'text-yellow-500/50'
                  },
                  'Low': {
                    background: 'bg-green-900/30 border-green-900',
                    text: 'text-green-300',
                    numberColor: 'text-green-500',
                    iconColor: 'text-green-500/50'
                  }
                };

                const severityIcons = {
                  'Critical': <Shield className={`h-10 w-10 ${severityColors['Critical'].iconColor}`} />,
                  'High': <Shield className={`h-10 w-10 ${severityColors['High'].iconColor}`} />,
                  'Medium': <Shield className={`h-10 w-10 ${severityColors['Medium'].iconColor}`} />,
                  'Low': <Shield className={`h-10 w-10 ${severityColors['Low'].iconColor}`} />
                };

                return (
                  <Card 
                    key={severity} 
                    className={`${severityColors[severity].background} border`}
                  >
                    <CardContent className="p-4 flex justify-between items-center">
                      <div>
                        <div className={`text-sm ${severityColors[severity].text}`}>{severity}</div>
                        <div className={`text-2xl font-bold ${severityColors[severity].numberColor}`}>{count}</div>
                      </div>
                      {severityIcons[severity]}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-lg">
            <h3 className="text-lg text-white font-semibold mb-4">Incident Trend (Last 7 Days)</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={trendData}
                  margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#aaa"
                    tickFormatter={(value) => format(new Date(value), 'MMM d')}
                  />
                  <YAxis stroke="#aaa" />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="critical" name="Critical" fill="#ef4444" />
                  <Bar dataKey="high" name="High" fill="#f97316" />
                  <Bar dataKey="medium" name="Medium" fill="#eab308" />
                  <Bar dataKey="low" name="Low" fill="#22c55e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
            <h3 className="text-lg text-white font-semibold flex items-center">
              <AlertTriangle className="mr-2 text-red-400" />
              Incident List
            </h3>
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              <Select 
                defaultValue="all" 
                onValueChange={setSeverityFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by severity" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue="all" 
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in progress">In Progress</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input 
                  placeholder="Search incidents..." 
                  className="bg-gray-700 border-gray-600 text-gray-300 pl-8"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
              </div>
              
              <Button className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap">
                <Calendar className="mr-2 h-4 w-4" />
                Date Range
              </Button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-850">
                <TableRow>
                  <TableHead className="text-gray-300">ID</TableHead>
                  <TableHead className="text-gray-300">Title</TableHead>
                  <TableHead className="text-gray-300">Severity</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">Device</TableHead>
                  <TableHead className="text-gray-300">Detected At</TableHead>
                  <TableHead className="text-gray-300">Assigned To</TableHead>
                  <TableHead className="text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedIncidents.map((incident) => (
                  <TableRow key={incident.id} className="hover:bg-gray-750 border-gray-700">
                    <TableCell className="font-medium text-gray-300">{incident.id}</TableCell>
                    <TableCell className="text-gray-300">{incident.title}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${getSeverityBadgeColor(incident.severity)}`}>
                        {incident.severity}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        {getStatusIcon(incident.status)}
                        <span className={`ml-2 px-2 py-1 rounded-full text-xs ${getStatusBadgeColor(incident.status)}`}>
                          {incident.status}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-300">{incident.device_id}</TableCell>
                    <TableCell className="text-gray-300">{format(new Date(incident.detected_at), 'MMM d, yyyy HH:mm')}</TableCell>
                    <TableCell className="text-gray-300">
                      {incident.assigned_to === null ? (
                        <span className="text-gray-500">Unassigned</span>
                      ) : (
                        incident.assigned_to
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-gray-700">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0 text-gray-400 hover:text-gray-300 hover:bg-gray-700">
                          <FileText className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {pageCount > 1 && (
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm text-gray-400">
                Showing {paginatedIncidents.length} of {filteredIncidents.length} incidents
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="border-gray-600 text-gray-300 hover:bg-gray-700" 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="flex items-center text-sm text-gray-300">
                  Page {currentPage} of {pageCount}
                </span>
                <Button 
                  variant="outline" 
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, pageCount))}
                  disabled={currentPage === pageCount}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </PageContainer>
  );
};

export default Incidents;
