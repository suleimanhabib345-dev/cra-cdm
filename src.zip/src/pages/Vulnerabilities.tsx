import React, { useState, useEffect } from 'react';
import PageContainer from '@/components/PageContainer';
import VulnerabilityDistribution from '@/components/vulnerabilities/VulnerabilityDistribution';
import { useVulnerabilityStats } from '@/hooks/useVulnerabilityStats';
import VulnerabilityOverviewSection from '@/components/vulnerabilities/VulnerabilityOverviewSection';
import VulnerabilityAgentDetails from '@/components/vulnerabilities/VulnerabilityAgentDetails';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  Search,
  Eye,
  Wrench,
  Trash,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info,
  FileText,
  FileSearch,
  Link,
  ExternalLink,
  FileSpreadsheet,
  Shield,
  RefreshCw,
  Database,
  Loader2
} from 'lucide-react';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

const vulnerabilityByPlatformData = [
  { name: 'Windows', value: 40 },
  { name: 'Windows Servers', value: 0 },
  { name: 'RHEL Servers', value: 0 },
  { name: 'CentOS Servers', value: 200 },
  { name: 'Ubuntu Servers', value: 165 },
];

const PLATFORM_COLORS = ['#1E90FF', '#4169E1', '#6495ED', '#00BFFF', '#87CEEB'];

const vulnerabilitiesData = [
  {
    id: 1,
    cveId: 'CVE-2021-44228',
    description: 'Apache Log4j2 2.0-beta9 through 2.15.0 JNDI features vulnerability allowing arbitrary code execution...',
    severity: 'Critical',
    cvssScore: 10.0,
    affectedSystems: '5 devices',
    publishedDate: '2021-12-10',
    status: 'In Progress',
    fullDescription: 'Apache Log4j2 2.0-beta9 through 2.15.0 (excluding security releases 2.12.2, 2.12.3, and 2.3.1) JNDI features used in configuration, log messages, and parameters do not protect against attacker controlled LDAP and other JNDI related endpoints. An attacker who can control log messages or log message parameters can execute arbitrary code loaded from LDAP servers when message lookup substitution is enabled.',
    attackVector: 'The attack vector is through user-controlled input that is logged by an application using a vulnerable version of Log4j. This could be through HTTP headers, form fields, or any other input that gets logged.',
    impactAssessment: 'The impact of this vulnerability is severe as it allows for complete system compromise. In your environment, 5 servers are currently affected, including critical application servers that process customer data.',
    lastModified: 'Dec 20, 2021',
    source: 'NVD',
    cvssDetails: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H',
    baseScoreMetrics: {
      attackVector: 'Network',
      attackComplexity: 'Low',
      userInteraction: 'None'
    },
    impactMetrics: {
      scope: 'Changed',
      confidentiality: 'High',
      integrity: 'High',
      availability: 'High'
    },
    affectedSoftware: [
      { vendor: 'Apache', product: 'Log4j', version: '2.0-beta9 through 2.15.0', cpe: 'cpe:2.3:a:apache:log4j:*:*:*:*:*:*:*:*' }
    ],
    remediationSteps: [
      { 
        title: 'Upgrade to Log4j 2.15.0 or later', 
        description: 'The recommended solution is to upgrade to Log4j 2.15.0 or later, which fixes the vulnerability.',
        confidence: 'High',
        details: [
          '# For Maven projects, update the dependency in pom.xml',
          '<dependency>',
          '    <groupId>org.apache.logging.log4j</groupId>',
          '    <artifactId>log4j-core</artifactId>',
          '    <version>2.15.0</version>',
          '</dependency>'
        ]
      },
      {
        title: 'Remove JndiLookup class from the classpath',
        description: 'If upgrading is not immediately possible, you can mitigate the vulnerability by removing the JndiLookup class from the classpath.',
        confidence: 'Medium',
        details: [
          'zip -q -d log4j-core-*.jar org/apache/logging/log4j/core/lookup/JndiLookup.class'
        ]
      },
      {
        title: 'Set system property to disable JNDI',
        description: 'For Log4j 2.10 and later, you can set the following system property to disable JNDI functionality.',
        confidence: 'Medium',
        details: [
          '-Dlog4j2.formatMsgNoLookups=true'
        ]
      }
    ],
    references: [
      { title: 'NVD - CVE-2021-44228', url: 'https://nvd.nist.gov/vuln/detail/CVE-2021-44228', description: 'National Vulnerability Database entry for CVE-2021-44228' },
      { title: 'Apache Log4j Security Vulnerabilities', url: 'https://logging.apache.org/log4j/2.x/security.html', description: 'Official Apache Log4j security page with details about the vulnerability and fixes' },
      { title: 'CISA Alert AA21-356A', url: 'https://www.cisa.gov/uscert/ncas/alerts/aa21-356a', description: 'CISA Alert: Mitigating Log4Shell and Other Log4j-Related Vulnerabilities' },
      { title: 'GitHub - Apache Log4j Security Vulnerabilities', url: 'https://github.com/apache/logging-log4j2/security/advisories', description: 'GitHub security advisories for Apache Log4j' }
    ]
  },
  {
    id: 2,
    cveId: 'CVE-2023-23397',
    description: 'Microsoft Outlook for Windows vulnerability that could allow an attacker to access a user\'s Net-NTLMv2 hash...',
    severity: 'Critical',
    cvssScore: 9.8,
    affectedSystems: '3 devices',
    publishedDate: '2023-03-14',
    status: 'Open'
  },
  {
    id: 3,
    cveId: 'CVE-2022-22965',
    description: 'Spring Framework RCE vulnerability via data binding on JDK 9+...',
    severity: 'High',
    cvssScore: 8.5,
    affectedSystems: '2 devices',
    publishedDate: '2022-03-31',
    status: 'Remediated'
  },
  {
    id: 4,
    cveId: 'CVE-2022-42889',
    description: 'Apache Commons Text prior to 1.10.0 allows RCE when using the default StringSubstitutor...',
    severity: 'High',
    cvssScore: 8.2,
    affectedSystems: '7 devices',
    publishedDate: '2022-10-13',
    status: 'Open'
  },
  {
    id: 5,
    cveId: 'CVE-2023-36884',
    description: 'Microsoft Office and Windows HTML Remote Code Execution Vulnerability...',
    severity: 'Critical',
    cvssScore: 9.5,
    affectedSystems: '12 devices',
    publishedDate: '2023-07-11',
    status: 'In Progress'
  }
];

const affectedDevicesData = [
  {
    id: 'SRV-001',
    hostname: 'APP-SERVER-001',
    ipAddress: '192.168.1.10',
    platform: 'Ubuntu 20.04 LTS',
    status: 'Vulnerable'
  },
  {
    id: 'SRV-002',
    hostname: 'DB-SERVER-001',
    ipAddress: '192.168.1.11',
    platform: 'CentOS 8.5',
    status: 'In Progress'
  },
  {
    id: 'SRV-003',
    hostname: 'APP-SERVER-002',
    ipAddress: '192.168.1.12',
    platform: 'Ubuntu 20.04 LTS',
    status: 'Vulnerable'
  },
  {
    id: 'SRV-004',
    hostname: 'APP-SERVER-003',
    ipAddress: '192.168.1.13',
    platform: 'Ubuntu 20.04 LTS',
    status: 'Vulnerable'
  },
  {
    id: 'SRV-005',
    hostname: 'APP-SERVER-004',
    ipAddress: '192.168.1.14',
    platform: 'Ubuntu 20.04 LTS',
    status: 'Vulnerable'
  }
];

const platformVulnerabilityData = [
  {
    platform: 'Windows',
    logo: '🪟',
    critical: 0,
    high: 10,
    medium: 26,
    low: 4,
    total: 40
  },
  {
    platform: 'Windows Servers',
    logo: '🖥️',
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    total: 0
  },
  {
    platform: 'RHEL Servers',
    logo: '🐧',
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    total: 0
  },
  {
    platform: 'CentOS Servers',
    logo: '🐧',
    critical: 14,
    high: 104,
    medium: 80,
    low: 2,
    total: 200
  },
  {
    platform: 'Ubuntu Servers',
    logo: '🐧',
    critical: 11,
    high: 90,
    medium: 63,
    low: 1,
    total: 165
  }
];

const Vulnerabilities = () => {
  const [searchValue, setSearchValue] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedVulnerability, setSelectedVulnerability] = useState(null);
  const [showDevicesModal, setShowDevicesModal] = useState(false);
  const [showVulnerabilityPage, setShowVulnerabilityPage] = useState(false);

  // NVD Scan state
  const [isScanning, setIsScanning] = useState(false);
  const [currentScan, setCurrentScan] = useState<{
    id: string;
    status: string;
    total_software: number;
    scanned_software: number;
    vulnerabilities_found: number;
  } | null>(null);
  const { toast } = useToast();

  const { platformCounts, isLoading, refetch: refetchStats } = useVulnerabilityStats();

  // Start NVD vulnerability scan
  const startNvdScan = async () => {
    setIsScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke('api', {
        method: 'POST',
        headers: { 'x-path': 'nvd/scan' }
      });

      if (error) throw error;

      if (data?.scan_id) {
        setCurrentScan({
          id: data.scan_id,
          status: 'running',
          total_software: data.total_software || 0,
          scanned_software: 0,
          vulnerabilities_found: 0
        });

        toast({
          title: "NVD Scan Started",
          description: `Scanning ${data.total_software} software packages for vulnerabilities...`
        });

        // Start polling for scan progress
        pollScanStatus(data.scan_id);
      } else {
        toast({
          title: "Scan Complete",
          description: data?.message || "No software found to scan"
        });
        setIsScanning(false);
      }
    } catch (error) {
      console.error('Error starting NVD scan:', error);
      toast({
        variant: "destructive",
        title: "Scan Failed",
        description: error instanceof Error ? error.message : "Failed to start vulnerability scan"
      });
      setIsScanning(false);
    }
  };

  // Poll scan status
  const pollScanStatus = async (scanId: string) => {
    const poll = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('api', {
          method: 'GET',
          headers: { 'x-path': `nvd/scan/${scanId}` }
        });

        if (error) throw error;

        setCurrentScan({
          id: scanId,
          status: data.status,
          total_software: data.total_software,
          scanned_software: data.scanned_software,
          vulnerabilities_found: data.vulnerabilities_found
        });

        if (data.status === 'completed') {
          toast({
            title: "Scan Complete",
            description: `Found ${data.vulnerabilities_found} vulnerabilities across ${data.scanned_software} software packages`
          });
          setIsScanning(false);
          refetchStats(); // Refresh vulnerability stats
        } else if (data.status === 'failed') {
          toast({
            variant: "destructive",
            title: "Scan Failed",
            description: data.error_message || "An error occurred during scanning"
          });
          setIsScanning(false);
        } else {
          // Continue polling
          setTimeout(poll, 5000);
        }
      } catch (error) {
        console.error('Error polling scan status:', error);
        setIsScanning(false);
      }
    };

    poll();
  };

  const filteredVulnerabilities = vulnerabilitiesData.filter(vulnerability => {
    const matchesSearch = searchValue === '' || 
      vulnerability.cveId.toLowerCase().includes(searchValue.toLowerCase()) ||
      vulnerability.description.toLowerCase().includes(searchValue.toLowerCase());
    
    const matchesSeverity = severityFilter === 'all' || vulnerability.severity.toLowerCase() === severityFilter.toLowerCase();
    const matchesStatus = statusFilter === 'all' || vulnerability.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const viewVulnerabilityDetails = (vulnerability) => {
    setSelectedVulnerability(vulnerability);
    setShowVulnerabilityPage(true);
  };

  const getStatusBadgeStyle = (status) => {
    switch(status) {
      case 'Open':
        return 'bg-red-900 text-red-300';
      case 'In Progress':
        return 'bg-yellow-900 text-yellow-300';
      case 'Remediated':
        return 'bg-green-900 text-green-300';
      case 'Vulnerable':
        return 'bg-red-900 text-red-300';
      default:
        return 'bg-gray-900 text-gray-300';
    }
  };

  const getSeverityBadgeStyle = (severity) => {
    switch(severity) {
      case 'Critical':
        return 'bg-red-900 text-red-300';
      case 'High':
        return 'bg-orange-900 text-orange-300';
      case 'Medium':
        return 'bg-yellow-900 text-yellow-300';
      case 'Low':
        return 'bg-green-900 text-green-300';
      default:
        return 'bg-gray-900 text-gray-300';
    }
  };

  if (showVulnerabilityPage && selectedVulnerability) {
    return (
      <PageContainer title={`Vulnerability: ${selectedVulnerability.cveId}`}>
        <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                className="border-gray-700 text-gray-300" 
                onClick={() => {
                  setShowVulnerabilityPage(false);
                  setActiveTab('details');
                }}
              >
                Back to Vulnerabilities
              </Button>
              <h1 className="text-xl font-bold text-white">{selectedVulnerability.cveId}</h1>
              <Badge variant="outline" className={getSeverityBadgeStyle(selectedVulnerability.severity)}>
                {selectedVulnerability.severity}
              </Badge>
            </div>
            <div className="flex space-x-2">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <CheckCircle className="mr-2 h-4 w-4" />
                Remediate
              </Button>
            </div>
          </div>

          {selectedVulnerability.cveId === 'CVE-2021-44228' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                  <p className="text-sm text-gray-400">CVSS Score: {selectedVulnerability.cvssScore}</p>
                  <p className="text-sm text-gray-400">Published: {selectedVulnerability.publishedDate}</p>
                  <p className="text-sm text-gray-400">Last Modified: {selectedVulnerability.lastModified}</p>
                  <p className="text-sm text-gray-400">Source: {selectedVulnerability.source}</p>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Description</h3>
                <p className="text-gray-300">{selectedVulnerability.fullDescription}</p>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">AI Analysis</h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-md font-medium text-gray-300">Vulnerability Summary</h4>
                    <p className="text-gray-400">This is a critical remote code execution vulnerability in Apache Log4j, a popular Java logging library. The vulnerability allows attackers to execute arbitrary code on affected systems by sending specially crafted requests that include malicious JNDI lookup patterns.</p>
                  </div>
                  
                  <div>
                    <h4 className="text-md font-medium text-gray-300">Attack Vector</h4>
                    <p className="text-gray-400">{selectedVulnerability.attackVector}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-md font-medium text-gray-300">Impact Assessment</h4>
                    <p className="text-gray-400">{selectedVulnerability.impactAssessment}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">CVSS Metrics</h3>
                <p className="text-xl font-bold text-white mb-2">{selectedVulnerability.cvssScore}</p>
                <p className="text-gray-400 mb-2">{selectedVulnerability.cvssDetails}</p>
                
                <div className="space-y-1">
                  <h4 className="text-md font-medium text-gray-300">Base Score Metrics</h4>
                  <p className="text-gray-400">Attack Vector: {selectedVulnerability.baseScoreMetrics.attackVector}</p>
                  <p className="text-gray-400">Attack Complexity: {selectedVulnerability.baseScoreMetrics.attackComplexity}</p>
                  <p className="text-gray-400">User Interaction: {selectedVulnerability.baseScoreMetrics.userInteraction}</p>
                </div>

                <div className="mt-4 space-y-1">
                  <h4 className="text-md font-medium text-gray-300">Impact Metrics</h4>
                  <p className="text-gray-400">Scope: {selectedVulnerability.impactMetrics.scope}</p>
                  <p className="text-gray-400">Confidentiality: {selectedVulnerability.impactMetrics.confidentiality}</p>
                  <p className="text-gray-400">Integrity: {selectedVulnerability.impactMetrics.integrity}</p>
                  <p className="text-gray-400">Availability: {selectedVulnerability.impactMetrics.availability}</p>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Affected Software</h3>
                <Table>
                  <TableHeader className="bg-gray-800">
                    <TableRow>
                      <TableHead className="text-gray-300">Vendor</TableHead>
                      <TableHead className="text-gray-300">Product</TableHead>
                      <TableHead className="text-gray-300">Version</TableHead>
                      <TableHead className="text-gray-300">CPE</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedVulnerability.affectedSoftware.map((software, index) => (
                      <TableRow key={index} className="border-gray-700">
                        <TableCell className="text-gray-300">{software.vendor}</TableCell>
                        <TableCell className="text-gray-300">{software.product}</TableCell>
                        <TableCell className="text-gray-300">{software.version}</TableCell>
                        <TableCell className="text-gray-300 font-mono text-xs">{software.cpe}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-medium">Affected Devices</h3>
                  <Button variant="outline" size="sm" className="h-8 px-2 text-gray-300 hover:text-white hover:bg-gray-700">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
                <Table>
                  <TableHeader className="bg-gray-800">
                    <TableRow>
                      <TableHead className="text-gray-300">Device ID</TableHead>
                      <TableHead className="text-gray-300">Hostname</TableHead>
                      <TableHead className="text-gray-300">IP Address</TableHead>
                      <TableHead className="text-gray-300">Platform</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {affectedDevicesData.map((device) => (
                      <TableRow key={device.id} className="border-gray-700">
                        <TableCell className="text-gray-300">{device.id}</TableCell>
                        <TableCell className="text-gray-300">{device.hostname}</TableCell>
                        <TableCell className="text-gray-300">{device.ipAddress}</TableCell>
                        <TableCell className="text-gray-300">{device.platform}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            device.status === 'Vulnerable' ? 'bg-red-900 text-red-300' :
                            device.status === 'In Progress' ? 'bg-yellow-900 text-yellow-300' :
                            'bg-green-900 text-green-300'
                          }`}>
                            {device.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" className="h-8 px-2 text-gray-300 hover:text-white hover:bg-gray-700">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" className="h-8 px-2 text-gray-300 hover:text-white hover:bg-gray-700">
                              <Wrench className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Remediation Steps</h3>
                <div className="space-y-4">
                  {selectedVulnerability.remediationSteps.map((step, index) => (
                    <div key={index} className="border border-gray-700 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-blue-900 rounded-full p-2">
                          <Shield className="h-5 w-5 text-blue-300" />
                        </div>
                        <div>
                          <div className="flex items-center mb-1">
                            <h4 className="font-medium text-white">{step.title}</h4>
                            <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                              step.confidence === 'High' ? 'bg-green-900 text-green-300' :
                              step.confidence === 'Medium' ? 'bg-yellow-900 text-yellow-300' :
                              'bg-orange-900 text-orange-300'
                            }`}>
                              Confidence: {step.confidence}
                            </span>
                          </div>
                          <p className="text-gray-400 mb-2">{step.description}</p>
                          <div className="bg-gray-900 p-3 rounded font-mono text-sm text-gray-300 mt-2">
                            {step.details.map((line, i) => (
                              <div key={i}>{line}</div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">Automated Remediation</h3>
                <p className="text-gray-300 mb-4">CRA CDM can automatically apply the recommended remediation to affected systems. Select the systems to remediate and click "Start Remediation".</p>
                
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="selectAll" className="rounded bg-gray-700 border-gray-600 text-blue-500" />
                    <label htmlFor="selectAll" className="ml-2 text-gray-300">Select All</label>
                  </div>
                  <p className="text-gray-400 text-sm">5 systems selected</p>
                  
                  {affectedDevicesData.map((device) => (
                    <div key={device.id} className="flex items-center">
                      <input type="checkbox" id={device.id} className="rounded bg-gray-700 border-gray-600 text-blue-500" defaultChecked />
                      <label htmlFor={device.id} className="ml-2 text-gray-300">{device.id} ({device.hostname}) - {device.platform}</label>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                    Schedule
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Start Remediation
                  </Button>
                </div>
              </div>

              <div className="bg-gray-750 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-2">References</h3>
                <div className="space-y-3">
                  {selectedVulnerability.references.map((ref, index) => (
                    <div key={index} className="flex items-start">
                      <Link className="text-gray-400 mr-2 mt-1 flex-shrink-0" size={16} />
                      <div>
                        <a href={ref.url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline flex items-center">
                          {ref.title}
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                        <p className="text-gray-400 text-sm">{ref.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer title="Vulnerabilities">
      <div className="bg-cdm-darker rounded-lg p-6 space-y-6">
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex justify-between items-center mb-4">
            <TabsList className="bg-cdm-dark border-gray-700">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>Overview</span>
              </TabsTrigger>
              <TabsTrigger value="details" className="flex items-center gap-2">
                <FileSearch className="h-4 w-4" />
                <span>Vulnerability Details</span>
              </TabsTrigger>
            </TabsList>
            
            <div className="flex items-center gap-2">
              <Select 
                defaultValue="all" 
                onValueChange={setSeverityFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by severity" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue="all" 
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-300 w-40">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-300">
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in progress">In Progress</SelectItem>
                  <SelectItem value="remediated">Remediated</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search vulnerabilities..."
                  className="bg-gray-700 border-gray-600 text-gray-300 pl-8"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
              </div>

              <Button
                onClick={startNvdScan}
                disabled={isScanning}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                {isScanning ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <Database className="mr-2 h-4 w-4" />
                    NVD Scan
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* NVD Scan Progress */}
          {currentScan && currentScan.status === 'running' && (
            <Card className="bg-blue-900/20 border-blue-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />
                    <div>
                      <p className="text-white font-medium">NVD Vulnerability Scan in Progress</p>
                      <p className="text-sm text-gray-400">
                        Scanned {currentScan.scanned_software} of {currentScan.total_software} packages •
                        Found {currentScan.vulnerabilities_found} vulnerabilities
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="w-32 bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                        style={{
                          width: `${currentScan.total_software > 0
                            ? (currentScan.scanned_software / currentScan.total_software) * 100
                            : 0}%`
                        }}
                      />
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      {currentScan.total_software > 0
                        ? Math.round((currentScan.scanned_software / currentScan.total_software) * 100)
                        : 0}% complete
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <VulnerabilityDistribution data={platformCounts} isLoading={isLoading} />

              <Card className="bg-cdm-dark border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Recent Alerts</CardTitle>
                  <Button 
                    variant="ghost" 
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 px-2 h-8"
                    onClick={() => setActiveTab('details')}
                  >
                    View All
                  </Button>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px]">
                    <div className="space-y-4">
                      {vulnerabilitiesData.slice(0, 3).map((vuln) => (
                        <div key={vuln.id} className="bg-gray-800 rounded-md p-3 border border-gray-700">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-sm font-semibold text-white">{vuln.cveId}</h3>
                              <p className="text-xs text-gray-400 mt-1 line-clamp-2">{vuln.description}</p>
                            </div>
                            <Badge variant="outline" className={getSeverityBadgeStyle(vuln.severity)}>
                              {vuln.severity}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center mt-2">
                            <span className="text-xs text-gray-400">{vuln.publishedDate}</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 h-7 px-2"
                              onClick={() => viewVulnerabilityDetails(vuln)}
                            >
                              Details
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
              
              <Card className="bg-cdm-dark border-gray-700 lg:col-span-2">
                <CardHeader>
                  <CardTitle className="text-white">Latest Vulnerabilities</CardTitle>
                  <p className="text-sm text-gray-400">Processed for each reporting CRA Agent</p>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader className="bg-gray-800">
                        <TableRow className="border-gray-700">
                          <TableHead className="text-gray-300 w-1/4">Platform / Vulnerabilities</TableHead>
                          <TableHead className="text-red-400 text-center">Critical</TableHead>
                          <TableHead className="text-orange-400 text-center">High</TableHead>
                          <TableHead className="text-yellow-400 text-center">Medium</TableHead>
                          <TableHead className="text-green-400 text-center">Low</TableHead>
                          <TableHead className="text-blue-400 text-center">Total Vulnerabilities</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {platformCounts.map((platform, index) => (
                          <TableRow key={index} className="border-gray-700 hover:bg-gray-750">
                            <TableCell className="font-medium text-gray-300 bg-gray-800">
                              <div className="flex items-center">
                                <span>{platform.platform}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-red-400 text-center font-semibold bg-gray-900">
                              {platform.critical}
                            </TableCell>
                            <TableCell className="text-orange-400 text-center font-semibold bg-gray-900">
                              {platform.high}
                            </TableCell>
                            <TableCell className="text-yellow-400 text-center font-semibold bg-gray-900">
                              {platform.medium}
                            </TableCell>
                            <TableCell className="text-green-400 text-center font-semibold bg-gray-900">
                              {platform.low}
                            </TableCell>
                            <TableCell className="text-blue-400 text-center font-semibold bg-gray-900">
                              {platform.total}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>

            <VulnerabilityOverviewSection />
            
            <VulnerabilityAgentDetails />
          </TabsContent>

          <TabsContent value="details" className="space-y-6">
            <Card className="bg-cdm-dark border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">All Vulnerabilities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader className="bg-gray-800">
                      <TableRow className="border-gray-700">
                        <TableHead className="text-gray-300">CVE ID</TableHead>
                        <TableHead className="text-gray-300">Description</TableHead>
                        <TableHead className="text-gray-300">Severity</TableHead>
                        <TableHead className="text-gray-300">CVSS</TableHead>
                        <TableHead className="text-gray-300">Affected Systems</TableHead>
                        <TableHead className="text-gray-300">Published Date</TableHead>
                        <TableHead className="text-gray-300">Status</TableHead>
                        <TableHead className="text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredVulnerabilities.map((vulnerability) => (
                        <TableRow key={vulnerability.id} className="border-gray-700 hover:bg-gray-750">
                          <TableCell className="font-medium text-blue-400">{vulnerability.cveId}</TableCell>
                          <TableCell className="text-gray-300 max-w-xs">
                            <div className="truncate">{vulnerability.description}</div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getSeverityBadgeStyle(vulnerability.severity)}>
                              {vulnerability.severity}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-300 font-medium">{vulnerability.cvssScore}</TableCell>
                          <TableCell className="text-gray-300">{vulnerability.affectedSystems}</TableCell>
                          <TableCell className="text-gray-300">{vulnerability.publishedDate}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getStatusBadgeStyle(vulnerability.status)}>
                              {vulnerability.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-gray-700"
                                onClick={() => viewVulnerabilityDetails(vulnerability)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className={`h-8 w-8 p-0 ${
                                  vulnerability.status === 'Remediated' 
                                    ? 'text-gray-500 cursor-not-allowed' 
                                    : 'text-yellow-400 hover:text-yellow-300 hover:bg-gray-700'
                                }`}
                                disabled={vulnerability.status === 'Remediated'}
                              >
                                <Wrench className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageContainer>
  );
};

export default Vulnerabilities;
