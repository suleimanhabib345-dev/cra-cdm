import type { ScanConfig, ScanResult, Finding, TerminalLine, GraphData, ScanStatus } from '@/types/adscan';

const ADSCAN_API_URL = import.meta.env.VITE_ADSCAN_API_URL || 'http://localhost:8400';

// --- Mock Data for UI Development ---

const MOCK_FINDINGS: Finding[] = [
  {
    id: 'f1',
    category: 'Kerberos',
    title: 'Kerberoastable Service Accounts Detected',
    severity: 'CRITICAL',
    description: 'Service accounts with SPNs set are vulnerable to offline password cracking via Kerberoasting. An attacker with any domain user credentials can request TGS tickets and attempt offline brute-force.',
    details: ['svc_backup — SPNs: MSSQLSvc/db01.corp.local:1433', 'svc_web — SPNs: HTTP/web01.corp.local', 'svc_exchange — SPNs: exchangeMDB/ex01.corp.local'],
    recommendation: 'Migrate to Group Managed Service Accounts (gMSAs) or enforce 25+ character passwords on all service accounts with SPNs.',
    riskScore: 20,
    references: ['https://attack.mitre.org/techniques/T1558/003/'],
  },
  {
    id: 'f2',
    category: 'Delegation',
    title: 'Unconstrained Delegation on Non-DC Computers',
    severity: 'CRITICAL',
    description: 'Computers with unconstrained Kerberos delegation cache TGTs from any authenticating user. If compromised, an attacker can impersonate any user including Domain Admins.',
    details: ['FILE01$ — file server', 'APP02$ — application server'],
    recommendation: 'Remove unconstrained delegation. Switch to constrained delegation or RBCD where delegation is required.',
    riskScore: 20,
    references: ['https://attack.mitre.org/techniques/T1558/'],
  },
  {
    id: 'f3',
    category: 'Password Policy',
    title: 'Weak Password Policy Configuration',
    severity: 'HIGH',
    description: 'The domain password policy allows passwords shorter than 12 characters and does not enforce complexity requirements adequately.',
    details: ['Minimum password length: 8', 'Password history: 3', 'Lockout threshold: 0 (no lockout)', 'Complexity: Enabled'],
    recommendation: 'Set minimum password length to 14+, enable lockout after 5 attempts, and increase password history to 24.',
    riskScore: 15,
    references: ['https://attack.mitre.org/techniques/T1110/'],
  },
  {
    id: 'f4',
    category: 'ADCS / PKI',
    title: 'ESC1 — Vulnerable Certificate Template',
    severity: 'CRITICAL',
    description: 'Certificate template "WebServer-Custom" allows requesters to specify a Subject Alternative Name (SAN) and has overly permissive enrollment rights, enabling domain privilege escalation.',
    details: ['Template: WebServer-Custom', 'Enrollee: Domain Users', 'Client Auth EKU: Yes', 'ENROLLEE_SUPPLIES_SUBJECT: Yes'],
    recommendation: 'Remove ENROLLEE_SUPPLIES_SUBJECT flag or restrict enrollment to specific security groups.',
    riskScore: 25,
    references: ['https://posts.specterops.io/certified-pre-owned-d95910965cd2'],
  },
  {
    id: 'f5',
    category: 'Account Hygiene',
    title: 'Stale User Accounts with Active Passwords',
    severity: 'MEDIUM',
    description: 'Multiple user accounts have not authenticated in over 90 days but remain enabled with valid credentials.',
    details: ['jsmith — last logon: 182 days ago', 'contractor01 — last logon: 245 days ago', 'temp_user — last logon: 310 days ago', 'old_admin — last logon: 401 days ago (adminCount=1)'],
    recommendation: 'Disable accounts inactive for 90+ days. Review and remove accounts inactive for 180+ days.',
    riskScore: 10,
    references: ['https://attack.mitre.org/techniques/T1078/002/'],
  },
  {
    id: 'f6',
    category: 'Legacy Protocols',
    title: 'SMBv1 Enabled on Domain Controllers',
    severity: 'HIGH',
    description: 'SMBv1 is enabled on one or more domain controllers, exposing them to EternalBlue and similar exploits.',
    details: ['DC01.corp.local — SMBv1 dialect accepted', 'DC02.corp.local — SMBv1 dialect accepted'],
    recommendation: 'Disable SMBv1 on all domain controllers and domain-joined computers.',
    riskScore: 15,
    references: ['https://attack.mitre.org/techniques/T1210/'],
  },
  {
    id: 'f7',
    category: 'Domain Trusts',
    title: 'Bidirectional Trust Without SID Filtering',
    severity: 'HIGH',
    description: 'A bidirectional trust exists with partner.local without SID filtering enabled, allowing cross-domain SID history injection attacks.',
    details: ['Trust: corp.local <-> partner.local', 'Direction: Bidirectional', 'SID Filtering: Disabled', 'Trust Type: Forest'],
    recommendation: 'Enable SID filtering (quarantine) on the trust or convert to a one-way trust where possible.',
    riskScore: 15,
    references: ['https://attack.mitre.org/techniques/T1134/005/'],
  },
  {
    id: 'f8',
    category: 'Credential Exposure',
    title: 'GPP cpassword Found in SYSVOL (MS14-025)',
    severity: 'CRITICAL',
    description: 'Group Policy Preferences XML files in SYSVOL contain encrypted passwords using Microsoft\'s published AES key, allowing any domain user to decrypt them.',
    details: ['\\\\corp.local\\SYSVOL\\corp.local\\Policies\\{31B2F340}\\Machine\\Preferences\\Groups\\Groups.xml', 'Decrypted password: Summer2024!', 'Target account: local_admin'],
    recommendation: 'Remove all GPP XML files containing cpassword. Use LAPS for local admin password management.',
    riskScore: 25,
    references: ['https://attack.mitre.org/techniques/T1552/006/'],
  },
  {
    id: 'f9',
    category: 'LAPS',
    title: 'Incomplete LAPS Deployment',
    severity: 'MEDIUM',
    description: 'LAPS is deployed but 6 out of 20 domain-joined computers do not have LAPS passwords set.',
    details: ['LAPS Coverage: 70% (14/20)', 'Missing: WKS05, WKS08, WKS12, SRV03, SRV07, PRINT01'],
    recommendation: 'Extend LAPS GPO to cover all computer OUs and verify LAPS client installation on missing hosts.',
    riskScore: 8,
    references: [],
  },
  {
    id: 'f10',
    category: 'Protocol Security',
    title: 'LDAP Signing Not Required',
    severity: 'MEDIUM',
    description: 'Domain controllers do not require LDAP signing, making LDAP connections vulnerable to man-in-the-middle attacks.',
    details: ['DC01: LDAP signing not enforced', 'DC02: LDAP signing not enforced'],
    recommendation: 'Set "Domain controller: LDAP server signing requirements" to "Require signing" in GPO.',
    riskScore: 10,
    references: ['https://attack.mitre.org/techniques/T1557/'],
  },
  {
    id: 'f11',
    category: 'Kerberos',
    title: 'AS-REP Roastable Accounts',
    severity: 'HIGH',
    description: 'Accounts with Kerberos pre-authentication disabled allow attackers to request encrypted AS-REP data for offline cracking without credentials.',
    details: ['svc_legacy — DONT_REQUIRE_PREAUTH set', 'backup_admin — DONT_REQUIRE_PREAUTH set'],
    recommendation: 'Enable Kerberos pre-authentication on all accounts unless absolutely required.',
    riskScore: 15,
    references: ['https://attack.mitre.org/techniques/T1558/004/'],
  },
  {
    id: 'f12',
    category: 'Hardening',
    title: 'Machine Account Quota Allows Unprivileged Join',
    severity: 'LOW',
    description: 'ms-DS-MachineAccountQuota is set to 10, allowing any authenticated user to join up to 10 computers to the domain.',
    details: ['ms-DS-MachineAccountQuota: 10'],
    recommendation: 'Set ms-DS-MachineAccountQuota to 0 and delegate computer join permissions to specific admin groups.',
    riskScore: 5,
    references: [],
  },
];

const MOCK_GRAPH: GraphData = {
  nodes: [
    { id: 'domain', label: 'corp.local', type: 'domain', x: 400, y: 300, vx: 0, vy: 0 },
    { id: 'dc01', label: 'DC01', type: 'dc', x: 300, y: 200, vx: 0, vy: 0 },
    { id: 'dc02', label: 'DC02', type: 'dc', x: 500, y: 200, vx: 0, vy: 0 },
    { id: 'da_group', label: 'Domain Admins', type: 'group', x: 200, y: 100, vx: 0, vy: 0, severity: 'CRITICAL' },
    { id: 'ea_group', label: 'Enterprise Admins', type: 'group', x: 600, y: 100, vx: 0, vy: 0, severity: 'CRITICAL' },
    { id: 'admin1', label: 'admin', type: 'user', x: 100, y: 50, vx: 0, vy: 0, severity: 'HIGH' },
    { id: 'svc_backup', label: 'svc_backup', type: 'user', x: 150, y: 400, vx: 0, vy: 0, severity: 'CRITICAL', details: 'Kerberoastable' },
    { id: 'svc_web', label: 'svc_web', type: 'user', x: 350, y: 450, vx: 0, vy: 0, severity: 'CRITICAL', details: 'Kerberoastable' },
    { id: 'file01', label: 'FILE01$', type: 'computer', x: 550, y: 400, vx: 0, vy: 0, severity: 'CRITICAL', details: 'Unconstrained Delegation' },
    { id: 'app02', label: 'APP02$', type: 'computer', x: 650, y: 350, vx: 0, vy: 0, severity: 'CRITICAL', details: 'Unconstrained Delegation' },
    { id: 'web01', label: 'WEB01$', type: 'computer', x: 250, y: 350, vx: 0, vy: 0 },
    { id: 'partner', label: 'partner.local', type: 'domain', x: 700, y: 300, vx: 0, vy: 0, severity: 'HIGH' },
    { id: 'jsmith', label: 'jsmith', type: 'user', x: 450, y: 450, vx: 0, vy: 0, severity: 'MEDIUM', details: 'Stale (182 days)' },
    { id: 'gpo1', label: 'Default Domain Policy', type: 'gpo', x: 300, y: 100, vx: 0, vy: 0 },
    { id: 'ou_servers', label: 'OU=Servers', type: 'ou', x: 500, y: 350, vx: 0, vy: 0 },
  ],
  edges: [
    { source: 'dc01', target: 'domain', label: 'dcFor', type: 'memberOf' },
    { source: 'dc02', target: 'domain', label: 'dcFor', type: 'memberOf' },
    { source: 'admin1', target: 'da_group', label: 'MemberOf', type: 'memberOf' },
    { source: 'admin1', target: 'ea_group', label: 'MemberOf', type: 'memberOf' },
    { source: 'da_group', target: 'dc01', label: 'AdminTo', type: 'adminTo' },
    { source: 'da_group', target: 'dc02', label: 'AdminTo', type: 'adminTo' },
    { source: 'svc_backup', target: 'da_group', label: 'Kerberoast→DA', type: 'attackPath' },
    { source: 'file01', target: 'da_group', label: 'UnconstrDeleg→DA', type: 'attackPath' },
    { source: 'svc_web', target: 'web01', label: 'ServiceOn', type: 'hasSession' },
    { source: 'app02', target: 'ou_servers', label: 'Contains', type: 'memberOf' },
    { source: 'file01', target: 'ou_servers', label: 'Contains', type: 'memberOf' },
    { source: 'domain', target: 'partner', label: 'TrustBiDir', type: 'trust' },
    { source: 'gpo1', target: 'domain', label: 'GpLink', type: 'gpLink' },
    { source: 'jsmith', target: 'web01', label: 'HasSession', type: 'hasSession' },
  ],
};

const MOCK_TERMINAL_LINES: TerminalLine[] = [
  { id: 1, timestamp: '13:45:01', type: 'system', message: 'ADScan v2.0 — Active Directory Security Assessment' },
  { id: 2, timestamp: '13:45:01', type: 'system', message: '═══════════════════════════════════════════════════' },
  { id: 3, timestamp: '13:45:02', type: 'info', message: '[+] Auth mode         : password' },
  { id: 4, timestamp: '13:45:02', type: 'info', message: '[+] Domain Controller : 10.0.0.1' },
  { id: 5, timestamp: '13:45:03', type: 'success', message: '[+] LDAPS bind successful (port 636)' },
  { id: 6, timestamp: '13:45:03', type: 'info', message: '[+] Base DN           : DC=corp,DC=local' },
  { id: 7, timestamp: '13:45:04', type: 'check', message: '[*] Running check 1/42: Password Policy...' },
  { id: 8, timestamp: '13:45:05', type: 'warning', message: '    ⚠ Minimum password length: 8 (should be 14+)' },
  { id: 9, timestamp: '13:45:05', type: 'warning', message: '    ⚠ Account lockout threshold: 0 (no lockout!)' },
  { id: 10, timestamp: '13:45:06', type: 'check', message: '[*] Running check 2/42: Privileged Accounts...' },
  { id: 11, timestamp: '13:45:07', type: 'info', message: '    Domain Admins: 3 members' },
  { id: 12, timestamp: '13:45:07', type: 'info', message: '    Enterprise Admins: 1 member' },
  { id: 13, timestamp: '13:45:08', type: 'check', message: '[*] Running check 3/42: Kerberos Security...' },
  { id: 14, timestamp: '13:45:09', type: 'error', message: '    ✗ CRITICAL: 3 Kerberoastable service accounts found' },
  { id: 15, timestamp: '13:45:09', type: 'error', message: '    ✗ svc_backup — MSSQLSvc/db01.corp.local:1433' },
  { id: 16, timestamp: '13:45:09', type: 'error', message: '    ✗ svc_web — HTTP/web01.corp.local' },
  { id: 17, timestamp: '13:45:10', type: 'warning', message: '    ⚠ 2 AS-REP roastable accounts detected' },
  { id: 18, timestamp: '13:45:11', type: 'check', message: '[*] Running check 4/42: Unconstrained Delegation...' },
  { id: 19, timestamp: '13:45:12', type: 'error', message: '    ✗ CRITICAL: 2 non-DC computers with unconstrained delegation' },
  { id: 20, timestamp: '13:45:13', type: 'check', message: '[*] Running check 5/42: Constrained Delegation...' },
  { id: 21, timestamp: '13:45:14', type: 'success', message: '    ✓ No dangerous constrained delegation targets found' },
  { id: 22, timestamp: '13:45:15', type: 'check', message: '[*] Running check 6/42: ADCS / PKI...' },
  { id: 23, timestamp: '13:45:16', type: 'error', message: '    ✗ CRITICAL: ESC1 vulnerability in template "WebServer-Custom"' },
  { id: 24, timestamp: '13:45:17', type: 'check', message: '[*] Running check 7/42: Domain Trusts...' },
  { id: 25, timestamp: '13:45:18', type: 'warning', message: '    ⚠ Bidirectional trust with partner.local — SID filtering disabled' },
  { id: 26, timestamp: '13:45:19', type: 'check', message: '[*] Running check 8/42: Account Hygiene...' },
  { id: 27, timestamp: '13:45:20', type: 'warning', message: '    ⚠ 4 stale accounts (90+ days inactive)' },
  { id: 28, timestamp: '13:45:21', type: 'check', message: '[*] Running check 9/42: Protocol Security...' },
  { id: 29, timestamp: '13:45:22', type: 'warning', message: '    ⚠ LDAP signing not enforced on DCs' },
  { id: 30, timestamp: '13:45:23', type: 'check', message: '[*] Running check 10/42: Group Policy Objects...' },
  { id: 31, timestamp: '13:45:24', type: 'success', message: '    ✓ No orphaned or empty GPOs found' },
  { id: 32, timestamp: '13:45:25', type: 'check', message: '[*] Running check 11/42: LAPS Coverage...' },
  { id: 33, timestamp: '13:45:26', type: 'warning', message: '    ⚠ LAPS coverage: 70% (14/20 hosts)' },
  { id: 34, timestamp: '13:45:27', type: 'check', message: '[*] Running checks 12-24...' },
  { id: 35, timestamp: '13:45:35', type: 'error', message: '    ✗ SMBv1 enabled on 2 domain controllers' },
  { id: 36, timestamp: '13:45:36', type: 'check', message: '[*] Running checks 25-35...' },
  { id: 37, timestamp: '13:45:45', type: 'error', message: '    ✗ CRITICAL: GPP cpassword found in SYSVOL' },
  { id: 38, timestamp: '13:45:46', type: 'check', message: '[*] Running check 36/42: ZeroLogon (CVE-2020-1472)...' },
  { id: 39, timestamp: '13:45:47', type: 'success', message: '    ✓ All DC machine accounts rotated post-patch' },
  { id: 40, timestamp: '13:45:48', type: 'check', message: '[*] Running check 37/42: NoPac (CVE-2021-42278/42287)...' },
  { id: 41, timestamp: '13:45:49', type: 'warning', message: '    ⚠ MachineAccountQuota is 10 (should be 0)' },
  { id: 42, timestamp: '13:45:50', type: 'check', message: '[*] Running check 38/42: PrintNightmare...' },
  { id: 43, timestamp: '13:45:51', type: 'warning', message: '    ⚠ Print Spooler reachable on DC (post-patch, but still running)' },
  { id: 44, timestamp: '13:45:52', type: 'check', message: '[*] Running check 39/42: NTLM Coercion...' },
  { id: 45, timestamp: '13:45:53', type: 'error', message: '    ✗ CRITICAL: AD CS deployed + EFS RPC reachable — PetitPotam relay viable' },
  { id: 46, timestamp: '13:45:54', type: 'check', message: '[*] Running check 40/42: NTLM Relay Config...' },
  { id: 47, timestamp: '13:45:55', type: 'warning', message: '    ⚠ LDAP channel binding not enforced' },
  { id: 48, timestamp: '13:45:56', type: 'check', message: '[*] Running checks 41-42: GPO Abuse / Transitive Privilege...' },
  { id: 49, timestamp: '13:45:57', type: 'success', message: '    ✓ No GPO permission abuse paths detected' },
  { id: 50, timestamp: '13:45:58', type: 'system', message: '═══════════════════════════════════════════════════' },
  { id: 51, timestamp: '13:45:58', type: 'system', message: 'Scan complete — 42/42 checks finished' },
  { id: 52, timestamp: '13:45:58', type: 'error', message: 'Risk Score: 28/100 [CRITICAL]' },
  { id: 53, timestamp: '13:45:58', type: 'info', message: 'CRITICAL: 5 | HIGH: 4 | MEDIUM: 4 | LOW: 1 | INFO: 1' },
];

// --- API Functions ---

export async function startScan(config: ScanConfig): Promise<{ scanId: string }> {
  try {
    const response = await fetch(`${ADSCAN_API_URL}/api/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    if (!response.ok) throw new Error(`Scan request failed: ${response.statusText}`);
    return response.json();
  } catch {
    // Fallback to mock for Quick Scan / development
    return { scanId: 'mock-scan-' + Date.now() };
  }
}

/**
 * Live-only scan start. Throws on failure instead of falling back to mock.
 * Used by the Start Scan button (requires real backend + credentials).
 */
export async function startScanLive(config: ScanConfig): Promise<{ scanId: string }> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${ADSCAN_API_URL}/api/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
      signal: controller.signal,
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(text || response.statusText);
    }
    return response.json();
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') {
      throw new Error('Connection timed out — backend did not respond within 15 seconds');
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

export function isMockScan(scanId: string): boolean {
  return scanId.startsWith('mock-');
}

export async function getScanStatus(scanId: string): Promise<{ status: ScanStatus; progress: number }> {
  try {
    const response = await fetch(`${ADSCAN_API_URL}/api/scan/${scanId}/status`);
    if (!response.ok) throw new Error('Failed to get scan status');
    const data = await response.json();
    return { status: data.status, progress: data.progress ?? 0 };
  } catch {
    return { status: 'completed', progress: 42 };
  }
}

export async function getScanResults(scanId: string): Promise<ScanResult> {
  try {
    const response = await fetch(`${ADSCAN_API_URL}/api/scan/${scanId}/results`);
    if (!response.ok) throw new Error('Failed to get scan results');
    return response.json();
  } catch {
    return getMockScanResult();
  }
}

export async function getGraphData(scanId: string): Promise<GraphData> {
  try {
    const response = await fetch(`${ADSCAN_API_URL}/api/graph/${scanId}`);
    if (!response.ok) throw new Error('Failed to get graph data');
    return response.json();
  } catch {
    return MOCK_GRAPH;
  }
}

/**
 * Opens a WebSocket to the backend for live terminal streaming.
 * Returns a cleanup function to close the connection.
 */
export function connectScanWebSocket(
  scanId: string,
  onLine: (line: TerminalLine) => void,
  onClose?: () => void,
): () => void {
  const wsUrl = ADSCAN_API_URL.replace(/^http/, 'ws');
  const ws = new WebSocket(`${wsUrl}/ws/scan/${scanId}`);

  ws.onmessage = (event) => {
    try {
      const line: TerminalLine = JSON.parse(event.data);
      onLine(line);
    } catch {
      // ignore malformed messages
    }
  };

  ws.onclose = () => onClose?.();
  ws.onerror = () => ws.close();

  return () => {
    if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
      ws.close();
    }
  };
}

/**
 * Polls scan status until completed or error. Returns final status.
 */
export async function pollScanUntilComplete(
  scanId: string,
  onStatusChange: (status: ScanStatus, progress: number) => void,
  intervalMs = 2000,
): Promise<ScanStatus> {
  return new Promise((resolve) => {
    const poll = async () => {
      const { status, progress } = await getScanStatus(scanId);
      onStatusChange(status, progress);
      if (status === 'completed' || status === 'error') {
        resolve(status);
      } else {
        setTimeout(poll, intervalMs);
      }
    };
    poll();
  });
}

export async function cancelScan(scanId: string): Promise<void> {
  try {
    await fetch(`${ADSCAN_API_URL}/api/scan/${scanId}/cancel`, {
      method: 'POST',
      signal: AbortSignal.timeout(5000),
    });
  } catch { /* ignore — best-effort cancel */ }
}

export function getMockScanResult(): ScanResult {
  return {
    id: 'mock-scan-1',
    domain: 'corp.local',
    dcIp: '10.0.0.1',
    scanTime: new Date().toISOString(),
    status: 'completed',
    findings: MOCK_FINDINGS,
    stats: {
      totalChecks: 42,
      completedChecks: 42,
      findingsCount: { CRITICAL: 4, HIGH: 3, MEDIUM: 3, LOW: 1, INFO: 1 },
      riskScore: 32,
      riskLevel: 'CRITICAL',
      lapsConverage: 70,
      deprecatedOsCount: 2,
      unconstrainedDelegation: 2,
      adminCountAccounts: 24,
      kerberoastableAccounts: 3,
      staleAccounts: 4,
    },
  };
}

export function getMockTerminalLines(): TerminalLine[] {
  return MOCK_TERMINAL_LINES;
}

export function getMockGraphData(): GraphData {
  return MOCK_GRAPH;
}
