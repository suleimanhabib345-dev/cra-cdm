import { supabase } from '@/integrations/supabase/client';
import type { FirewallRule } from '@/types/agent-data';

export const FirewallRulesService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('firewall_rules')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching firewall rules:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('firewall_rules')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false});

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all firewall rules:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getInboundRules(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('firewall_rules')
        .select('*')
        .eq('agent_id', agentId)
        .eq('direction', 'inbound')
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching inbound firewall rules:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
