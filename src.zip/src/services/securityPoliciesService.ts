import { supabase } from '@/integrations/supabase/client';
import type { SecurityPolicy } from '@/types/agent-data';

export const SecurityPoliciesService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('security_policies')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching security policies:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('security_policies')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all security policies:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getNonCompliantPolicies() {
    try {
      const { data, error } = await supabase
        .from('security_policies')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('is_compliant', false)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching non-compliant policies:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
