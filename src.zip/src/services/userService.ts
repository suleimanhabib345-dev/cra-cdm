
import { request } from './baseApi';
import { supabase } from '@/integrations/supabase/client';

export const UserService = {
  async getAll() {
    try {
      // Get current user's company_id
      const { data: { user } } = await supabase.auth.getUser();
      let companyId: string | null = null;

      if (user?.id) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('company_id, role')
          .eq('id', user.id)
          .single();
        companyId = profile?.company_id || null;

        // Super admins see all users
        if (profile?.role === 'super_admin') {
          const { data, error } = await supabase.from('profiles').select('*');
          if (error) return { data: null, error: error.message, status: 500 };
          return { data, error: null, status: 200 };
        }
      }

      // No company = no users visible
      if (!companyId) {
        return { data: [], error: null, status: 200 };
      }

      let query = supabase.from('profiles').select('*');
      query = query.eq('company_id', companyId);

      const { data, error } = await query;
      if (error) {
        return { data: null, error: error.message, status: 500 };
      }
      return { data, error: null, status: 200 };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      return { data: null, error: errorMessage, status: 500 };
    }
  },
  
  async create(userData: {
    email: string;
    password: string;
    first_name: string;
    last_name: string;
    role?: string;
  }) {
    try {
      // First create the auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            first_name: userData.first_name,
            last_name: userData.last_name
          }
        }
      });
      
      if (authError) {
        console.error('Auth error creating user:', authError);
        return { data: null, error: authError.message, status: 400 };
      }
      
      // Now update the profile with role if needed
      if (userData.role && authData.user) {
        const { data, error } = await supabase
          .from('profiles')
          .update({ role: userData.role })
          .eq('id', authData.user.id)
          .select();
          
        if (error) {
          console.error('Error updating profile:', error);
          return { data: null, error: error.message, status: 500 };
        }
        
        return { data, error: null, status: 200 };
      }
      
      return { data: authData.user, error: null, status: 200 };
    } catch (err) {
      console.error('Exception creating user:', err);
      const errorMessage = err instanceof Error ? err.message : "Unknown error occurred";
      return { data: null, error: errorMessage, status: 500 };
    }
  },
  
  async delete(userId: string) {
    const { data, error } = await supabase.functions.invoke('api', {
      headers: { 'x-path': `users/${userId}`, 'x-method': 'DELETE' },
    });

    if (error) {
      let message = error.message;
      try {
        const resp = (error as any)?.context?.response ?? (error as any)?.context;
        if (resp && typeof resp.text === 'function') {
          const text = await resp.text();
          try {
            const parsed = JSON.parse(text);
            message = parsed?.error || parsed?.message || text;
          } catch {
            message = text;
          }
        }
      } catch {
        // fall through with default message
      }
      console.error(`Error deleting user ${userId}:`, message);
      return { data: null, error: message, status: (error as any).status || 500 };
    }

    return { data, error: null, status: 200 };
  },
  
  async update(userId: string, userData: {
    first_name?: string;
    last_name?: string;
    role?: string;
  }) {
    return request<any>('direct:profiles', 'PUT', { id: userId, ...userData });
  }
};
