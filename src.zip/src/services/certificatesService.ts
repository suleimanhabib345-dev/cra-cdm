import { supabase } from '@/integrations/supabase/client';
import type { Certificate } from '@/types/agent-data';

export const CertificatesService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('certificates')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching certificates:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('certificates')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all certificates:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getExpiredCertificates() {
    try {
      const { data, error } = await supabase
        .from('certificates')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('is_expired', true)
        .order('valid_to', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching expired certificates:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
