import { supabase } from '@/integrations/supabase/client';
import type { WindowsKBUpdate } from '@/types/agent-data';

export const WindowsKBService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('windows_kb_updates')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching KB updates:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('windows_kb_updates')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all KB updates:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getPendingUpdates() {
    try {
      const { data, error } = await supabase
        .from('windows_kb_updates')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('status', 'pending')
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching pending updates:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
