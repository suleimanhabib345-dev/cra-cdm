
import { request } from './baseApi';
import { supabase } from '@/integrations/supabase/client';

export const CompanyService = {
  async getAll() {
    const { data, error } = await supabase
      .from('companies')
      .select('*');
      
    if (error) {
      console.error('Error fetching companies:', error);
      return { data: null, error: error.message, status: 500 };
    }
    
    return { data, error: null, status: 200 };
  },
  
  async getById(id: string) {
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .eq('id', id)
      .single();
      
    if (error) {
      console.error(`Error fetching company ${id}:`, error);
      return { data: null, error: error.message, status: 500 };
    }
    
    return { data, error: null, status: 200 };
  },
  
  async create(companyData: {
    name: string;
    contact_email?: string;
    contact_phone?: string;
    address?: string;
  }) {
    const { data, error } = await supabase
      .from('companies')
      .insert(companyData)
      .select();
      
    if (error) {
      console.error('Error creating company:', error);
      return { data: null, error: error.message, status: 500 };
    }
    
    return { data: data[0], error: null, status: 200 };
  },
  
  async update(id: string, companyData: {
    name?: string;
    contact_email?: string;
    contact_phone?: string;
    address?: string;
    license_key?: string;
    license_expires?: string;
  }) {
    const { data, error } = await supabase
      .from('companies')
      .update(companyData)
      .eq('id', id)
      .select();
      
    if (error) {
      console.error(`Error updating company ${id}:`, error);
      return { data: null, error: error.message, status: 500 };
    }
    
    return { data: data[0], error: null, status: 200 };
  },
  
  async delete(id: string) {
    const { error } = await supabase
      .from('companies')
      .delete()
      .eq('id', id);
      
    if (error) {
      console.error(`Error deleting company ${id}:`, error);
      return { data: null, error: error.message, status: 500 };
    }
    
    return { data: true, error: null, status: 200 };
  }
};
