
import { request } from './baseApi';
import { supabase } from '@/integrations/supabase/client';

export const DeviceService = {
  async getAll() {
    try {
      const { data: devicesData, error: devicesError } = await supabase
        .from('devices')
        .select('*')
        .order('hostname');

      const { data: groupsData, error: groupsError } = await supabase
        .rpc('get_device_groups_with_counts');

      if (devicesError) throw devicesError;
      if (groupsError) throw groupsError;

      return { 
        data: {
          devices: devicesData || [],
          groups: groupsData || []
        }, 
        error: null 
      };
    } catch (err) {
      console.error('Error in DeviceService.getAll:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  },
  
  async register(deviceData: {
    hostname: string;
    ip_address?: string;
    mac_address?: string;
    platform?: string;
    os_version?: string;
  }) {
    try {
      const { data, error } = await supabase
        .from('devices')
        .insert(deviceData)
        .select();

      if (error) {
        console.error('Error registering device:', error);
        return { data: null, error: error.message };
      }

      return { data: data[0], error: null };
    } catch (err) {
      console.error('Error in DeviceService.register:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  },
  
  async create(groupData: {
    name: string;
    description?: string;
  }) {
    try {
      const { data, error } = await supabase
        .from('device_groups')
        .insert(groupData)
        .select();

      if (error) {
        console.error('Error creating device group:', error);
        return { data: null, error: error.message };
      }

      return { data: data[0], error: null };
    } catch (err) {
      console.error('Error in DeviceService.create:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  },
  
  async delete(deviceId: string) {
    try {
      const { error } = await supabase
        .from('device_groups')
        .delete()
        .eq('id', deviceId);

      if (error) {
        console.error('Error deleting device group:', error);
        return { data: null, error: error.message };
      }

      return { data: true, error: null };
    } catch (err) {
      console.error('Error in DeviceService.delete:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  },
  
  async update(deviceId: string, deviceData: {
    hostname?: string;
    ip_address?: string;
    mac_address?: string;
    platform?: string;
    os_version?: string;
    group_id?: string;
    status?: 'active' | 'inactive' | 'maintenance';
  }) {
    try {
      const { data, error } = await supabase
        .from('devices')
        .update(deviceData)
        .eq('id', deviceId)
        .select();

      if (error) {
        console.error('Error updating device:', error);
        return { data: null, error: error.message };
      }

      return { data: data[0], error: null };
    } catch (err) {
      console.error('Error in DeviceService.update:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  }
};
