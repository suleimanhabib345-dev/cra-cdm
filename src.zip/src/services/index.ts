
import { UserService } from './userService';
import { DeviceService } from './deviceService';
import { VulnerabilityService } from './vulnerabilityService';
import { CompanyService } from './companyService';
import { AgentService } from './agentService';
import { SystemGroupsService } from './systemGroupsService';
import { SystemUsersService } from './systemUsersService';
import { FilePermissionsService } from './filePermissionsService';
import { WindowsKBService } from './windowsKBService';
import { ProcessesService } from './processesService';
import { NetworkConnectionsService } from './networkConnectionsService';
import { ScheduledTasksService } from './scheduledTasksService';
import { SecurityPoliciesService } from './securityPoliciesService';
import { FirewallRulesService } from './firewallRulesService';
import { SystemServicesService } from './systemServicesService';
import { CertificatesService } from './certificatesService';
import { EnvironmentVariablesService } from './environmentVariablesService';
import { LicenseService } from './licenseService';

export * from './userService';
export * from './deviceService';
export * from './vulnerabilityService';
export * from './companyService';
export * from './agentService';
export * from './systemGroupsService';
export * from './systemUsersService';
export * from './filePermissionsService';
export * from './windowsKBService';
export * from './processesService';
export * from './networkConnectionsService';
export * from './scheduledTasksService';
export * from './securityPoliciesService';
export * from './firewallRulesService';
export * from './systemServicesService';
export * from './certificatesService';
export * from './environmentVariablesService';
export * from './licenseService';
export type { ApiResponse } from './baseApi';

// Legacy export to maintain backward compatibility
export const ApiService = {
  User: UserService,
  Device: DeviceService,
  Vulnerability: VulnerabilityService,
  Company: CompanyService,
  Agent: AgentService,
  SystemGroups: SystemGroupsService,
  SystemUsers: SystemUsersService,
  FilePermissions: FilePermissionsService,
  WindowsKB: WindowsKBService,
  Processes: ProcessesService,
  NetworkConnections: NetworkConnectionsService,
  ScheduledTasks: ScheduledTasksService,
  SecurityPolicies: SecurityPoliciesService,
  FirewallRules: FirewallRulesService,
  SystemServices: SystemServicesService,
  Certificates: CertificatesService,
  EnvironmentVariables: EnvironmentVariablesService,
  License: LicenseService
};

export default ApiService;
