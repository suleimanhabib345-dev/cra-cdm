
import { supabase } from '@/integrations/supabase/client';

export interface LicenseData {
  company_id: string;
  license_key: string;
  volume: number;
  date_created: string;
  expiration_date: string;
  hostname?: string | null;
  is_active?: boolean;
}

export interface LicenseUpdateData {
  is_active?: boolean;
  volume?: number;
  expiration_date?: string;
  hostname?: string | null;
}

export const LicenseService = {
  async getAll() {
    const { data, error } = await supabase.functions.invoke('api', {
      method: 'GET',
      headers: { 'x-path': 'licenses' }
    });

    if (error) {
      console.error('Error fetching licenses:', error);
      return { data: null, error: error.message, status: 500 };
    }

    return { data, error: null, status: 200 };
  },

  async create(licenseData: LicenseData) {
    const { data, error } = await supabase.functions.invoke('api', {
      method: 'POST',
      headers: { 'x-path': 'licenses' },
      body: licenseData
    });

    if (error) {
      console.error('Error creating license:', error);
      return { data: null, error: error.message, status: 500 };
    }

    return { data, error: null, status: 200 };
  },

  async update(id: string, updateData: LicenseUpdateData) {
    const { data, error } = await supabase.functions.invoke('api', {
      method: 'PATCH',
      headers: { 'x-path': `licenses/${id}` },
      body: updateData
    });

    if (error) {
      console.error(`Error updating license ${id}:`, error);
      return { data: null, error: error.message, status: 500 };
    }

    return { data, error: null, status: 200 };
  },

  async revoke(id: string) {
    const { data, error } = await supabase.functions.invoke('api', {
      method: 'DELETE',
      headers: { 'x-path': `licenses/${id}` },
    });

    if (error) {
      console.error(`Error revoking license ${id}:`, error);
      return { data: null, error: error.message, status: 500 };
    }

    return { data: true, error: null, status: 200 };
  }
};
