import { supabase } from '@/integrations/supabase/client';
import type { ScheduledTask } from '@/types/agent-data';

export const ScheduledTasksService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('scheduled_tasks')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching scheduled tasks:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('scheduled_tasks')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all scheduled tasks:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getEnabledTasks() {
    try {
      const { data, error } = await supabase
        .from('scheduled_tasks')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('is_enabled', true)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching enabled tasks:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
