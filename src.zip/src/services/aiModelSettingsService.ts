/**
 * AI Model Settings Service
 * Stores and retrieves fine-grained AI execution parameters applied across
 * WebScan, CloudScan, ADScan, and CI/CD scan workflows.
 */

export interface AIModelSettings {
  // Token management
  maxInputTokens: number | null;     // null = auto (model registry default)
  maxOutputTokens: number | null;    // null = auto (model registry default)
  safeTokenThreshold: number;        // 0.50–0.85, fraction of context reserved for output

  // Execution
  maxSteps: number;                  // total agent loop iterations (10–120)
  maxToolCallRetries: number;        // retry attempts per LLM call (1–5)

  // Model behavior
  temperature: number | null;        // null = not sent (model default), 0.0–2.0
  topP: number | null;               // null = not sent (model default), 0.0–1.0

  // Free-model optimization
  autoTokenShrinking: boolean;       // compress history when near context limit
  chunkingEnabled: boolean;          // chunk large skills across multiple steps
}

export const DEFAULT_AI_MODEL_SETTINGS: AIModelSettings = {
  maxInputTokens: null,
  maxOutputTokens: null,
  safeTokenThreshold: 0.38,          // matches _OUTPUT_RESERVE in ai_agent.py
  maxSteps: 60,
  maxToolCallRetries: 3,
  temperature: null,
  topP: null,
  autoTokenShrinking: true,
  chunkingEnabled: true,
};

const STORAGE_KEY = 'cra_ai_model_settings';

export function loadAIModelSettings(): AIModelSettings {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return { ...DEFAULT_AI_MODEL_SETTINGS, ...JSON.parse(stored) };
  } catch { /* ignore parse errors */ }
  return { ...DEFAULT_AI_MODEL_SETTINGS };
}

export function saveAIModelSettings(settings: AIModelSettings): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}

export function resetAIModelSettings(): AIModelSettings {
  const defaults = { ...DEFAULT_AI_MODEL_SETTINGS };
  saveAIModelSettings(defaults);
  return defaults;
}
