import { supabase } from '@/integrations/supabase/client';
import type { FilePermission } from '@/types/agent-data';

export const FilePermissionsService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('file_permissions')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching file permissions:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('file_permissions')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all file permissions:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getSensitiveFiles() {
    try {
      const { data, error } = await supabase
        .from('file_permissions')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('is_sensitive', true)
        .order('detected_at', { ascending: false});

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching sensitive files:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
