
import { supabase } from '@/integrations/supabase/client';

export const AgentService = {
  async getAll() {
    try {
      const { data: agentsData, error: agentsError } = await supabase
        .from('agents')
        .select('*')
        .order('hostname');

      const { data: statusData, error: statusError } = await supabase
        .rpc('get_agent_status_overview');

      if (agentsError) throw agentsError;
      if (statusError) throw statusError;

      return { 
        data: {
          agents: agentsData || [],
          statusOverview: statusData || []
        }, 
        error: null 
      };
    } catch (err) {
      console.error('Error in AgentService.getAll:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  },

  async updateAgentStatus(agentId: string, status: string) {
    try {
      const { data, error } = await supabase
        .from('agents')
        .update({ status })
        .eq('id', agentId)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error updating agent status:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error occurred'
      };
    }
  }
};
