import type {
  CloudScanConfig, CloudScanResult, CloudGraphData, AttackPath,
  CloudFinding, TrustRelationship, CloudScanSummary, CloudScanStatus,
  EnumModuleStatus,
} from '@/types/cloudscan';
import type { TerminalLine } from '@/types/adscan';
import { testAIProvider as _testAIProvider } from '@/services/aiProviderService';

const CLOUDSCAN_API_URL = import.meta.env.VITE_CLOUDSCAN_API_URL || 'http://localhost:8401';

/** Test AI provider connectivity using CloudScan backend (fallback to direct). */
export async function testCloudAIProvider(config: {
  provider: string;
  apiKey: string;
  model: string;
  baseUrl?: string;
}): Promise<{ status: string; error?: string; response?: string }> {
  return _testAIProvider(config, CLOUDSCAN_API_URL);
}

/** Fetch the raw .md content of a SCOPE agent from the backend. */
export async function fetchAgentContent(agentName: string): Promise<string | null> {
  try {
    const resp = await fetch(`${CLOUDSCAN_API_URL}/api/agents/${agentName}`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    return data.content ?? null;
  } catch {
    return null;
  }
}

/** List all SCOPE agents from backend. */
export async function fetchAgentList(): Promise<{ agents: Record<string, { available: boolean }>; subagents: Record<string, { available: boolean }> } | null> {
  try {
    const resp = await fetch(`${CLOUDSCAN_API_URL}/api/agents`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!resp.ok) return null;
    return resp.json();
  } catch {
    return null;
  }
}

// --- Mock Data ---

const MOCK_ATTACK_PATHS: AttackPath[] = [
  {
    id: 'ap1',
    name: 'IAM CreateAccessKey — Privilege Escalation to Admin',
    severity: 'critical',
    category: 'privilege_escalation',
    description: 'User alice has iam:CreateAccessKey on *. Can create keys for any user, including admins, enabling full account takeover.',
    exploitability: 'trivial',
    steps: ['List IAM users with admin permissions', 'Create access key for admin user', 'Use new credentials to assume admin role'],
    mitreTechniques: ['T1098.001', 'T1078.004'],
    detectionOpportunities: ['CloudTrail: CreateAccessKey event for non-self user', 'GuardDuty: Credential exfiltration anomaly'],
    remediation: ['Remove iam:CreateAccessKey from alice\'s policy or restrict Resource to own ARN', 'Enable MFA requirement for IAM key creation'],
    affectedResources: ['arn:aws:iam::123456789012:user/alice'],
  },
  {
    id: 'ap2',
    name: 'Wildcard Trust Policy — Cross-Account Takeover',
    severity: 'critical',
    category: 'trust_misconfiguration',
    description: 'Role DevOps has a trust policy with Principal: "*", allowing any AWS account to assume it. The role has AdministratorAccess.',
    exploitability: 'trivial',
    steps: ['Identify wildcard trust on role DevOps', 'From any AWS account, call sts:AssumeRole', 'Receive temporary credentials with admin access'],
    mitreTechniques: ['T1078.004', 'T1550.001'],
    detectionOpportunities: ['CloudTrail: AssumeRole from unknown account', 'Config Rule: iam-role-trust-policy-wildcard'],
    remediation: ['Replace wildcard principal with specific account ARN', 'Add ExternalId condition', 'Require MFA condition on trust policy'],
    affectedResources: ['arn:aws:iam::123456789012:role/DevOps'],
  },
  {
    id: 'ap3',
    name: 'S3 Public Bucket — Data Exfiltration',
    severity: 'critical',
    category: 'data_exposure',
    description: 'Bucket "prod-customer-data" has public read ACL and contains PII. Bucket policy also grants s3:GetObject to Principal: "*".',
    exploitability: 'trivial',
    steps: ['List objects in prod-customer-data bucket', 'Download objects without authentication', 'Exfiltrate customer data'],
    mitreTechniques: ['T1530', 'T1567.002'],
    detectionOpportunities: ['S3 access logging: anonymous GetObject requests', 'CloudTrail: S3 data events from unknown IPs'],
    remediation: ['Enable S3 Block Public Access at account level', 'Remove public ACL', 'Restrict bucket policy to specific principals'],
    affectedResources: ['arn:aws:s3:::prod-customer-data'],
  },
  {
    id: 'ap4',
    name: 'Lambda PassRole — Privilege Escalation via Function',
    severity: 'high',
    category: 'privilege_escalation',
    description: 'User bob has lambda:CreateFunction + iam:PassRole. Can create a Lambda function with an admin role and invoke it to execute arbitrary code as admin.',
    exploitability: 'easy',
    steps: ['Create Lambda function with admin execution role', 'Deploy code that creates admin access keys', 'Invoke function and retrieve credentials'],
    mitreTechniques: ['T1098.001', 'T1584.007'],
    detectionOpportunities: ['CloudTrail: CreateFunction with high-privilege role', 'Lambda: New function execution with admin permissions'],
    remediation: ['Remove iam:PassRole or restrict to specific roles', 'Add permission boundary to limit PassRole scope'],
    affectedResources: ['arn:aws:iam::123456789012:user/bob'],
  },
  {
    id: 'ap5',
    name: 'KMS Key Policy — Cross-Account Decryption',
    severity: 'high',
    category: 'data_exposure',
    description: 'KMS key "prod-encryption-key" allows kms:Decrypt to an external account (999888777666) without condition keys.',
    exploitability: 'moderate',
    steps: ['From external account, call kms:Decrypt with key ARN', 'Decrypt any ciphertext encrypted with the key', 'Access encrypted S3 objects or RDS snapshots'],
    mitreTechniques: ['T1552.004'],
    detectionOpportunities: ['CloudTrail: Decrypt events from external accounts', 'KMS key policy audit via Config'],
    remediation: ['Remove external account from key policy', 'Add kms:ViaService condition to restrict usage context'],
    affectedResources: ['arn:aws:kms:us-east-1:123456789012:key/prod-encryption-key'],
  },
  {
    id: 'ap6',
    name: 'Security Group — Open SSH to Internet',
    severity: 'high',
    category: 'network_exposure',
    description: 'Security group sg-0abc123 allows SSH (port 22) inbound from 0.0.0.0/0. Attached to 3 production EC2 instances.',
    exploitability: 'moderate',
    steps: ['Scan public IP ranges for open port 22', 'Attempt SSH bruteforce or use leaked credentials', 'Gain shell access to production instances'],
    mitreTechniques: ['T1110.001', 'T1021.004'],
    detectionOpportunities: ['VPC Flow Logs: High volume SSH traffic', 'GuardDuty: SSH bruteforce finding'],
    remediation: ['Restrict SSH to specific CIDR ranges or VPN', 'Use SSM Session Manager instead of SSH', 'Enable GuardDuty'],
    affectedResources: ['arn:aws:ec2:us-east-1:123456789012:security-group/sg-0abc123'],
  },
  {
    id: 'ap7',
    name: 'Users Without MFA — Credential Compromise Risk',
    severity: 'medium',
    category: 'credential_risk',
    description: '5 IAM users with console access do not have MFA enabled, increasing risk of account compromise via phished or leaked passwords.',
    exploitability: 'moderate',
    steps: ['Obtain user password via phishing or credential dump', 'Login to AWS Console without MFA challenge', 'Perform actions with user\'s full permissions'],
    mitreTechniques: ['T1078.004', 'T1556'],
    detectionOpportunities: ['CloudTrail: ConsoleLogin without MFA', 'IAM Credential Report analysis'],
    remediation: ['Enforce MFA for all console users via SCP', 'Enable hardware MFA for admin accounts'],
    affectedResources: ['alice', 'bob', 'contractor01', 'dev-user', 'staging-deploy'],
  },
  {
    id: 'ap8',
    name: 'RDS Public Accessibility — Database Exposure',
    severity: 'medium',
    category: 'network_exposure',
    description: 'RDS instance "prod-postgres" has PubliclyAccessible=true and is in a subnet with internet gateway route.',
    exploitability: 'moderate',
    steps: ['Resolve RDS endpoint DNS', 'Attempt connection from external network', 'Bruteforce or use leaked database credentials'],
    mitreTechniques: ['T1190', 'T1110'],
    detectionOpportunities: ['VPC Flow Logs: External connections to RDS port', 'RDS Enhanced Monitoring: Failed authentication attempts'],
    remediation: ['Set PubliclyAccessible=false', 'Move to private subnet', 'Restrict security group to application tier only'],
    affectedResources: ['arn:aws:rds:us-east-1:123456789012:db/prod-postgres'],
  },
  {
    id: 'ap9',
    name: 'Secrets Manager — Missing Rotation',
    severity: 'low',
    category: 'credential_risk',
    description: '3 secrets in Secrets Manager have not been rotated in over 90 days and have no rotation schedule configured.',
    exploitability: 'difficult',
    steps: ['Compromise long-lived secret via other vector', 'Use stale credentials that haven\'t been rotated'],
    mitreTechniques: ['T1552.001'],
    detectionOpportunities: ['Config Rule: secretsmanager-rotation-enabled-check'],
    remediation: ['Enable automatic rotation with appropriate Lambda rotation function', 'Set rotation schedule to 30 days'],
    affectedResources: ['db/prod-password', 'api/third-party-key', 'service/legacy-token'],
  },
];

const MOCK_FINDINGS: CloudFinding[] = [
  { id: 'cf1', resourceType: 'iam_user', resourceId: 'alice', arn: 'arn:aws:iam::123456789012:user/alice', region: 'global', service: 'IAM', severity: 'critical', title: 'Overprivileged user with iam:CreateAccessKey on *', description: 'User can create access keys for any IAM user, enabling privilege escalation.', remediation: 'Restrict iam:CreateAccessKey Resource to user\'s own ARN.' },
  { id: 'cf2', resourceType: 'iam_role', resourceId: 'DevOps', arn: 'arn:aws:iam::123456789012:role/DevOps', region: 'global', service: 'IAM', severity: 'critical', title: 'Wildcard trust principal on admin role', description: 'Trust policy allows Principal: "*" — any AWS account can assume this role.', remediation: 'Replace wildcard with specific account ARN and add ExternalId condition.' },
  { id: 'cf3', resourceType: 's3_bucket', resourceId: 'prod-customer-data', arn: 'arn:aws:s3:::prod-customer-data', region: 'us-east-1', service: 'S3', severity: 'critical', title: 'Public S3 bucket with customer data', description: 'Bucket has public read ACL and bucket policy allows anonymous GetObject.', remediation: 'Enable S3 Block Public Access and remove public ACL.' },
  { id: 'cf4', resourceType: 'iam_user', resourceId: 'bob', arn: 'arn:aws:iam::123456789012:user/bob', region: 'global', service: 'IAM', severity: 'high', title: 'PassRole + Lambda escalation path', description: 'User has lambda:CreateFunction and iam:PassRole allowing privilege escalation.', remediation: 'Remove iam:PassRole or add permission boundary.' },
  { id: 'cf5', resourceType: 'kms_key', resourceId: 'prod-encryption-key', arn: 'arn:aws:kms:us-east-1:123456789012:key/prod-encryption-key', region: 'us-east-1', service: 'KMS', severity: 'high', title: 'Cross-account decrypt access without conditions', description: 'External account can decrypt data without ViaService or context conditions.', remediation: 'Remove external account or add kms:ViaService condition.' },
  { id: 'cf6', resourceType: 'ec2_sg', resourceId: 'sg-0abc123', arn: 'arn:aws:ec2:us-east-1:123456789012:security-group/sg-0abc123', region: 'us-east-1', service: 'EC2', severity: 'high', title: 'SSH open to internet (0.0.0.0/0)', description: 'Security group allows inbound SSH from any IP. Attached to 3 production instances.', remediation: 'Restrict to VPN CIDR or use SSM Session Manager.' },
  { id: 'cf7', resourceType: 'iam_user', resourceId: 'multiple', arn: 'arn:aws:iam::123456789012:user/*', region: 'global', service: 'IAM', severity: 'medium', title: '5 users without MFA', description: 'Console users without multi-factor authentication enabled.', remediation: 'Enforce MFA via SCP or IAM policy condition.' },
  { id: 'cf8', resourceType: 'rds_instance', resourceId: 'prod-postgres', arn: 'arn:aws:rds:us-east-1:123456789012:db/prod-postgres', region: 'us-east-1', service: 'RDS', severity: 'medium', title: 'RDS instance publicly accessible', description: 'Database is publicly accessible and in a subnet with internet gateway route.', remediation: 'Set PubliclyAccessible=false and move to private subnet.' },
  { id: 'cf9', resourceType: 'secretsmanager', resourceId: 'multiple', arn: 'arn:aws:secretsmanager:us-east-1:123456789012:secret/*', region: 'us-east-1', service: 'Secrets Manager', severity: 'low', title: 'Secrets without rotation schedule', description: '3 secrets have no rotation configured and haven\'t been rotated in 90+ days.', remediation: 'Enable automatic rotation with 30-day schedule.' },
  { id: 'cf10', resourceType: 's3_bucket', resourceId: 'logs-archive', arn: 'arn:aws:s3:::logs-archive', region: 'us-east-1', service: 'S3', severity: 'low', title: 'S3 bucket without versioning', description: 'Bucket lacks versioning — accidental or malicious deletion is permanent.', remediation: 'Enable bucket versioning.' },
];

const MOCK_GRAPH: CloudGraphData = {
  nodes: [
    { id: 'user:alice', label: 'alice', type: 'user', x: 150, y: 200, vx: 0, vy: 0, severity: 'critical', details: 'iam:CreateAccessKey on *' },
    { id: 'user:bob', label: 'bob', type: 'user', x: 150, y: 350, vx: 0, vy: 0, severity: 'high', details: 'PassRole + Lambda' },
    { id: 'user:contractor01', label: 'contractor01', type: 'user', x: 100, y: 450, vx: 0, vy: 0, severity: 'medium', details: 'No MFA' },
    { id: 'role:DevOps', label: 'DevOps', type: 'role', x: 400, y: 150, vx: 0, vy: 0, severity: 'critical', details: 'Wildcard trust — AdminAccess' },
    { id: 'role:Lambda-Exec', label: 'Lambda-Exec', type: 'role', x: 400, y: 350, vx: 0, vy: 0, service: 'Lambda' },
    { id: 'role:Prod-Deploy', label: 'Prod-Deploy', type: 'role', x: 400, y: 250, vx: 0, vy: 0 },
    { id: 'group:Developers', label: 'Developers', type: 'group', x: 250, y: 280, vx: 0, vy: 0 },
    { id: 'esc:admin', label: 'Admin Access', type: 'escalation', x: 650, y: 200, vx: 0, vy: 0, severity: 'critical' },
    { id: 'data:s3:prod', label: 'prod-customer-data', type: 'data', x: 650, y: 350, vx: 0, vy: 0, severity: 'critical', service: 'S3' },
    { id: 'data:kms:prod', label: 'prod-encryption-key', type: 'data', x: 650, y: 450, vx: 0, vy: 0, severity: 'high', service: 'KMS' },
    { id: 'data:rds:prod', label: 'prod-postgres', type: 'data', x: 550, y: 500, vx: 0, vy: 0, severity: 'medium', service: 'RDS' },
    { id: 'ext:999888', label: '999888777666', type: 'external', x: 100, y: 100, vx: 0, vy: 0, severity: 'high', details: 'External AWS Account' },
    { id: 'service:lambda', label: 'Lambda', type: 'service', x: 350, y: 450, vx: 0, vy: 0, service: 'Lambda' },
    { id: 'network:sg', label: 'sg-0abc123', type: 'network', x: 500, y: 100, vx: 0, vy: 0, severity: 'high', details: 'SSH 0.0.0.0/0' },
  ],
  edges: [
    { source: 'user:alice', target: 'esc:admin', edgeType: 'priv_esc', severity: 'critical', label: 'CreateAccessKey → Admin' },
    { source: 'user:bob', target: 'role:Lambda-Exec', edgeType: 'priv_esc', severity: 'high', label: 'PassRole → Lambda' },
    { source: 'role:Lambda-Exec', target: 'esc:admin', edgeType: 'priv_esc', severity: 'high', label: 'Exec as Admin' },
    { source: 'ext:999888', target: 'role:DevOps', edgeType: 'cross_account', severity: 'critical', label: 'AssumeRole (wildcard)' },
    { source: 'role:DevOps', target: 'esc:admin', edgeType: 'priv_esc', severity: 'critical', label: 'AdminAccess' },
    { source: 'user:alice', target: 'group:Developers', edgeType: 'membership', label: 'MemberOf' },
    { source: 'user:bob', target: 'group:Developers', edgeType: 'membership', label: 'MemberOf' },
    { source: 'group:Developers', target: 'role:Prod-Deploy', edgeType: 'trust', label: 'CanAssume' },
    { source: 'role:Prod-Deploy', target: 'data:s3:prod', edgeType: 'data_access', severity: 'critical', label: 's3:GetObject' },
    { source: 'ext:999888', target: 'data:kms:prod', edgeType: 'data_access', severity: 'high', label: 'kms:Decrypt' },
    { source: 'service:lambda', target: 'role:Lambda-Exec', edgeType: 'service', label: 'ExecutionRole' },
    { source: 'network:sg', target: 'data:rds:prod', edgeType: 'network', severity: 'medium', label: 'Port 5432' },
    { source: 'user:contractor01', target: 'data:s3:prod', edgeType: 'data_access', severity: 'medium', label: 's3:ListBucket' },
  ],
};

const MOCK_SUMMARY: CloudScanSummary = {
  totalUsers: 15,
  totalRoles: 42,
  totalPolicies: 89,
  totalTrustRelationships: 34,
  criticalPrivEscRisks: 3,
  wildcardTrustPolicies: 1,
  crossAccountTrusts: 12,
  usersWithoutMfa: 5,
  riskScore: 'critical',
  servicesAnalyzed: 12,
  pathsByCategory: {
    privilege_escalation: 2,
    trust_misconfiguration: 1,
    data_exposure: 2,
    credential_risk: 2,
    network_exposure: 2,
    persistence: 0,
    lateral_movement: 0,
    permission_misconfiguration: 0,
  },
  reachability: {
    principalsWithAdminReach: 4,
    principalsWithDataReach: 8,
    maxBlastRadiusPrincipal: 'role/DevOps',
    maxBlastRadiusNodes: 28,
    avgHopCount: 2.3,
  },
};

const MOCK_TERMINAL_LINES: TerminalLine[] = [
  { id: 1, timestamp: '14:22:01', type: 'system', message: 'CloudScan v2.0 — AWS Security Assessment' },
  { id: 2, timestamp: '14:22:01', type: 'system', message: '═══════════════════════════════════════════════════════════' },
  { id: 3, timestamp: '14:22:02', type: 'info', message: '[+] Provider          : AWS' },
  { id: 4, timestamp: '14:22:02', type: 'info', message: '[+] Account           : 123456789012' },
  { id: 5, timestamp: '14:22:02', type: 'info', message: '[+] Caller            : arn:aws:iam::123456789012:user/auditor' },
  { id: 6, timestamp: '14:22:03', type: 'success', message: '[+] STS GetCallerIdentity — credentials verified' },
  { id: 7, timestamp: '14:22:03', type: 'info', message: '[+] Regions           : us-east-1, eu-west-1 (2 enabled)' },
  { id: 8, timestamp: '14:22:04', type: 'system', message: '── Phase 1: Enumeration (12 modules) ──────────────────────' },
  { id: 9, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating IAM...' },
  { id: 10, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating STS...' },
  { id: 11, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating S3...' },
  { id: 12, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating KMS...' },
  { id: 13, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating Secrets...' },
  { id: 14, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating Lambda...' },
  { id: 15, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating EC2...' },
  { id: 16, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating RDS...' },
  { id: 17, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating SNS...' },
  { id: 18, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating SQS...' },
  { id: 19, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating API Gateway...' },
  { id: 20, timestamp: '14:22:04', type: 'check', message: '[*] Enumerating CodeBuild...' },
  { id: 21, timestamp: '14:22:08', type: 'success', message: '    ✓ IAM enumeration complete — 15 users, 42 roles, 89 policies' },
  { id: 22, timestamp: '14:22:09', type: 'success', message: '    ✓ STS enumeration complete — 8 trust relationships' },
  { id: 23, timestamp: '14:22:11', type: 'warning', message: '    ⚠ S3: 1 public bucket detected (prod-customer-data)' },
  { id: 24, timestamp: '14:22:12', type: 'success', message: '    ✓ S3 enumeration complete — 12 buckets analyzed' },
  { id: 25, timestamp: '14:22:14', type: 'warning', message: '    ⚠ KMS: Cross-account decrypt on prod-encryption-key' },
  { id: 26, timestamp: '14:22:15', type: 'success', message: '    ✓ KMS complete | ✓ Secrets complete' },
  { id: 27, timestamp: '14:22:17', type: 'success', message: '    ✓ Lambda complete — 8 functions' },
  { id: 28, timestamp: '14:22:19', type: 'warning', message: '    ⚠ EC2: sg-0abc123 allows SSH from 0.0.0.0/0' },
  { id: 29, timestamp: '14:22:20', type: 'success', message: '    ✓ EC2 complete — 15 instances, 23 security groups' },
  { id: 30, timestamp: '14:22:22', type: 'warning', message: '    ⚠ RDS: prod-postgres is publicly accessible' },
  { id: 31, timestamp: '14:22:23', type: 'success', message: '    ✓ RDS | ✓ SNS | ✓ SQS | ✓ API Gateway | ✓ CodeBuild' },
  { id: 32, timestamp: '14:22:24', type: 'info', message: '    12/12 modules complete' },
  { id: 33, timestamp: '14:22:25', type: 'system', message: '── Phase 2: Attack Path Analysis ──────────────────────────' },
  { id: 34, timestamp: '14:22:26', type: 'check', message: '[*] Building identity graph from enumeration data...' },
  { id: 35, timestamp: '14:22:28', type: 'check', message: '[*] Extracting trust relationships...' },
  { id: 36, timestamp: '14:22:30', type: 'error', message: '    ✗ CRITICAL: Wildcard trust on role DevOps — any account can assume' },
  { id: 37, timestamp: '14:22:31', type: 'check', message: '[*] Analyzing privilege escalation paths...' },
  { id: 38, timestamp: '14:22:33', type: 'error', message: '    ✗ CRITICAL: alice → CreateAccessKey → Admin (trivial)' },
  { id: 39, timestamp: '14:22:34', type: 'error', message: '    ✗ CRITICAL: Public S3 bucket with customer data' },
  { id: 40, timestamp: '14:22:35', type: 'warning', message: '    ⚠ HIGH: bob → PassRole → Lambda → Admin (easy)' },
  { id: 41, timestamp: '14:22:36', type: 'warning', message: '    ⚠ HIGH: Cross-account KMS decrypt without conditions' },
  { id: 42, timestamp: '14:22:37', type: 'check', message: '[*] Computing reachability and blast radius...' },
  { id: 43, timestamp: '14:22:39', type: 'info', message: '    4 principals with admin reach | avg 2.3 hops' },
  { id: 44, timestamp: '14:22:40', type: 'info', message: '    Max blast radius: role/DevOps (28 reachable nodes)' },
  { id: 45, timestamp: '14:22:41', type: 'system', message: '── Phase 3: Verification ──────────────────────────────────' },
  { id: 46, timestamp: '14:22:42', type: 'success', message: '    ✓ All claims verified against evidence ledger' },
  { id: 47, timestamp: '14:22:43', type: 'success', message: '    ✓ MITRE ATT&CK technique IDs validated' },
  { id: 48, timestamp: '14:22:44', type: 'system', message: '═══════════════════════════════════════════════════════════' },
  { id: 49, timestamp: '14:22:44', type: 'error', message: 'Risk Score: CRITICAL' },
  { id: 50, timestamp: '14:22:44', type: 'info', message: 'Attack Paths: 9 total | Critical: 3 | High: 3 | Medium: 2 | Low: 1' },
  { id: 51, timestamp: '14:22:44', type: 'info', message: '12 services analyzed | 14 graph nodes | 13 edges' },
  { id: 52, timestamp: '14:22:44', type: 'success', message: 'Scan complete — results ready for review' },
];

const MOCK_MODULE_STATUS: EnumModuleStatus[] = [
  { id: 'iam', name: 'IAM', status: 'complete', findingsCount: 4 },
  { id: 'sts', name: 'STS', status: 'complete', findingsCount: 1 },
  { id: 's3', name: 'S3', status: 'complete', findingsCount: 2 },
  { id: 'kms', name: 'KMS', status: 'complete', findingsCount: 1 },
  { id: 'secrets', name: 'Secrets Manager', status: 'complete', findingsCount: 1 },
  { id: 'lambda', name: 'Lambda', status: 'complete', findingsCount: 0 },
  { id: 'ec2', name: 'EC2', status: 'complete', findingsCount: 1 },
  { id: 'rds', name: 'RDS', status: 'complete', findingsCount: 1 },
  { id: 'sns', name: 'SNS', status: 'complete', findingsCount: 0 },
  { id: 'sqs', name: 'SQS', status: 'complete', findingsCount: 0 },
  { id: 'apigateway', name: 'API Gateway', status: 'complete', findingsCount: 0 },
  { id: 'codebuild', name: 'CodeBuild', status: 'complete', findingsCount: 0 },
];

// --- API Functions ---

export async function startCloudScan(config: CloudScanConfig): Promise<{ scanId: string }> {
  try {
    const response = await fetch(`${CLOUDSCAN_API_URL}/api/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    if (!response.ok) throw new Error(`Scan request failed: ${response.statusText}`);
    return response.json();
  } catch {
    return { scanId: 'mock-cloud-' + Date.now() };
  }
}

/**
 * Live-only scan start. Throws on failure instead of falling back to mock.
 * Used by the Start Scan button (requires real backend + credentials).
 */
export async function startCloudScanLive(config: CloudScanConfig): Promise<{ scanId: string }> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${CLOUDSCAN_API_URL}/api/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
      signal: controller.signal,
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(text || response.statusText);
    }
    return response.json();
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') {
      throw new Error('Connection timed out — backend did not respond within 15 seconds');
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

export function isMockScan(scanId: string): boolean {
  return scanId.startsWith('mock-');
}

export async function getCloudScanStatus(scanId: string): Promise<{ status: CloudScanStatus; moduleStatus: Record<string, string> }> {
  const response = await fetch(`${CLOUDSCAN_API_URL}/api/scan/${scanId}/status`);
  if (!response.ok) throw new Error(`Status check failed: ${response.statusText}`);
  const data = await response.json();
  return { status: data.status, moduleStatus: data.moduleStatus ?? {} };
}

export async function getCloudScanResults(scanId: string): Promise<CloudScanResult> {
  const response = await fetch(`${CLOUDSCAN_API_URL}/api/scan/${scanId}/results`);
  if (!response.ok) throw new Error(`Results fetch failed: ${response.statusText}`);
  return response.json();
}

export async function getCloudGraphData(scanId: string): Promise<import('@/types/cloudscan').CloudGraphData> {
  try {
    const response = await fetch(`${CLOUDSCAN_API_URL}/api/graph/${scanId}`);
    if (!response.ok) throw new Error('Failed to get graph');
    return response.json();
  } catch {
    return getMockCloudScanResult().graph;
  }
}

/**
 * Fetches all output lines from the backend HTTP endpoint.
 */
export async function getCloudScanOutput(scanId: string): Promise<TerminalLine[]> {
  try {
    const resp = await fetch(`${CLOUDSCAN_API_URL}/api/scan/${scanId}/output`, {
      signal: AbortSignal.timeout(5000),
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return (data.lines || []) as TerminalLine[];
  } catch {
    return [];
  }
}

/**
 * Opens a WebSocket to the CloudScan backend for live terminal streaming.
 * Falls back to HTTP polling if WebSocket fails or is slow to connect.
 * Lines are deduplicated by ID so WS replay + HTTP poll don't double-print.
 */
export function connectCloudScanWebSocket(
  scanId: string,
  onLine: (line: TerminalLine) => void,
  onClose?: () => void,
): () => void {
  const seenIds = new Set<number>();
  let httpPollTimer: ReturnType<typeof setInterval> | null = null;
  let wsConnected = false;
  let stopped = false;

  const emitLine = (line: TerminalLine) => {
    const id = line.id ?? 0;
    if (!seenIds.has(id)) {
      seenIds.add(id);
      onLine(line);
    }
  };

  const startHttpPoll = () => {
    if (httpPollTimer || stopped) return;
    httpPollTimer = setInterval(async () => {
      if (stopped) { clearInterval(httpPollTimer!); return; }
      const lines = await getCloudScanOutput(scanId);
      lines.forEach(emitLine);
    }, 1500);
  };

  const wsUrl = CLOUDSCAN_API_URL.replace(/^https?/, (p) => (p === 'https' ? 'wss' : 'ws'));
  let ws: WebSocket;
  try {
    ws = new WebSocket(`${wsUrl}/ws/scan/${scanId}`);
  } catch {
    startHttpPoll();
    return () => { stopped = true; if (httpPollTimer) clearInterval(httpPollTimer); onClose?.(); };
  }

  ws.onopen = () => { wsConnected = true; };

  ws.onmessage = (event) => {
    try { emitLine(JSON.parse(event.data)); } catch { /* ignore malformed */ }
  };

  ws.onerror = () => {
    ws.close();
    if (!wsConnected) startHttpPoll();
  };

  ws.onclose = () => {
    // Always start HTTP poll when WS drops — even if it was connected.
    // seenIds deduplicates so replayed lines are not double-emitted.
    if (!stopped) startHttpPoll();
    if (!stopped) onClose?.();
  };

  // If WS doesn't open within 3s, start HTTP poll alongside it as safety net
  const wsTimeout = setTimeout(() => {
    if (!wsConnected && !stopped) startHttpPoll();
  }, 3000);

  return () => {
    stopped = true;
    clearTimeout(wsTimeout);
    if (httpPollTimer) clearInterval(httpPollTimer);
    if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
      ws.close();
    }
  };
}

/**
 * Polls cloud scan status until completed or error.
 * Retries on transient network errors rather than stopping.
 */
export async function cancelCloudScan(scanId: string): Promise<void> {
  try {
    await fetch(`${CLOUDSCAN_API_URL}/api/scan/${scanId}/cancel`, { method: 'POST' });
  } catch { /* best-effort */ }
}

export async function pollCloudScanUntilComplete(
  scanId: string,
  onStatusChange: (status: CloudScanStatus, moduleStatus: Record<string, string>) => void,
  intervalMs = 3000,
): Promise<CloudScanStatus> {
  return new Promise((resolve) => {
    let consecutiveErrors = 0;
    let cancelled = false;
    const stop = () => { cancelled = true; };

    const poll = async () => {
      if (cancelled) return;
      try {
        const { status, moduleStatus } = await getCloudScanStatus(scanId);
        consecutiveErrors = 0;
        onStatusChange(status, moduleStatus);
        if (status === 'completed' || status === 'error' || status === 'cancelled' as string) {
          resolve(status);
        } else {
          setTimeout(poll, intervalMs);
        }
      } catch {
        consecutiveErrors++;
        if (consecutiveErrors >= 5) {
          resolve('error');
        } else {
          setTimeout(poll, intervalMs * consecutiveErrors);
        }
      }
    };
    poll();
    // Attach a stop method so callers can cancel the poll
    (resolve as unknown as { stop: () => void }).stop = stop;
  });
}

export function getMockCloudScanResult(): CloudScanResult {
  return {
    id: 'mock-cloud-1',
    accountId: '123456789012',
    provider: 'aws',
    scanTime: new Date().toISOString(),
    status: 'completed',
    summary: MOCK_SUMMARY,
    graph: MOCK_GRAPH,
    attackPaths: MOCK_ATTACK_PATHS,
    findings: MOCK_FINDINGS,
    trustRelationships: [],
  };
}

export function getMockTerminalLines(): TerminalLine[] {
  return MOCK_TERMINAL_LINES;
}

export function getMockModuleStatus(): EnumModuleStatus[] {
  return MOCK_MODULE_STATUS;
}
