import { supabase } from '@/integrations/supabase/client';
import type { EnvironmentVariable } from '@/types/agent-data';

export const EnvironmentVariablesService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('environment_variables')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching environment variables:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('environment_variables')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all environment variables:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getSensitiveVariables() {
    try {
      const { data, error } = await supabase
        .from('environment_variables')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('is_sensitive', true)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching sensitive variables:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
