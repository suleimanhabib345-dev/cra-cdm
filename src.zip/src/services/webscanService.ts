import type {
  WebScanConfig,
  WebScanResult,
  WebScanStatus,
  WebVulnerability,
  WebVulnSeverity,
  MCPToolCall,
  BrowserState,
  CrawlNode,
  WSEvent,
  WSEventType,
  WebScanHistoryEntry,
  AIProviderConfig,
} from '@/types/webscan';
import type { TerminalLine } from '@/types/adscan';
import {
  loadProviderConfig as _loadProviderConfig,
  saveProviderConfig as _saveProviderConfig,
  testAIProvider as _testAIProvider,
} from '@/services/aiProviderService';

const WEBSCAN_API_URL = import.meta.env.VITE_WEBSCAN_API_URL || 'http://localhost:8402';

// ── Mock Data (fallback when backend is unavailable) ────────────────────────

const MOCK_VULNS: WebVulnerability[] = [
  {
    id: 'wv-1', title: 'SQL Injection in login form', severity: 'critical', cvss: 9.8,
    cwe: 'CWE-89', endpoint: '/api/auth/login', method: 'POST', parameter: 'username',
    description: 'The login endpoint is vulnerable to SQL injection through the username parameter.',
    evidence: "' OR 1=1 --",
    remediation: 'Use parameterized queries or an ORM. Never concatenate user input into SQL statements.',
    references: ['https://owasp.org/www-community/attacks/SQL_Injection'],
  },
  {
    id: 'wv-2', title: 'Cross-Site Scripting (Reflected XSS)', severity: 'high', cvss: 7.5,
    cwe: 'CWE-79', endpoint: '/search?q=', method: 'GET', parameter: 'q',
    description: 'Reflected XSS vulnerability in search functionality allows script injection.',
    evidence: '<img src=x onerror=alert(1)>',
    remediation: 'Encode all user-supplied output. Implement Content-Security-Policy headers.',
  },
  {
    id: 'wv-3', title: 'Missing Content-Security-Policy', severity: 'medium', cvss: 5.3,
    cwe: 'CWE-1021', endpoint: '/', method: 'GET',
    description: 'No Content-Security-Policy header is set, increasing XSS attack surface.',
    remediation: 'Implement a strict CSP header with nonce or hash-based script allowlisting.',
  },
  {
    id: 'wv-4', title: 'Information Disclosure via Error Messages', severity: 'medium', cvss: 4.7,
    cwe: 'CWE-209', endpoint: '/api/v2/users', method: 'GET',
    description: 'Detailed error messages expose internal stack traces and framework versions.',
    remediation: 'Implement generic error responses in production. Log details server-side only.',
  },
  {
    id: 'wv-5', title: 'Missing HSTS Header', severity: 'medium', cvss: 4.8,
    cwe: 'CWE-319', endpoint: '/', method: 'GET',
    description: 'Strict-Transport-Security is not set. Users can be downgraded to HTTP.',
    remediation: 'Set Strict-Transport-Security: max-age=31536000; includeSubDomains; preload.',
  },
  {
    id: 'wv-6', title: 'Missing X-Frame-Options Header', severity: 'low', cvss: 3.1,
    cwe: 'CWE-1021', endpoint: '/', method: 'GET',
    description: 'Without X-Frame-Options, the application may be vulnerable to clickjacking.',
    remediation: 'Set X-Frame-Options: DENY or SAMEORIGIN header.',
  },
  {
    id: 'wv-7', title: 'Server Version Disclosure', severity: 'info', cvss: 0.0,
    cwe: 'CWE-200', endpoint: '/', method: 'GET',
    description: 'Server header reveals software version information.',
    evidence: 'Server: nginx/1.24.0',
    remediation: 'Remove or obfuscate the Server header in production.',
  },
];

const MOCK_TERMINAL_LINES: TerminalLine[] = [
  { id: 1, timestamp: '15:30:01', type: 'system', message: 'WebScan v1.0 — Playwright-Based Web Security Scanner' },
  { id: 2, timestamp: '15:30:01', type: 'system', message: '=========================================================' },
  { id: 3, timestamp: '15:30:02', type: 'info', message: '[+] Target: https://app.example.com' },
  { id: 4, timestamp: '15:30:02', type: 'info', message: '[+] Scan type: full' },
  { id: 5, timestamp: '15:30:03', type: 'success', message: '[+] Target reachable (HTTP 200)' },
  { id: 6, timestamp: '15:30:03', type: 'info', message: '[+] Technologies: React, Next.js, Tailwind CSS' },
  { id: 7, timestamp: '15:30:04', type: 'system', message: '-- Phase 1: Crawling ---------------------------------------' },
  { id: 8, timestamp: '15:30:04', type: 'info', message: '  Max depth: 3 | Max pages: 50' },
  { id: 9, timestamp: '15:30:05', type: 'success', message: '  [200] https://app.example.com/ — 12 links (340ms)' },
  { id: 10, timestamp: '15:30:06', type: 'success', message: '  [200] https://app.example.com/login — 3 links (280ms)' },
  { id: 11, timestamp: '15:30:07', type: 'success', message: '  [200] https://app.example.com/dashboard — 8 links (450ms)' },
  { id: 12, timestamp: '15:30:08', type: 'success', message: '  [200] https://app.example.com/api/docs — 5 links (190ms)' },
  { id: 13, timestamp: '15:30:09', type: 'warning', message: '  [403] https://app.example.com/admin — 0 links (120ms)' },
  { id: 14, timestamp: '15:30:10', type: 'success', message: '  [200] https://app.example.com/search — 2 links (210ms)' },
  { id: 15, timestamp: '15:30:11', type: 'info', message: 'Crawl complete: 6 pages visited, 0 errors' },
  { id: 16, timestamp: '15:30:12', type: 'system', message: '-- Phase 2: Security Audit ---------------------------------' },
  { id: 17, timestamp: '15:30:13', type: 'check', message: '  [MCP] browser_navigate({"url":"https://app.example.com/"})' },
  { id: 18, timestamp: '15:30:14', type: 'check', message: '  [MCP] check_headers({"url":"https://app.example.com/"})' },
  { id: 19, timestamp: '15:30:15', type: 'warning', message: '  [MEDIUM] Missing Content-Security-Policy Header — /' },
  { id: 20, timestamp: '15:30:15', type: 'warning', message: '  [MEDIUM] Missing HSTS Header — /' },
  { id: 21, timestamp: '15:30:16', type: 'warning', message: '  [LOW] Missing X-Frame-Options Header — /' },
  { id: 22, timestamp: '15:30:17', type: 'check', message: '  [MCP] browser_navigate({"url":"https://app.example.com/login"})' },
  { id: 23, timestamp: '15:30:18', type: 'check', message: '  [MCP] xss_test({"url":"/search?q=","param":"q"})' },
  { id: 24, timestamp: '15:30:19', type: 'error', message: '  [HIGH] Reflected XSS in \'q\' Parameter — /search?q=' },
  { id: 25, timestamp: '15:30:20', type: 'error', message: '  [CRITICAL] SQL Injection in login form — /api/auth/login' },
  { id: 26, timestamp: '15:30:21', type: 'warning', message: '  [MEDIUM] Information Disclosure via Error Messages — /api/v2/users' },
  { id: 27, timestamp: '15:30:22', type: 'check', message: '  [MCP] get_content({"url":"https://app.example.com/"})' },
  { id: 28, timestamp: '15:30:23', type: 'info', message: '  [INFO] Server Version Disclosure — /' },
  { id: 29, timestamp: '15:30:24', type: 'info', message: 'Audit complete: 7 vulnerabilities found' },
  { id: 30, timestamp: '15:30:25', type: 'system', message: '=========================================================' },
  { id: 31, timestamp: '15:30:25', type: 'success', message: 'Scan complete — 7 finding(s)' },
  { id: 32, timestamp: '15:30:25', type: 'info', message: '  Critical: 1 | High: 1 | Medium: 3 | Low: 1' },
];

const MOCK_TOOL_CALLS: MCPToolCall[] = [
  { id: 'tc-1', timestamp: '15:30:13', tool: 'browser_navigate', params: { url: 'https://app.example.com/' }, result: 'status=200', duration: 340, status: 'success' },
  { id: 'tc-2', timestamp: '15:30:14', tool: 'browser_check_headers', params: { url: 'https://app.example.com/' }, result: 'headers=8', duration: 120, status: 'success' },
  { id: 'tc-3', timestamp: '15:30:17', tool: 'browser_navigate', params: { url: 'https://app.example.com/login' }, result: 'status=200', duration: 280, status: 'success' },
  { id: 'tc-4', timestamp: '15:30:18', tool: 'browser_xss_test', params: { url: '/search?q=', param: 'q' }, result: 'reflected=yes', duration: 450, status: 'success' },
  { id: 'tc-5', timestamp: '15:30:22', tool: 'browser_get_content', params: { url: 'https://app.example.com/' }, result: 'len=24580', duration: 80, status: 'success' },
];

// ── API Functions ───────────────────────────────────────────────────────────

export interface AIScanSettings {
  aiMaxSteps?: number;
  aiMaxInputTokens?: number | null;
  aiMaxOutputTokens?: number | null;
  aiTemperature?: number | null;
  aiTopP?: number | null;
  aiSafeTokenThreshold?: number;
  aiAutoTokenShrinking?: boolean;
  aiChunkingEnabled?: boolean;
  aiToolCallRetries?: number;
}

export async function startWebScan(config: {
  targetUrl: string;
  scanType: string;
  maxDepth?: number;
  maxPages?: number;
  headless?: boolean;
  includeSubdomains?: boolean;
  excludePatterns?: string[];
  aiProvider?: string;
  aiApiKey?: string;
  aiModel?: string;
  aiBaseUrl?: string;
  agentId?: string;
  agentName?: string;
  agentInstructions?: string;
} & AIScanSettings): Promise<{ scanId: string }> {
  const response = await fetch(`${WEBSCAN_API_URL}/api/scan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  if (!response.ok) throw new Error(`Scan request failed: ${response.statusText}`);
  return response.json();
}

export async function startWebScanLive(config: {
  targetUrl: string;
  scanType: string;
  maxDepth?: number;
  maxPages?: number;
  headless?: boolean;
  includeSubdomains?: boolean;
  excludePatterns?: string[];
  aiProvider?: string;
  aiApiKey?: string;
  aiModel?: string;
  aiBaseUrl?: string;
  agentId?: string;
  agentName?: string;
  agentInstructions?: string;
} & AIScanSettings): Promise<{ scanId: string }> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${WEBSCAN_API_URL}/api/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
      signal: controller.signal,
    });
    if (!response.ok) {
      const text = await response.text().catch(() => response.statusText);
      throw new Error(text || response.statusText);
    }
    return response.json();
  } catch (err) {
    if (err instanceof Error) {
      if (err.name === 'AbortError') {
        throw new Error('WebScan backend did not respond within 15s — is the Docker container running?');
      }
      // "Load failed" / "Failed to fetch" = network-level block (CORS, mixed-content, or backend down)
      const msg = err.message;
      if (msg === 'Load failed' || msg === 'Failed to fetch' || msg === 'NetworkError when attempting to fetch resource.') {
        const backendHost = new URL(WEBSCAN_API_URL).hostname;
        throw new Error(
          `Cannot reach WebScan backend (${WEBSCAN_API_URL}). ` +
          `Likely causes: (1) Docker container not running — ssh to EC2 and run ` +
          `"cd ~/cra-build/docker/webscan && docker compose up -d --build", ` +
          `(2) Mixed-content: frontend is HTTPS but backend is HTTP — put backend behind nginx+SSL on port 443, ` +
          `(3) Firewall: ensure port 8402 is open in EC2 security group`
        );
      }
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

export function isMockScan(scanId: string): boolean {
  return scanId.startsWith('mock-');
}

export async function getWebScanStatus(scanId: string): Promise<{
  status: WebScanStatus;
  findingsCount: number;
  toolCallsCount: number;
}> {
  const response = await fetch(`${WEBSCAN_API_URL}/api/scan/${scanId}/status`);
  if (!response.ok) throw new Error('Failed to get scan status');
  return response.json();
}

export async function getWebScanResults(scanId: string): Promise<WebScanResult | null> {
  try {
    const response = await fetch(`${WEBSCAN_API_URL}/api/scan/${scanId}/results`);
    if (!response.ok) throw new Error('Failed to get results');
    return response.json();
  } catch {
    return null;
  }
}

export async function cancelWebScan(scanId: string): Promise<void> {
  try {
    await fetch(`${WEBSCAN_API_URL}/api/scan/${scanId}/cancel`, { method: 'POST' });
  } catch { /* ignore */ }
}

export async function getWebScanScreenshot(scanId: string): Promise<string | null> {
  try {
    const response = await fetch(`${WEBSCAN_API_URL}/api/scan/${scanId}/screenshot`);
    if (!response.ok) return null;
    const data = await response.json();
    return data.image;
  } catch {
    return null;
  }
}

export async function testAIProvider(config: {
  provider: string;
  apiKey: string;
  model: string;
  baseUrl?: string;
}): Promise<{ status: string; error?: string; response?: string }> {
  return _testAIProvider(config, WEBSCAN_API_URL);
}

// ── WebSocket ───────────────────────────────────────────────────────────────

export interface WebScanWSCallbacks {
  onTerminal?: (line: TerminalLine) => void;
  onScreenshot?: (b64: string) => void;
  onBrowserState?: (state: BrowserState) => void;
  onCrawlProgress?: (node: CrawlNode) => void;
  onFinding?: (finding: WebVulnerability) => void;
  onToolCall?: (tc: MCPToolCall) => void;
  onStatus?: (status: WebScanStatus) => void;
  onSync?: (seq: number) => void;
  onClose?: () => void;
}

export function connectWebScanWebSocket(
  scanId: string,
  callbacks: WebScanWSCallbacks,
  since = 0,
): () => void {
  const wsUrl = WEBSCAN_API_URL.replace(/^http/, 'ws');
  const url = since > 0 ? `${wsUrl}/ws/scan/${scanId}?since=${since}` : `${wsUrl}/ws/scan/${scanId}`;
  const ws = new WebSocket(url);

  ws.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data) as WSEvent;
      switch (msg.type) {
        case 'terminal':
          callbacks.onTerminal?.(msg.data as TerminalLine);
          break;
        case 'screenshot':
          callbacks.onScreenshot?.((msg.data as { image: string }).image);
          break;
        case 'browser_state':
          callbacks.onBrowserState?.(msg.data as BrowserState);
          break;
        case 'crawl_progress':
          callbacks.onCrawlProgress?.(msg.data as CrawlNode);
          break;
        case 'finding': {
          // Normalize snake_case keys from Python asdict() to camelCase
          const raw = msg.data as Record<string, unknown>;
          const finding: WebVulnerability = {
            ...(raw as unknown as WebVulnerability),
            affectedEndpoints: (raw.affected_endpoints as string[] | undefined) ?? [],
          };
          callbacks.onFinding?.(finding);
          break;
        }
        case 'tool_call':
          callbacks.onToolCall?.(msg.data as MCPToolCall);
          break;
        case 'status':
          callbacks.onStatus?.((msg.data as { status: WebScanStatus }).status);
          break;
        case 'sync':
          callbacks.onSync?.((msg.data as { seq: number }).seq);
          break;
      }
    } catch { /* ignore malformed */ }
  };

  ws.onclose = () => callbacks.onClose?.();
  ws.onerror = () => ws.close();

  return () => {
    if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
      ws.close();
    }
  };
}

// ── Poll until complete ─────────────────────────────────────────────────────

export async function pollWebScanUntilComplete(
  scanId: string,
  onStatusChange: (status: WebScanStatus) => void,
  intervalMs = 2000,
): Promise<WebScanStatus> {
  return new Promise((resolve) => {
    let consecutiveErrors = 0;
    const poll = async () => {
      try {
        const { status } = await getWebScanStatus(scanId);
        consecutiveErrors = 0;
        onStatusChange(status);
        if (status === 'completed' || status === 'error' || status === 'cancelled') {
          resolve(status);
        } else {
          setTimeout(poll, intervalMs);
        }
      } catch {
        consecutiveErrors++;
        if (consecutiveErrors >= 5) {
          resolve('error');
        } else {
          setTimeout(poll, intervalMs * consecutiveErrors);
        }
      }
    };
    poll();
  });
}

// ── Mock Data Accessors ─────────────────────────────────────────────────────

export function getMockWebVulns(): WebVulnerability[] {
  return MOCK_VULNS;
}

export function getMockTerminalLines(): TerminalLine[] {
  return MOCK_TERMINAL_LINES;
}

export function getMockToolCalls(): MCPToolCall[] {
  return MOCK_TOOL_CALLS;
}

// ── History Persistence ─────────────────────────────────────────────────────

const WEB_HISTORY_KEY = 'cra_webscan_history';

export function loadWebScanHistory(): WebScanHistoryEntry[] {
  try {
    const stored = localStorage.getItem(WEB_HISTORY_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch { /* ignore */ }
  return [];
}

export function saveWebScanHistory(entries: WebScanHistoryEntry[]) {
  localStorage.setItem(WEB_HISTORY_KEY, JSON.stringify(entries));
}

// ── Provider Persistence — delegates to shared service ─────────────────────

export function loadProviderConfig(): AIProviderConfig | null {
  return _loadProviderConfig();
}

export function saveProviderConfig(config: AIProviderConfig) {
  _saveProviderConfig(config);
}
