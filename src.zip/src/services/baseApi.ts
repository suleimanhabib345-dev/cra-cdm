
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';

export type ApiResponse<T> = {
  data: T | null;
  error: string | null;
  status: number;
};

async function request<T>(
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
  body?: any
): Promise<ApiResponse<T>> {
  try {
    // For direct Supabase access instead of edge functions
    if (endpoint.startsWith('direct:')) {
      const directEndpoint = endpoint.replace('direct:', '');
      let result;
      
      switch (method) {
        case 'GET':
          result = await supabase.from(directEndpoint as any).select('*');
          break;
        case 'POST':
          result = await supabase.from(directEndpoint as any).insert(body).select();
          break;
        case 'PUT':
          const { id, ...updateData } = body;
          result = await supabase.from(directEndpoint as any).update(updateData).eq('id', id).select();
          break;
        case 'DELETE':
          result = await supabase.from(directEndpoint as any).delete().eq('id', body);
          break;
        default:
          throw new Error(`Unsupported method: ${method}`);
      }

      if (result.error) {
        console.error(`Supabase error for ${directEndpoint}:`, result.error);
        return { 
          data: null, 
          error: result.error.message, 
          status: result.error.code === '23505' ? 409 : 500 
        };
      }
      
      return { data: result.data as T, error: null, status: 200 };
    }

    // Edge function request approach
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError) {
      console.error('Authentication error:', sessionError);
      return { data: null, error: 'Authentication error', status: 401 };
    }
    
    const token = sessionData.session?.access_token;
    
    // For public endpoints that don't require authentication
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
    
    console.log(`Making ${method} request to ${endpoint}`, body ? 'with body' : 'without body');
    
    const { data, error } = await supabase.functions.invoke(`api/${endpoint}`, {
      body: body ? JSON.stringify(body) : undefined,
      headers,
      method,
    });
    
    if (error) {
      console.error(`API error for ${endpoint}:`, error);
      return { data: null, error: error.message, status: error.status || 500 };
    }
    
    return { data: data as T, error: null, status: 200 };
  } catch (err) {
    console.error(`API request exception for ${endpoint}:`, err);
    const errorMessage = err instanceof Error ? err.message : "Unknown error occurred";
    return { data: null, error: errorMessage, status: 500 };
  }
}

export { request };
