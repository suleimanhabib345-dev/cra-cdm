import { supabase } from '@/integrations/supabase/client';
import type { SystemService } from '@/types/agent-data';

export const SystemServicesService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('system_services')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false});

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching system services:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('system_services')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all system services:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getRunningServices(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('system_services')
        .select('*')
        .eq('agent_id', agentId)
        .eq('status', 'running')
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching running services:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
