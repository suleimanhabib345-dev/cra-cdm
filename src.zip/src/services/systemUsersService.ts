import { supabase } from '@/integrations/supabase/client';
import type { SystemUser } from '@/types/agent-data';

export const SystemUsersService = {
  async getByAgent(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('system_users')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching system users:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAll() {
    try {
      const { data, error } = await supabase
        .from('system_users')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching all system users:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getAdminUsers() {
    try {
      const { data, error } = await supabase
        .from('system_users')
        .select(`
          *,
          agent:agents(hostname, platform)
        `)
        .eq('is_admin', true)
        .order('detected_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching admin users:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
