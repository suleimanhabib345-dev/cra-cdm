/**
 * Shared AI Provider Service
 * Used by WebScan, CloudScan, and ADScan — single source of truth for provider config.
 */

export type AIProviderType = 'openai' | 'anthropic' | 'openrouter' | 'groq' | 'gemini' | 'custom';

export interface AIProviderConfig {
  id: string;
  name: string;
  type: AIProviderType;
  apiKey: string;
  model: string;
  baseUrl?: string;
  maxTokens?: number;
  temperature?: number;
}

// Shared localStorage key — all scan modules read from here
export const PROVIDER_STORAGE_KEY = 'cra_webscan_provider';

const BASE_URLS: Record<string, string> = {
  openai:     'https://api.openai.com/v1',
  openrouter: 'https://openrouter.ai/api/v1',
  groq:       'https://api.groq.com/openai/v1',
  gemini:     'https://generativelanguage.googleapis.com/v1beta/openai',
};

export function loadProviderConfig(): AIProviderConfig | null {
  try {
    const stored = localStorage.getItem(PROVIDER_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch { /* ignore */ }
  return null;
}

export function saveProviderConfig(config: AIProviderConfig) {
  localStorage.setItem(PROVIDER_STORAGE_KEY, JSON.stringify(config));
}

// Direct browser test — works for OpenRouter, Groq, OpenAI (all support CORS)
async function _testProviderDirect(config: {
  provider: string;
  apiKey: string;
  model: string;
  baseUrl?: string;
}): Promise<{ status: string; error?: string; response?: string }> {
  const base = config.baseUrl || BASE_URLS[config.provider];
  if (!base) {
    return { status: 'error', error: `No API base URL for provider "${config.provider}" — configure Base URL` };
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${config.apiKey}`,
  };
  if (config.provider === 'openrouter') {
    headers['HTTP-Referer'] = 'https://cra.io';
    headers['X-Title'] = 'CRACDM';
  }

  try {
    const resp = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: config.model,
        messages: [{ role: 'user', content: "Say 'ok'" }],
        max_tokens: 5,
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({ error: { message: resp.statusText } }));
      const msg = (err as { error?: { message?: string } })?.error?.message || `HTTP ${resp.status}`;
      return { status: 'error', error: msg };
    }

    const data = await resp.json() as { choices?: { message?: { content?: string } }[] };
    return { status: 'ok', response: data.choices?.[0]?.message?.content ?? 'ok' };
  } catch (err) {
    return { status: 'error', error: err instanceof Error ? err.message : 'Direct connection failed' };
  }
}

/**
 * Test an AI provider. Tries the backend first (proxied test), falls back
 * to direct browser call. Works when the backend is unreachable.
 */
export async function testAIProvider(
  config: { provider: string; apiKey: string; model: string; baseUrl?: string },
  backendUrl?: string,
): Promise<{ status: string; error?: string; response?: string }> {
  if (backendUrl) {
    try {
      const response = await fetch(`${backendUrl}/api/provider/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
        signal: AbortSignal.timeout(20000),
      });
      if (response.ok) return response.json();
    } catch { /* fall through to direct test */ }
  }

  // Backend unreachable — test directly from browser
  return _testProviderDirect(config);
}
