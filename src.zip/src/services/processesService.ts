import { supabase } from '@/integrations/supabase/client';
import type { SystemProcess } from '@/types/agent-data';

export const ProcessesService = {
  async getByAgent(agentId: string, limit: number = 1000) {
    try {
      const { data, error } = await supabase
        .from('system_processes')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching system processes:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getLatestSnapshot(agentId: string) {
    try {
      // Get the latest snapshot timestamp
      const { data: latestData, error: latestError } = await supabase
        .from('system_processes')
        .select('detected_at')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false })
        .limit(1)
        .single();

      if (latestError || !latestData) {
        return { data: [], error: null };
      }

      // Get all processes from that snapshot
      const { data, error } = await supabase
        .from('system_processes')
        .select('*')
        .eq('agent_id', agentId)
        .eq('detected_at', latestData.detected_at);

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching latest process snapshot:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
