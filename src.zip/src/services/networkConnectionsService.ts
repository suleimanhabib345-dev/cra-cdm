import { supabase } from '@/integrations/supabase/client';
import type { NetworkConnection } from '@/types/agent-data';

export const NetworkConnectionsService = {
  async getByAgent(agentId: string, limit: number = 1000) {
    try {
      const { data, error } = await supabase
        .from('network_connections')
        .select('*')
        .eq('agent_id', agentId)
        .order('detected_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching network connections:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  },

  async getEstablishedConnections(agentId: string) {
    try {
      const { data, error } = await supabase
        .from('network_connections')
        .select('*')
        .eq('agent_id', agentId)
        .eq('state', 'ESTABLISHED')
        .order('detected_at', { ascending: false })
        .limit(500);

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching established connections:', err);
      return {
        data: null,
        error: err instanceof Error ? err.message : 'Unknown error'
      };
    }
  }
};
