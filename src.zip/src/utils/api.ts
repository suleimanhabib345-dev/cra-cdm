
import { supabase } from '@/integrations/supabase/client';

// Define types with proper interfaces
export interface DeviceGroup {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
  company_id: string | null;
}

export interface License {
  id: string;
  license_key: string;
  company_id: string;
  volume: number;
  date_created: string;
  expiration_date: string;
  hostname: string | null;
  is_active: boolean;
}

export interface Alert {
  id: string;
  title: string;
  description: string | null;
  severity: string;
  status: string | null;
  created_at: string;
  device_id: string | null;
}

// Define options interfaces
export interface QueryOptions {
  select?: string;
  filter?: string;
  equals?: any;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  range?: [number, number];
  page?: number;
  pageSize?: number;
  table?: string;
}

// Helper function for pagination with count
const paginateWithCount = async (query: any, page: number = 1, pageSize: number = 10) => {
  try {
    // Get count of results
    const countResponse = await query.count();
    if (countResponse.error) throw countResponse.error;
    const count = countResponse.count || 0;
    
    // Calculate offset
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    
    // Get paginated data
    const { data, error } = await query.range(from, to);
    
    if (error) throw error;
    return { data, error: null, loading: false, count };
  } catch (error) {
    console.error('Error in pagination:', error);
    return { data: null, error, loading: false, count: 0 };
  }
};

// API endpoints
export const api = {
  deviceGroups: {
    getAll: async (options: QueryOptions = {}) => {
      try {
        // Get device groups with devices count
        const { data, error } = await supabase
          .from('device_groups')
          .select(`
            *,
            devices:devices(id)
          `)
          .order(options.sortBy || 'name', { ascending: options.sortOrder === 'asc' });
        
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error('Error fetching device groups:', error);
        return { data: null, error, loading: false };
      }
    },
    
    getById: async (id: string, options: QueryOptions = {}) => {
      try {
        const { data, error } = await supabase
          .from('device_groups')
          .select(options.select || '*')
          .eq('id', id)
          .single();
          
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error(`Error fetching device group ${id}:`, error);
        return { data: null, error, loading: false };
      }
    },
    
    create: async (deviceGroup: Partial<DeviceGroup>) => {
      try {
        // Ensure required fields are present
        if (!deviceGroup.name) {
          throw new Error("Device group name is required");
        }
        
        // Explicitly type the device group to match the database schema
        const deviceGroupData = {
          name: deviceGroup.name,
          description: deviceGroup.description || null,
          company_id: deviceGroup.company_id || null
        };
        
        const { data, error } = await supabase
          .from('device_groups')
          .insert(deviceGroupData)
          .select();
          
        if (error) throw error;
        return { data: data[0], error: null, loading: false };
      } catch (error) {
        console.error('Error creating device group:', error);
        return { data: null, error, loading: false };
      }
    },
    
    update: async (id: string, updates: Partial<DeviceGroup>) => {
      try {
        const { data, error } = await supabase
          .from('device_groups')
          .update(updates)
          .eq('id', id)
          .select();
          
        if (error) throw error;
        return { data: data[0], error: null, loading: false };
      } catch (error) {
        console.error(`Error updating device group ${id}:`, error);
        return { data: null, error, loading: false };
      }
    },
    
    delete: async (id: string) => {
      try {
        const { error } = await supabase
          .from('device_groups')
          .delete()
          .eq('id', id);
          
        if (error) throw error;
        return { data: true, error: null, loading: false };
      } catch (error) {
        console.error(`Error deleting device group ${id}:`, error);
        return { data: null, error, loading: false };
      }
    }
  },
  
  vulnerabilities: {
    getAll: async (options: QueryOptions = {}) => {
      try {
        let query = supabase
          .from('vulnerabilities')
          .select(options.select || '*');
        
        if (options.sortBy) {
          query = query.order(options.sortBy, { ascending: options.sortOrder === 'asc' });
        }
        
        if (options.limit) {
          query = query.limit(options.limit);
        }
        
        const { data, error } = await query;
        
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error('Error fetching vulnerabilities:', error);
        return { data: null, error, loading: false };
      }
    },
    
    getById: async (id: string, options: QueryOptions = {}) => {
      try {
        const { data, error } = await supabase
          .from('vulnerabilities')
          .select(options.select || '*')
          .eq('id', id)
          .single();
          
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error(`Error fetching vulnerability ${id}:`, error);
        return { data: null, error, loading: false };
      }
    },
    
    getAffectedDevices: async (vulnerabilityId: string) => {
      try {
        const { data, error } = await supabase
          .from('device_vulnerabilities')
          .select(`
            *,
            device:agents!device_id(*)
          `)
          .eq('vulnerability_id', vulnerabilityId);
          
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error(`Error fetching affected devices for vulnerability ${vulnerabilityId}:`, error);
        return { data: null, error, loading: false };
      }
    }
  },
  
  alerts: {
    getAll: async (options: QueryOptions = {}) => {
      try {
        let query = supabase
          .from('alerts')
          .select(options.select || '*');
        
        if (options.page && options.pageSize) {
          return await paginateWithCount(query, options.page, options.pageSize);
        } else {
          const { data, error } = await query;
          if (error) throw error;
          return { data, error: null, loading: false };
        }
      } catch (error) {
        console.error('Error fetching alerts:', error);
        return { data: null, error, loading: false };
      }
    }
  },
  
  licenses: {
    getAll: async (options: QueryOptions = {}) => {
      try {
        let query = supabase
          .from('licenses')
          .select(`
            *,
            companies(name)
          `);
          
        if (options.sortBy) {
          query = query.order(options.sortBy, { ascending: options.sortOrder === 'asc' });
        }
        
        const { data, error } = await query;
        
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error('Error fetching licenses:', error);
        return { data: null, error, loading: false };
      }
    },
    
    getById: async (id: string, options: QueryOptions = {}) => {
      try {
        const { data, error } = await supabase
          .from('licenses')
          .select(`
            *,
            companies(name)
          `)
          .eq('id', id)
          .single();
          
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error(`Error fetching license ${id}:`, error);
        return { data: null, error, loading: false };
      }
    },
    
    create: async (license: Partial<License>) => {
      try {
        // Ensure required fields
        if (!license.company_id || !license.license_key || !license.volume || !license.expiration_date) {
          throw new Error("Missing required license fields");
        }
        
        // Create a properly typed license object
        const licenseData = {
          company_id: license.company_id,
          license_key: license.license_key,
          volume: license.volume,
          expiration_date: license.expiration_date,
          hostname: license.hostname || null,
          is_active: license.is_active ?? true
        };
        
        const { data, error } = await supabase
          .from('licenses')
          .insert(licenseData)
          .select();
          
        if (error) throw error;
        return { data: data[0], error: null, loading: false };
      } catch (error) {
        console.error('Error creating license:', error);
        return { data: null, error, loading: false };
      }
    },
    
    update: async (id: string, updates: Partial<License>) => {
      try {
        const { data, error } = await supabase
          .from('licenses')
          .update(updates)
          .eq('id', id)
          .select();
          
        if (error) throw error;
        return { data: data[0], error: null, loading: false };
      } catch (error) {
        console.error(`Error updating license ${id}:`, error);
        return { data: null, error, loading: false };
      }
    },
    
    delete: async (id: string) => {
      try {
        const { error } = await supabase
          .from('licenses')
          .delete()
          .eq('id', id);
          
        if (error) throw error;
        return { data: true, error: null, loading: false };
      } catch (error) {
        console.error(`Error deleting license ${id}:`, error);
        return { data: null, error, loading: false };
      }
    }
  },
  
  companies: {
    getAll: async (options: QueryOptions = {}) => {
      try {
        let query = supabase
          .from('companies')
          .select(options.select || '*');
          
        if (options.sortBy) {
          query = query.order(options.sortBy, { ascending: options.sortOrder === 'asc' });
        }
        
        const { data, error } = await query;
        
        if (error) throw error;
        return { data, error: null, loading: false };
      } catch (error) {
        console.error('Error fetching companies:', error);
        return { data: null, error, loading: false };
      }
    }
  }
};
